import React from 'react';
import { FormattedMessage } from 'react-intl';
import { Link as RouterLink } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

// material-ui
// import {
//     Button, Grid, TextField, Stack, InputLabel, Select, MenuItem
//   } from '@material-ui/core';

import { useTheme } from '@material-ui/core/styles';
import { Grid, Stack, Typography, useMediaQuery } from '@material-ui/core';//Divider, 

// project imports
import AuthWrapper1 from '../pages/authentication/AuthWrapper1'
import Logo from 'ui-component/Logo';
import AuthCardWrapper from  '../pages/authentication/AuthCardWrapper'
import ResetPassword from '../pages/authentication/login/resetPassword';


// ================================|| LOGIN MAIN ||================================ //

const Login = () => {
    const theme = useTheme();
    const matchDownSM = useMediaQuery(theme.breakpoints.down('sm'));
    const customization = useSelector((state) => state.customization);

    return (
        <AuthWrapper1>
            <Grid container sx={{ minHeight: '100vh' }} style={{ background: "#F8FAFB" }}>
                <Grid className={customization.locale == "en" ? "loginScreen" : "loginScreenRight"} item xs={12}>
                    {/* <Grid container justifyContent="center" alignItems="center" sx={{ minHeight: 'calc(100vh - 68px)' }}>
                        <Grid item sx={{ m: { xs: 1, sm: 3 }, mb: 0 }}> */}
                    <Grid item container xs={6}>
                        <AuthCardWrapper>
                            <Grid container xs={12} >
                                <Grid item sx={{ mb: 3 }}>
                                    
                                        <Logo />
                                    
                                </Grid>
                                <Grid item xs={12}>
                                    <Grid

                                        direction={matchDownSM ? 'column-reverse' : 'row'}


                                    >
                                        <Grid item>
                                            <Stack spacing={1}>
                                                <Typography
                                                    // color={theme.palette.secondary.main}
                                                    gutterBottom
                                                    variant={matchDownSM ? 'h3' : 'h2'}
                                                >
                                                    {<FormattedMessage id="resetPassword" />}
                                                </Typography>
                                                <Typography style={{marginTop:"0px",marginBottom:"10px"}} variant="caption" fontSize="16px" textAlign={matchDownSM ? 'center' : 'left'}>
                                                {<FormattedMessage id="resetPasswordDescription" />}
                                                </Typography>
                                            </Stack>
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item xs={12}>
                                    <ResetPassword />
                                </Grid>
                            </Grid>
                        </AuthCardWrapper>
                    </Grid>
                    <Grid item container xs={6}>
                    <img className='loginImg' src={process.env.PUBLIC_URL + '/assets/images/login.png'} alt="loginScreen" />
                    <img className={customization.locale == "en" ? "loginLogo" : "loginLogoLeft"} src={process.env.PUBLIC_URL + '/assets/images/loginScreen.png'} alt="loginLogo" />
                    <img className='bottomLogo' src={process.env.PUBLIC_URL + '/assets/images/bottomLogo.png'} alt="loginLogo" />
                    </Grid>


                    {/* </Grid>
                    </Grid> */}
                </Grid>
                {/* <Grid item xs={12} sx={{ m: 3, mt: 1 }}>
                    <AuthFooter />
                </Grid> */}
            </Grid>
        </AuthWrapper1>
    );
};

export default Login;
