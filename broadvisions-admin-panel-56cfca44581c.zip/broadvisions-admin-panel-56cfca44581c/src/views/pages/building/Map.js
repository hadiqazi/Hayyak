import React from 'react'
import MapPicker from 'react-google-map-picker'
import { FormattedMessage } from 'react-intl';
import { useSelector } from 'react-redux';
import CancelIcon from '@mui/icons-material/Cancel';
import {
    Button,
    Grid,
    Typography,
} from '@material-ui/core';
const Map = (props) => {
    const customization = useSelector((state) => state.customization);


    return (
        <>
        <Grid item container xs ={12}>
            <Grid xs ={6}>
            <Typography color="inherit" variant="h3" component="div">
        <FormattedMessage id="yourLocation" /> 
                </Typography>
            </Grid>
            <Grid xs ={6} className='' >
                <CancelIcon className={customization.locale == "en" ? "cancelIcon" : "cancelIconArabic"}  onClick={props.handleClose}/>
                </Grid>
        
        
        </Grid>
   


            <MapPicker defaultLocation={props.defaultLocation}
                zoom={props.zoom}
                mapTypeId="roadmap"
                style={{ height: '600px',width:'600px' }}
                onChangeLocation={props.handleChangeLocation}
                onChangeZoom={props.handleChangeZoom}
                apiKey='AIzaSyDELO-ePSILAjzduuEYxMCFTb2S-s-6DMU'
                 />
            <Button style={{width:"100%"}} className='hayyak_btn' onClick={props.handleClose} fullWidth variant="contained"><FormattedMessage id="confirmLocation" /></Button>

        </>
    );
}

export default Map