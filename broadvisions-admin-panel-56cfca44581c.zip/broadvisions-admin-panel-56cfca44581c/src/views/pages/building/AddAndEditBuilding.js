import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import MobileTimePicker from '@mui/lab/MobileTimePicker';

import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import { Divider } from '@mui/material';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

import Typography from '@mui/material/Typography';
import GpsFixedIcon from '@mui/icons-material/GpsFixed';
import Modal from '@mui/material/Modal';
import moment from 'moment';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { useSelector } from 'react-redux';
import '../../../assets/css/style.css'
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import TimePicker from '@mui/lab/TimePicker';
import SimpleMap from './Map'
import {
  Button, Grid, TextField, Stack
} from '@material-ui/core';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import MainCard from 'ui-component/cards/MainCard';
import { gridSpacing } from 'store/constant';
import AnimateButton from 'ui-component/extended/AnimateButton';
import { useFormik } from 'formik';
import { SNACKBAR_OPEN } from 'store/actions';
import axios from 'axios';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { baseURL, version1, propertyService } from 'defaultValues';
import { FormattedMessage } from 'react-intl';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

const DefaultLocation = { lat: 31.47545251327922, lng: 74.40129815039714 };
const DefaultZoom = 10;

const BuildingEdit = () => {
  const customization = useSelector((state) => state.customization);
  console.log('state', customization.locale)
  const { state } = useLocation();
  const [lastPage, setLastPage] = React.useState(state?.lastPageNo);
  const [open, setOpen] = React.useState(false);
  const { buildingId } = useParams();
  const [valueIn, setValueIn] = React.useState(state ? `${moment(state?.createdAt).locale('en').format("dddd MMM D")}${' '}${state?.checkInTime}` : null);
  const [valueOut, setValueOut] = React.useState(state ? `${moment(state?.createdAt).locale('en').format("dddd MMM D")}${' '}${state?.checkOutTime}` : null);
  const [newValueIn, setNewValueIn] = React.useState(null);
  const [newValueOut, setNewValueOut] = React.useState(null);
  const [english, setEnglish] = React.useState(true);
  const [arabic, setArabic] = React.useState(false);
  const [defaultLocation, setDefaultLocation] = useState(DefaultLocation);
  const [location, setLocation] = useState();
  const [zoom, setZoom] = useState(DefaultZoom);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [errorZipCodeValid, setErrorZipCodeValid] = React.useState(false);
  const [errorValueIn, setErrorValueIn] = React.useState(false);
  const [errorValueOut, setErrorValueOut] = React.useState(false);
  const [errorLocation, setErrorLocation] = React.useState(false);
  const [errorCountry, setErrorCountry] = React.useState(false);
  const [errorBuildingName, setErrorBuildingName] = React.useState(false);
  const [errorBuildingNameArabic, setErrorBuildingNameArabic] = React.useState(false);
  const [errorAddress, setErrorAddress] = React.useState(false);
  const [errorAddressArabic, setErrorAddressArabic] = React.useState(false);
  const [errorCity, setErrorCity] = React.useState(false);
  const [errorCityArabic, setErrorCityArabic] = React.useState(false);
  const [errorState, setErrorState] = React.useState(false);
  const [errorStateArabic, setErrorStateArabic] = React.useState(false);
  const [errorAboutBuilding, setErrorAboutBuilding] = React.useState(false);
  const [errorAboutBuildingArabic, setErrorAboutBuildingArabic] = React.useState(false);
  const [errorZipCode, setErrorZipCode] = React.useState(false);
  const [value, setValue] = React.useState('1');

  const formik = useFormik({
    initialValues: {
      buildingName: state?.name ? state?.name.en : '',
      buildingNameArabic: state?.name ? state?.name.ar : '',
      address: state?.address ? state?.address.en : '',
      addressArabic: state?.address ? state?.address.ar : '',
      city: state?.city ? state?.city.en : '',
      cityArabic: state?.city ? state?.city.ar : '',
      state: state?.state ? state?.state?.en : '',
      stateArabic: state?.state ? state?.state?.ar : '',
      aboutBuilding: state?.description ? state?.description.en : '',
      aboutBuildingArabic: state?.description ? state?.description.ar : '',
      zipCode: state?.zip ? state?.zip : '',
      map: state?.location ? `${state.location[0]}${' '} ${state.location[1]}` : '',
      checkInTime: state?.checkInTime ? state?.checkInTime : '',
      checkOutTime: state?.checkOutTime ? state?.checkOutTime : '',
      country: state?.country ? state.country.en : ''

    },
    enableReinitialize: true,
    onSubmit: values => {
      var letters = /^[0-9]*$/;
      var addressLetters = /^([a-zA-z0-9/\\''(),-\s]{2,255})$/;
      if (
        valueIn == undefined
        || valueOut == undefined
        || (!state && location == undefined)
        || values.country.length === 0
        || values.buildingName.length === 0
        || values.buildingNameArabic.length === 0
        || values.address.length === 0
        || values.addressArabic.length === 0
        || values.city.length === 0
        || values.cityArabic.length === 0
        || values.state.length === 0
        || values.stateArabic.length === 0
        || values.aboutBuilding.length === 0
        || values.aboutBuildingArabic.length === 0
        || values.zipCode.length === 0
        || values.zipCode.length < 5
        || !values.zipCode.match("^[0-9]*$")
      ) {
        if (values.zipCode.length === 0 || values.zipCode.length < 5 || (!values.zipCode.match("^[0-9]*$"))) {

          if (values.zipCode.length === 0) {
            setErrorZipCode(<FormattedMessage id="zipCodeRequired" />)
          }
          else if (values.zipCode.length < 5) {
            setErrorZipCode(<FormattedMessage id="zipCodeLengthRequired" />)

          }

          else if (!values.zipCode.match("^[0-9]*$")) {
            setErrorZipCode(<FormattedMessage id="correctZip" />)
          }

        }
        else {
          setErrorZipCode(false)
        }
        if (valueIn == undefined || valueIn == "") {
          setValueIn("")
          setErrorValueIn(<FormattedMessage id="selectCheckInTime" />)
        }
        else {
          setErrorValueIn(false)
        }
        if (valueOut == undefined || valueOut == "") {
          setValueOut("")
          setErrorValueOut(<FormattedMessage id="selectCheckOutTime" />)
        }
        else {
          setErrorValueOut(false)
        }
        if (!state && location == undefined) {
          setErrorLocation(<FormattedMessage id="selectLocation" />)
        }
        else {
          setErrorLocation(false)
        }
        if (values.country.length === 0) {
          setErrorCountry(<FormattedMessage id="selectCountry" />)
        }
        else {
          setErrorCountry(false)
        }
        if (values.buildingName || (values.buildingName.match(letters))) {
          if (values.buildingName.length === 0) {
            setErrorBuildingName(<FormattedMessage id="buildingRequired" />)
          }
          else if ((values.buildingName.match(letters))) {
            setErrorBuildingName(<FormattedMessage id="validBuildingRequired" />)
          }
          else {
            setErrorBuildingName(false)
          }
        }
        if (values.buildingNameArabic || (values.buildingNameArabic.match(letters))) {
          if (values.buildingNameArabic.length === 0) {
            setErrorBuildingNameArabic(<FormattedMessage id="buildingRequired" />)
          }
          else if ((values.buildingNameArabic.match(letters))) {
            setErrorBuildingNameArabic(<FormattedMessage id="validBuildingRequired" />)
          }
          else {
            setErrorBuildingNameArabic(false)
          }
        }
        if (values.address || !(values.address.match(addressLetters))) {
          if (values.address.length === 0) {
            setErrorAddress(<FormattedMessage id="addressRequired" />)
          }
          else if (!(values.address.match(addressLetters))) {
            setErrorAddress(<FormattedMessage id="validAddressRequired" />)
          }
          else {
            setErrorAddress(false)
          }
        }
        if (values.addressArabic || !(values.addressArabic.match(addressLetters))) {
          if (values.addressArabic.length === 0) {
            setErrorAddressArabic(<FormattedMessage id="addressRequired" />)
          }
          else if (!(values.addressArabic.match(addressLetters))) {
            setErrorAddressArabic(<FormattedMessage id="validAddressRequired" />)
          }
          else {
            setErrorAddressArabic(false)
          }
        }
        if (values.city || (values.city.match(letters))) {
          if (values.city.length === 0) {
            setErrorCity(<FormattedMessage id="cityRequired" />)
          }
          else if ((values.city.match(letters))) {
            setErrorCity(<FormattedMessage id="validCityRequired" />)
          }
          else {
            setErrorCity(false)
          }
        }
        if (values.cityArabic || (values.cityArabic.match(letters))) {
          if (values.cityArabic.length === 0) {
            setErrorCityArabic(<FormattedMessage id="cityRequired" />)
          }
          else if ((values.cityArabic.match(letters))) {
            setErrorCityArabic(<FormattedMessage id="validCityRequired" />)
          }
          else {
            setErrorCityArabic(false)
          }
        }
        if (values.state || (values.state.match(letters))) {
          if (values.state.length === 0) {
            setErrorState(<FormattedMessage id="stateRequired" />)
          }
          else if ((values.state.match(letters))) {
            setErrorState(<FormattedMessage id="validStateRequired" />)
          }
          else {
            setErrorState(false)
          }
        }
        if (values.stateArabic || (values.stateArabic.match(letters))) {
          if (values.stateArabic.length === 0) {
            setErrorStateArabic(<FormattedMessage id="stateRequired" />)
          }
          else if ((values.stateArabic.match(letters))) {
            setErrorStateArabic(<FormattedMessage id="validStateRequired" />)
          }
          else {
            setErrorStateArabic(false)
          }
        }
        if (values.aboutBuilding.length === 0) {
          setErrorAboutBuilding(<FormattedMessage id="descriptionRequired" />)
        }
        else {
          setErrorAboutBuilding(false)
        }
        if (values.aboutBuildingArabic.length === 0) {
          setErrorAboutBuildingArabic(<FormattedMessage id="descriptionRequired" />)
        }
        else {
          setErrorAboutBuildingArabic(false)
        }

        dispatch({
          type: SNACKBAR_OPEN,
          open: true,
          message: <FormattedMessage id="allFields" />,
          variant: 'alert',
          alertSeverity: 'error'
        });
        return
      }

      if (state) {
        let data = createUpdatedObj(values)
        axios({
          method: 'put',
          url: `${baseURL}/${propertyService}/${version1}/building/${buildingId}`,
          data: data,

        }).then(res => {
          if (res.status === 200) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: <FormattedMessage id="buildingUpdated" />,
              variant: 'alert',
              alertSeverity: 'success'
            });
            navigate('/buildings', { state: lastPage });
            return;
          }
        }).catch((error) => {
          if (error.response && error.response.data.status && error.response.data.message) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: error.response.data.message,
              variant: 'alert',
              alertSeverity: 'error'
            });
            return;
          }
          dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: <FormattedMessage id="errorMessage" />,
            variant: 'alert',
            alertSeverity: 'error'
          });
          return;
        })

      }
      else {
        let obj = createObj(values)

        axios({
          method: 'post',
          url: `${baseURL}/${propertyService}/${version1}/building`,
          data: obj,
        }).then(res => {
          if (res.status === 201) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: <FormattedMessage id="buildingSaved" />,
              variant: 'alert',
              alertSeverity: 'success'
            });

            navigate('/buildings');
            return;
          }
        }).catch((error) => {
          if (error.response && error.response.data.status && error.response.data.message) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: error.response.data.message,
              variant: 'alert',
              alertSeverity: 'error'
            });
            return;
          }
          dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: <FormattedMessage id="errorMessage" />,
            variant: 'alert',
            alertSeverity: 'error'
          });
          return;
        })
      }
    }
  });
  const createUpdatedObj = (values) => {
    let obj = {
      name: {
        en: values.buildingName,
        ar: values.buildingNameArabic
      },
      description: {
        en: values.aboutBuilding,
        ar: values.aboutBuildingArabic
      },
      location:
      {
        coordinates: location == undefined ? [state.location?.coordinates[0], state.location?.coordinates[1]] : [location.lng, location.lat]
      },
      address: {
        en: values.address,
        ar: values.addressArabic
      },
      city: {
        en: values.city,
        ar: values.cityArabic
      },
      state: {
        en: values.state,
        ar: values.stateArabic
      },
      country: {
        en: state ? state.country.en : values.country,
        ar: state ? state.country.ar : values.country,
      },
      zip: values.zipCode,
      checkInTime: newValueIn ? `${newValueIn.getHours() <= 9 ? "0" + newValueIn.getHours() : newValueIn.getHours()}${':'}${newValueIn.getMinutes() <= 9 ? "0" + newValueIn.getMinutes() : newValueIn.getMinutes()}` : state.checkInTime,
      checkOutTime: newValueOut ? `${newValueOut.getHours() <= 9 ? "0" + newValueOut.getHours() : newValueOut.getHours()}${':'}${newValueOut.getMinutes() <= 9 ? "0" + newValueOut.getMinutes() : newValueOut.getMinutes()}` : state.checkOutTime,

    }
    return obj;
  }
  const createObj = (values) => {
    let obj = {
      name: {
        en: values.buildingName,
        ar: values.buildingNameArabic
      },
      description: {
        en: values.aboutBuilding,
        ar: values.aboutBuildingArabic
      },
      location:
      {
        coordinates: location == undefined ? [state.location?.coordinates[0], state.location?.coordinates[1]] : [location.lng, location.lat]
      },
      address: {
        en: values.address,
        ar: values.addressArabic
      },
      city: {
        en: values.city,
        ar: values.cityArabic
      },
      state: {
        en: values.state,
        ar: values.stateArabic
      },
      country: {
        en: state ? state.country.en : values.country,
        ar: state ? state.country.ar : values.country,
      },
      zip: values.zipCode,
      checkInTime: `${valueIn.getHours() <= 9 ? "0" + valueIn.getHours() : valueIn.getHours()}${':'}${valueIn.getMinutes() <= 9 ? "0" + valueIn.getMinutes() : valueIn.getMinutes()}`,
      checkOutTime: `${valueOut.getHours() <= 9 ? "0" + valueOut.getHours() : valueOut.getHours()}${':'}${valueOut.getMinutes() <= 9 ? "0" + valueOut.getMinutes() : valueOut.getMinutes()}`
    }
    return obj;
  }
  const handleChangeLocation = (lat, lng) => {
    setLocation({ lat: lat, lng: lng });
    setDefaultLocation({ lat: lat, lng: lng });
  }

  const handleChangeZoom = (newZoom) => {
    setZoom(newZoom);
  }

  const handleOpen = () => {
    setOpen(true);
  }
  const handleClose = () => {
    setOpen(false);
  }
  const handleChangeTab = (event, newValue) => {

    setValue(newValue);
    if (newValue === '1') {
      setArabic(false)
      setEnglish(true)
    }
    else {
      setArabic(true)
      setEnglish(false)
    }
  };


  const handleArabic = () => {
    setArabic(true)
    setEnglish(false)
  }
  const handleEnglish = () => {
    setArabic(false)
    setEnglish(true)
  }
  const handleCheckInTime = (newValue) => {

    setValueIn(newValue)
    setNewValueIn(newValue)
  }
  const handleCheckOutTime = (newValue) => {

    setValueOut(newValue)
    setNewValueOut(newValue)
  }
  // useEffect(() => {
 
  //   return () => {

  //   }
  // }, [])


  return (
    <MainCard>
      <div onClick={() => navigate(`../../../buildings`, { state: lastPage })} className={customization.locale == "en" ? "backDiv" : "backDivAr"}>
        {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
        {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
        <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
      </div>

      <Typography style={{ marginBottom: "30px" }} variant="h3" gutterBottom component="div">
        {state ? <FormattedMessage id="building-page-title-update" /> : <FormattedMessage id="buildingNew" />}
      </Typography>
      <div className='formBuilding'>
        <Box sx={{ width: '100%', typography: 'body1' }}>
          <TabContext value={value}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <TabList onChange={handleChangeTab} aria-label="lab API tabs example">
                <Tab label={<FormattedMessage id="englishTab" />} value="1" />
                <Tab label={<FormattedMessage id="arabicTab" />} value="2" />
                {/* <Tab label="Item Three" value="3" /> */}
              </TabList>
            </Box>
            {/* <TabPanel value="1">Item One</TabPanel>
        <TabPanel value="2">Item Two</TabPanel>
        <TabPanel value="3">Item Three</TabPanel> */}
          </TabContext>
        </Box>
        <Divider className='dividers'></Divider>
        {/*     
      <Stack style={{ paddingBottom: "20px", paddingLeft: "20px" }} spacing={2} direction="row">
        <Button onClick={handleEnglish} variant={english ? "contained" : "outlined"}> <FormattedMessage id="english" /></Button>
        <Button onClick={handleArabic} variant={arabic ? "contained" : "outlined"}> <FormattedMessage id="arabic" /></Button>
      </Stack> */}
        <form onSubmit={formik.handleSubmit}>


          {english && <>
            <Grid className="left" item xs={12}>
              <TextField

                fullWidth
                id="buildingName"
                name="buildingName"
                label={<FormattedMessage id="buildingName" />}
                placeholder={customization.locale == "en" ? "Building Name" : "اسم المبنى"}
                defaultValue={formik.values.buildingName}
                onChange={formik.handleChange}
                error={errorBuildingName}
                helperText={errorBuildingName}
                InputLabelProps={{
                  shrink: true
                }}
              />
            </Grid>
            <Grid className="left" item xs={12}>
              <TextField
                fullWidth

                id="address"
                name="address"
                label={<FormattedMessage id="address" />}
                placeholder={customization.locale == "en" ? "Address" : "عنوان"}
                defaultValue={formik.values.address}
                onChange={formik.handleChange}
                error={errorAddress}
                helperText={errorAddress}
                InputLabelProps={{
                  shrink: true
                }}
              />
            </Grid>
            <Grid item container xs={12}>
              <Grid className="left" item xs={5.65}>
                <TextField
                  fullWidth
                  id="city"

                  name="city"
                  label={<FormattedMessage id="city" />}
                  placeholder={customization.locale == "en" ? "City" : "مدينة"}
                  defaultValue={formik.values.city}
                  onChange={formik.handleChange}
                  error={errorCity}
                  helperText={errorCity}
                  InputLabelProps={{
                    shrink: true
                  }}
                />
              </Grid>
              <Grid className="left" item xs={5.65}>
                <TextField
                  fullWidth
                  id="state"

                  name="state"
                  label={<FormattedMessage id="state" />}
                  placeholder={customization.locale == "en" ? "State" : "ولاية"}
                  defaultValue={formik.values.state}
                  onChange={formik.handleChange}
                  error={errorState}
                  helperText={errorState}
                  InputLabelProps={{
                    shrink: true
                  }}
                />
              </Grid>
            </Grid>

          </>}

          {arabic && <> <Grid className="left" item xs={12}>
            <TextField
              fullWidth
              id="buildingNameArabic"
              name="buildingNameArabic"
              label={<FormattedMessage id="buildingName" />}
              placeholder={customization.locale == "en" ? "Building Name" : "اسم المبنى"}
              defaultValue={formik.values.buildingNameArabic}
              onChange={formik.handleChange}
              error={errorBuildingNameArabic}
              helperText={errorBuildingNameArabic}
              InputLabelProps={{
                shrink: true
              }}
            />
          </Grid>
            <Grid className="left" item xs={12}>
              <TextField
                fullWidth
                id="addressArabic"
                name="addressArabic"
                label={<FormattedMessage id="address" />}
                placeholder={customization.locale == "en" ? "Address" : "عنوان"}
                defaultValue={formik.values.addressArabic}
                onChange={formik.handleChange}
                error={errorAddressArabic}
                helperText={errorAddressArabic}
                InputLabelProps={{
                  shrink: true
                }}
              />
            </Grid>
            <Grid item container xs={12}>
              <Grid className="left" item xs={5.65}>
                <TextField
                  fullWidth
                  id="cityArabic"
                  name="cityArabic"
                  label={<FormattedMessage id="city" />}
                  placeholder={customization.locale == "en" ? "City" : "مدينة"}
                  defaultValue={formik.values.cityArabic}
                  onChange={formik.handleChange}
                  error={errorCityArabic}
                  helperText={errorCityArabic}
                  InputLabelProps={{
                    shrink: true
                  }}
                />
              </Grid>
              <Grid className="left" item xs={5.65}>
                <TextField
                  fullWidth
                  id="stateArabic"

                  name="stateArabic"
                  label={<FormattedMessage id="state" />}
                  placeholder={customization.locale == "en" ? "State" : "ولاية"}
                  defaultValue={formik.values.stateArabic}
                  onChange={formik.handleChange}
                  error={errorStateArabic}
                  helperText={errorStateArabic}
                  InputLabelProps={{
                    shrink: true
                  }}
                />
              </Grid>


            </Grid>  </>}

          <Grid item container>  <Grid className="left" item xs={5.65}>
            <TextField
              fullWidth
              id="zipCode"
              name="zipCode"

              label={<FormattedMessage id="zipCode" />}
              placeholder={customization.locale == "en" ? "Zip Code" : "الرمز البريدي"}
              defaultValue={formik.values.zipCode}
              onChange={formik.handleChange}
              error={errorZipCode}
              helperText={errorZipCode}
              InputLabelProps={{
                shrink: true
              }}
            />
          </Grid>
          </Grid>

          {english && <Grid className="left" item xs={12}>
            <TextField
              id="outlined-multiline-static"
              label={<FormattedMessage id="aboutBuilding" />}

              rows={4}
              fullWidth
              name="aboutBuilding"
              placeholder={customization.locale == "en" ? "About Building" : "حول البناء"}
              defaultValue={formik.values.aboutBuilding}
              onChange={formik.handleChange}
              error={errorAboutBuilding}
              helperText={errorAboutBuilding}
              InputLabelProps={{
                shrink: true
              }}
            />
          </Grid>}

          {arabic && <Grid className="left" item xs={12}>
            <TextField
              id="outlined-multiline-static"
              label={<FormattedMessage id="aboutBuilding" />}

              rows={4}
              fullWidth
              name="aboutBuildingArabic"
              placeholder={customization.locale == "en" ? "About Building" : "حول البناء"}
              defaultValue={formik.values.aboutBuildingArabic}
              onChange={formik.handleChange}
              error={errorAboutBuildingArabic}
              helperText={errorAboutBuildingArabic}
              InputLabelProps={{
                shrink: true
              }}
            />
          </Grid>}
        </form>
      </div>

      <form onSubmit={formik.handleSubmit}>

        <Grid item xs={8.3} style={{ paddingTop: "10px" }}>
          <Grid item container spacing={2}>
            <Grid item xs={5.8}>

              <LocalizationProvider dateAdapter={AdapterDateFns}>


                <MobileTimePicker
                  label={<FormattedMessage id="checkin" />}
                  value={valueIn}
                  error={errorValueIn}
                  helperText={errorValueIn}
                  onChange={(newValue) => { handleCheckInTime(newValue) }}
                  renderInput={(params) => <TextField {...params} />}
                />
              </LocalizationProvider>
              {errorValueIn && <Typography className="validationError" variant="body1" gutterBottom >{errorValueIn}</Typography>}
            </Grid>
            <Grid item xs={5.8}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <MobileTimePicker
                  label={<FormattedMessage id="checkout" />}
                  value={valueOut}
                  error={errorValueOut}
                  helperText={errorValueOut}
                  onChange={(newValue) => { handleCheckOutTime(newValue) }}
                  renderInput={(params) => <TextField {...params} />}
                />
              </LocalizationProvider>
              {errorValueOut && <Typography className="validationError" variant="body1" gutterBottom >{errorValueOut}</Typography>}
            </Grid>
            <Grid style={{ paddingTop: "30px" }} item xs={5.8}>
              {state ?
                <div className='locationInput'>
                  <TextField
                    fullWidth
                    onClick={handleOpen} id="map" label={<FormattedMessage id="location" />}
                    value={location ? `${location != undefined ? location?.lng : ""}${' '} ${location != undefined ? location?.lat : ""}` : `${state?.location?.coordinates[0]}${' '} ${state?.location?.coordinates[1]}`}
                    variant="outlined" />

                  <LocationOnIcon className={customization.locale == "en" ? "locationLeft" : "locationLeftArabic"} />
                  <GpsFixedIcon className={customization.locale == "en" ? "locationRight" : "locationRightArabic"} />
                  <Modal
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                  >
                    <Box sx={style}>
                      <SimpleMap
                        handleClose={handleClose}
                        handleChangeLocation={handleChangeLocation}
                        handleChangeZoom={handleChangeZoom}
                        zoom={zoom}
                        defaultLocation={defaultLocation}
                      />
                    </Box>
                  </Modal>
                </div>

                : <div className='locationInput'>
                  <TextField
                    fullWidth
                    error={errorLocation}
                    helperText={errorLocation}

                    onClick={handleOpen} id="map" label={<FormattedMessage id="location" />}
                    value={state ? formik.values.map : `${location != undefined ? location.lng : ""}${' '} ${location != undefined ? location.lat : ""}`}
                    variant="outlined" />
                  <LocationOnIcon className={!errorLocation ? customization.locale == "en" ? "locationLeft" : "locationLeftArabic" : customization.locale == "en" ? "locationLeftCondition" : "locationLeftArabicCondition"} />
                  <GpsFixedIcon className={!errorLocation ? customization.locale == "en" ? "locationRight" : "locationRightArabic" : customization.locale == "en" ? "locationRightCondition" : "locationRightArabicCondition"} />

                  <Modal
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                  >
                    <Box sx={style}>
                      <SimpleMap
                        handleClose={handleClose}
                        handleChangeLocation={handleChangeLocation}
                        handleChangeZoom={handleChangeZoom}
                        zoom={zoom}
                        defaultLocation={defaultLocation}
                      />
                    </Box>
                  </Modal>
                </div>}
            </Grid>

            {/* <FormControl  > */}
            <Grid item xs={5.8} >
              <FormControl fullWidth style={{ marginTop: "13px" }} >
                <InputLabel fullWidth className={errorCountry ? "validation dropdown_font" : "dropdown_font"} id="demo-simple-select-label"><FormattedMessage id="country" /></InputLabel>
                <Select
                  error={errorCountry}
                  helperText={errorCountry}
                  labelId="country"
                  id="country"
                  name="country"
                  defaultValue={formik.values.country}
                  value={formik.values.country}
                  onChange={formik.handleChange}
                  label={<FormattedMessage id="country" />}
                >
                  <MenuItem value="Saudi Arabia"><FormattedMessage id="Saudi" /></MenuItem>
                </Select>

              </FormControl >
              {errorCountry && <Typography className="validationError" variant="body1" gutterBottom >{errorCountry}</Typography>}
            </Grid>
            {/*  */}


          </Grid>
          <Grid item xs={12}>
            <Stack direction="row">
              <AnimateButton>
                <Button className='hayyak_btn' style={{ marginRight: "10px" }} variant="contained" type="submit">
                  <FormattedMessage id="save" />
                </Button>
                <Button onClick={() => navigate(`../../../buildings`, { state: lastPage })} className='cancel_btn'  >
                  <FormattedMessage id="cancel" />
                </Button>
              </AnimateButton>
            </Stack>
          </Grid>
        </Grid>
      </form>
    </MainCard>
  )
};

export default BuildingEdit;
