import { FormattedMessage } from 'react-intl';
import 'react-confirm-alert/src/react-confirm-alert.css';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import { useDispatch, useSelector } from 'react-redux';
import useAuth from 'hooks/useAuth';
import { SNACKBAR_OPEN } from 'store/actions';
import Select from '@mui/material/Select';
import PropTypes from 'prop-types';
import Rating from '@mui/material/Rating';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { baseURL, version1, propertyService } from 'defaultValues';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import { Divider } from '@mui/material';
import { makeStyles, useTheme } from '@material-ui/styles';
import '../../../assets/css/style.css'
import {
    CardContent,
    Grid,
    IconButton,
    TableCell,
    TableHead,
    TablePagination,
    TableRow,
    TableSortLabel,
    Toolbar,
    Tooltip,
    Typography,
} from '@material-ui/core';
import { visuallyHidden } from '@material-ui/utils';
import { useNavigate, useLocation } from 'react-router-dom';
import Loader from 'ui-component/Loader';
import clsx from 'clsx';
import MainCard from 'ui-component/cards/MainCard';
import DeleteIcon from '@material-ui/icons/Delete';
import SubCard from 'ui-component/cards/SubCard';


// tableheader options
const headCells = [
    {
        id: 'bookingId',
        numeric: false,
        label: <FormattedMessage id="bookingId" />,
        align: 'left'
    },
    {
        id: 'property',
        numeric: false,
        label: <FormattedMessage id="property" />,
        align: 'left'
    },
    {
        id: 'checkIn',
        numeric: false,
        label: <FormattedMessage id="checkIn" />,
        align: 'left'
    },
    {
        id: 'checkOut',
        numeric: false,
        label: <FormattedMessage id="checkOut" />,
        align: 'left'
    },
    {
        id: 'bookedBy',
        numeric: false,
        label: <FormattedMessage id="bookedBy" />,
        align: 'left'
    },
    {
        id: 'noOfRooms',
        numeric: false,
        label: <FormattedMessage id="noOfRooms" />,
        align: 'left'
    }
];

// style constant
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    paper: {
        width: '100%',
        marginBottom: theme.spacing(2)
    },
    table: {
        minWidth: 750
    },
    sortSpan: visuallyHidden
}));

const useToolbarStyles = makeStyles((theme) => ({
    root: {
        padding: 0,
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(1)
    },
    highlight: {
        color: theme.palette.secondary.main
    },
    title: {
        flex: '1 1 100%'
    }
}));

// ===========================|| TABLE HEADER ||=========================== //

function EnhancedTableHead({ classes, onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort, selected }) {
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow>
                {numSelected <= 0 &&
                    headCells.map((headCell) => (
                        <TableCell
                            key={headCell.id}
                            align={headCell.align}
                            padding={headCell.disablePadding ? 'none' : 'normal'}
                            sortDirection={orderBy === headCell.id ? order : false}
                        >
                            <TableSortLabel
                                disabled
                                active={orderBy === headCell.id}
                                direction={orderBy === headCell.id ? order : 'asc'}
                                onClick={createSortHandler(headCell.id)}
                            >
                                {headCell.label}
                                {orderBy === headCell.id ? (
                                    <span className={classes.sortSpan}>{order === 'desc' ? 'sorted descending' : 'sorted ascending'}</span>
                                ) : null}
                            </TableSortLabel>
                        </TableCell>
                    ))}
                {numSelected <= 0 && (
                    <TableCell sortDirection={false} align="center" sx={{ pr: 3 }}>
                        <FormattedMessage id="actions" />
                    </TableCell>
                )}
            </TableRow>
        </TableHead>
    );
}

EnhancedTableHead.propTypes = {
    selected: PropTypes.array,
    classes: PropTypes.object.isRequired,
    numSelected: PropTypes.number.isRequired,
    onRequestSort: PropTypes.func.isRequired,
    onSelectAllClick: PropTypes.func.isRequired,
    order: PropTypes.oneOf(['asc', 'desc']).isRequired,
    orderBy: PropTypes.string.isRequired,
    rowCount: PropTypes.number.isRequired
};

// ===========================|| TABLE HEADER TOOLBAR ||=========================== //

const EnhancedTableToolbar = (props) => {
    const classes = useToolbarStyles();
    const { numSelected } = props;

    return (
        <Toolbar
            className={clsx(classes.root, {
                [classes.highlight]: numSelected > 0
            })}
        >
            {numSelected > 0 ? (
                <Typography className={classes.title} color="inherit" variant="h4" component="div">
                    {numSelected} Selected
                </Typography>
            ) : (
                <Typography className={classes.title} variant="h6" id="tableTitle" component="div">
                    Nutrition
                </Typography>
            )}

            {numSelected > 0 && (
                <Tooltip title="Delete">
                    <IconButton>
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </Tooltip>
            )}
        </Toolbar>
    );
};

EnhancedTableToolbar.propTypes = {
    numSelected: PropTypes.number.isRequired
};

// ===========================|| CUSTOMER LIST ||=========================== //
const ReviewsListing = () => {

    const { state } = useLocation();
    const { checkPermission } = useAuth();
    const classes = useStyles();
    const theme = useTheme();
    const navigate = useNavigate();
    const customization = useSelector((state) => state.customization);
    const [buildings, setBuildings] = useState([]);
    const [propertiesList, setPropertiesList] = useState([]);
    const [selectedPropertiesList, setSelectedPropertiesList] = React.useState('');
    const dispatch = useDispatch();
    const [noData, setNoData] = useState(false);
    const [visitDropdowns, setVisitDropdowns] = useState(false);
    const [selectedBuilding, setSelectedBuilding] = React.useState('');
    const [page, setPage] = useState(0);
    const [objectData, setObjectData] = useState({ status: "PENDING" });
    const [bookingsList, setBookingsList] = useState([]);
    const [pagination, setPagination] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
        setNoData(false)
        setIsLoading(true)
        setPage(0)
        setValue(newValue);
        loadStatus(newValue);
    };
    const loadStatus = (newValue) => {
        let obj = null
        if (newValue === "1") {
            obj = { status: "PENDING" }
            setObjectData(obj)
            if (state) {
                obj = {
                    status: "PENDING",
                    buildingId: state.building._id,
                    propertyId: state._id
                }
                setObjectData(obj)
            }

            else if (!state && selectedBuilding && selectedPropertiesList === '') {
                obj = {
                    status: "PENDING",
                    buildingId: selectedBuilding,
                }
                setObjectData(obj)
            }
            else if (!state && selectedBuilding && selectedPropertiesList) {
                obj = {
                    status: "PENDING",
                    buildingId: selectedBuilding,
                    propertyId: selectedPropertiesList
                }
                setObjectData(obj)
            }
            setObjectData({ status: "PENDING" })
        }
        else if (newValue === "2") {
            obj = { status: "ACCEPT" }
            setObjectData(obj)
            if (state) {
                obj = {
                    status: "ACCEPT",
                    buildingId: state.building._id,
                    propertyId: state._id
                }
                setObjectData(obj)
            }
            else if (!state && selectedBuilding && selectedPropertiesList === '') {
                obj = {
                    status: "ACCEPT",
                    buildingId: selectedBuilding,
                }
                setObjectData(obj)
            }
            else if (!state && selectedBuilding && selectedPropertiesList) {
                obj = {
                    status: "ACCEPT",
                    buildingId: selectedBuilding,
                    propertyId: selectedPropertiesList
                }
                setObjectData(obj)
            }
            setObjectData({ status: "ACCEPT" })
        }
        else if (newValue === "3") {
            obj = { status: "REJECT" }
            setObjectData(obj)
            if (state) {
                obj = {
                    status: "REJECT",
                    buildingId: state.building._id,
                    propertyId: state._id
                }
                setObjectData(obj)
            }
            else if (!state && selectedBuilding && selectedPropertiesList === '') {
                obj = {
                    status: "REJECT",
                    buildingId: selectedBuilding,
                }
                setObjectData(obj)
            }
            else if (!state && selectedBuilding && selectedPropertiesList) {
                obj = {
                    status: "REJECT",
                    buildingId: selectedBuilding,
                    propertyId: selectedPropertiesList
                }
                setObjectData(obj)
            }
            setObjectData({ status: "REJECT" })
        }
    }
    const loadPropertiesData = (id) => {
        axios({
            method: 'get',
            url: `${baseURL}/${propertyService}/${version1}/property?buildingId=${id}`,
        }).then(res => {
            setPropertiesList(res.data.properties)
            setIsLoading(false)
        }).catch(err => {
            console.error(err);
            setIsLoading(false);
        });
    }
    const handleChangeBuilding = (event) => {
        setVisitDropdowns(true)
        setSelectedBuilding(event.target.value);
        if (event.target.value === "") {
            setSelectedPropertiesList('')
        }
        if (event.target.value) {
            let data = {
                status: objectData.status,
                buildingId: event.target.value
            }
            setObjectData(data)
            loadPropertiesData(event.target.value)
        }
    };
    useEffect(() => {
        setIsLoading(true)
        if (state === null) {
            handleChange('', '1')
            loadFilterData()
            setSelectedBuilding('');
            setSelectedPropertiesList('');
        }

        loadBuildingData();
    }, [state]);

    useEffect(() => {
        setIsLoading(true)
        loadFilterData();
        loadBuildingData();
    }, [objectData, selectedBuilding, selectedPropertiesList, page]);



    const loadFilterData = () => {
        let filter
        let pageNo = page
        if (state) {
            loadPropertiesData(state.building._id)
            setSelectedBuilding(state.building._id)
            setSelectedPropertiesList(state._id)

            filter = {
                status: objectData.status,
                buildingId: state.building._id,
                propertyId: state._id
            }
        }
       if (selectedBuilding && !selectedPropertiesList ) {
            filter = {
                status: objectData.status,
                buildingId: selectedBuilding,
            
            }
        }
         if (selectedBuilding && selectedPropertiesList) {
            filter = {
                status: objectData.status,
                buildingId: selectedBuilding,
                propertyId: selectedPropertiesList
            }
        }

    if (!(state) && selectedBuilding === "" && selectedPropertiesList === "") {
        filter = {
            status: objectData.status,
        }
    }
    axios({
        method: 'post',
        url: `${baseURL}/${propertyService}/${version1}/rating/filter?page=${++pageNo}`,
        data: filter,
    }).then(res => {
        setBookingsList(res.data.ratings)
        setPagination(res.data.pagination)
        setIsLoading(false)
    }).catch(err => {
        console.error(err);
        setIsLoading(false);
    });
}

const handleChangeProperty = (event) => {
    setVisitDropdowns(true)
    setSelectedPropertiesList(event.target.value);
    if (event.target.value) {
        let filter = {
            status: objectData.status,
            buildingId: selectedBuilding,
            propertyId: event.target.value
        }
        setObjectData(filter)
    }
};
const handleAccept = (id) => {
    let accept = true
    let obj = {
        status: "ACCEPT"
    }
    callStatus(obj, id, accept)
}
const handleReject = (id) => {
    let accept = false
    let obj = {
        status: "REJECT"
    }
    callStatus(obj, id, accept)
}
const callStatus = (obj, id, accept) => {
    axios({
        method: 'post',
        url: `${baseURL}/${propertyService}/${version1}/rating/status?id=${id}`,
        data: obj,
    }).then(res => {
        if (res.status === 200) {

            dispatch({
                type: SNACKBAR_OPEN,
                open: true,
                message: accept ? <FormattedMessage id="acceptedReview" /> : <FormattedMessage id="rejectedReview" />,
                variant: 'alert',
                alertSeverity: 'success'
            });
            loadFilterData()
            return;
        }
    }).catch((error) => {
        console.error(error.response)
        if (error.response && error.response.data.status && error.response.data.message) {
            dispatch({
                type: SNACKBAR_OPEN,
                open: true,
                message: error.response.data.message,
                variant: 'alert',
                alertSeverity: 'error'
            });
            return;
        }
        dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: 'Error sending request.',
            variant: 'alert',
            alertSeverity: 'error'
        });
        return;
    })
}

const handleChangePage = (event, newPage) => {

    setIsLoading(true)
    setPage(newPage)
    setIsLoading(false)
};
const loadBuildingData = () => {
    axios({
        method: 'get',
        url: `${baseURL}/${propertyService}/${version1}/building`,
    }).then(res => {
        setBuildings(res.data.buildings)
        setIsLoading(false)
    }).catch(err => {
        console.error(err);
        setIsLoading(false);
    });
}

if (isLoading) {
    return <Loader />;
}

return (
    <>
        <MainCard content={false}>
            <CardContent>
                <Grid item xs={12} container spacing={2}>
                    <Grid item xs={12}>
                        <Typography style={{ marginBottom: "0px" }} variant="h3" gutterBottom component="div">
                            <FormattedMessage id="reviews" />
                        </Typography>
                    </Grid>

                </Grid>
                <Grid item container xs={12}>
                    <Grid className='dropList' item container xs={6} style={{ marginTop: "15px", height: "50px" }} >

                        <Box sx={{ width: '100%', typography: 'body1' }}>
                            <TabContext value={value}>
                                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                                    <TabList onChange={handleChange} aria-label="lab API tabs example">
                                        <Tab label={<FormattedMessage id="pending" />} value="1" />
                                        <Tab label={<FormattedMessage id="published" />} value="2" />
                                        <Tab label={<FormattedMessage id="rejected" />} value="3" />
                                    </TabList>
                                </Box>
                            </TabContext>
                        </Box>
                    </Grid>
                    <Grid className='drops' item xs={6} style={{ float: "right", display: "flex" }}>
                        <Grid item xs={6}>
                            <FormControl sx={{ m: 1, width: 300 }}>
                                <InputLabel id="demo-multiple-name-labels"> <FormattedMessage id="building" /></InputLabel>
                                <Select
                                    disabled={state ? true : false}
                                    labelId="demo-multiple-name-label"
                                    id="demo-multiple-name-property"
                                    value={selectedBuilding}
                                    onChange={handleChangeBuilding}
                                    input={<OutlinedInput label={<FormattedMessage id="building" />} />}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    {buildings.map((type) => (
                                        <MenuItem
                                            key={type._id}
                                            value={type._id}
                                        >
                                            {type.name[customization.locale ? customization.locale : "en"]}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={6}>
                            <FormControl sx={{ m: 1, width: 300 }}>
                                <InputLabel id="demo-multiple-name-label"><FormattedMessage id="property" /></InputLabel>
                                <Select
                                    disabled={state ? true : false}
                                    labelId="demo-multiple-name-label"
                                    id="demo-multiple-name-property"
                                    value={selectedPropertiesList}
                                    onChange={handleChangeProperty}
                                    input={<OutlinedInput label={<FormattedMessage id="property" />} />}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    {propertiesList.map((type) => (
                                        <MenuItem
                                            key={type._id}
                                            value={type._id}
                                        >
                                            {type.name[customization.locale ? customization.locale : "en"]}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>

                    <Divider style={{ width: "100%" }}></Divider>
                </Grid>
            </CardContent>

            <MainCard className='subcard'>
                {noData && <Typography
                    style={{ color: "#7A7A7A", margin: "20px" }}
                    variant="subtitle1"
                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                >
                    <FormattedMessage id="noData" />
                </Typography>}

                {bookingsList?.map((row, index) => {
                    return (
                        <SubCard style={{ marginTop: "20px" }}>
                            <Grid item container xs={12}>
                                <Grid xs={12}>
                                    <Grid xs={2}>
                                        <Rating className={customization.locale === "en" ? "ratingLeft" : "ratingRight"} name="read-only" defaultValue={row.rate} value={row.rate} readOnly />
                                    </Grid>
                                    <div className={customization.locale === "en" ? "point" : "pointAr"}>
                                        <p className='points'>{`${row.rate}.0/5.0`}</p></div>
                                    <Grid xs={12} style={{ marginTop: "40px" }}>
                                        <Typography
                                            style={{ color: "#7A7A7A", marginTop: "10px" }}
                                            variant="subtitle1"
                                            sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                        >
                                            {' '}
                                            {row?.review?.comment}
                                            {' '}
                                        </Typography>
                                        <Grid className={customization.locale === "en" ? "floatLeft" : "floatRight"} xs={12} style={{ margin: "20px 0px", display: "inline-flex" }}>
                                            <div className={customization.locale === "en" ? "chipSet" : "chipSetAr"}>
                                                <span className='spanLeft'>
                                                    {customization.locale === "en" ? "Booking ID:" : "معرف الحجز:"}
                                                </span>
                                                <span className='spanRight'>
                                                    {row?.bookingId}
                                                </span>
                                            </div>
                                            <div className={customization.locale === "en" ? "chipSet" : "chipSetAr"}>
                                                <span className='spanLeft'>
                                                    {customization.locale === "en" ? "Building:" : "بناء:"}
                                                </span>
                                                <span className='spanRight'>
                                                    {row?.building?.name[customization.locale ? customization.locale : "en"]}
                                                </span>
                                            </div>
                                            <div className={customization.locale === "en" ? "chipSet" : "chipSetAr"}>
                                                <span className='spanLeft'>
                                                    {customization.locale === "en" ? "Property:" : "ملكية:"}
                                                </span>
                                                <span className='spanRight'>
                                                    {row?.property?.name[customization.locale ? customization.locale : "en"]}
                                                </span>
                                            </div>
                                        </Grid>
                                    </Grid>
                                    {objectData?.status === 'PENDING' &&
                                        <>
                                            <Divider className='dividers'></Divider>
                                            <div style={{ width: "100%", display: "inline-flex" }}>
                                                {checkPermission("UPDATE_REVIEW") &&
                                                    <div className='acceptHover'>
                                                        <IconButton onClick={() => handleAccept(row._id)} style={{ padding: "10px 0px" }}>
                                                            <p className='accept_btn'><FormattedMessage id="accept" /></p>
                                                        </IconButton>
                                                    </div>}
                                                {checkPermission("UPDATE_REVIEW") &&
                                                    <div className='rejectHover'>
                                                        <IconButton onClick={() => handleReject(row._id)} style={{ padding: "10px 0px", marginLeft: "10px" }}  >
                                                            <p className='reject_btn'><FormattedMessage id="reject" /></p>
                                                        </IconButton>
                                                    </div>
                                                }
                                            </div>
                                        </>
                                    }
                                    {objectData?.status === 'ACCEPT' &&
                                        <>
                                            <Divider className='dividers'></Divider>
                                            <div style={{ width: "100%", display: "inline-flex" }}>

                                                {checkPermission("UPDATE_REVIEW") && <div className='rejectHover'>
                                                    <IconButton onClick={() => handleReject(row._id)} style={{ padding: "10px 0px", marginLeft: "10px" }}  >
                                                        <p className='reject_btn'><FormattedMessage id="reject" /></p>
                                                    </IconButton>
                                                </div>
                                                }
                                            </div>
                                        </>
                                    }

                                    {objectData?.status === 'REJECT' &&
                                        <>
                                            <Divider className='dividers'></Divider>
                                            <div style={{ width: "100%", display: "inline-flex" }}>
                                                {checkPermission("UPDATE_REVIEW") &&
                                                    <div className='acceptHover'>
                                                        <IconButton onClick={() => handleAccept(row._id)} style={{ padding: "10px 0px" }}>
                                                            <p className='accept_btn'><FormattedMessage id="accept" /></p>
                                                        </IconButton>
                                                    </div>
                                                }
                                            </div>
                                        </>
                                    }
                                </Grid>
                            </Grid>
                        </SubCard>
                    )
                })}
            </MainCard>
            <TablePagination
                rowsPerPageOptions={pagination?.size ?? 0}
                component="div"
                count={pagination?.total ?? 0}
                rowsPerPage={pagination?.size ?? 0}
                page={page}
                onPageChange={handleChangePage}
            />
        </MainCard>
    </>
);
};
export default ReviewsListing;
