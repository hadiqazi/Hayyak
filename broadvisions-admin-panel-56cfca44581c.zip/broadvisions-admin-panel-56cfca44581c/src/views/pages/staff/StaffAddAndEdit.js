/* eslint-disable */
import React, { useEffect } from 'react';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';


import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';

import { useDispatch, useSelector } from 'react-redux';
import Typography from '@mui/material/Typography';
import '../../../assets/css/style.css'
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';
import {
  Button, Grid, TextField, Stack
} from '@material-ui/core';
import MainCard from 'ui-component/cards/MainCard';
import { gridSpacing } from 'store/constant';
import AnimateButton from 'ui-component/extended/AnimateButton';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { SNACKBAR_OPEN } from 'store/actions';
import axios from 'axios';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { baseURL, version1, propertyService, userService } from 'defaultValues';
import { FormattedMessage } from 'react-intl';

const StaffAddAndEdit = () => {
  const { state } = useLocation();
  console.log('state is', state)
  const customization = useSelector((state) => state.customization);
  const [arabic, setArabic] = React.useState(false);
  const [roles, setRoles] = React.useState([]);
  const [english, setEnglish] = React.useState(true);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [lastPage, setLastPage] = React.useState(state?.lastPageNo);
  const [errorName, setErrorName] = React.useState(false);
  const [errorLastName, setErrorLastName] = React.useState(false);
  const [errorEmail, setErrorEmail] = React.useState(false);
  const [errorPhone, setErrorPhone] = React.useState(false);
  const [errorRole, setErrorRole] = React.useState(false);

  const formik = useFormik({
    initialValues: {
      name: state?.firstName ? state?.firstName : '',
      lastName: state?.lastName ? state?.lastName : '',
      email: state?.email ? state?.email : '',
      role: state?.role ? state?.role?._id : '',
      phone: state?.phone ? state?.phone : '',
    },

    enableReinitialize: true,

    onSubmit: values => {
      let obj = {
        firstName: values.name,
        lastName: values.lastName,
        email: values.email,
        role: values.role,
        phone: values.phone.toString(),
      }

      var letters = /^[0-9]*$/;
      var phoneNum = /^(?:[0-9] ?){6,14}[0-9]$/;
      if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email) ||
        !/^(?:[0-9] ?){6,14}[0-9]$/i.test(values.phone) ||
        values.name.length === 0 || values.lastName.length === 0 || values.role.length === 0 || values.email.length === 0
        || (values.name.match(letters)) || (values.lastName.match(letters))
        || values.phone.length === 0

      ) {
        if (values.name.length === 0) {
          setErrorName(<FormattedMessage id="firstNameRequired" />)
        }
        else if ((values.name.match(letters))) {
          setErrorName(<FormattedMessage id="validFirstNameRequired" />)
        }


        else {
          setErrorName(false)
        }
        if (values.lastName.length === 0) {
          setErrorLastName(<FormattedMessage id="lastNameRequired" />)
        }
        else if ((values.lastName.match(letters))) {
          setErrorLastName(<FormattedMessage id="validLastNameRequired" />)
        }

        else {
          setErrorLastName(false)
        }

        if (values.phone.length === 0) {
          setErrorPhone(<FormattedMessage id="phoneRequired" />)
        }
        else if (!(/^(?:[0-9] ?){6,14}[0-9]$/i.test(values.phone))) {
          setErrorPhone(<FormattedMessage id="validPhoneRequired" />)
        }
        else {
          setErrorPhone(false)
        }
        if (values.role.length === 0) {
          setErrorRole(<FormattedMessage id="roleRequired" />)
        }
        else {
          setErrorRole(false)
        }
        if (values.email.length === 0) {
          setErrorEmail(<FormattedMessage id="emailRequired" />)

        }
        else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
          setErrorEmail(<FormattedMessage id="emailInvalid" />)
        }
        else {
          setErrorEmail(false)
        }
        dispatch({
          type: SNACKBAR_OPEN,
          open: true,
          message: <FormattedMessage id="allFieldsEnglish" />,
          variant: 'alert',
          alertSeverity: 'error'
        });
        return;
      }
      if (state) {


        axios({
          method: 'put',
          url: `${baseURL}/${userService}/${version1}/admin/${state._id}`,
          data: obj,
        }).then(res => {
          if (res.status === 200) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: <FormattedMessage id="staffUpdated" />,
              variant: 'alert',
              alertSeverity: 'success'
            });

            navigate('/staff', { state: lastPage });
            return;
          }
        }).catch((error) => {
          console.error(error.response)
          if (error.response && error.response.data.status && error.response.data.message) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: error.response.data.message,
              variant: 'alert',
              alertSeverity: 'error'
            });
            return;
          }
          dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: <FormattedMessage id="errorMessage" />,
            variant: 'alert',
            alertSeverity: 'error'
          });
          return;
        })
      }
      else {
        axios({
          method: 'post',
          url: `${baseURL}/${userService}/${version1}/admin`,
          data: obj,
        }).then(res => {
          if (res.status === 200) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: <FormattedMessage id="staffSaved" />,
              variant: 'alert',
              alertSeverity: 'success'
            });

            navigate('/staff');
            return;
          }
        }).catch((error) => {
          if (error.response && error.response.data.status && error.response.data.messageCode) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: error.response.data.messageCode === "admin.duplicate" ? <FormattedMessage id="duplicateAdmin" /> : error.response.data.messageCode,
              variant: 'alert',
              alertSeverity: 'error'
            });

            return;
          }
          dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: <FormattedMessage id="errorMessage" />,
            variant: 'alert',
            alertSeverity: 'error'
          });
          return;
        })
      }

    }
  });
  useEffect(() => {
    axios({
      method: 'get',
      url: `${baseURL}/${userService}/${version1}/role`,
    }).then(res => {
      console.log('roels', res)
      setRoles(res.data.roles)
    }).catch((err) => console.log(err))
  }, []);

  const handleArabic = () => {
    setArabic(true)
    setEnglish(false)
  }
  const handleEnglish = () => {
    setArabic(false)
    setEnglish(true)
  }

  return (
    <>
      <MainCard>
        <div onClick={() => navigate(`../../../staff`, { state: lastPage })} className={customization.locale == "en" ? "backDiv" : "backDivAr"}>
          {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
          {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
          <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
        </div>

        <Typography style={{ marginBottom: "30px" }} variant="h3" gutterBottom component="div">
          {state ? <FormattedMessage id="staff-update" /> : <FormattedMessage id="staff-add" />}
        </Typography>

        <form onSubmit={formik.handleSubmit}>
          <Grid container spacing={gridSpacing}>
            <Grid style={{ marginBottom: "20px" }} item xs={12}>
              <Grid container spacing={3}>
                <Grid style={{ paddingTop: "40px", paddingLeft: "40px" }} item xs={6}>
                  <TextField
                    fullWidth
                    id="name"
                    name="name"
                    label={<FormattedMessage id="fullName" />}
                    placeholder={customization.locale == "en" ? "First Name" : "الاسم بالكامل"}
                    defaultValue={formik.values.name}
                    value={formik.values.name}
                    onChange={formik.handleChange}
                    error={errorName}
                    helperText={errorName}
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </Grid>
                <Grid style={{ paddingTop: "40px", paddingLeft: "40px" }} item xs={6}>
                  <TextField
                    fullWidth
                    id="lastName"
                    name="lastName"
                    label={<FormattedMessage id="lastName" />}
                    placeholder={customization.locale == "en" ? "Last Name" : "اسم العائلة"}
                    defaultValue={formik.values.lastName}
                    value={formik.values.lastName}
                    onChange={formik.handleChange}
                    error={errorLastName}
                    helperText={errorLastName}
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </Grid>



                <Grid style={{ paddingTop: "40px", paddingLeft: "40px" }} item xs={6}>
                  <TextField

                    fullWidth
                    id="email"
                    name="email"
                    label={<FormattedMessage id="email" />}
                    placeholder={customization.locale == "en" ? "Email" : "بريد الالكتروني"}
                    defaultValue={formik.values.email}
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    error={errorEmail}
                    helperText={errorEmail}
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </Grid>

                <Grid style={{ paddingTop: "25px", paddingLeft: "40px", marginTop: "15px" }} item xs={6}>
                  <FormControl fullWidth>
                    <InputLabel className={errorRole ? "validation dropdown_font" : "dropdown_font"} id="demo-multiple-name-label"><FormattedMessage id="role" /></InputLabel>
                    <Select

                      error={errorRole}
                      helperText={errorRole}
                      labelId="role"
                      id="role"
                      name="role"
                      defaultValue={formik.values.role}
                      value={formik.values.role}
                      onChange={formik.handleChange}
                      label={<FormattedMessage id="role" />}
                    >
                      {roles?.map((type) => (
                        <MenuItem key={type._id} value={type._id} >{type.name}</MenuItem>
                      ))}
                    </Select>
                    {errorRole && <Typography className="validationError" variant="body1" gutterBottom >{errorRole}</Typography>}
                  </FormControl>
                </Grid>

                <Grid style={{ paddingTop: "40px", paddingLeft: "40px" }} item xs={6}>
                  <TextField
                    fullWidth
                    type='number'
                    id="phone"
                    name="phone"
                    label={<FormattedMessage id="phone" />}
                    placeholder={customization.locale == "en" ? "Phone" : "هاتف"}
                    defaultValue={formik.values.phone}
                    value={formik.values.phone}
                    onChange={formik.handleChange}
                    error={errorPhone}
                    helperText={errorPhone}
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </Grid>


              </Grid>
            </Grid>

            <Grid item xs={12}>
              <Stack direction="row" >
                <AnimateButton>
                  <Button className='hayyak_btn' style={{ marginRight: "10px" }} variant="contained" type="submit">
                    <FormattedMessage id="save" />
                  </Button>
                  <Button onClick={() => navigate(`../../../staff`, { state: lastPage })} className='cancel_btn'  >
                    <FormattedMessage id="cancel" />
                  </Button>
                </AnimateButton>
              </Stack>
            </Grid>
          </Grid>
        </form>
      </MainCard>
    </>
  )
};

export default StaffAddAndEdit;
