/* eslint-disable */
import React, { useEffect } from 'react';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';


import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';

import { useDispatch, useSelector } from 'react-redux';
import Typography from '@mui/material/Typography';
import '../../../assets/css/style.css'
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';
import {
    Button, Grid, TextField, Stack
} from '@material-ui/core';
import MainCard from 'ui-component/cards/MainCard';
import { gridSpacing } from 'store/constant';
import AnimateButton from 'ui-component/extended/AnimateButton';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { SNACKBAR_OPEN } from 'store/actions';
import axios from 'axios';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { baseURL, version1, propertyService, userService } from 'defaultValues';
import { FormattedMessage } from 'react-intl';

const RolesAddAndEdit = () => {
    const { state } = useLocation();
    console.log('state is', state)
    const customization = useSelector((state) => state.customization);
    const [arabic, setArabic] = React.useState(false);
    const [roles, setRoles] = React.useState([]);
    const [english, setEnglish] = React.useState(true);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [lastPage, setLastPage] = React.useState(state?.lastPageNo);
    const [permissions, setPermissions] = React.useState([])
    const [errorName, setErrorName] = React.useState(false);
    const [errorLastName, setErrorLastName] = React.useState(false);
    const [errorEmail, setErrorEmail] = React.useState(false);
    const [errorPhone, setErrorPhone] = React.useState(false);
    const [errorRole, setErrorRole] = React.useState(false);

    const formik = useFormik({
        initialValues: {
            roleName: state?.name ? state?.name : '',
            roleText: state?.roleText ? state?.roleText : '',
            permissions: state ? state?.permissions.map(item => item._id) : [],
        },

        enableReinitialize: true,

        onSubmit: values => {
            let obj = {
                name: values.roleName,
                roleText: values.roleText,
                permissions: values.permissions
            }

            var letters = /^[0-9]*$/;
            var phoneNum = /^(?:[0-9] ?){6,14}[0-9]$/;
            if (values.roleName.length === 0 || values.roleText.length === 0 || values.permissions.length === 0
                || (values.roleName.match(letters)) || (values.roleText.match(letters))

            ) {
                if (values.roleName.length === 0) {
                    setErrorName(<FormattedMessage id="roleNameRequired" />)
                }
                else if ((values.roleName.match(letters))) {
                    setErrorName(<FormattedMessage id="validRoleNameRequired" />)
                }


                else {
                    setErrorName(false)
                }
                if (values.roleText.length === 0) {
                    setErrorLastName(<FormattedMessage id="roleTextRequired" />)
                }
                else if ((values.roleText.match(letters))) {
                    setErrorLastName(<FormattedMessage id="validRoleTextRequired" />)
                }

                else {
                    setErrorLastName(false)
                }

                if (values.permissions.length === 0) {
                    setErrorRole(<FormattedMessage id="permissionsRequired" />)
                }
                else {
                    setErrorRole(false)
                }
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="allFieldsEnglish" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
                return;
            }
            if (state) {
                axios({
                    method: 'put',
                    url: `${baseURL}/${userService}/${version1}/role/${state._id}`,
                    data: obj,
                }).then(res => {
                    if (res.status === 200) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: <FormattedMessage id="rolesUpdated" />,
                            variant: 'alert',
                            alertSeverity: 'success'
                        });

                        navigate('/roles', { state: lastPage });
                        return;
                    }
                }).catch((error) => {
                    console.error(error.response)
                    if (error.response && error.response.data.status && error.response.data.message) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: error.response.data.message,
                            variant: 'alert',
                            alertSeverity: 'error'
                        });
                        return;
                    }
                    dispatch({
                        type: SNACKBAR_OPEN,
                        open: true,
                        message: <FormattedMessage id="errorMessage" />,
                        variant: 'alert',
                        alertSeverity: 'error'
                    });
                    return;
                })
            }
            else {
                axios({
                    method: 'post',
                    url: `${baseURL}/${userService}/${version1}/role`,
                    data: obj,
                }).then(res => {
                    if (res.status === 200) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: <FormattedMessage id="rolesSaved" />,
                            variant: 'alert',
                            alertSeverity: 'success'
                        });

                        navigate('/roles');
                        return;
                    }
                }).catch((error) => {
                    if (error.response && error.response.data.status && error.response.data.messageCode) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: error.response.data.messageCode === "admin.duplicate" ? <FormattedMessage id="duplicateAdmin" /> : error.response.data.messageCode,
                            variant: 'alert',
                            alertSeverity: 'error'
                        });

                        return;
                    }
                    dispatch({
                        type: SNACKBAR_OPEN,
                        open: true,
                        message: <FormattedMessage id="errorMessage" />,
                        variant: 'alert',
                        alertSeverity: 'error'
                    });
                    return;
                })
            }

        }
    });
    const loadPermissions = () => {
        axios({
            method: 'get',
            url: `${baseURL}/${userService}/${version1}/permission`,

        }).then(res => {
            console.log('permissions', res.data.permissions);
            setPermissions(res.data.permissions)
        }).catch((err) => console.log(err))

    }
    useEffect(() => {
        axios({
            method: 'get',
            url: `${baseURL}/${userService}/${version1}/role`,
        }).then(res => {
            console.log('roels', res)
            setRoles(res.data.roles)
        }).catch((err) => console.log(err))
        loadPermissions()


    }, []);

    const handleArabic = () => {
        setArabic(true)
        setEnglish(false)
    }
    const handleEnglish = () => {
        setArabic(false)
        setEnglish(true)
    }

    return (
        <>
            <MainCard>
                <div onClick={() => navigate(`../../../roles`, { state: lastPage })} className={customization.locale == "en" ? "backDiv" : "backDivAr"}>
                    {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
                    {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
                    <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
                </div>

                <Typography style={{ marginBottom: "30px" }} variant="h3" gutterBottom component="div">
                    {state ? <FormattedMessage id="roles-update" /> : <FormattedMessage id="roles-add" />}
                </Typography>

                <form onSubmit={formik.handleSubmit}>
                    <Grid container spacing={gridSpacing}>
                        <Grid style={{ marginBottom: "20px" }} item xs={12}>
                            <Grid container spacing={3}>
                                <Grid style={{ paddingTop: "40px", paddingLeft: "40px" }} item xs={6}>
                                    <TextField
                                        fullWidth
                                        id="roleName"
                                        name="roleName"
                                        label={<FormattedMessage id="roleName" />}
                                        placeholder={customization.locale == "en" ? "Role Name" : "اسم الدور"}
                                        defaultValue={formik.values.roleName}
                                        value={formik.values.roleName}
                                        onChange={formik.handleChange}
                                        error={errorName}
                                        helperText={errorName}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                    />
                                </Grid>
                                <Grid style={{ paddingTop: "40px", paddingLeft: "40px" }} item xs={6}>
                                    <TextField
                                        fullWidth
                                        id="roleText"
                                        name="roleText"
                                        label={<FormattedMessage id="roleText" />}
                                        placeholder={customization.locale == "en" ? "Role Text" : "نص الدور"}
                                        defaultValue={formik.values.roleText}
                                        value={formik.values.roleText}
                                        onChange={formik.handleChange}
                                        error={errorLastName}
                                        helperText={errorLastName}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                    />
                                </Grid>



                                <Grid style={{ paddingTop: "25px", paddingLeft: "40px", marginTop: "15px" }} item xs={6}>
                                    <FormControl fullWidth>
                                        <InputLabel className={errorRole ? "validation dropdown_font" : "dropdown_font"} id="demo-multiple-name-label"><FormattedMessage id="permissions" /></InputLabel>
                                        <Select
                                            error={errorRole}
                                            helperText={errorRole}
                                            labelId="permissions"
                                            id="permissions"
                                            multiple
                                            name="permissions"
                                            defaultValue={formik.values.permissions}
                                            value={formik.values.permissions}
                                            onChange={formik.handleChange}
                                            label={<FormattedMessage id="permissions" />}
                                        >
                                            {permissions?.map((type) => (
                                                <MenuItem key={type._id} value={type._id} >{type.name}</MenuItem>
                                            ))}
                                        </Select>
                                        {errorRole && <Typography className="validationError" variant="body1" gutterBottom >{errorRole}</Typography>}
                                    </FormControl>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Grid item xs={12}>
                            <Stack direction="row" >
                                <AnimateButton>
                                    <Button className='hayyak_btn' style={{ marginRight: "10px" }} variant="contained" type="submit">
                                        <FormattedMessage id="save" />
                                    </Button>
                                    <Button onClick={() => navigate(`../../../roles`, { state: lastPage })} className='cancel_btn'  >
                                        <FormattedMessage id="cancel" />
                                    </Button>
                                </AnimateButton>
                            </Stack>
                        </Grid>
                    </Grid>
                </form>
            </MainCard>
        </>
    )
};

export default RolesAddAndEdit;
