/* eslint-disable */
import { FormattedMessage } from 'react-intl';
import 'react-confirm-alert/src/react-confirm-alert.css';
import moment from 'moment';
import { SNACKBAR_OPEN } from 'store/actions';
import PropTypes from 'prop-types';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { baseURL, version1, propertyService } from 'defaultValues';
import { useRef } from "react";
import AlertDialog from '../../../utils/alert/confirmAlert'
import DeleteIcon from '@mui/icons-material/Delete';
import '../../../../src/assets/css/style.css'
import DateFormatter from 'utils/date';
import { useDispatch, useSelector } from 'react-redux';
// material-ui
import { makeStyles, useTheme } from '@material-ui/styles';
import {
    Button,
    CardContent,
    Grid,
    IconButton,
    InputAdornment,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TablePagination,
    TableRow,
    TableSortLabel,
    TextField,
    Toolbar,
    Tooltip,
    Typography,
    Fab,
} from '@material-ui/core';
import { visuallyHidden } from '@material-ui/utils';
import AddCircleIcon from '@mui/icons-material/AddCircle';

import Loader from 'ui-component/Loader';

// third-party
import clsx from 'clsx';

// project imports
import MainCard from 'ui-component/cards/MainCard';

// assets
import DeleteTwoToneIcon from '@material-ui/icons/DeleteTwoTone';
import SearchIcon from '@material-ui/icons/Search';
import EditTwoToneIcon from '@material-ui/icons/EditTwoTone';

import useAuth from 'hooks/useAuth';

const rowsInitial = [];

// table sort
function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}


function getComparator(order, orderBy) {
    return order === 'desc' ? (a, b) => descendingComparator(a, b, orderBy) : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
        const order = comparator(a[0], b[0]);
        if (order !== 0) return order;
        return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
}

// table header options
const headCells = [
    {
        id: 'name',
        numeric: false,
        label: <FormattedMessage id="name" />,
        align: 'left'
    },
    {
        id: 'type',
        numeric: false,
        label: <FormattedMessage id="type" />,
        align: 'left'
    },
    {
        id: 'added-on',
        numeric: false,
        label: <FormattedMessage id="added-on" />,
        align: 'left'
    }
];

// style constant
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    paper: {
        width: '100%',
        marginBottom: theme.spacing(2)
    },
    table: {
        minWidth: 750
    },
    sortSpan: visuallyHidden
}));

const useToolbarStyles = makeStyles((theme) => ({
    root: {
        padding: 0,
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(1)
    },
    highlight: {
        color: theme.palette.secondary.main
    },
    title: {
        flex: '1 1 100%'
    }
}));

// ===========================|| TABLE HEADER ||=========================== //

function EnhancedTableHead({ classes, onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort, selected }) {
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };

    return (
        <TableHead className='tableHeads'>
            <TableRow>
                {/* <TableCell padding='normal'> 
                #
              </TableCell> */}
                {numSelected <= 0 &&
                    headCells.map((headCell) => (
                        <TableCell
                            key={headCell.id}
                            align={headCell.align}
                            padding={headCell.disablePadding ? 'none' : 'normal'}
                            sortDirection={orderBy === headCell.id ? order : false}
                        >
                            <TableSortLabel
                                disabled
                                active={orderBy === headCell.id}
                                direction={orderBy === headCell.id ? order : 'asc'}
                                onClick={createSortHandler(headCell.id)}
                            >
                                {headCell.label}
                                {orderBy === headCell.id ? (
                                    <span className={classes.sortSpan}>{order === 'desc' ? 'sorted descending' : 'sorted ascending'}</span>
                                ) : null}
                            </TableSortLabel>
                        </TableCell>
                    ))}
                {numSelected <= 0 && (
                    <TableCell sortDirection={false} align="center" sx={{ pr: 3 }}>
                        <FormattedMessage id="actions" />
                    </TableCell>
                )}
            </TableRow>
        </TableHead>
    );
}

EnhancedTableHead.propTypes = {
    selected: PropTypes.array,
    classes: PropTypes.object.isRequired,
    numSelected: PropTypes.number.isRequired,
    onRequestSort: PropTypes.func.isRequired,
    onSelectAllClick: PropTypes.func.isRequired,
    order: PropTypes.oneOf(['asc', 'desc']).isRequired,
    orderBy: PropTypes.string.isRequired,
    rowCount: PropTypes.number.isRequired
};

// ===========================|| TABLE HEADER TOOLBAR ||=========================== //

const EnhancedTableToolbar = (props) => {
    const classes = useToolbarStyles();
    const { numSelected } = props;

    return (
        <Toolbar
            className={clsx(classes.root, {
                [classes.highlight]: numSelected > 0
            })}
        >
            {numSelected > 0 ? (
                <Typography className={classes.title} color="inherit" variant="h4" component="div">
                    {numSelected} Selected
                </Typography>
            ) : (
                <Typography className={classes.title} variant="h6" id="tableTitle" component="div">
                    Nutrition
                </Typography>
            )}

            {numSelected > 0 && (
                <Tooltip title="Delete">
                    <IconButton>
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </Tooltip>
            )}
        </Toolbar>
    );
};

EnhancedTableToolbar.propTypes = {
    numSelected: PropTypes.number.isRequired
};

// ===========================|| CUSTOMER LIST ||=========================== //

const AmenityListing = () => {
    const { checkPermission } = useAuth();
    const { state } = useLocation();
    const classes = useStyles();
    const theme = useTheme();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const customization = useSelector((state) => state.customization);
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('calories');
    const [openConfirmation, setOpenConfirmation] = useState(false);
    const [open, setOpen] = useState(false);
    const [message, setMessage] = useState('');
    const [heading, setHeading] = useState('');
    const [idToDelete, setIdToDelete] = useState();
    const [selected, setSelected] = useState([]);
    const [edit, setEdit] = useState([]);
    const [page, setPage] = useState(state ? state : 0);
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [search, setSearch] = useState('');
    const [saveInfoSearch, setSaveInfoSearch] = useState([]);
    const [rows, setRows] = useState(rowsInitial);
    const [isLoading, setIsLoading] = useState(false);

    const handleSearch = (event) => {
        const newString = event.target.value;
        setSearch(newString);
        setPage(0);
        // setPage(1);
        let result = saveInfoSearch.filter(item => item.name[customization.locale ? customization.locale : "en"].toLowerCase().includes(event.target.value.toLowerCase()))
        setRows(result)
    };
    const handleRequestSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const handleOpen = () => {
        axios({
            method: 'delete',
            url: `${baseURL}/${propertyService}/${version1}/amenity/${idToDelete}`,
        }).then(res => {
            if (res.status === 200) {
                loadData()
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="amenityDeleted" />,
                    variant: 'alert',
                    alertSeverity: 'success'
                });
                return;
            }
        }).catch(err => {
            console.error(err);
            // setIsLoading(false);
        })
        setOpen(false)
    };

    const handleClose = () => {
        setOpen(false);
    };

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelectedId = rows.map((n) => n.name);
            setSelected(newSelectedId);
            return;
        }
        setSelected([]);
    };
    const handleAddAmenityClick = () => {
        navigate(`add`);
    };

    const handleEditAmenityClick = (event, row) => {
        setEdit(row)
        row['lastPageNo'] = page
        navigate(`edit/${row._id}`, { state: row });
    };

    const handleDeleteAmenityAPICall = (event, id) => {
        setOpen(true)
        setMessage(<FormattedMessage id="deleteMessage" />)
        setHeading(<FormattedMessage id="deleteAmenity" />)
        setIdToDelete(id)
    }

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const isSelected = (name) => selected.indexOf(name) !== -1;

    const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

    const loadData = () => {
        axios({
            method: 'get',
            url: `${baseURL}/${propertyService}/${version1}/amenity`,
        }).then(res => {
            setRows(res.data.amenities)
            setSaveInfoSearch(res.data.amenities)
            setIsLoading(false)
        }).catch(err => {
            console.error(err);
            setIsLoading(false);
        });
    }

    useEffect(() => {
        setIsLoading(true)
        loadData();
        return (() => { })
    }, []);

    if (isLoading) {
        return <Loader />;
    }

    return (
        <>
            <MainCard classname="font-link" content={false}>

                <CardContent>
                    <Grid container justifyContent="space-between" alignItems="center" spacing={2}>
                        <Grid item xs={6} sm={6}>
                            <Typography
                                variant="h3"
                            >
                                {<FormattedMessage id="amenity-page-title" />}
                            </Typography>
                        </Grid>
                        <Grid item xs={6} sm={6} sx={{ textAlign: 'right' }}>
                            <Grid item container xs={12}>
                                <Grid xs={7} sm={7} >
                                    {/* <Tooltip title={<FormattedMessage id="addAmenity" />}> */}
                                    {checkPermission("CREATE_AMENITY") &&
                                        <Button className='font-link hayyak_btn_in ' onClick={handleAddAmenityClick} variant="contained" type="submit">
                                            <AddCircleIcon className={customization.locale == "en" ? "addIcon" : "addIconArabic"} fontSize="small" />
                                            <FormattedMessage id="addNewAmenity" />
                                        </Button>
                                    }
                                    {/* </Tooltip> */}
                                </Grid>
                                <Grid xs={5} sm={5} >
                                    <TextField
                                        className="searchbar"
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <SearchIcon fontSize="small" />
                                                </InputAdornment>
                                            )
                                        }}
                                        onChange={handleSearch}
                                        placeholder={customization.locale == "en" ? "Search Amenities" : "وسائل الراحة البحث"}
                                        value={search}
                                        size="small"
                                    />
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>

                </CardContent>

                {/* table */}
                <TableContainer>
                    <Table className={classes.table} aria-labelledby="tableTitle">
                        <EnhancedTableHead
                            classes={classes}
                            numSelected={selected.length}
                            order={order}
                            orderBy={orderBy}
                            onSelectAllClick={handleSelectAllClick}
                            onRequestSort={handleRequestSort}
                            rowCount={rows.length}
                            selected={selected}
                        />
                        <TableBody>
                            {stableSort(rows, getComparator(order, orderBy))
                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map((row, index) => {
                                    const isItemSelected = isSelected(row.name);
                                    const labelId = `enhanced-table-checkbox-${index}`;

                                    return (
                                        <TableRow
                                            role="checkbox"
                                            aria-checked={isItemSelected}
                                            tabIndex={-1}
                                            key={index}
                                            selected={isItemSelected}
                                        >

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                                >
                                                    {' '}
                                                    {row.name[customization.locale ? customization.locale : "en"]}
                                                    {' '}
                                                </Typography>
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                                >
                                                    {' '}
                                                    {row.amenityType.name[customization.locale ? customization.locale : "en"]}
                                                    {' '}
                                                </Typography>
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >

                                                <DateFormatter date={row.createdAt} />

                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>



                                            <TableCell align="center" sx={{ pr: 3 }}>
                                                {checkPermission("UPDATE_AMENITY") &&
                                                    <IconButton className='edit_btn' onClick={(event) => handleEditAmenityClick(event, row)}>
                                                        <EditTwoToneIcon sx={{ fontSize: '1.3rem' }} />
                                                    </IconButton>}
                                                {checkPermission("DELETE_AMENITY") && <IconButton className='dlt_btn' onClick={(event) => handleDeleteAmenityAPICall(event, row._id)}>
                                                    <DeleteIcon sx={{ fontSize: '1.3rem' }} />
                                                </IconButton>}
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                            {emptyRows > 0 && (
                                <TableRow
                                    style={{
                                        height: 53 * emptyRows
                                    }}
                                >
                                    <TableCell colSpan={6} />
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>

                {/* table pagination */}
                <TablePagination

                    rowsPerPageOptions={[5, 10, 25]}
                    component="div"
                    count={rows.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </MainCard>
            <AlertDialog

                heading={heading}
                open={open}
                message={message}
                handleOpen={handleOpen}
                handleClose={handleClose}
            />
        </>
    );
};

export default AmenityListing;
