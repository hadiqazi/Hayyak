/* eslint-disable */
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';


import Typography from '@mui/material/Typography';
import '../../../assets/css/style.css'
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { Divider } from '@mui/material';
import {
  Button, Grid, TextField, Stack
} from '@material-ui/core';
import OutlinedInput from '@mui/material/OutlinedInput';
import MainCard from 'ui-component/cards/MainCard';
import { gridSpacing } from 'store/constant';
import AnimateButton from 'ui-component/extended/AnimateButton';
import { useFormik } from 'formik';
import { SNACKBAR_OPEN } from 'store/actions';
import axios from 'axios';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { baseURL, version1, propertyService, userService } from 'defaultValues';
import { FormattedMessage } from 'react-intl';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';



const AmenityEdit = () => {
  const { state } = useLocation();
  const { amenityId } = useParams();
  const [lastPage, setLastPage] = React.useState(state?.lastPageNo);
  const [amenityTypes, setAmenityTypes] = React.useState([]);
  const customization = useSelector((state) => state.customization);
  const [arabic, setArabic] = React.useState(false);
  const [english, setEnglish] = React.useState(true);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [errorArabicName, setErrorArabicName] = React.useState(false);
  const [errorName, setErrorName] = React.useState(false);
  const [errorType, setErrorType] = React.useState(false);
  const [value, setValue] = React.useState('1');

  const formik = useFormik({
    initialValues: {
      name: state?.name ? state?.name.en : '',
      amenityType: state?.amenityType ? state?.amenityType._id : '',
      nameArabic: state?.name ? state?.name.ar : '',
    },
    enableReinitialize: true,
    onSubmit: values => {
      var letters = /^[0-9]*$/;
      if (values.nameArabic.length === 0 || values.name.length === 0 || values.amenityType.length === 0 ||
        (values.name.match(letters)) || (values.nameArabic.match(letters))) {
        if (values.name || (values.name.match(letters))) {
          if (values.name.length === 0) {
            setErrorName(<FormattedMessage id="amenityRequired" />)
          }
          else if ((values.name.match(letters))) {
            setErrorName(<FormattedMessage id="validAmenityRequired" />)
          }
          else {
            setErrorName(false)
          }
        }
        if (values.nameArabic || (values.nameArabic.match(letters))) {
          if (values.nameArabic.length === 0) {
            setErrorArabicName(<FormattedMessage id="amenityRequired" />)
          }
          else if ((values.nameArabic.match(letters))) {
            setErrorArabicName(<FormattedMessage id="validAmenityRequired" />)
          }
          else {
            setErrorArabicName(false)
          }
        }

        if (values.amenityType.length === 0) {
          setErrorType(<FormattedMessage id="amenityTypeRequired" />)
        }
        else {
          setErrorType(false)
        }
        if (values.nameArabic.length === 0 || values.name.length === 0 || values.amenityType.length === 0) {
          dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: <FormattedMessage id="allFields" />,
            variant: 'alert',
            alertSeverity: 'error'
          });
        }
        return
      }
      if (state) {
        let obj = {
          id: amenityId,
          name: {
            "en": values.name,
            "ar"
              : values.nameArabic
          }
        }
        axios({
          method: 'put',
          url: `${baseURL}/${propertyService}/${version1}/amenity/${amenityId}`,

          data: obj,

        }).then(res => {
          if (res.status === 200) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: <FormattedMessage id="amenityUpdated" />,
              variant: 'alert',
              alertSeverity: 'success'
            });
            navigate('/amenity', { state: lastPage });
            return;
          }
        }).catch((error) => {
          if (error.response && error.response.data.status && error.response.data.message) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: error.response.data.message,
              variant: 'alert',
              alertSeverity: 'error'
            });
            return;
          }
          dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: 'Please fill all the fields in both English and Arabic first.',
            variant: 'alert',
            alertSeverity: 'error'
          });
          return;
        })
      }
      else {
        let obj = {
          name: {
            "en": values.name,
            "ar": values.nameArabic,
          },
          typeId: values.amenityType

        }
        axios({
          method: 'post',
          url: `${baseURL}/${propertyService}/${version1}/amenity`,
          data: obj,
        }).then(res => {
          if (res.status === 201) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: <FormattedMessage id="amenitySaved" />,
              variant: 'alert',
              alertSeverity: 'success'
            });

            navigate('/amenity');
            return;
          }
        }).catch((error) => {
          if (error.response && error.response.data.status && error.response.data.message) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: error.response.data.message,
              variant: 'alert',
              alertSeverity: 'error'
            });
            return;
          }
          dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: <FormattedMessage id="errorMessage" />,
            variant: 'alert',
            alertSeverity: 'error'
          });
          return;
        })
      }
    }
  });

  const handleChangeTab = (event, newValue) => {

    setValue(newValue);
    if (newValue === '1') {
      setArabic(false)
      setEnglish(true)
    }
    else {
      setArabic(true)
      setEnglish(false)
    }
  };



  const handleArabic = () => {
    setArabic(true)
    setEnglish(false)
  }
  const handleEnglish = () => {
    setArabic(false)
    setEnglish(true)
  }

  useEffect(() => {
    axios({
      method: 'get',
      url: `${baseURL}/${propertyService}/${version1}/amenity-type`,
    }).then(res => {
      setAmenityTypes(res.data.amenityTypes)
    }).catch((err) => console.log(err))
  }, []);

  return (
    <>
      <MainCard className='amenityMain'>
        <div onClick={() => navigate(`../../../amenity`, { state: lastPage })} className={customization.locale == "en" ? "backDiv" : "backDivAr"}>

          {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
          {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
          <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
        </div>

        <Typography style={{ marginBottom: "30px" }} variant="h3" gutterBottom component="div">
          {state ? <FormattedMessage id="amenity-page-title-update" /> : <FormattedMessage id="amenityNew" />}
        </Typography>
        {/* <Stack style={{ paddingBottom: "10px", paddingLeft: "20px" }} spacing={2} direction="row">
          <Button onClick={handleEnglish} variant={english ? "contained" : "outlined"}> <FormattedMessage id="english" /></Button>
          <Button onClick={handleArabic} variant={arabic ? "contained" : "outlined"}> <FormattedMessage id="arabic" /></Button>
        </Stack> */}
        <div className='formD'>
          <Box sx={{ width: '100%', typography: 'body1' }}>
            <TabContext value={value}>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <TabList onChange={handleChangeTab} aria-label="lab API tabs example">
                  <Tab className='local' label={<FormattedMessage id="englishTab" />} value="1" />
                  <Tab className='local2' label={<FormattedMessage id="arabicTab" />} value="2" />
                  {/* <Tab label="Item Three" value="3" /> */}
                </TabList>
              </Box>
              {/* <TabPanel value="1">Item One</TabPanel>
        <TabPanel value="2">Item Two</TabPanel>
        <TabPanel value="3">Item Three</TabPanel> */}
            </TabContext>
          </Box>
          <Divider className='dividers'></Divider>


          <form onSubmit={formik.handleSubmit}>
            <Grid container spacing={gridSpacing}>
              <Grid item xs={12}>
                <Grid container spacing={3}>

                  {english && <Grid style={{ paddingTop: "50px", paddingLeft: "40px" }} item xs={12}>
                    <TextField

                      className='amenityEn'
                      id="name"
                      name="name"
                      label={<FormattedMessage id="amenity-name" />}
                      placeholder={customization.locale == "en" ? "Amenity Name" : "اسم وسائل الراحة"}
                      defaultValue={formik.values.name}
                      value={formik.values.name}
                      onChange={formik.handleChange}
                      error={errorName}
                      helperText={errorName}
                      InputLabelProps={{
                        shrink: true
                      }}
                    />
                  </Grid>}
                  {arabic && <Grid style={{ paddingTop: "50px", paddingLeft: "40px" }} className="paddings" item xs={12}>
                    <TextField

                      className="field"

                      fullWidth
                      id="nameArabic"
                      name="nameArabic"
                      label={<FormattedMessage id="amenity-name" />}
                      placeholder={customization.locale == "en" ? "Amenity Name" : "اسم وسائل الراحة"}
                      defaultValue={formik.values.nameArabic}
                      value={formik.values.nameArabic}
                      onChange={formik.handleChange}
                      error={errorArabicName}
                      helperText={errorArabicName}
                      InputLabelProps={{
                        shrink: true
                      }}
                    />
                  </Grid>}
                </Grid>

              </Grid>
            </Grid>
          </form>
        </div>
        <form onSubmit={formik.handleSubmit}>
          <Grid item xs={12}>

            {state ?
              <Grid item xs={6}>
                {/* <FormControl sx={{ m: 1, width: 300 }}> */}

                <FormControl style={{ width: "95%" }}>
                  <InputLabel className={errorType ? "validation dropdown_font" : "dropdown_font"} id="demo-multiple-name-label"><FormattedMessage id="amenityType" /></InputLabel>
                  <Select
                    disabled
                    error={errorType}
                    helperText={errorType}
                    labelId="amenityType"
                    id="amenityType"
                    name="amenityType"
                    defaultValue={formik.values.amenityType}
                    value={formik.values.amenityType}
                    onChange={formik.handleChange}
                    label={<FormattedMessage id="amenityType" />}
                  >
                    {amenityTypes?.map((type) => (
                      <MenuItem key={type._id} value={type._id} >{type.name[customization.locale ? customization.locale : "en"]}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              :
              <Grid item xs={6}>
                <FormControl style={{ width: "95%" }}>
                  <InputLabel className={errorType ? "validation dropdown_font" : "dropdown_font"} id="demo-multiple-name-label"><FormattedMessage id="amenityType" /></InputLabel>
                  <Select
                    error={errorType}
                    helperText={errorType}
                    labelId="amenityType"
                    id="amenityType"
                    name="amenityType"
                    defaultValue={formik.values.amenityType}
                    value={formik.values.amenityType}
                    onChange={formik.handleChange}
                    label={<FormattedMessage id="amenityType" />}
                  >
                    {amenityTypes?.map((type) => (
                      <MenuItem key={type._id} value={type._id} >{type.name[customization.locale ? customization.locale : "en"]}</MenuItem>
                    ))}
                  </Select>
                  {errorType && <Typography className="validationError" variant="body1" gutterBottom >{errorType}</Typography>}
                </FormControl>
              </Grid>
            }

          </Grid>

          <Grid item xs={12} style={{ marginTop: "20px" }}>
            <Stack direction="row" >
              <AnimateButton>
                <Button className='hayyak_btn' style={{ marginRight: "10px" }} variant="contained" type="submit">
                  <FormattedMessage id="save" />
                </Button>
                <Button onClick={() => navigate(`../../../amenity`, { state: lastPage })} className='cancel_btn'  >
                  <FormattedMessage id="cancel" />
                </Button>

              </AnimateButton>
            </Stack>
          </Grid>
        </form>
      </MainCard>
    </>
  )
};

export default AmenityEdit;
