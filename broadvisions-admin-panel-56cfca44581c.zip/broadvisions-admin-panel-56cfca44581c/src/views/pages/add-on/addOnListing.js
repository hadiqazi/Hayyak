/* eslint-disable */
import { FormattedMessage } from 'react-intl';
import { useLocation } from 'react-router-dom';
import AlertDialog from '../../../utils/alert/confirmAlert'
import { SNACKBAR_OPEN } from 'store/actions';
import { NumberFormat } from 'react-intl';
import PropTypes from 'prop-types';
import React, { useState, useEffect } from 'react';
import DateFormatter from 'utils/date';
import moment from 'moment';
import axios from 'axios';
import { baseURL, version1, propertyService } from 'defaultValues';


import { useDispatch, useSelector } from 'react-redux';

// material-ui
import { makeStyles, useTheme } from '@material-ui/styles';
import {
    CardContent,
    Grid,
    IconButton,
    InputAdornment,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TablePagination,
    TableRow,
    TableSortLabel,
    TextField,
    Toolbar,
    Tooltip,
    Button,
    Typography,
    Fab,
} from '@material-ui/core';
import { visuallyHidden } from '@material-ui/utils';
import AddIcon from '@material-ui/icons/AddTwoTone';
import { useNavigate } from 'react-router-dom';

import Loader from 'ui-component/Loader';

// third-party
import clsx from 'clsx';

// project imports
import MainCard from 'ui-component/cards/MainCard';

// assets
import DeleteIcon from '@material-ui/icons/Delete';
import DeleteTwoToneIcon from '@material-ui/icons/DeleteTwoTone';
import SearchIcon from '@material-ui/icons/Search';
import EditTwoToneIcon from '@material-ui/icons/EditTwoTone';
import useAuth from 'hooks/useAuth';
import AddCircleIcon from '@mui/icons-material/AddCircle';

const rowsInitial = [];
var formatter = new Intl.NumberFormat();

// table sort
function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}

function getComparator(order, orderBy) {
    return order === 'desc' ? (a, b) => descendingComparator(a, b, orderBy) : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
        const order = comparator(a[0], b[0]);
        if (order !== 0) return order;
        return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
}

// table header options
const headCells = [
    {
        id: 'image',
        numeric: false,
        label: <FormattedMessage id="image" />,
        align: 'left'
    },
    {
        id: 'name',
        numeric: false,
        label: <FormattedMessage id="name" />,
        align: 'left'
    },
    {
        id: 'price',
        numeric: false,
        label: <FormattedMessage id="price" />,
        align: 'left'
    },
    {
        id: 'added-on',
        numeric: false,
        label: <FormattedMessage id="added-on" />,
        align: 'left'
    },
];

// style constant
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    paper: {
        width: '100%',
        marginBottom: theme.spacing(2)
    },
    table: {
        minWidth: 750
    },
    sortSpan: visuallyHidden
}));

const useToolbarStyles = makeStyles((theme) => ({
    root: {
        padding: 0,
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(1)
    },
    highlight: {
        color: theme.palette.secondary.main
    },
    title: {
        flex: '1 1 100%'
    }
}));

// ===========================|| TABLE HEADER ||=========================== //

function EnhancedTableHead({ classes, onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort, selected }) {
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };

    return (
        <TableHead className='tableHeads'>
            <TableRow>

                {numSelected <= 0 &&
                    headCells.map((headCell) => (
                        <TableCell
                            key={headCell.id}
                            align={headCell.align}
                            padding={headCell.disablePadding ? 'none' : 'normal'}
                            sortDirection={orderBy === headCell.id ? order : false}
                        >
                            <TableSortLabel
                                disabled
                                active={orderBy === headCell.id}
                                direction={orderBy === headCell.id ? order : 'asc'}
                                onClick={createSortHandler(headCell.id)}
                            >
                                {headCell.label}
                                {orderBy === headCell.id ? (
                                    <span className={classes.sortSpan}>{order === 'desc' ? 'sorted descending' : 'sorted ascending'}</span>
                                ) : null}
                            </TableSortLabel>
                        </TableCell>
                    ))}
                {numSelected <= 0 && (
                    <TableCell sortDirection={false} align="center" sx={{ pr: 3 }}>
                        <FormattedMessage id="actions" />
                    </TableCell>
                )}
            </TableRow>
        </TableHead>
    );
}

EnhancedTableHead.propTypes = {
    selected: PropTypes.array,
    classes: PropTypes.object.isRequired,
    numSelected: PropTypes.number.isRequired,
    onRequestSort: PropTypes.func.isRequired,
    onSelectAllClick: PropTypes.func.isRequired,
    order: PropTypes.oneOf(['asc', 'desc']).isRequired,
    orderBy: PropTypes.string.isRequired,
    rowCount: PropTypes.number.isRequired
};

// ===========================|| TABLE HEADER TOOLBAR ||=========================== //

const EnhancedTableToolbar = (props) => {
    const classes = useToolbarStyles();
    const { numSelected } = props;

    return (
        <Toolbar
            className={clsx(classes.root, {
                [classes.highlight]: numSelected > 0
            })}
        >
            {numSelected > 0 ? (
                <Typography className={classes.title} color="inherit" variant="h4" component="div">
                    {numSelected} Selected
                </Typography>
            ) : (
                <Typography className={classes.title} variant="h6" id="tableTitle" component="div">
                    Nutrition
                </Typography>
            )}

            {numSelected > 0 && (
                <Tooltip title="Delete">
                    <IconButton>
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </Tooltip>
            )}
        </Toolbar>
    );
};

EnhancedTableToolbar.propTypes = {
    numSelected: PropTypes.number.isRequired
};

// ===========================|| CUSTOMER LIST ||=========================== //

const RoleListing = () => {
    const classes = useStyles();
    const { state } = useLocation();
    const theme = useTheme();
    const navigate = useNavigate();
    const customization = useSelector((state) => state.customization);
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('calories');
    const dispatch = useDispatch();
    const [selected, setSelected] = useState([]);
    const [page, setPage] = useState(state ? state : 0);
    const [saveInfoSearch, setSaveInfoSearch] = useState('');
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [search, setSearch] = useState('');
    const [rows, setRows] = useState(rowsInitial);
    const [isLoading, setIsLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const { checkPermission } = useAuth();
    const [message, setMessage] = useState('');
    const [heading, setHeading] = useState('');
    const [idToDelete, setIdToDelete] = useState();

    const handleOpen = () => {
        axios({
            method: 'delete',
            url: `${baseURL}/${propertyService}/${version1}/value-added-service/${idToDelete}`,
        }).then(res => {
            if (res.status === 200) {
                loadData()
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="addOnDeleted" />,
                    variant: 'alert',
                    alertSeverity: 'success'
                });
                return;
            }
        }).catch(err => {
            console.error(err);
            // setIsLoading(false);
        });
        setOpen(false)
    };

    const handleClose = () => {
        setOpen(false);
    };


    const handleSearch = (event) => {
        const newString = event.target.value;
        setSearch(newString);
        setPage(0);
        let result = saveInfoSearch.filter(item => item.name[customization.locale ? customization.locale : "en"].toLowerCase().includes(event.target.value.toLowerCase()))
        setRows(result)

    };

    const handleRequestSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelectedId = rows.map((n) => n.name);
            setSelected(newSelectedId);
            return;
        }
        setSelected([]);
    };

    const handleAddAmenityClick = () => {
        console.log('in add role click')
        navigate(`add`);
    };

    const handleEditAmenityClick = (event, row) => {
        row['lastPageNo'] = page
        navigate(`edit/${row._id}`, { state: row });
    };

    const handleDeleteAmenityAPICall = (event, id) => {
        setOpen(true)
        setMessage(<FormattedMessage id="deleteMessage" />)
        setHeading(<FormattedMessage id="deleteService" />)
        setIdToDelete(id)

    }

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const isSelected = (name) => selected.indexOf(name) !== -1;

    const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

    const loadData = () => {
        axios({
            method: 'get',
            url: `${baseURL}/${propertyService}/${version1}/value-added-service`,
        }).then(res => {
            console.log('response', res.data.valueAddedServices);
            setRows(res.data.valueAddedServices)
            setSaveInfoSearch(res.data.valueAddedServices)
            setIsLoading(false)
        }).catch(err => {
            console.error(err);
            setIsLoading(false);
        });
    }

    useEffect(() => {
        setIsLoading(true)
        loadData();
    }, []);

    if (isLoading) {
        return <Loader />;
    }

    return (
        <>
            <MainCard content={false}>

                <CardContent>
                    <Grid container justifyContent="space-between" alignItems="center" spacing={2}>
                        <Grid item xs={6} sm={6}>
                            <Typography
                                variant="h3"
                            >
                                {<FormattedMessage id="addOns-page-title" />}
                            </Typography>
                        </Grid>
                        <Grid item xs={6} sm={6} sx={{ textAlign: 'right' }}>
                            <Grid item container xs={12}>
                                <Grid xs={7} sm={7} >
                                    {/* <Tooltip title={<FormattedMessage id="addValue" />}> */}
                                    {checkPermission("CREATE_VAS") &&
                                        <Button className='hayyak_btn_in ' onClick={handleAddAmenityClick} variant="contained" type="submit">
                                            <AddCircleIcon className={customization.locale == "en" ? "addIcon" : "addIconArabic"} fontSize="small" />
                                            <FormattedMessage id="addNewService" />
                                        </Button>
                                    }
                                    {/* </Tooltip> */}
                                </Grid>
                                <Grid xs={5} sm={5} >
                                    <TextField
                                        className="searchbar"
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <SearchIcon fontSize="small" />
                                                </InputAdornment>
                                            )
                                        }}
                                        onChange={handleSearch}
                                        placeholder={customization.locale == "en" ? "Search Services" : "خدمات البحث"}
                                        value={search}
                                        size="small"
                                    />
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </CardContent>




                {/* <CardContent>
                    <Grid container justifyContent="space-between" alignItems="center" spacing={2}>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <SearchIcon fontSize="small" />
                                        </InputAdornment>
                                    )
                                }}
                                onChange={handleSearch}
                                placeholder={customization.locale=="en"? "Search Services":"خدمات البحث"}
                                value={search}
                                size="small"
                            />
                        </Grid>
                        <Grid item xs={12} sm={6} sx={{ textAlign: 'right' }}>
                            <Tooltip title={<FormattedMessage id="addValue" />}>
                                <Fab
                                    color="primary"
                                    size="small"
                                    onClick={handleAddAmenityClick}
                                    sx={{ boxShadow: 'none', ml: 1, width: '32px', height: '32px', minHeight: '32px' }}
                                >
                                    <AddIcon fontSize="small" />
                                </Fab>
                            </Tooltip>
                        </Grid>
                    </Grid>
                </CardContent> */}

                {/* table */}
                <TableContainer>
                    <Table className={classes.table} aria-labelledby="tableTitle">
                        <EnhancedTableHead
                            classes={classes}
                            numSelected={selected.length}
                            order={order}
                            orderBy={orderBy}
                            onSelectAllClick={handleSelectAllClick}
                            onRequestSort={handleRequestSort}
                            rowCount={rows.length}
                            selected={selected}
                        />
                        <TableBody>
                            {stableSort(rows, getComparator(order, orderBy))
                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map((row, index) => {
                                    const isItemSelected = isSelected(row.name);
                                    const labelId = `enhanced-table-checkbox-${index}`;

                                    return (
                                        <TableRow
                                            role="checkbox"
                                            aria-checked={isItemSelected}
                                            tabIndex={-1}
                                            key={index}
                                            selected={isItemSelected}
                                        >
                                            {/* <TableCell component="th" scope="row">
                                        <Typography
                                          variant="subtitle1"
                                          sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                        >
                                          {' '}
                                          {index+1}{' '}
                                        </Typography>
                                        </TableCell> */}
                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >

                                                <img className='border' src={row.image?.imageUrl} />

                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                                >
                                                    {' '}
                                                    {row.name[customization.locale ? customization.locale : "en"]}
                                                    {' '}
                                                </Typography>
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                                >
                                                    {' '}
                                                    {formatter.format(row.price) + ' ' + 'SAR'}
                                                    {' '}
                                                </Typography>
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <DateFormatter date={row.createdAt} />
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>
                                            <TableCell align="center" sx={{ pr: 3 }}>
                                                {checkPermission("UPDATE_VAS") &&
                                                    <IconButton className='edit_btn' color="primary" onClick={(event) => handleEditAmenityClick(event, row)}>
                                                        <EditTwoToneIcon sx={{ fontSize: '1.3rem' }} />
                                                    </IconButton>}
                                                {checkPermission("DELETE_VAS") &&
                                                    <IconButton className='dlt_btn' color="secondary" onClick={(event) => handleDeleteAmenityAPICall(event, row._id)}>
                                                        <DeleteIcon sx={{ fontSize: '1.3rem' }} />
                                                    </IconButton>
                                                }
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                            {emptyRows > 0 && (
                                <TableRow
                                    style={{
                                        height: 53 * emptyRows
                                    }}
                                >
                                    <TableCell colSpan={6} />
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>

                {/* table pagination */}
                <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    component="div"
                    count={rows.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </MainCard>
            <AlertDialog
                heading={heading}
                open={open}
                message={message}
                handleOpen={handleOpen}
                handleClose={handleClose}
            />
        </>
    );
};

export default RoleListing;
