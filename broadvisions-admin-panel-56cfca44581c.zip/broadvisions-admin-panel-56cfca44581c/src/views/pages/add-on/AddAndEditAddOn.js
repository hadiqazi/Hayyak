/* eslint-disable */
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';
import IconButton from '@mui/material/IconButton';
import { Divider } from '@mui/material';
import PhotoCamera from '@mui/icons-material/PhotoCamera';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
// material-ui
import AddCircleIcon from '@mui/icons-material/AddCircle';
import Typography from '@mui/material/Typography';
import { useSelector } from 'react-redux';
import '../../../assets/css/style.css'
import AddIcon from '@mui/icons-material/Add';
import {
  Button, Grid, TextField, Stack, InputLabel, Select, MenuItem
} from '@material-ui/core';

// project imports
import MainCard from 'ui-component/cards/MainCard';
import { gridSpacing } from 'store/constant';
import AnimateButton from 'ui-component/extended/AnimateButton';
import { useFormik } from 'formik';
import { SNACKBAR_OPEN } from 'store/actions';
import { styled } from '@mui/material/styles';
import axios from 'axios';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { baseURL, version1, propertyService, userService } from 'defaultValues';
import { FormattedMessage } from 'react-intl';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
const Input = styled('input')({
  display: 'none',
});
const AmenityEdit = () => {
  const customization = useSelector((state) => state.customization);
  const { state } = useLocation();
  const [lastPage, setLastPage] = React.useState(state?.lastPageNo);
  const { addOnId } = useParams();
  const [coverImage, setCoverImage] = useState(null);
  const [arabic, setArabic] = React.useState(false);
  const [imagePath, setImagePath] = React.useState(false);
  const [english, setEnglish] = React.useState(true);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [errorName, setErrorName] = React.useState(false);
  const [errorDescription, setErrorDescription] = React.useState(false);
  const [errorPrice, setErrorPrice] = React.useState(false);
  const [errorNameArabic, setErrorNameArabic] = React.useState(false);
  const [errorDescriptionArabic, setErrorDescriptionArabic] = React.useState(false);
  const [errorImage, setErrorImage] = React.useState(false);
  const [value, setValue] = React.useState('1');

  const formik = useFormik({
    initialValues: {
      name: state?.name ? state?.name.en : '',
      nameArabic: state?.name ? state?.name.ar : '',
      description: state?.description ? state?.description.en : '',
      descriptionArabic: state?.description ? state?.description.ar : '',
      price: state?.price ? state?.price : '',

    },
    enableReinitialize: true,
    onSubmit: values => {
      var letters = /^[0-9]*$/;
      let formData = createObj(values)
      if ((imagePath === false && (!state?.image?.imageUrl)) ||
        values.name.length === 0 || (values.name.match(letters)) ||
        values.description.length === 0 ||
        (values.price.length === 0 || values.price < 1) ||
        values.nameArabic.length === 0 || (values.nameArabic.match(letters)) ||
        values.descriptionArabic.length === 0) {
        if (imagePath === false && (!state?.image?.imageUrl)) {
          setErrorImage(<FormattedMessage id="imageRequired" />)
        }
        else {
          setErrorImage(false)
        }
        if (values.name || (values.name.match(letters))) {
          if (values.name.length === 0) {
            setErrorName(<FormattedMessage id="serviceRequired" />)
          }
          else if ((values.name.match(letters))) {
            setErrorName(<FormattedMessage id="validNameRequired" />)
          }
          else {
            setErrorName(false)
          }
        }
        if (values.description.length === 0) {
          setErrorDescription(<FormattedMessage id="descriptionRequired" />)
        }
        else {
          setErrorDescription(false)
        }
        if (values.price || values.price < 1) {
          if (values.price.length === 0) {
            setErrorPrice(<FormattedMessage id="priceRequired" />)
          }
          else if (values.price < 1) {
            setErrorPrice(<FormattedMessage id="invalidNumber" />)
          }
          else {
            setErrorPrice(false)
          }
        }
        if (values.nameArabic || (values.nameArabic.match(letters))) {
          if (values.nameArabic.length === 0) {
            setErrorNameArabic(<FormattedMessage id="serviceRequired" />)
          }
          else if ((values.nameArabic.match(letters))) {
            setErrorNameArabic(<FormattedMessage id="validNameRequired" />)
          }
          else {
            setErrorNameArabic(false)
          }
        }
        if (values.descriptionArabic.length === 0) {
          setErrorDescriptionArabic(<FormattedMessage id="descriptionRequired" />)
        }
        else {
          setErrorDescriptionArabic(false)
        }
        dispatch({
          type: SNACKBAR_OPEN,
          open: true,
          message: <FormattedMessage id="allFields" />,
          variant: 'alert',
          alertSeverity: 'error'
        });
        if (values.name.match(letters) ||
          values.nameArabic.match(letters)) {
          return
        }
        return;
      }
      if (state) {
        axios({
          method: 'put',
          url: `${baseURL}/${propertyService}/${version1}/value-added-service/${addOnId}`,
          data: formData,
          headers: { "Content-Type": "multipart/form-data" },
        }).then(res => {
          if (res.status === 200) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: <FormattedMessage id="serviceUpdated" />,
              variant: 'alert',
              alertSeverity: 'success'
            });
            navigate('/value-added-services', { state: lastPage });
            return;
          }
        }).catch((error) => {
          console.error(error.response)
          if (error.response && error.response.data.status && error.response.data.message) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: error.response.data.message,
              variant: 'alert',
              alertSeverity: 'error'
            });
            return;
          }
          dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: <FormattedMessage id="errorMessage" />,
            variant: 'alert',
            alertSeverity: 'error'
          });
          return;
        })
      }
      else {
        axios({
          method: 'post',
          url: `${baseURL}/${propertyService}/${version1}/value-added-service/`,
          data: formData,
          headers: { "Content-Type": "multipart/form-data" },
        }).then(res => {
          if (res.status === 201) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: <FormattedMessage id="serviceSaved" />,
              variant: 'alert',
              alertSeverity: 'success'
            });

            navigate('/value-added-services');
            return;
          }
        }).catch((error) => {
          console.error(error.response)
          if (error.response && error.response.data.status && error.response.data.message) {
            dispatch({
              type: SNACKBAR_OPEN,
              open: true,
              message: error.response.data.message,
              variant: 'alert',
              alertSeverity: 'error'
            });
            return;
          }
          dispatch({
            type: SNACKBAR_OPEN,
            open: true,
            message: <FormattedMessage id="errorMessage" />,
            variant: 'alert',
            alertSeverity: 'error'
          });
          return;
        })
      }
    }
  });
  const createObj = (values) => {
    let name = {
      "en": values.name,
      "ar": values.nameArabic,
    }
    let description = {
      "en": values.description,
      "ar": values.descriptionArabic,
    }
    let formData = new FormData();
    formData.append('name', JSON.stringify(name));
    formData.append('description', JSON.stringify(description));
    formData.append('price', values.price);
    imagePath ?
      formData.append('image', imagePath) : null

    return formData;
  }
  const handleChangeTab = (event, newValue) => {

    setValue(newValue);
    if (newValue === '1') {
      setArabic(false)
      setEnglish(true)
    }
    else {
      setArabic(true)
      setEnglish(false)
    }
  };

  const handleArabic = () => {
    setArabic(true)
    setEnglish(false)
  }
  const handleEnglish = () => {
    setArabic(false)
    setEnglish(true)
  }
  const uploadImage = (event) => {
    if (event.target.files && event.target.files[0]) {
      setCoverImage(URL.createObjectURL(event.target.files[0]));
    }
    let path = event.target.files[0]
    setImagePath(path)
  }
  return (
    <>
      <MainCard className='addOnMain'>
        <div onClick={() => navigate(`../../../value-added-services`, { state: lastPage })} className={customization.locale == "en" ? "backDiv" : "backDivAr"}>
        {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
          {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
          <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
        </div>
        <Typography style={{ marginBottom: "30px" }} variant="h3" gutterBottom component="div">
          {state ? <FormattedMessage id="addOns-page-title-update" /> : <FormattedMessage id="addOnNew" />}
        </Typography>

        <form onSubmit={formik.handleSubmit}>
          <Grid item xs={12}>

            <Grid style={{ paddingBottom: "20px", paddingLeft: "none" }} item xs={6}>
              {coverImage ? <img className='border'  src={coverImage} /> :
                state?.image?.imageUrl && <img className='border' src={state?.image?.imageUrl} />}

              <div className='uploadDiv'>
                <div className={customization.locale == "en" ? "iconAdd" : "iconAddArabic"}>
                <label htmlFor="icon-button-file">
                  <Input accept="image/*" id="icon-button-file" type="file" onChange={uploadImage} />
                  <IconButton color="primary" aria-label="upload picture" component="span">
                    <AddIcon className='uploads' />

                  </IconButton>
                  
                </label>
                </div>
               
                <Typography className={customization.locale == "en" ? "uploadLabel" : "uploadLabelArabic"} variant="subtitle" gutterBottom >Upload Photo</Typography>
              </div>
              {errorImage && <Typography className="validationError" variant="body1" gutterBottom >{errorImage}</Typography>}
            </Grid>
            </Grid>

            
            <div className='formAddOn'>
              <Grid item xs={12}>
                <Box sx={{ width: '100%', typography: 'body1' }}>
                  <TabContext value={value}>
                    <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                      <TabList onChange={handleChangeTab} aria-label="lab API tabs example">
                      <Tab label={<FormattedMessage id="englishTab" /> } value="1" />
                <Tab label={<FormattedMessage id="arabicTab" /> } value="2" />
                        {/* <Tab label="Item Three" value="3" /> */}
                      </TabList>
                    </Box>
                    {/* <TabPanel value="1">Item One</TabPanel>
        <TabPanel value="2">Item Two</TabPanel>
        <TabPanel value="3">Item Three</TabPanel> */}
                  </TabContext>
                </Box>
                <Divider className='dividers'></Divider>
              </Grid>
           
         
        
             
                {english && <><Grid className="left" item xs={12}>
                  <TextField
                    fullWidth
                    id="name"
                    name="name"
                    label={<FormattedMessage id="name" />}
                    placeholder={customization.locale == "en" ? "Name" : "اسم"}
                    value={formik.values.name}
                    defaultValue={formik.values.name}
                    onChange={formik.handleChange}
                    error={errorName}
                    helperText={errorName}
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </Grid>

                  <Grid item xs={12} className="left">
                    <TextField
                      id="outlined-multiline-static"
                      label={<FormattedMessage id="description" />}
                      
                      rows={4}
                      fullWidth
                      name="description"
                      placeholder={customization.locale == "en" ? "Description" : "وصف"}
                      value={formik.values.description}
                      defaultValue={formik.values.description}
                      onChange={formik.handleChange}
                      error={errorDescription}
                      helperText={errorDescription}
                      InputLabelProps={{
                        shrink: true
                      }}
                    />
                  </Grid></>}

                {arabic && <>
                  <Grid className="left" item xs={12}>
                    <TextField
                      fullWidth
                      id="nameArabic"
                      name="nameArabic"
                      label={<FormattedMessage id="name" />}
                      placeholder={customization.locale == "en" ? "Name" : "اسم"}
                      value={formik.values.nameArabic}
                      defaultValue={formik.values.nameArabic}
                      onChange={formik.handleChange}
                      error={errorNameArabic}
                      helperText={errorNameArabic}
                      InputLabelProps={{
                        shrink: true
                      }}
                    />
                  </Grid>

                  <Grid className="left" item xs={12}>
                    <TextField
                      id="outlined-multiline-static"
                      label={<FormattedMessage id="description" />}
                      
                      rows={4}
                      fullWidth
                      name="descriptionArabic"
                      placeholder={customization.locale == "en" ? "Description" : "وصف"}
                      value={formik.values.descriptionArabic}
                      defaultValue={formik.values.descriptionArabic}
                      onChange={formik.handleChange}
                      error={errorDescriptionArabic}
                      helperText={errorDescriptionArabic}
                      InputLabelProps={{
                        shrink: true
                      }}
                    />
                  </Grid>
                  </>}
</div>
                <Grid item xs={6}>
                  <TextField
                  style={{width:"94.5%"}}
                    type="number"
                    
                    id="price"
                    name="price"
                    label={<FormattedMessage id="price" />}
                    placeholder={customization.locale == "en" ? "Price" : "سعر"}
                    value={formik.values.price}
                    defaultValue={formik.values.price}
                    onChange={formik.handleChange}
                    error={errorPrice}
                    helperText={errorPrice}
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </Grid>
             
            <Grid item xs={12}>
              <Stack direction="row" >
                <AnimateButton>
                  <Button className='hayyak_btn' style={{ marginRight: "10px" }} variant="contained" type="submit">
                    <FormattedMessage id="save" />
                  </Button>
                  <Button onClick={() => navigate(`../../../value-added-services`, { state: lastPage })} className='cancel_btn'  >
                    <FormattedMessage id="cancel" />
                  </Button>
                </AnimateButton>
              </Stack>
            </Grid>
        
        </form>
      </MainCard>
    </>
  )
};

export default AmenityEdit;
