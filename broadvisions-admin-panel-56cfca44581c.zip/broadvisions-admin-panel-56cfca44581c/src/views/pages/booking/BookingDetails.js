import { FormattedMessage } from 'react-intl';
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';
import AlertDialog from '../../../utils/alert/confirmAlert'
import { useDispatch, useSelector } from 'react-redux';
import useAuth from 'hooks/useAuth';
import CircularProgress from '@mui/material/CircularProgress';
import DateFormatter from 'utils/date';
import CancelIcon from '@mui/icons-material/Cancel';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import moment from 'moment';
import {
    TextField
} from '@material-ui/core';
import { useFormik } from 'formik';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Modal from '@mui/material/Modal';
import { baseURL, version1, bookingService } from 'defaultValues';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import { SNACKBAR_OPEN } from 'store/actions';
import '../../../assets/css/style.css'
import Divider from '@mui/material/Divider';
import {
    CardContent,
    Grid,
    IconButton,
    Typography,
} from '@material-ui/core';
import { useNavigate, useLocation } from 'react-router-dom';
import Loader from 'ui-component/Loader';
import MainCard from 'ui-component/cards/MainCard';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};


var formatter = new Intl.NumberFormat();


const PropertyDetails = () => {
    const { state } = useLocation();
    console.log('state is', state)
    const navigate = useNavigate();
    const customization = useSelector((state) => state.customization);
    const [rows, setRows] = useState();
    const [cols, setCols] = useState([]);
    const [lastPage, setLastPage] = React.useState(state?.lastPageNo);
    const [stateObj, setStateObj] = React.useState(state);
    const { checkPermission } = useAuth();
    const [isLoading, setIsLoading] = useState(false);
    const [totalBookingCost, setTotalBookingCost] = useState();
    const [value, setValue] = React.useState(2);
    const [open, setOpen] = useState(false);
    const [cancel, setCancel] = useState(false);
    const [message, setMessage] = useState('');
    const [roomNights, setRoomNights] = React.useState()
    const [total, setTotal] = React.useState()
    const [status, setStatus] = useState('');
    const [cancelError, setCancelError] = useState(false);

    const dispatch = useDispatch();

    const formik = useFormik({
        initialValues: {
            description: '',
        },

        enableReinitialize: true,
        onSubmit: values => {
            if (values.description.length === 0) {
                setCancelError(<FormattedMessage id="reasonCancel" />)
            }
            else {
                setCancelError(false)
                let obj = {
                    // "by": state.guest.name,
                    "reason": values.description
                }

                axios({
                    method: 'patch',
                    url: `${baseURL}/${bookingService}/${version1}/booking/cancel?id=${state._id}`,
                    data: obj,
                }).then(res => {
                    if (res.status === 200) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: <FormattedMessage id="cancelBookingMessage" />,
                            variant: 'alert',
                            alertSeverity: 'success'
                        });
                        setCancel(false)
                        navigate('/bookings');
                        return;
                    }
                }).catch((error) => {
                    if (error.response && error.response.data.status && error.response.data.message) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: error.response.data.message,
                            variant: 'alert',
                            alertSeverity: 'error'
                        });
                        return;
                    }
                    dispatch({
                        type: SNACKBAR_OPEN,
                        open: true,
                        message: 'Error sending request.',
                        variant: 'alert',
                        alertSeverity: 'error'
                    });
                    return;
                })
            }
        }
    });

    const loadData = () => {
        let totalServicesCost = 0
        axios({
            method: 'get',
            url: `${baseURL}/${bookingService}/${version1}/booking/detail?id=${state._id}`,
        }).then(res => {

            console.log('resdetail', res.data.booking)
            setRows(res.data.booking)
            res?.data?.booking?.services?.forEach(element => {
                totalServicesCost = totalServicesCost + element.total
            });

            setTotalBookingCost(totalServicesCost)


            setIsLoading(false)
        }).catch(err => {
            console.error(err);
            setIsLoading(false);
        });
    }
    const loadStatus = () => {
        if (state?.filterObj === 'ACTIVE') {
            setStatus(<FormattedMessage id="active" />)
        }
        else if (state?.filterObj === 'CURRENT') {
            setStatus(<FormattedMessage id="current" />)
        }
        else if (state?.filterObj === 'UPCOMING') {
            setStatus(<FormattedMessage id="upcoming" />)
        }

        else if (state?.filterObj === 'COMPLETED') {
            setStatus(<FormattedMessage id="completed" />)
        }

        else if (state?.filterObj === 'CANCELLED') {
            setStatus(<FormattedMessage id="cancelled" />)
        }



    }
    useEffect(() => {
        setIsLoading(true)
        loadData()
        loadStatus()
        var day1 = new Date(moment(state.checkIn).locale('en').format('L'));
        var day2 = new Date(moment(state.checkOut).locale('en').format('L'));
        var difference = Math.abs(day2 - day1);
        let days = difference / (1000 * 3600 * 24)
        setRoomNights(days)
    }, [])

    const handleClose = () => {
        setOpen(false);
    };
    const handleCancelOpen = () => {
        setCancel(true)
    }
    const handleCancelClose = () => {
        setCancel(false)
    }
    const handleOpen = () => {

    }

    if (isLoading) {
        // return <CircularProgress />;
        return <Loader />;
    }
    return (
        <>
            <MainCard content={false}>
                <div onClick={() => navigate(`../../../bookings`, { state: stateObj })} className={customization.locale == "en" ? "backDiv newBackLeft" : "backDivAr newBackRight"}>
                    {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
                    {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
                    <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
                </div>

                <Grid container item xs={12}>
                    <Grid item xs={12} style={{ display: "inline-flex" }}>
                        <Typography style={{ marginBottom: "10px", marginLeft: "20px", color: "#E44057", fontWeight: "500", marginRight: "20px" }} variant="subtitle" gutterBottom component="div">
                            {`BOOKING  #${state.bookingId}`}
                        </Typography>
                        <div style={{ marginTop: "-5px" }}>
                            <Button style={{ margin: "0px", textTransform: "uppercase" }} disabled className='statusBtn'>{status}</Button>
                        </div>
                    </Grid>
                </Grid>



                <Grid container item xs={12}>
                    <Grid item xs={6}>

                        <Typography style={{ marginBottom: "10px", marginLeft: "20px", marginRight: "20px", fontSize: "20px", fontWeight: "600", color: "black" }} gutterBottom component="div">
                            {state?.property?.name[customization.locale ? customization.locale : "en"]}
                        </Typography>
                    </Grid>
                    {checkPermission("CANCEL_BOOKING") &&
                    <Grid item xs={6}>
                        
                        {rows?.status === "ACTIVE" && <Button className={customization.locale == "en" ? "cancelBookingRight" : "cancelBookingLeft"} onClick={handleCancelOpen} variant="outlined"><FormattedMessage id="cancelBooking" /></Button>}
                    </Grid>}

                </Grid>
                {/* 
                <Grid  container item xs={12}> */}
                {/* <Grid style={{ alignItems: 'flex-end' }} item xs={2} > */}
                <div style={{ display: "inline-block", paddingTop: "20px" }}>

                    <Modal
                        open={cancel}
                        onClose={handleCancelClose}
                        aria-labelledby="modal-modal-title"
                        aria-describedby="modal-modal-description"
                    >
                        <Box sx={style}>
                            <form onSubmit={formik.handleSubmit}>
                                <Grid item container xs={12}>
                                    <Grid xs={6}>
                                        <Typography color="inherit" variant="h3" component="div">
                                            <FormattedMessage id="cancelBooking" />
                                        </Typography>
                                    </Grid>
                                    <Grid xs={6} className='' style={{cursor:"pointer"}} >
                                        <CancelIcon className={customization.locale == "en" ? "cancelIcon" : "cancelIconArabic"}  onClick={handleCancelClose} />
                                    </Grid>



                                    <Typography style={{ marginTop: "10px" }} variant="subtitle" gutterBottom component="div">
                                        <FormattedMessage id="reasonCancel" />
                                    </Typography>
                                    <TextField
                                        style={{ padding: "15px 0px" }}
                                        id="outlined-multiline-static"
                                        // label={<FormattedMessage id="description" />}

                                        rows={4}
                                        fullWidth
                                        name="description"

                                        onChange={formik.handleChange}
                                        error={cancelError}
                                        helperText={cancelError}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                    />


                                    <Button className='hayyak_btn_cancel' variant="contained" type="submit" fullWidth>
                                        <FormattedMessage id="cancelBooking" />
                                    </Button>
                                </Grid>

                            </form>
                        </Box>
                    </Modal>
                </div>

                {/* </Grid> */}
                {/* </Grid> */}
                <CardContent>

                    <Grid container item xs={12} >
                        <Grid container item xs={6} style={{height:"fit-content"}} >
                            <Grid container item xs={12}  >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' variant="subtitle" component="div">
                                        <FormattedMessage id="checkInDetails" />
                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography className='details_clr mg_tp' variant="h3" component="div">
                                        <CalendarTodayIcon className={customization.locale == "en" ? "bookingIcons" : "bookingIconsLeft"} />

                                        {
                                            customization.locale == "en" ?
                                                moment(state.checkIn).locale('en').format('ll')
                                                :
                                                moment(state.checkIn).locale('ar').format('ll')

                                        }

                                    </Typography>
                                </Grid>
                                <Divider></Divider>
                            </Grid>


                            <Grid container item xs={12}  >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' variant="subtitle" component="div">
                                        <FormattedMessage id="checkOutDetails" />

                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography className='details_clr mg_tp' variant="h3" component="div">
                                        <CalendarTodayIcon className={customization.locale == "en" ? "bookingIcons" : "bookingIconsLeft"} />
                                        {
                                            customization.locale == "en" ?
                                                moment(state.checkOut).locale('en').format('ll')
                                                :
                                                moment(state.checkOut).locale('ar').format('ll')

                                        }
                                    </Typography>
                                </Grid>
                                <Divider></Divider>
                            </Grid>



                            <Grid container item xs={12}  >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' variant="subtitle" component="div">
                                        <FormattedMessage id="bedType" />

                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography className='details_clr mg_tp' variant="h3" component="div">
                                        {rows?.propertyId.bedType.name[customization.locale ? customization.locale : "en"]}

                                    </Typography>
                                </Grid>
                                <Divider></Divider>
                            </Grid>




                            <Grid container item xs={12}  >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' variant="subtitle" component="div">
                                        <FormattedMessage id="rooms" />
                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography className='details_clr mg_tp' variant="h3" component="div">
                                        {state.rooms.length}
                                    </Typography>
                                </Grid>
                                <Divider></Divider>
                            </Grid>





                            <Grid container item xs={12}  >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' style={{ marginBottom: "10px" }} variant="subtitle" component="div">
                                        <FormattedMessage id="roomNumberDetails" />

                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    {state.rooms.map((item, index) => <span className="listDetails details_clr">
                                        {item.number}{index < state.rooms.length - 1 ? "," : ""}
                                    </span>)}

                                </Grid>

                            </Grid>

                            <Grid style={{ marginTop: "20px" }} item xs={12}  >
                                <Typography style={{ marginBottom: "10px", fontSize: "16px", fontWeight: "400", color: "black" }} gutterBottom component="div">
                                    <FormattedMessage id="bookedByDetails" />
                                </Typography>

                                <Grid item style={{ width: "7%", display: "inline-block" }}>
                                    <img style={{ width: "45px", height: "45px", borderRadius: "20px" }} src={state?.guest?.image ? state?.guest?.image : process.env.PUBLIC_URL + '/assets/images/download.jfif'} />
                                </Grid>
                                <Grid item xs={10} style={{ display: "inline-block", marginLeft: "20px", marginBottom: "0px" }}>
                                    <Typography style={{ fontSize: "14px", fontWeight: "400", color: "black" }} gutterBottom component="div">
                                        {state.guest.name}
                                    </Typography>
                                    <Typography style={{ marginBottom: "10px", fontSize: "12px" }} variant="subtitle" gutterBottom component="div">
                                        {state.guest.email}
                                    </Typography>
                                </Grid>
                            </Grid>



                        </Grid>

                        <Grid item xs={5} className={customization.locale == "en" ? "roomChargesLeft bookingDet" : "roomChargesRight bookingDet"}  >
                            <Grid className='price' item xs={12} container>
                                <Typography style={{ width: "100%", fontSize: "16px", fontWeight: "400" }} variant="h3" component="div">
                                    <FormattedMessage id="roomCharges" />
                                    <Divider style={{ marginBottom: "10px", marginTop: "15px" }} className='gap'></Divider>

                                </Typography>
                                <Grid item xs={6} container>

                                    <Typography style={{ width: "100%", fontWeight: "400", fontSize: "14px" }} variant="h4" component="div">
                                        <FormattedMessage id="pricePerNight" />
                                    </Typography>
                                    <Typography className='bookingPaddings' style={{ width: "100%", color: "#A6A6A6", fontSize: "11px", fontWeight: "400" }} variant="subtitle" component="div">
                                        {/* 230SAR * 10 */}
                                        {formatter.format(rows?.propertyPrice) + ' ' + 'SAR'} <span>&#215;</span> {roomNights}
                                    </Typography>

                                </Grid>
                                <Grid item xs={6} container>

                                    <Typography className='details_clr_price align_left' style={{ width: "100%" }} variant="subtitle" component="div">
                                        {formatter.format(rows?.cost?.roomCost) + ' ' + 'SAR'}


                                    </Typography>
                                    <Typography className='align_left bookingPaddings' style={{ width: "100%", color: "#A6A6A6", fontSize: "11px", fontWeight: "400" }} variant="subtitle" component="div">
                                        <span>&#215;</span> {rows?.rooms?.length}  {<FormattedMessage id="rooms" />}

                                    </Typography>
                                    {/* <Typography style={{ width: "100%" }} variant="subtitle" component="div">
                                            *2 Rooms
                                           

                                        </Typography> */}


                                </Grid>
                                {rows?.services?.length > 0 &&
                                    <Typography style={{ width: "100%", marginTop: "10px", fontSize: "16px", fontWeight: "400" }} variant="h3" component="div">
                                    </Typography>
                                }


                                <>
                                    <Grid item xs={6} container>
                                        <Typography style={{ width: "100%", fontSize: "14px", fontWeight: "400", paddingTop: "10px" }} variant="h4" component="div">
                                            <FormattedMessage id="extraServices" />
                                        </Typography>
                                        <Typography className='details_clr_price bookingPaddings' style={{ width: "100%", fontSize: "11px", fontWeight: "400", color: "#A6A6A6" }} variant="subtitle" component="div">
                                            {rows?.services?.length} {<FormattedMessage id="services" />}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={6} container>
                                        <Typography className='align_left details_clr_price' style={{ width: "100%", paddingTop: "10px" }} variant="subtitle" component="div">
                                            {formatter.format(totalBookingCost) + ' ' + 'SAR'}
                                        </Typography>
                                    </Grid>

                                </>


                                <Typography style={{ width: "100%" }} variant="h3" component="div">
                                    <Divider className='gap'></Divider>
                                </Typography>

                                <Grid item xs={12} container>
                                    <Grid item xs={6} container>
                                        <Typography style={{ width: "100%", fontSize: "16px", fontWeight: "400", paddingTop: "5px" }} variant="h3" component="div">
                                            <FormattedMessage id="total" />
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={6} container>
                                        <Typography className=' align_left details_clr' style={{ width: "100%" }} variant="h3" component="div">
                                            {formatter.format(rows?.cost?.totalBookingCost) + ' ' + 'SAR'}

                                        </Typography>

                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>

                    <Grid>

                        <Grid style={{ marginTop: "20px" }} item container xs={12} >

                            <Grid item xs={6} >
                                <Grid item xs={12} container>
                                    <Typography style={{ width: "100%", fontSize: "20px", fontWeight: "600", color: "black" }} component="div">
                                        <FormattedMessage id="extraServices" />
                                    </Typography>

                                    {rows?.services?.length === 0 && <Typography style={{ width: "100%", marginTop: "30px", fontWeight: "500", marginLeft: "2px" }} variant="subtitle" component="div">
                                        <FormattedMessage id="noServices" />
                                    </Typography>}

                                    <table style={{ width: "100%", marginTop: "10px" }}>
                                        {rows?.services?.map(item =>
                                        (
                                            <>

                                                <tr key={item.bookingId}>
                                                    <td style={{ width: "15%" }}><img
                                                        className='bordersValue' src={item?.service?.image?.imageUrl} /></td>
                                                    <td>
                                                        <p className="bold">{item?.service?.name[customization.locale ? customization.locale : "en"]}
                                                        </p>
                                                        <p style={{ fontSize: "11px", fontWeight: "400" }}>{formatter.format(item?.service?.price)} SAR <span>&#215;</span>  {formatter.format(item?.totalQuantity)} </p>
                                                    </td>
                                                    <td style={{ float: "right", margin: "25px 25px" }} className="bolds details_clr">{formatter.format(item?.total)} SAR</td>
                                                </tr>
                                                <Divider className='divide'></Divider>
                                            </>
                                        )


                                        )}

                                    </table>


                                </Grid>
                            </Grid>

                        </Grid>
                    </Grid>
                </CardContent>
            </MainCard>

            <AlertDialog
                open={open}
                message={message}
                handleOpen={handleOpen}
                handleClose={handleClose}
            />
        </>
    );
};

export default PropertyDetails;