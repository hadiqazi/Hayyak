import { FormattedMessage } from 'react-intl';
import 'react-confirm-alert/src/react-confirm-alert.css';
import PropTypes from 'prop-types';
import React, { useState, useEffect } from 'react';
import { baseURL, version1, bookingService } from 'defaultValues';
import Link from '@mui/material/Link';
import DateFormatter from 'utils/date';
import axios from 'axios';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import { useSelector } from 'react-redux';
import { makeStyles, useTheme } from '@material-ui/styles';
import '../../../assets/css/style.css'
import {
    CardContent,
    Grid,
    IconButton,
    InputAdornment,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TablePagination,
    TableRow,
    TableSortLabel,
    TextField,
    Toolbar,
    Tooltip,
    Typography,
    Fab,
} from '@material-ui/core';
import { visuallyHidden } from '@material-ui/utils';
import { useNavigate, useLocation } from 'react-router-dom';
import Loader from 'ui-component/Loader';
import clsx from 'clsx';
import MainCard from 'ui-component/cards/MainCard';
import DeleteIcon from '@material-ui/icons/Delete';
import SearchIcon from '@material-ui/icons/Search';
import { GridFilterInputValue } from '@mui/x-data-grid';


// table sort
function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}


function getComparator(order, orderBy) {
    return order === 'desc' ? (a, b) => descendingComparator(a, b, orderBy) : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
        const order = comparator(a[0], b[0]);
        if (order !== 0) return order;
        return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
}

// table header options
const headCells = [
    {
        id: 'bookingId',
        numeric: false,
        label: <FormattedMessage id="bookingId" />,
        align: 'left'
    },
    {
        id: 'property',
        numeric: false,
        label: <FormattedMessage id="property" />,
        align: 'left'
    },
    {
        id: 'building',
        numeric: false,
        label: <FormattedMessage id="building" />,
        align: 'left'
    },

    {
        id: 'bookingDates',
        numeric: false,
        label: <FormattedMessage id="bookingDates" />,
        align: 'left'
    },

    {
        id: 'bookedBy',
        numeric: false,
        label: <FormattedMessage id="bookedBy" />,
        align: 'left'
    },
    {
        id: 'noOfRooms',
        numeric: false,
        label: <FormattedMessage id="noOfRooms" />,
        align: 'left'
    },
    {
        id: 'actions',
        numeric: false,
        label: <FormattedMessage id="actions" />,
        align: 'center'
    }
];

// style constant
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    paper: {
        width: '100%',
        marginBottom: theme.spacing(2)
    },
    table: {
        minWidth: 750
    },
    sortSpan: visuallyHidden
}));

const useToolbarStyles = makeStyles((theme) => ({
    root: {
        padding: 0,
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(1)
    },
    highlight: {
        color: theme.palette.secondary.main
    },
    title: {
        flex: '1 1 100%'
    }
}));

// ===========================|| TABLE HEADER ||=========================== //

function EnhancedTableHead({ classes, onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort, selected }) {
    const customization = useSelector((state) => state.customization);
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };

    return (
        <TableHead className='tableHeads'>
            <TableRow>
                {numSelected <= 0 &&
                    headCells.map((headCell) => (
                        <TableCell
                            key={headCell.id}
                            align={headCell.align}
                            padding={headCell.disablePadding ? 'none' : 'normal'}
                            sortDirection={orderBy === headCell.id ? order : false}
                        >
                            <TableSortLabel
                                disabled
                                active={orderBy === headCell.id}
                                direction={orderBy === headCell.id ? order : 'asc'}
                                onClick={createSortHandler(headCell.id)}
                            >
                                {headCell.label}
                                {orderBy === headCell.id ? (
                                    <span className={classes.sortSpan}>{order === 'desc' ? 'sorted descending' : 'sorted ascending'}</span>
                                ) : null}
                            </TableSortLabel>
                        </TableCell>
                    ))}

            </TableRow>
        </TableHead>
    );
}

EnhancedTableHead.propTypes = {
    selected: PropTypes.array,
    classes: PropTypes.object.isRequired,
    numSelected: PropTypes.number.isRequired,
    onRequestSort: PropTypes.func.isRequired,
    onSelectAllClick: PropTypes.func.isRequired,
    order: PropTypes.oneOf(['asc', 'desc']).isRequired,
    orderBy: PropTypes.string.isRequired,
    rowCount: PropTypes.number.isRequired
};

// ===========================|| TABLE HEADER TOOLBAR ||=========================== //

const EnhancedTableToolbar = (props) => {
    const classes = useToolbarStyles();
    const { numSelected } = props;

    return (
        <Toolbar
            className={clsx(classes.root, {
                [classes.highlight]: numSelected > 0
            })}
        >
            {numSelected > 0 ? (
                <Typography className={classes.title} color="inherit" variant="h4" component="div">
                    {numSelected} Selected
                </Typography>
            ) : (
                <Typography className={classes.title} variant="h6" id="tableTitle" component="div">
                    Nutrition
                </Typography>
            )}

            {numSelected > 0 && (
                <Tooltip title="Delete">
                    <IconButton>
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </Tooltip>
            )}
        </Toolbar>
    );
};

EnhancedTableToolbar.propTypes = {
    numSelected: PropTypes.number.isRequired
};

// ===========================|| CUSTOMER LIST ||=========================== //

const PropertyListing = () => {
    const { state } = useLocation();
    const [buildingState, setBuildingState] = useState([state]);
    const classes = useStyles();
    const theme = useTheme();
    const navigate = useNavigate();
    const customization = useSelector((state) => state.customization);
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('calories');
    const [open, setOpen] = useState(false);
    const [message, setMessage] = useState('');
    const [idToDeleteProperty, setIdToDeleteProperty] = useState();
    const [selected, setSelected] = useState([]);
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [search, setSearch] = useState('');
    const [saveInfoSearch, setSaveInfoSearch] = useState([]);
    const [bookingsList, setBookingsList] = useState([]);
    const [pagination, setPagination] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [visit, setVisit] = useState(true);
    const [filterObj, setFilterObj] = useState("ACTIVE");
    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
        setIsLoading(true)
        setSearch('')
        setPage(0)
        var obj = null
        setValue(newValue);
        filterValue(newValue)

    };
    const filterValue = (newValue) => {

        if (newValue === "1") {
            setFilterObj("ACTIVE")

        }
        else if (newValue === "2") {
            setFilterObj("CURRENT")
        }
        else if (newValue === "3") {
            setFilterObj("UPCOMING")
        }
        else if (newValue === "4") {

            setFilterObj("COMPLETED")
        }

        else if (newValue === "5") {

            setFilterObj("CANCELLED")
        }
    }
    const loadFilterData = () => {
        let obj
        let pageNo = page + 1

        if (state && visit) {
            setPage(state.lastPageNo - 1)
            setValue(state.tabValue)
            setFilterObj(state.filterObj)
            pageNo = state.lastPageNo
            obj = {
                status: state.filterObj
            }
        }
        if (search.length > 0) {
            obj = {
                bookingId: search,
                status: filterObj
            }
        }
        else {
            obj = {
                status: filterObj
            }

        }
        axios({
            method: 'post',
            url: `${baseURL}/${bookingService}/${version1}/booking/filter?page=${pageNo}`,
            data: obj
        }).then(res => {
            console.log('res', res)
            setBookingsList(res.data.booking)
            setPagination(res.data.pagination)
            setSaveInfoSearch(res.data.booking)
            setIsLoading(false)
        }).catch(err => {
            console.error(err);
            setIsLoading(false);
        });
    }
    const handleSearch = (event) => {
        const newString = event.target.value;
        setPage(0)
        setSearch(event.target.value)
        filterValue(value)
    }

    const handleRequestSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelectedId = bookingsList.map((n) => n.name);
            setSelected(newSelectedId);
            return;
        }
        setSelected([]);
    };
    const handlePage = (e, row) => {

        row['tabValue'] = value
        row['filterObj'] = filterObj
        row['lastPageNo'] = pagination?.page
        navigate(`details/${row._id}`, { state: row });
    }
    const handleChangePage = (event, newPage) => {
        setVisit(false)
        setIsLoading(true)
        setPage(newPage)
        setIsLoading(false)
    };

    const isSelected = (name) => selected.indexOf(name) !== -1;

    const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - bookingsList.length) : 0;


    useEffect(() => {
        loadFilterData()
    }, [filterObj, search, page]);

    if (isLoading) {
        return <Loader />;
    }

    return (
        <>
            <MainCard content={false}>
                <CardContent>
                    <Grid item xs={12} container spacing={2}>
                        <Grid item xs={9}>
                            <Typography style={{ marginBottom: "10px" }} variant="h3" gutterBottom component="div">
                                <FormattedMessage id="bookings" />
                            </Typography>
                        </Grid>
                        <Grid item xs={3} style={{ float: "right" }}>
                            <TextField
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <SearchIcon fontSize="small" />
                                        </InputAdornment>
                                    )
                                }}
                                onChange={handleSearch}
                                placeholder={customization.locale == "en" ? "Search Booking Id" : "البحث عن معرف الحجز"}
                                value={search}
                                size="small"
                            />
                        </Grid>
                    </Grid>
                    <Grid item container xs={12} >

                        <Box sx={{ width: '100%', typography: 'body1' }}>
                            <TabContext value={value}>
                                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                                    <TabList onChange={handleChange} aria-label="lab API tabs example">
                                        <Tab label={<FormattedMessage id="active" />} value="1" />
                                        <Tab label={<FormattedMessage id="current" />} value="2" />
                                        <Tab label={<FormattedMessage id="upcoming" />} value="3" />
                                        <Tab label={<FormattedMessage id="completed" />} value="4" />
                                        <Tab label={<FormattedMessage id="cancelled" />} value="5" />
                                    </TabList>
                                </Box>
                            </TabContext>
                        </Box>




                    </Grid>
                </CardContent>





                {/* <CardContent>
                    <Grid container justifyContent="space-between" alignItems="center" spacing={2}>


                        <Grid item xs={12} sm={6}>
                            <Box sx={{ width: '100%', typography: 'body1' }}>
                                <TabContext value={value}>
                                    <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                                        <TabList onChange={handleChange} aria-label="lab API tabs example">
                                            <Tab label="Active" value="1" />
                                            <Tab label="Current" value="2" />
                                            <Tab label="Upcoming" value="3" />
                                            <Tab label="Past" value="4" />
                                            <Tab label="Cancelled" value="5" />
                                        </TabList>
                                    </Box>
                                </TabContext>
                            </Box>
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                style={{ float: "right" }}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <SearchIcon fontSize="small" />
                                        </InputAdornment>
                                    )
                                }}
                                onChange={handleSearch}
                                placeholder="Search Bookings"
                                value={search}
                                size="small"
                            />
                        </Grid>



                    </Grid>
                </CardContent> */}

                {/* table */}
                <TableContainer>
                    <Table className={classes.table} aria-labelledby="tableTitle">
                        <EnhancedTableHead
                            classes={classes}
                            numSelected={selected.length}
                            order={order}
                            orderBy={orderBy}
                            onSelectAllClick={handleSelectAllClick}
                            onRequestSort={handleRequestSort}
                            rowCount={bookingsList.length}
                            selected={selected}
                        />
                        <TableBody>
                            {/* {stableSort(bookingsList, getComparator(order, orderBy))
                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage) */}
                            {bookingsList?.map((row, index) => {
                                const isItemSelected = isSelected(row.name);
                                const labelId = `enhanced-table-checkbox-${index}`;

                                return (
                                    <TableRow
                                        role="checkbox"
                                        aria-checked={isItemSelected}
                                        tabIndex={-1}
                                        key={index}
                                        selected={isItemSelected}
                                    >

                                        <TableCell
                                            component="th"
                                            id={labelId}
                                            scope="row"
                                            // onClick={(event) => handleClick(event, row.name)}
                                            sx={{ cursor: 'pointer' }}
                                        >
                                            <Typography
                                                variant="subtitle1"
                                                sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                            >

                                                {' '}
                                                {row.bookingId}
                                                {' '}
                                            </Typography>
                                            {/* <Typography variant="caption"> {row.email} </Typography> */}
                                        </TableCell>

                                        <TableCell
                                            component="th"
                                            id={labelId}
                                            scope="row"
                                            // onClick={(event) => handleClick(event, row.name)}
                                            sx={{ cursor: 'pointer' }}
                                        >
                                            <Typography
                                                variant="subtitle1"
                                                sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                            >

                                                {' '}
                                                {row.property.name[customization.locale ? customization.locale : "en"]}
                                                {' '}
                                            </Typography>
                                            <Typography variant="caption"> {row.email} </Typography>
                                        </TableCell>

                                        <TableCell
                                            component="th"
                                            id={labelId}
                                            scope="row"
                                            // onClick={(event) => handleClick(event, row.name)}
                                            sx={{ cursor: 'pointer' }}
                                        >
                                            <Typography
                                                variant="subtitle1"
                                                sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                            >

                                                {' '}
                                                {row.property.building.name[customization.locale ? customization.locale : "en"]}
                                                {' '}
                                            </Typography>
                                            <Typography variant="caption"> {row.email} </Typography>
                                        </TableCell>



                                        <TableCell
                                            component="th"
                                            id={labelId}
                                            scope="row"
                                            // onClick={(event) => handleClick(event, row.name)}
                                            sx={{ cursor: 'pointer' }}
                                        >
                                            <DateFormatter date={row.checkIn} /> -  <DateFormatter date={row.checkOut} />
                                            <Typography variant="caption"> {row.email} </Typography>
                                        </TableCell>

                                        {/* <TableCell
                                            component="th"
                                            id={labelId}
                                            scope="row"
                                            // onClick={(event) => handleClick(event, row.name)}
                                            sx={{ cursor: 'pointer' }}
                                        >
                                            <DateFormatter date={row.checkOut} />
                                            <Typography variant="caption"> {row.email} </Typography>
                                        </TableCell> */}

                                        <TableCell
                                            component="th"
                                            id={labelId}
                                            scope="row"
                                            // onClick={(event) => handleClick(event, row.name)}
                                            sx={{ cursor: 'pointer' }}
                                        >
                                            <Typography
                                                variant="subtitle1"
                                                sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                            >

                                                {/* <div  style={{ display: "inline-block" }}>
                                                    <img style={{ width: "30px", height: "30px",borderRadius:"20px" }} src={row?.guest?.image ? row?.guest?.image : process.env.PUBLIC_URL + '/assets/images/download.jfif'} /><span className="bookingImage">{row.guest.name}</span>
                                                </div> */}
                                                {row?.guest?.name}

                                            </Typography>
                                            <Typography variant="caption"> {row.email} </Typography>
                                        </TableCell>

                                        <TableCell
                                            component="th"
                                            id={labelId}
                                            scope="row"
                                            // onClick={(event) => handleClick(event, row.name)}
                                            sx={{ cursor: 'pointer' }}
                                        >
                                            <Typography
                                                variant="subtitle1"
                                                sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                            >
                                                {' '}
                                                {row.rooms.length}


                                                {' '}

                                            </Typography>
                                            <Typography variant="caption"> {row.email} </Typography>
                                        </TableCell>

                                        <TableCell align="center" sx={{ pr: 3 }}>
                                            <Link className="details" onClick={(e) => handlePage(e, row)} underline="always">
                                                <FormattedMessage id="viewDetails" />
                                            </Link>
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                            {emptyRows > 0 && (
                                <TableRow
                                    style={{
                                        height: 53 * emptyRows
                                    }}
                                >
                                    <TableCell colSpan={6} />
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>

                {/* table pagination */}
                <TablePagination
                    
                    component="div"
                    count={pagination.total ?? 0}
                    rowsPerPage={pagination.size ?? 0}
                    page={page}
                    onPageChange={handleChangePage}
                // onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </MainCard>
            {/* <AlertDialog
                open={open}
                message={message}
                handleOpen={handleOpen}
                handleClose={handleClose}
            /> */}
        </>
    );
};

export default PropertyListing;
