/* eslint-disable */
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';


import Typography from '@mui/material/Typography';
import '../../../../assets/css/style.css'
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { Divider } from '@mui/material';
import {
    Button, Grid, TextField, Stack
} from '@material-ui/core';
import OutlinedInput from '@mui/material/OutlinedInput';
import MainCard from 'ui-component/cards/MainCard';
import { gridSpacing } from 'store/constant';
import AnimateButton from 'ui-component/extended/AnimateButton';
import { useFormik } from 'formik';
import { SNACKBAR_OPEN } from 'store/actions';
import axios from 'axios';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { baseURL, version1, propertyService, userService } from 'defaultValues';
import { FormattedMessage } from 'react-intl';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';


const ResetPassword = ({ loginIndex, ...others }) => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [showPassword, setShowPassword] = React.useState(false);
    const [email, setEmail] = React.useState(false);
    const [forgotPassword, setForgotPassword] = React.useState(false);
    const customization = useSelector((state) => state.customization);

    const formik = useFormik({
        initialValues: {
            email: '',
        },

        enableReinitialize: true,
        onSubmit: values => {

            let obj = {
                email: values.email
            }
            if (values?.email.length===0)
            {
               setEmail(<FormattedMessage id="emailRequired" />)
                return;
            }
            else{
                setEmail(false)
            }
            axios({
                method: 'post',
                url: `${baseURL}/${userService}/${version1}/admin/update-password-admin`,
                data: obj,
            }).then(res => {
                if (res.status === 200) {
                    dispatch({
                        type: SNACKBAR_OPEN,
                        open: true,
                        message: <FormattedMessage id="passwordResetEmail" />,
                        variant: 'alert',
                        alertSeverity: 'success'
                    });
                    return;
                }
            }).catch((error) => {
                if (error.response && error.response.data.status && error.response.data.message) {
                    if (error.response.data.message==='admin.not.found')
                    {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message:<FormattedMessage id="accountDoesntExist" />,
                            variant: 'alert',
                            alertSeverity: 'error'
                        });
                        return;
                    }
                    else {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: error.response.data.message,
                            variant: 'alert',
                            alertSeverity: 'error'
                        });
                        return;
                    }
                   
                }
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="errorMessage" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
                return;
            })
        }
    });

    const handleClickShowPassword = () => {
        setShowPassword(!showPassword);
    };
    const handlePassword = () => {
        setForgotPassword(true)
    }
    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };
    const handleSubmit = () => {

    }

    return (
        <form onSubmit={formik.handleSubmit} >
            <FormControl fullWidth >

                <TextField className='loginInputPass'
                    label={<FormattedMessage id="emailAddress" />}
                    id="outlined-adornment-email-login"
                    type="email"
                    value={formik.values.email}
                    name="email"
                    //   onBlur={handleBlur}
                    onChange={formik.handleChange}
                />
                  {email && <Typography className='emailError' variant="caption" fontSize="16px" >
                                                    {email}
                                                </Typography>
}


                {/* {touched.email && errors.email && (
                    <FormHelperText error id="standard-weight-helper-text-email-login">
                        {' '}
                        {errors.email}{' '}
                    </FormHelperText>
                )} */}
            </FormControl>

            <Box
                style={{marginTop:"30px"}}
            >
                <AnimateButton>
                    <Button className='loginButton' fullWidth size="large" type="submit" variant="contained">
                        {<FormattedMessage id="resetPasswordButton" />}
                    </Button>
                </AnimateButton>
            </Box>
        </form>
    )
}

export default ResetPassword;
