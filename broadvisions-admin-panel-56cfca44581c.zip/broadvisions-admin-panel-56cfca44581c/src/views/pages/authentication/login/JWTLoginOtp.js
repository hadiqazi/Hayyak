
import PropTypes from 'prop-types';
import React from 'react';
import { ACCOUNT_INITIALIZE, LOGIN, LOGOUT } from 'store/actions';
import { useNavigate, useLocation } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { SNACKBAR_OPEN } from 'store/actions';
import { FormattedMessage } from 'react-intl';
import axios from 'axios';
import useAuth from 'hooks/useAuth';
import { baseURL, version1 } from 'defaultValues';
import TextField from '@mui/material/TextField';
import OTPInput, { ResendOTP } from "otp-input-react";
import "../../../../../src/assets/css/style.css";
import ForgotPassword from "../../../forgotPassword/index.js";
// material-ui
import { makeStyles } from '@material-ui/styles';
import {

    Box,
    Button,
    Checkbox,
    FormControl,
    FormControlLabel,
    FormHelperText,
    Grid,
    IconButton,
    InputAdornment,
    InputLabel,
    OutlinedInput,
    Typography
} from '@material-ui/core';

// third party
import * as Yup from 'yup';
import { Formik } from 'formik';

// project imports



import AnimateButton from 'ui-component/extended/AnimateButton';

import useScriptRef from 'hooks/useScriptRef';

// assets
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import { useDispatch, useSelector } from 'react-redux';
import { Navigate } from 'react-router';
import { userService } from 'defaultValues';

// style constant
const useStyles = makeStyles((theme) => ({
    loginInput: {
        ...theme.typography.customInput
    },


}));

// ===============================|| JWT LOGIN ||=============================== //

const JWTLoginOtp = (props, { loginIndex, ...others }) => {
    const { login } = useAuth();
    const { verifyLogin } = useAuth();
    const classes = useStyles();
    const navigate = useNavigate();
    const [OTP, setOTP] = React.useState('');
    const dispatch = useDispatch();
    const scriptedRef = useScriptRef();
    const [showPassword, setShowPassword] = React.useState(false);
    const [forgotPassword, setForgotPassword] = React.useState(false);
    const customization = useSelector((state) => state.customization);

    const handleVerify = async () => {
        if (OTP.length < 4) {
            dispatch({
                type: SNACKBAR_OPEN,
                open: true,
                message: <FormattedMessage id="fullOtp" />,
                variant: 'alert',
                alertSeverity: 'error'
            });
            return;
        }
        let obj = {
            email: props.email,
            otp: OTP
        }

        axios({
            method: 'post',
            url: `${baseURL}/${userService}/${version1}/auth/login-admin-otp`,
            data: obj
        }).then(async res => {

            await verifyLogin(res.data,props.rememberMe);


        }).catch((err) => {
            if (err.response && err.response.data.status === 401) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="invalidOtp" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
                return;
            }
        }
        )
    }
    return (
        <Formik
            initialValues={{
                email: '',
                password: '',
                submit: null
            }}
            validationSchema={Yup.object().shape({
                email: Yup.string().email('Must be a valid email').max(255).required('Email is required'),
                password: Yup.string().max(255).required('Password is required')
            })}
            onSubmit={async (values, { setErrors, setStatus, setSubmitting }) => {
                try {
                    await login(values.email, values.password);

                    if (scriptedRef.current) {
                        props.handlePass(true)
                        setStatus({ success: true });

                        setSubmitting(false);
                    }
                } catch (err) {
                    console.error(err);
                    if (scriptedRef.current) {
                        setStatus({ success: false });
                        setErrors({ submit: err.message });
                        setSubmitting(false);
                    }
                }
            }}
        >

            {({ errors, handleBlur, handleChange, handleSubmit, isSubmitting, touched, values }) => (
                <form noValidate onSubmit={handleSubmit} {...others}>
                    <div className='otpInput'>
                        <OTPInput value={OTP} onChange={setOTP} autoFocus OTPLength={4} otpType="number" disabled={false} />
                        {/* <ResendOTP onResendClick={() => console.log("Resend clicked")} /> */}
                    </div>
                    {errors.submit && (
                        <Box
                            sx={{
                                mt: 3
                            }}
                        >
                            <FormHelperText error> <FormattedMessage id="correctCredentials" /></FormHelperText>
                        </Box>
                    )}
                    <Box
                        style={{ marginTop: "20px" }}
                    >
                        <AnimateButton>
                            <Button onClick={handleVerify} className='loginButton' disabled={isSubmitting} fullWidth size="large" type="submit" variant="contained">
                                {<FormattedMessage id="verify" />}
                            </Button>
                        </AnimateButton>
                    </Box>
                </form>
            )}




        </Formik>
    );
};

JWTLoginOtp.propTypes = {
    loginIndex: PropTypes.number
};

export default JWTLoginOtp;