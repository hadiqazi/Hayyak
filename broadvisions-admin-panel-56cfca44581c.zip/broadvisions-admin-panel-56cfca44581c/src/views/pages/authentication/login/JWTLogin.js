import PropTypes from 'prop-types';
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { FormattedMessage } from 'react-intl';
import TextField from '@mui/material/TextField';
import "../../../../../src/assets/css/style.css";
import ForgotPassword from "../../../forgotPassword/index.js";

// material-ui
import { makeStyles } from '@material-ui/styles';
import {

    Box,
    Button,
    Checkbox,
    FormControl,
    FormControlLabel,
    FormHelperText,
    Grid,
    IconButton,
    InputAdornment,
    InputLabel,
    OutlinedInput,
    Typography
} from '@material-ui/core';

// third party
import * as Yup from 'yup';
import { Formik } from 'formik';

// project imports
import AnimateButton from 'ui-component/extended/AnimateButton';
import useAuth from 'hooks/useAuth';
import useScriptRef from 'hooks/useScriptRef';

// assets
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import { useDispatch, useSelector } from 'react-redux';
import { Navigate } from 'react-router';

// style constant
const useStyles = makeStyles((theme) => ({
    loginInput: {
        ...theme.typography.customInput
    },
}));

// ===============================|| JWT LOGIN ||=============================== //

const JWTLogin = (props, { loginIndex, ...others }) => {
    const classes = useStyles();
    const navigate = useNavigate();
    const { login } = useAuth();
    const scriptedRef = useScriptRef();
    const [checked, setChecked] = React.useState(false);
    const [showPassword, setShowPassword] = React.useState(false);
    const [forgotPassword, setForgotPassword] = React.useState(false);
    const customization = useSelector((state) => state.customization);
    const handleClickShowPassword = () => {
        setShowPassword(!showPassword);
    };
    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };
    const handleCheck = (value) => {
        setChecked(value)
        props.handleRememberMe(value)

    }

    return (
        <Formik
            initialValues={{
                email: '',
                password: '',
                submit: null
            }}
            validationSchema={Yup.object().shape({
                email: Yup.string().email('Must be a valid email').max(255).required(<FormattedMessage id="requiredEmail" />),
                password: Yup.string().max(255).required(<FormattedMessage id="requiredPassword" />)
            })}
            onSubmit={async (values, { setErrors, setStatus, setSubmitting }) => {
                try {
                    await login(values.email, values.password);
                    if (scriptedRef.current) {
                        props.handlePass(values.email)
                        setStatus({ success: true });
                        setSubmitting(false);
                    }
                } catch (err) {
                    console.error(err);
                    if (scriptedRef.current) {
                        setStatus({ success: false });
                        setErrors({ submit: err.message });
                        setSubmitting(false);
                    }
                }
            }}
        >

            {({ errors, handleBlur, handleChange, handleSubmit, isSubmitting, touched, values }) => (
                <form noValidate onSubmit={handleSubmit} {...others}>
                    <FormControl fullWidth error={Boolean(touched.email && errors.email)} className={classes.loginInput}>

                        <TextField className='loginInput'
                            label={<FormattedMessage id="emailAddress" />}
                            id="outlined-adornment-email-login"
                            type="email"
                            value={values.email}
                            name="email"
                            //   onBlur={handleBlur}
                            onChange={handleChange}
                        />


                        {touched.email && errors.email && (
                            <FormHelperText error id="standard-weight-helper-text-email-login">
                                {' '}
                                {errors.email}{' '}
                            </FormHelperText>
                        )}
                    </FormControl>

                    <FormControl fullWidth error={Boolean(touched.password && errors.password)} className={classes.loginInput}>
                        {/* <InputLabel htmlFor="outlined-adornment-password-login">Password</InputLabel> */}
                        <IconButton className={customization.locale == "en" ? "showPassword" : "showPasswordLeft"}
                            aria-label="toggle password visibility"
                            onClick={handleClickShowPassword}
                            onMouseDown={handleMouseDownPassword}
                            edge="end"
                        >
                            {showPassword ? <Visibility /> : <VisibilityOff />}
                        </IconButton>
                        <TextField
                            className='loginInput'
                            id="outlined-adornment-password-login"
                            type={showPassword ? 'text' : 'password'}
                            value={values.password}
                            name="password"
                            // onBlur={handleBlur}
                            onChange={handleChange}

                            inputProps={{
                                classes: {
                                    notchedOutline: classes.notchedOutline
                                }
                            }}
                            label={<FormattedMessage id="password" />}
                        />
                        {touched.password && errors.password && (
                            <FormHelperText error id="standard-weight-helper-text-password-login">
                                {' '}
                                {errors.password}{' '}
                            </FormHelperText>
                        )}
                    </FormControl>
                    <Grid item xs={12} container justifyContent="space-between">
                        <Grid item xs={6}>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={checked}
                                        onChange={(event) => handleCheck(event.target.checked)}
                                        name="checked"
                                        color="primary"
                                    />
                                }
                                label={<FormattedMessage id="rememberMe" />}
                            />
                        </Grid>
                        <Grid item xs={6}>
                            <Typography sx={{ textAlign: "right", paddingTop: "10px" }}
                                variant="subtitle1"
                            // sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                            >
                                <Link to='/forgetPassword' className='forgotPassword'> {<FormattedMessage id="forgotPassword" />}</Link>
                            </Typography>
                        </Grid>
                    </Grid>

                    {errors.submit && (
                        <Box
                            sx={{
                                mt: 3
                            }}
                        >
                            <FormHelperText error> <FormattedMessage id="correctCredentials" /></FormHelperText>
                        </Box>
                    )}
                    <Box
                        sx={{
                            mt: 2
                        }}
                    >
                        <AnimateButton>
                            <Button style={{textTransform:"uppercase"}} className='loginButton' disabled={isSubmitting} fullWidth size="large" type="submit" variant="contained">
                                {<FormattedMessage id="login" />}
                            </Button>
                        </AnimateButton>
                    </Box>
                </form>
            )}
        </Formik>
    );
};

JWTLogin.propTypes = {
    loginIndex: PropTypes.number
};

export default JWTLogin;