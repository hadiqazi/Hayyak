/* eslint-disable */
import { FormattedMessage } from 'react-intl';
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';
import HorizontalBarGraph from '@chartiful/react-horizontal-bar-graph'
import useAuth from 'hooks/useAuth';
import DeleteIcon from '@material-ui/icons/Delete';
import AlertDialog from '../../../utils/alert/confirmAlert'
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import Loader from 'ui-component/Loader';
import { SNACKBAR_OPEN } from 'store/actions';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import GradeIcon from '@mui/icons-material/Grade';
import CircularProgress from '@mui/material/CircularProgress';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { baseURL, version1, propertyService } from 'defaultValues';
import Button from '@mui/material/Button';
import { useDispatch, useSelector } from 'react-redux';
import Box from '@mui/material/Box';
import Rating from '@mui/material/Rating';
import StarIcon from '@mui/icons-material/Star';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import '../../../assets/css/style.css'
import ImageList from '@mui/material/ImageList';
import Divider from '@mui/material/Divider';
import ImageListItem from '@mui/material/ImageListItem';
import {
    CardContent,
    Grid,
    IconButton,
    Typography,
} from '@material-ui/core';
import { useNavigate, useLocation } from 'react-router-dom';
import MainCard from 'ui-component/cards/MainCard';
import DeleteTwoToneIcon from '@material-ui/icons/DeleteTwoTone';
import EditTwoToneIcon from '@material-ui/icons/EditTwoTone';
import { Grade } from 'material-ui-icons';


var formatter = new Intl.NumberFormat();

const PropertyDetails = () => {
    const { state } = useLocation();
    console.log('state is', state)
    const { checkPermission } = useAuth();
    const navigate = useNavigate();
    const customization = useSelector((state) => state.customization);
    const [rows, setRows] = useState([]);
    const [ratings, setRatings] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const dispatch = useDispatch();
    const [value, setValue] = React.useState(2);
    const [open, setOpen] = useState(false);
    const [message, setMessage] = useState('');
    const [heading, setHeading] = useState('');

    const loadData = () => {
        let newArr = []
        axios({
            method: 'get',
            url: `${baseURL}/${propertyService}/${version1}/property/${state._id}`,
        }).then(res => {
            for (const [key, value] of Object.entries(res.data.property.average)) {
                newArr.push(value)
            }
            console.log('details', res.data.property)
            console.log('ratingList', newArr)
            setRatings(newArr)
            setRows(res.data.property)
            setIsLoading(false)
        }).catch(err => {
            console.error(err);
            setIsLoading(false);
        });
    }

    const handleDeleteProperty = (e) => {
        setOpen(true)
        setMessage(<FormattedMessage id="deleteMessage" />)
        setHeading(<FormattedMessage id="deleteProperty" />)
    }
    const handleEditProperty = (e) => {
        rows['lastPageNo'] = state.page
        rows['checkedPage'] = state.checkedPage

        navigate(`../../edit/${rows._id}`, { state: rows });
    }
    const handleClose = () => {
        setOpen(false);
    };
    const handlePendingReviews = () => {
        navigate('../../../reviews', { state: rows });
    }
    const handleOpen = () => {

        axios({
            method: 'delete',
            url: `${baseURL}/${propertyService}/${version1}/property/${rows._id}`,
        }).then(res => {
            if (res.status === 200) {
                loadData()
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="propertyDeleted" />,
                    variant: 'alert',
                    alertSeverity: 'success'
                });
                return;
            }
        }).catch(err => {
            console.error(err);
            setIsLoading(false);
        })
        navigate(-1);
        setOpen(false)
    };

    useEffect(() => {
        setIsLoading(true)
        loadData();
    }, []);


    if (isLoading) {
        return <Loader />;
        // return <CircularProgress />;
    }
    return (
        <>
            <MainCard content={false}>
                <Grid item container xs={12}>
                    <Grid item xs={6}>
                        <div onClick={() => navigate(-1)} className={customization.locale == "en" ? "backDiv newBackLeft" : "backDivAr newBackRight"}>
                            {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
                            {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
                            <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
                        </div>
                    </Grid>
                    {/* <Grid  item xs={6} >
                            <div style={{float:"right",display:"inline-flex"}}>
                                <div className='edit_div'> 
                            <IconButton onClick={(event) => handleEditProperty()}>
                            <EditTwoToneIcon className='edit_btn' sx={{ fontSize: '1.3rem' }} />
                            <p className='dlt_property'><FormattedMessage id="edit" /></p>
                        </IconButton></div>
                        <div className='dlt_div'>
                        <IconButton onClick={(event) => handleDeleteProperty()}>
                            <DeleteIcon className='dlt_btn' sx={{ fontSize: '1.3rem' }} />  <p className='edit_property'><FormattedMessage id="delete" /></p>
                        </IconButton>
                        </div>
                        
                        </div>
                    </Grid> */}
                </Grid>



                <Grid container item xs={12}>


                </Grid>
                <CardContent>
                    <Grid container item xs={12} >
                        <Grid className={customization.locale == "en" ? "borderRight" : "borderLeft"} container item xs={7} >


                            <Grid container item xs={8} >
                                <Grid style={{ marginBottom: "20px" }} item xs={12}>
                                    <Typography style={{ fontSize: "20px", fontWeight: "600" }} variant="h2" gutterBottom component="div">
                                        {rows?.propertyType?.name[customization.locale ? customization.locale : "en"]} {' - '}
                                        {rows?.bedType?.name[customization.locale ? customization.locale : "en"]}
                                    </Typography>
                                </Grid>
                            </Grid>

                            <Grid container item xs={8} >


                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' variant="h3" component="div">
                                        <FormattedMessage id="beds" />
                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography className='details_clr' variant="h5" style={{ marginTop: "10px" }} gutterBottom component="div">
                                        {rows?.bedType?.name[customization.locale ? customization.locale : "en"]}
                                    </Typography>
                                </Grid>
                                <Divider></Divider>
                            </Grid>

                            <Grid container item xs={8} >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' variant="h3" component="div">
                                        <FormattedMessage id="rooms" />
                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography className='details_clr' variant="h5" style={{ marginTop: "10px" }} gutterBottom component="div">
                                        {rows?.roomCount}

                                    </Typography>
                                </Grid>
                                <Divider></Divider>
                            </Grid>


                            <Grid container item xs={8} >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' variant="h3" component="div">
                                        <FormattedMessage id="propertyType" />
                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography className='details_clr' variant="h5" style={{ marginTop: "10px" }} gutterBottom component="div">
                                        {rows?.propertyType?.name[customization.locale ? customization.locale : "en"]}

                                    </Typography>
                                </Grid>
                                <Divider></Divider>
                            </Grid>



                            <Grid container item xs={8} >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' variant="h3" component="div">
                                        <FormattedMessage id="noOfGuests" />
                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography className='details_clr' variant="h5" style={{ marginTop: "10px" }} gutterBottom component="div">
                                        {rows?.guestCount}

                                    </Typography>
                                </Grid>
                                <Divider></Divider>
                            </Grid>

                            {/* <Grid container item xs={8} >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' style={{ width: "100%" }} variant="h3" component="div">
                                        <FormattedMessage id="aboutRoom" />
                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography className='details_clr' display="block" variant="h5" style={{ marginTop: "10px" }} gutterBottom component="div">
                                        {rows?.description ? rows?.description[customization.locale ? customization.locale : "en"] : null}
                                    </Typography>
                                </Grid>
                                <Divider></Divider>
                            </Grid> */}
                            <Grid container item xs={8} >
                                <Grid item xs={6} >
                                    <Typography className='details_clr_left' style={{ width: "100%", marginBottom: "10px" }} variant="h3" component="div">
                                        <FormattedMessage id="price" />
                                    </Typography>
                                </Grid>
                                <Grid item xs={6} >
                                    <Typography style={{ color: "black", marginTop: "10px" }} className='details_clr' display="block" variant="subtitle2" gutterBottom component="div">
                                        <span > {rows?.price ? formatter.format(rows.price) + ' ' + 'SAR' : null}</span><span><FormattedMessage id="night" /></span>
                                    </Typography>
                                </Grid>
                            </Grid>
                            <Grid item container xs={12} >
                                <img className='borderCover' src={rows?.coverImage} />
                            </Grid>
                            <Grid item container xs={12} >
                                <ImageList sx={{ width: 500 }} cols={7} >
                                    {rows?.images?.map((item) => (
                                        <ImageListItem key={item.uuid}>
                                            <img className='borders'
                                                src={item?.imageUrl}
                                                srcSet={item?.imageUrl}
                                                loading="lazy"
                                            />
                                        </ImageListItem>
                                    ))}
                                </ImageList>
                            </Grid>
                            <Grid item xs={12} container>
                                <Typography style={{ width: "100%", marginTop: "20px", fontSize: "20px", fontWeight: "600" }} variant="h3" component="div">
                                    <FormattedMessage id="aboutRoom" />
                                </Typography>
                                <Typography display="block" variant="h5" style={{ marginTop: "10px", color: "#909090", fontWeight: "400" }} gutterBottom component="div">
                                    {rows?.description ? rows?.description[customization.locale ? customization.locale : "en"] : null}
                                </Typography>
                            </Grid>
                            <Grid item xs={12} container>
                                <Grid item xs={10} container>
                                    <Typography style={{ width: "100%", marginTop: "20px", fontSize: "20px", fontWeight: "600" }} variant="h3" component="div">
                                        <FormattedMessage id="amenities" />
                                    </Typography>
                                    <Stack style={{ display: "inline-block", marginTop: "10px" }} spacing={1}>
                                        {rows?.amenities?.map(item =>
                                            <Chip style={{ margin: "5px", color: "black" }} label={item?.name[customization.locale ? customization.locale : "en"]} variant="outlined" />
                                        )
                                        }
                                    </Stack>
                                </Grid>
                            </Grid>

                            <Grid style={{ marginTop: "30px" }} item xs={12} container>
                                <Typography style={{ width: "100%", fontSize: "20px", fontWeight: "600" }} variant="h3" component="div">
                                    <FormattedMessage id="valueAddedServices" />
                                </Typography>

                                <table style={{ width: "100%" }}>
                                    {rows.valueAddedServices?.map(item =>
                                    (
                                        <>
                                            <tr key={item._id}>
                                                <td style={{ width: "11%" }}><img className='bordersValue' style={{ width: "60px" }} src={item?.image?.imageUrl} /></td>
                                                <td>
                                                    <p style={{ marginBottom: "8px" }} className="bold">{item.name[customization.locale ? customization.locale : "en"]}
                                                    </p>
                                                    <p style={{
                                                        margin: "0px", fontSize: " 11px",
                                                        fontweight: "400"
                                                    }}>{item.description[customization.locale ? customization.locale : "en"]}</p>
                                                </td>
                                                <td className="bolds details_clr ">{formatter.format(item.price) + ' ' + 'SAR'}</td>
                                            </tr>
                                            <Divider className='divide'></Divider>
                                        </>
                                    )
                                    )}
                                </table>
                            </Grid>
                        </Grid>
                        <Grid item xs={4} style={{ marginLeft: "", marginRight: "35px" }}>

                            <Grid item xs={12}  >
                                <div className={customization.locale == "en" ? "floatRight" : "floatLeft"} style={{ display: "inline-flex" }}>
                                    {checkPermission("UPDATE_PROPERTY") &&
                                        <div className='edit_div'>
                                            <IconButton onClick={(event) => handleEditProperty()}>
                                                <EditTwoToneIcon className='edit_btn' sx={{ fontSize: '1.3rem' }} />
                                                <p className='dlt_property'><FormattedMessage id="edit" /></p>
                                            </IconButton></div>
                                    }
                                    {checkPermission("DELETE_PROPERTY") &&
                                        <div className={customization.locale == "en" ? "marginLeft dlt_div" : "marginRight dlt_div"}>
                                            <IconButton onClick={(event) => handleDeleteProperty()}>
                                                <DeleteIcon className='dlt_btn' sx={{ fontSize: '1.3rem' }} />  <p className='edit_property'><FormattedMessage id="delete" /></p>
                                            </IconButton>
                                        </div>
                                    }

                                </div>
                            </Grid>
                            <Grid style={{ marginTop: "70px" }} item xs={12} container>
                                <Grid style={{ width: "100%", display: "inline-flex" }}>
                                    <Typography style={{ marginTop: "3px" }} variant="h3" component="div">
                                        <FormattedMessage id="reviews" />
                                    </Typography>
                                    <Typography style={{ marginLeft: "5px", marginRight: "5px" }} variant="h3" component="div">
                                        ({rows?.ratingCounts?.totalReviews})
                                        <Chip onClick={handlePendingReviews} className='pendingChip' label={`${rows?.ratingCounts?.pendingReviews} ${customization.locale === "en" ? "pending" : "ريثما"}`} variant="outlined" />
                                    </Typography>
                                </Grid>
                                <Grid item xs={0.9} style={{ marginTop: "7px" }}>
                                    <GradeIcon style={{ color: "#FFC20E" }} />
                                </Grid>
                                <Grid style={{ marginTop: "10px", float: "left" }} item xs={11}>


                                    <p className='points'>{`${Math.round(ratings[0] * 10) / 10} / 5.0`}<span style={{ marginRight: "10px", marginLeft: "10px", color: "#7A7A7A", fontSize: "14px", fontWeight: "400" }}> <FormattedMessage id="basedOn" /> {rows?.ratingCounts?.totalRatings} <FormattedMessage id="ratings" /></span></p>


                                </Grid>
                            </Grid>

                            <Grid className='listSet'>
                                <Grid item xs={10} className={customization.locale == "en" ? "ratingGraphEn" : "ratingGraphAr"}>
                                    <HorizontalBarGraph

                                        data={[ratings[5], ratings[4], ratings[3], ratings[2], ratings[1]]}
                                        barWidthPercentage={0.6}
                                        labels={['5 star', '4 star', '3 star', '2 star', '1 star']}
                                        width={350}
                                        height={200}
                                        barRadius={10}
                                        barColor='#E44057'
                                        baseConfig={{
                                            hasYAxisBackgroundLines: false,
                                            hasXAxisBackgroundLines: false,

                                            // xAxisLabelStyle: {
                                            //     rotation: 0,
                                            //     fontSize: 11,
                                            //     width: 60,
                                            //     yOffset: 4,
                                            //     xOffset: -12
                                            // },
                                            // yAxisLabelStyle: {
                                            //     rotation: 30,
                                            //     fontSize: 13,
                                            //     prefix: '$',
                                            //     position: 'bottom',
                                            //     xOffset: 15,
                                            //     yOffset: -10,
                                            //     decimals: 2,
                                            //     height: 50
                                            // }
                                        }}


                                    />
                                </Grid>
                                <Grid item xs={2}>
                                    <ul className={customization.locale == "en" ? "ratingList" : "ratingListAr"}>
                                        <li>5 <FormattedMessage id="star" /></li>
                                        <li>4 <FormattedMessage id="star" /></li>
                                        <li>3 <FormattedMessage id="star" /></li>
                                        <li>2 <FormattedMessage id="star" /></li>
                                        <li>1 <FormattedMessage id="star" /></li>
                                    </ul>
                                </Grid>
                            </Grid>

                        </Grid>
                    </Grid>

                </CardContent>
            </MainCard>
            <AlertDialog
                heading={heading}
                open={open}
                message={message}
                handleOpen={handleOpen}
                handleClose={handleClose}
            />
        </>
    );
};

export default PropertyDetails;
