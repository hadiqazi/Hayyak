import { FormattedMessage } from 'react-intl';
import 'react-confirm-alert/src/react-confirm-alert.css';
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';
import moment from 'moment';
import useAuth from 'hooks/useAuth';
import Divider from '@mui/material/Divider';
import PropTypes from 'prop-types';
import { SNACKBAR_OPEN } from 'store/actions';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import React, { useState, useEffect } from 'react';
import DateFormatter from '../../../../src/utils/date'
import axios from 'axios';
import { baseURL, version1, propertyService } from 'defaultValues';
import AlertDialog from '../../../utils/alert/confirmAlert'
import { useDispatch, useSelector } from 'react-redux';
import { makeStyles, useTheme } from '@material-ui/styles';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import '../../../assets/css/style.css'
import {
    CardContent,
    Grid,
    IconButton,
    InputAdornment,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TablePagination,
    TableRow,
    TableSortLabel,
    TextField,
    Toolbar,
    Tooltip,
    Typography,
    Button,
    Fab,
} from '@material-ui/core';
import { visuallyHidden } from '@material-ui/utils';
import AddIcon from '@material-ui/icons/AddTwoTone';
import { useNavigate, useLocation } from 'react-router-dom';
import Loader from 'ui-component/Loader';
import clsx from 'clsx';
import MainCard from 'ui-component/cards/MainCard';
import DeleteIcon from '@material-ui/icons/Delete';
import DeleteTwoToneIcon from '@material-ui/icons/DeleteTwoTone';
import SearchIcon from '@material-ui/icons/Search';
import EditTwoToneIcon from '@material-ui/icons/EditTwoTone';

const rowsInitial = [];
var formatter = new Intl.NumberFormat();

// table sort
function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}

function getComparator(order, orderBy) {
    return order === 'desc' ? (a, b) => descendingComparator(a, b, orderBy) : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
        const order = comparator(a[0], b[0]);
        if (order !== 0) return order;
        return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
}
const headCells = [
    {
        id: 'propertyName',
        numeric: false,
        label: <FormattedMessage id="propertyName" />,
        align: 'left'
    },
    {
        id: 'noOfRooms',
        numeric: false,
        label: <FormattedMessage id="noOfRooms" />,
        align: 'left'
    },
    {
        id: 'propertyType',
        numeric: false,
        label: <FormattedMessage id="propertyType" />,
        align: 'left'
    },
    {
        id: 'bedType',
        numeric: false,
        label: <FormattedMessage id="bedType" />,
        align: 'left'
    },
    {
        id: 'price',
        numeric: false,
        label: <FormattedMessage id="price" />,
        align: 'left'
    },
    {
        id: 'added-on',
        numeric: false,
        label: <FormattedMessage id="added-on" />,
        align: 'left'
    }
];

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    paper: {
        width: '100%',
        marginBottom: theme.spacing(2)
    },
    table: {
        minWidth: 750
    },
    sortSpan: visuallyHidden
}));

const useToolbarStyles = makeStyles((theme) => ({
    root: {
        padding: 0,
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(1)
    },
    highlight: {
        color: theme.palette.secondary.main
    },
    title: {
        flex: '1 1 100%'
    }
}));

// ===========================|| TABLE HEADER ||=========================== //

function EnhancedTableHead({ classes, onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort, selected }) {
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };

    return (
        <TableHead className='tableHeads'>
            <TableRow>
                {/* <TableCell padding='normal'> 
                #
              </TableCell> */}
                {numSelected <= 0 &&
                    headCells.map((headCell) => (
                        <TableCell
                            key={headCell.id}
                            align={headCell.align}
                            padding={headCell.disablePadding ? 'none' : 'normal'}
                            sortDirection={orderBy === headCell.id ? order : false}
                        >
                            <TableSortLabel
                                disabled
                                active={orderBy === headCell.id}
                                direction={orderBy === headCell.id ? order : 'asc'}
                                onClick={createSortHandler(headCell.id)}
                            >
                                {headCell.label}
                                {orderBy === headCell.id ? (
                                    <span className={classes.sortSpan}>{order === 'desc' ? 'sorted descending' : 'sorted ascending'}</span>
                                ) : null}
                            </TableSortLabel>
                        </TableCell>
                    ))}
                {numSelected <= 0 && (
                    <TableCell sortDirection={false} align="center" sx={{ pr: 3 }}>
                        <FormattedMessage id="actions" />
                    </TableCell>
                )}
            </TableRow>
        </TableHead>
    );
}

EnhancedTableHead.propTypes = {
    selected: PropTypes.array,
    classes: PropTypes.object.isRequired,
    numSelected: PropTypes.number.isRequired,
    onRequestSort: PropTypes.func.isRequired,
    onSelectAllClick: PropTypes.func.isRequired,
    order: PropTypes.oneOf(['asc', 'desc']).isRequired,
    orderBy: PropTypes.string.isRequired,
    rowCount: PropTypes.number.isRequired
};

// ===========================|| TABLE HEADER TOOLBAR ||=========================== //

const EnhancedTableToolbar = (props) => {
    const classes = useToolbarStyles();
    const { numSelected } = props;

    return (
        <Toolbar
            className={clsx(classes.root, {
                [classes.highlight]: numSelected > 0
            })}
        >
            {numSelected > 0 ? (
                <Typography className={classes.title} color="inherit" variant="h4" component="div">
                    {numSelected} Selected
                </Typography>
            ) : (
                <Typography className={classes.title} variant="h6" id="tableTitle" component="div">
                    Nutrition
                </Typography>
            )}

            {numSelected > 0 && (
                <Tooltip title="Delete">
                    <IconButton>
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </Tooltip>
            )}
        </Toolbar>
    );
};

EnhancedTableToolbar.propTypes = {
    numSelected: PropTypes.number.isRequired
};

// ===========================|| CUSTOMER LIST ||=========================== //

const PropertyListing = (props) => {
    const { state } = useLocation();
    console.log('state is ssss', state)
    const [buildingState, setBuildingState] = useState([state]);
    const classes = useStyles();
    const theme = useTheme();
    const { checkPermission } = useAuth();
    const navigate = useNavigate();
    const dispatch = useDispatch();
    console.log('naviagte', useLocation())
    const customization = useSelector((state) => state.customization);
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('calories');
    const [open, setOpen] = useState(false);
    const [message, setMessage] = useState('');
    const [heading, setHeading] = useState('');
    const [idToDelete, setIdToDelete] = useState();
    const [idToDeleteProperty, setIdToDeleteProperty] = useState();
    const [selected, setSelected] = useState([]);
    const [edit, setEdit] = useState([]);
    const [page, setPage] = useState(state?.lastPageNo ? state.lastPageNo : 0);
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [search, setSearch] = useState('');
    const [saveInfoSearch, setSaveInfoSearch] = useState([]);
    const [propertiesList, setPropertiesList] = useState(rowsInitial);
    const [isLoading, setIsLoading] = useState(false);

    const handleSearch = (event) => {
        const newString = event.target.value;
        setSearch(newString);
        setPage(0);
        let result = saveInfoSearch.filter(item => item.name[customization.locale ? customization.locale : "en"].toLowerCase().includes(event.target.value.toLowerCase()))
        setPropertiesList(result)

    };
    const handleAddProperty = () => {
        navigate(`/property/add/`, { state: buildingState._id });
    }
    const handleRequestSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const handleOpen = () => {
        if (idToDeleteProperty) {
            axios({
                method: 'delete',
                url: `${baseURL}/${propertyService}/${version1}/property/${idToDeleteProperty}`,
            }).then(res => {
                if (res.status === 200) {
                    loadData()
                    dispatch({
                        type: SNACKBAR_OPEN,
                        open: true,
                        message: <FormattedMessage id="propertyDeleted" />,
                        variant: 'alert',
                        alertSeverity: 'success'
                    });
                    return;
                }
            }).catch(err => {
                console.error(err);
                // setIsLoading(false);
            })
            setOpen(false)
            setIdToDeleteProperty()

        }
        else if (idToDelete) {
            axios({
                method: 'delete',
                url: `${baseURL}/${propertyService}/${version1}/building/${idToDelete}`,
            }).then(res => {
                if (res.status === 200) {
                    loadData()
                    dispatch({
                        type: SNACKBAR_OPEN,
                        open: true,
                        message: <FormattedMessage id="buildingDeleted" />,
                        variant: 'alert',
                        alertSeverity: 'success'
                    });
                    return;
                }
            }).catch(err => {
                console.error(err);
                // setIsLoading(false);
            })
            setOpen(false)
            setIdToDelete()
            navigate(`/buildings`);
        }
    };

    const handleDeleteBuilding = () => {
        setOpen(true)
        setMessage(<FormattedMessage id="deleteMessage" />)
        setHeading(<FormattedMessage id="deleteBuilding" />)
        setIdToDelete(state._id)

    };
    const handleEditBuilding = () => {
        navigate(`/buildings/edit/${state?._id}`, { state: state });

    };

    const handleClose = () => {
        setOpen(false);
    };

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelectedId = propertiesList.map((n) => n.name);
            setSelected(newSelectedId);
            return;
        }
        setSelected([]);
    };

    const handleEditProperty = (event, row) => {
        setEdit(row)
        row['lastPageNo'] = page
        row['checkedPage'] = true
        navigate(`/../property/edit/${row._id}`, { state: row });
    };
    const handlePropertyNavigate = (e, row) => {
        // setEdit(row)
        row['lastPageNo'] = page
        row['checkedPage'] = true
        // navigate(`/../property/edit/${row._id}`, { state: row });
        navigate(`../details/${row._id}`, { state: row });
    }

    const handleDeleteProperty = (event, id) => {
        setOpen(true)
        setMessage(<FormattedMessage id="deleteMessage" />)
        setHeading(<FormattedMessage id="deleteProperty" />)
        setIdToDeleteProperty(id)
    }
    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const isSelected = (name) => selected.indexOf(name) !== -1;

    const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - propertiesList.length) : 0;

    const loadData = () => {
        if (state?.checkedPage) {
            axios({
                method: 'get',
                url: `${baseURL}/${propertyService}/${version1}/property?buildingId=${state.building._id}`,
            }).then(res => {
                console.log('poreprt', res.data.properties)
                setPropertiesList(res.data.properties)
                setSaveInfoSearch(res.data.properties)
                setIsLoading(false)
            }).catch(err => {
                console.error(err);
                setIsLoading(false);
            });
        }
        else {
            axios({
                method: 'get',
                url: `${baseURL}/${propertyService}/${version1}/property?buildingId=${state._id}`,
            }).then(res => {
                console.log('poreprt', res.data.properties)
                setPropertiesList(res.data.properties)
                setSaveInfoSearch(res.data.properties)
                setIsLoading(false)
            }).catch(err => {
                console.error(err);
                setIsLoading(false);
            });
        }

    }

    useEffect(() => {
        setIsLoading(true)
        setBuildingState(state)
        loadData();
    }, []);

    if (isLoading) {
        return <Loader />;
    }

    return (
        <>
            <MainCard content={false}>

                <div onClick={() => navigate('../../buildings')} className={customization.locale == "en" ? "backDiv newBackLeft" : "backDivAr newBackRight"}>
                    {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
                    {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
                    <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
                </div>

                <Grid container item xs={12}>
                    <Grid item xs={6}>
                        <Typography style={{ marginBottom: "10px", marginLeft: "20px", marginRight: "20px" }} variant="h3" gutterBottom component="div">
                            {state?.checkedPage ? state?.building?.name[customization.locale ? customization.locale : "en"] : state?.name[customization.locale ? customization.locale : "en"]}

                        </Typography>
                    </Grid>

                    <Grid item xs={6} >
                        <div className={customization.locale == "en" ? "propertyBtnsRight" : "propertyBtnsLeft"} >
                            {checkPermission("UPDATE_BUILDING") && <div className='edit_div'>

                                <IconButton onClick={(event) => handleEditBuilding(event)}>
                                    <EditTwoToneIcon className='edit_btn' sx={{ fontSize: '1.3rem' }} />
                                    <p className='dlt_property'><FormattedMessage id="edit" /></p>
                                </IconButton></div>
                            }
                            {checkPermission("DELETE_BUILDING") &&
                                <div className={customization.locale == "en" ? "marginLeft dlt_div" : "marginRight dlt_div"}>
                                    <IconButton onClick={(event) => handleDeleteBuilding(event)}>
                                        <DeleteIcon className='dlt_btn' sx={{ fontSize: '1.3rem' }} />  <p className='edit_property'><FormattedMessage id="delete" /></p>
                                    </IconButton>
                                </div>
                            }

                        </div>
                    </Grid>

                </Grid>
                <Divider className='divideProperty'></Divider>

                <CardContent style={{ paddingTop: "5px" }}>
                    <Grid container justifyContent="space-between" alignItems="center" >
                        <Grid item xs={6} sm={6}>
                            <Typography
                                variant="h3"
                            >
                                {<FormattedMessage id="properties" />}
                            </Typography>
                        </Grid>
                        <Grid item xs={6} sm={6} sx={{ textAlign: 'right' }}>
                            <Grid item container xs={12}>
                                <Grid xs={7} sm={7} >
                                    {/* <Tooltip title={<FormattedMessage id="addProperty" />}> */}
                                    {checkPermission("CREATE_PROPERTY") &&
                                        <Button className='hayyak_btn_in ' onClick={handleAddProperty} variant="contained" type="submit">
                                            <AddCircleIcon className={customization.locale == "en" ? "addIcon" : "addIconArabic"} fontSize="small" />
                                            <FormattedMessage id="addProperty" />
                                        </Button>
                                    }
                                    {/* </Tooltip> */}
                                </Grid>
                                <Grid xs={5} sm={5} >
                                    <TextField
                                        className="searchbar"
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <SearchIcon fontSize="small" />
                                                </InputAdornment>
                                            )
                                        }}
                                        onChange={handleSearch}
                                        placeholder={customization.locale == "en" ? "Search Property" : "خاصية البحث"}
                                        value={search}
                                        size="small"
                                    />
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>

                </CardContent>


                {/* table */}
                <TableContainer>
                    <Table className={classes.table} aria-labelledby="tableTitle">
                        <EnhancedTableHead
                            classes={classes}
                            numSelected={selected.length}
                            order={order}
                            orderBy={orderBy}
                            onSelectAllClick={handleSelectAllClick}
                            onRequestSort={handleRequestSort}
                            rowCount={propertiesList.length}
                            selected={selected}
                        />
                        <TableBody>
                            {stableSort(propertiesList, getComparator(order, orderBy))
                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map((row, index) => {
                                    const isItemSelected = isSelected(row.name);
                                    const labelId = `enhanced-table-checkbox-${index}`;

                                    return (
                                        <TableRow
                                            role="checkbox"
                                            aria-checked={isItemSelected}
                                            tabIndex={-1}
                                            key={index}
                                            selected={isItemSelected}
                                        >

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                onClick={(e) => handlePropertyNavigate(e, row)}
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                                >
                                                    <div style={{ display: "inline-block" }}>
                                                        <img className='border' src={row.coverImage} /><span className={customization.locale == "en" ? "propertyImage" : "propertyImageArabic"}>{row.name[customization.locale ? customization.locale : "en"]}</span>
                                                    </div>

                                                </Typography>
                                                {/* <Typography variant="caption"> {row.email} </Typography> */}
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                onClick={(e) => handlePropertyNavigate(e, row)}
                                                scope="row"
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                                >

                                                    {' '}
                                                    {row.roomCount}
                                                    {' '}
                                                </Typography>
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                onClick={(e) => handlePropertyNavigate(e, row)}
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                                >
                                                    {' '}
                                                    {row.propertyType.name[customization.locale ? customization.locale : "en"]}
                                                    {/* {<Moment parse="YYYY-MM-DD HH:mm">{row.createdAt}</Moment>} */}
                                                    {' '}
                                                </Typography>
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                onClick={(e) => handlePropertyNavigate(e, row)}
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                                >
                                                    {' '}
                                                    {row.bedType.name[customization.locale ? customization.locale : "en"]}
                                                    {/* {<Moment parse="YYYY-MM-DD HH:mm">{row.createdAt}</Moment>} */}
                                                    {' '}
                                                </Typography>
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                scope="row"
                                                onClick={(e) => handlePropertyNavigate(e, row)}
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ color: theme.palette.mode === 'dark' ? theme.palette.grey[600] : 'grey.900' }}
                                                >
                                                    {' '}
                                                    {formatter.format(row.price) + ' ' + 'SAR'}{<FormattedMessage id="night" />}
                                                    {/* {<Moment parse="YYYY-MM-DD HH:mm">{row.createdAt}</Moment>} */}
                                                    {' '}
                                                </Typography>
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell
                                                component="th"
                                                id={labelId}
                                                onClick={(e) => handlePropertyNavigate(e, row)}
                                                scope="row"
                                                // onClick={(event) => handleClick(event, row.name)}
                                                sx={{ cursor: 'pointer' }}
                                            >
                                                <DateFormatter date={row.createdAt} />
                                                <Typography variant="caption"> {row.email} </Typography>
                                            </TableCell>

                                            <TableCell align="center" sx={{ pr: 3 }}>
                                                {checkPermission("UPDATE_PROPERTY") &&
                                                    <IconButton className='edit_btn' color="primary" onClick={(event) => handleEditProperty(event, row)}>
                                                        <EditTwoToneIcon sx={{ fontSize: '1.3rem' }} />
                                                    </IconButton>
                                                }
                                                {checkPermission("DELETE_PROPERTY") &&
                                                    <IconButton className='dlt_btn' color="secondary" onClick={(event) => handleDeleteProperty(event, row._id)}>
                                                        <DeleteIcon sx={{ fontSize: '1.3rem' }} />
                                                    </IconButton>
                                                }
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                            {emptyRows > 0 && (
                                <TableRow
                                    style={{
                                        height: 53 * emptyRows
                                    }}
                                >
                                    <TableCell colSpan={6} />
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>

                {/* table pagination */}
                <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    component="div"
                    count={propertiesList.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </MainCard>
            <AlertDialog
                heading={heading}
                open={open}
                message={message}
                handleOpen={handleOpen}
                handleClose={handleClose}
            />
        </>
    );
};

export default PropertyListing;
