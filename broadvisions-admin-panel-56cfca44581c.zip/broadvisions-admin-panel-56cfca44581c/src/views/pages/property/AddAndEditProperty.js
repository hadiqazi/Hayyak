import React, { useEffect, useState, useRef } from 'react';
import ReactDOM from "react-dom";
import { isEqual } from "lodash";
import Loader from 'ui-component/Loader';
import Checkbox from '@mui/material/Checkbox';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Divider } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import Typography from '@mui/material/Typography';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import AlertDialog from '../../../utils/alert/confirmAlert'
import CircularProgress from '@mui/material/CircularProgress';
import IconButton from '@mui/material/IconButton';
import PhotoCamera from '@mui/icons-material/PhotoCamera';
import { styled } from '@mui/material/styles';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import AddIcon from '@mui/icons-material/Add';
import _ from 'lodash';
import { DataGrid } from '@mui/x-data-grid';
import '../../../assets/css/style.css'
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';
import {
    Button, Grid, TextField, Stack
} from '@material-ui/core';
import MainCard from 'ui-component/cards/MainCard';
import { gridSpacing } from 'store/constant';
import AnimateButton from 'ui-component/extended/AnimateButton';
import { useFormik } from 'formik';
import { SNACKBAR_OPEN } from 'store/actions';
import axios from 'axios';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { baseURL, version1, propertyService } from 'defaultValues';
import { FormattedMessage } from 'react-intl';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import "../../../../src/assets/css/style.css"

const rowsInitial = [];
const Input = styled('input')({
    display: 'none',
});
var formatter = new Intl.NumberFormat();
var customValueAddedServices = [];
var fileObj = [];
var fileArray = [];
var galleryImages = [];
var customDelete = [];


const PropertyEdit = () => {

    const { state } = useLocation();
    console.log('sttae is', state)
    const [coverImage, setCoverImage] = useState(null)
    const [file, setFile] = useState([null])
    const customization = useSelector((state) => state.customization);
    const [loading, setLoading] = React.useState(false);
    const { propertyId } = useParams();
    const [amenitiesData, setAmenitiesData] = useState(rowsInitial);
    const [valueAddedServices, setValueAddedServices] = useState(rowsInitial);
    const [open, setOpen] = useState(false);
    const [message, setMessage] = useState('');
    const [heading, setHeading] = useState('');
    const [selectedRoom, setSelectedRoom] = React.useState('');
    const [roomChange, setRoomChange] = React.useState('');
    const [propertyType, setPropertyType] = React.useState([]);
    const [gallery, setGallery] = React.useState([]);
    const [deleteEmailIds, setDeleteEmailIds] = React.useState([]);
    const [roomsNumber, setRoomsNumber] = React.useState([]);
    const [selectedAmenities, setSelectedAmenities] = React.useState([]);
    const [selectedValueAddedServices, setSelectedValueAddedServices] = React.useState();
    const [roomData, setRoomData] = React.useState([]);
    const [bedType, setBedType] = React.useState([]);
    const [imagePath, setImagePath] = React.useState();
    const [galleryImagePath, setGalleryImagePath] = React.useState(null);
    const [english, setEnglish] = React.useState(true);
    const [checkedState, setCheckedState] = useState(
        new Array(selectedValueAddedServices?.length).fill([false])
    );

    const [total, setTotal] = useState(0);
    const [arabic, setArabic] = React.useState(false);
    const [value, setValue] = React.useState('1');
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [lastPage, setLastPage] = React.useState(state?.lastPageNo);
    const [errorPropertyName, setErrorPropertyName] = React.useState(false);
    const [errorPpropertyNameArabic, setErrorPropertyNameArabic] = React.useState(false);
    const [errorAboutProperty, setErrorAboutProperty] = React.useState(false);
    const [errorAboutPropertyArabic, setErrorAboutPropertyArabic] = React.useState(false);
    const [errorPrice, setErrorPrice] = React.useState(false);
    const [errorNoOfGuests, setErrorNoOfGuests] = React.useState(false);
    const [errorPropertyType, setErrorPropertyType] = React.useState(false);
    const [errorBedtype, setErrorBedType] = React.useState(false);
    const [errorCoverImage, setErrorCoverImage] = React.useState(false);
    const [errorGalleryImages, setErrorGalleryImages] = React.useState(false);
    const [errorAmenities, setErrorAmenities] = React.useState(false);
    const [errorValueAddedServices, setErrorValueAddedServices] = React.useState(false);
    const [errorRooms, setErrorRooms] = React.useState(false)



    const columns = [
        { field: [customization.locale == "en" ? "nameEn" : "nameAr"], flex: 1, headerName: 'Amenities' }
    ];
    const valueColumns = [
        { field: [customization.locale == "en" ? "nameEn" : "nameAr"], headerName: 'Value Added Services' },
        { field: 'price', headerName: 'Price' },

    ];

    const formik = useFormik({
        initialValues: {
            propertyName: propertyId ? state?.name.en : '',
            propertyNameArabic: propertyId ? state?.name.ar : '',
            aboutProperty: propertyId ? state?.description.en : '',
            aboutPropertyArabic: propertyId ? state?.description.ar : '',
            price: propertyId ? state?.price : '',
            noOfGuests: propertyId ? state?.guestCount : '',
            propertyType: propertyId ? state?.propertyType._id : '',
            beds: propertyId ? state?.bedType._id : '',

        },
        enableReinitialize: true,
        onSubmit: values => {
            var letters = /^[0-9]*$/;
            var roomLetter = /^[A-Za-z0-9].*$/;

            if (!state?.coverImage && coverImage == null ||
                file[0] == null && !state?.images ||
                selectedAmenities.length === 0 ||
                customValueAddedServices.length === 0 ||
                values.propertyName.length === 0 || (values.propertyName.match(letters))
                || values.propertyNameArabic.length === 0 || (values.propertyNameArabic.match(letters)) ||
                values.aboutProperty.length === 0 || values.aboutPropertyArabic.length === 0 ||
                (values.price.length === 0 || values.price < 1) || (values.noOfGuests.length === 0 || values.noOfGuests < 1) ||
                values.propertyType.length === 0 || values.beds.length === 0 ||
                (!selectedRoom && (typeof state !== 'object') || (selectedRoom && !selectedRoom.match(roomLetter)))
            ) {
                if (!selectedRoom || (!selectedRoom.match(roomLetter))) {

                    if (!selectedRoom && (typeof state !== 'object')) {


                        setErrorRooms(<FormattedMessage id="roomsRequired" />)

                    }

                    else if ((!selectedRoom.match(roomLetter) && (typeof state !== 'object'))) {
                        setErrorRooms(<FormattedMessage id="invalidRoomNumber" />)
                    }
                    else {
                        setErrorRooms(false)
                    }

                }
                else {
                    setErrorRooms(false)
                }
                if (customValueAddedServices.length === 0) {
                    setErrorValueAddedServices(<FormattedMessage id="valueAddedServicesRequired" />)
                }
                else {
                    setErrorValueAddedServices(false)
                }
                if (selectedAmenities.length === 0) {
                    setErrorAmenities(<FormattedMessage id="amenitiesRequired" />)
                }
                else {
                    setErrorAmenities(false)
                }

                if (!state?.coverImage && coverImage == null) {
                    setErrorCoverImage(<FormattedMessage id="coverImage" />)
                }
                else {
                    setErrorCoverImage(false)
                }
                if (file[0] == null && !state?.images) {
                    setErrorGalleryImages(<FormattedMessage id="galleryImages" />)
                }
                else {
                    setErrorGalleryImages(false)
                }

                if (values.propertyName || (values.propertyName.match(letters))) {
                    if (values.propertyName.length === 0) {


                        setErrorPropertyName(<FormattedMessage id="propertyNameRequired" />)

                    }

                    else if ((values.propertyName.match(letters))) {
                        setErrorPropertyName(<FormattedMessage id="validPropertyNameRequired" />)
                    }
                    else {
                        setErrorPropertyName(false)
                    }
                }

                if (values.propertyNameArabic || (values.propertyNameArabic.match(letters))) {
                    if (values.propertyNameArabic.length === 0) {


                        setErrorPropertyNameArabic(<FormattedMessage id="propertyNameRequired" />)

                    }

                    else if ((values.propertyNameArabic.match(letters))) {
                        setErrorPropertyNameArabic(<FormattedMessage id="validPropertyNameRequired" />)
                    }
                    else {
                        setErrorPropertyNameArabic(false)
                    }
                }

                if (values.aboutProperty.length === 0) {
                    setErrorAboutProperty(<FormattedMessage id="descriptionRequired" />)
                }
                else {
                    setErrorAboutProperty(false)
                }
                if (values.aboutPropertyArabic.length === 0) {
                    setErrorAboutPropertyArabic(<FormattedMessage id="descriptionRequired" />)
                }
                else {
                    setErrorAboutPropertyArabic(false)
                }
                if (values.price || values.price < 1) {
                    if (values.price.length === 0) {
                        setErrorPrice(<FormattedMessage id="priceRequired" />)
                    }
                    else if (values.price < 1) {
                        setErrorPrice(<FormattedMessage id="invalidNumber" />)
                    }
                    else {
                        setErrorPrice(false)
                    }
                }
                if (values.noOfGuests || values.noOfGuests < 1) {
                    if (values.noOfGuests.length === 0) {
                        setErrorNoOfGuests(<FormattedMessage id="noOfGuestsRequired" />)
                    }
                    else if (values.noOfGuests < 1) {
                        setErrorNoOfGuests(<FormattedMessage id="invalidNumber" />)
                    }
                    else {
                        setErrorNoOfGuests(false)
                    }
                }
                if (values.propertyType.length === 0) {
                    setErrorPropertyType(<FormattedMessage id="propertyTypeRequired" />)
                }
                else {
                    setErrorPropertyType(false)
                }
                if (values.beds.length === 0) {
                    setErrorBedType(<FormattedMessage id="bedTypeRequired" />)
                }
                else {
                    setErrorBedType(false)
                }
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="allFields" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
                if (values.propertyName.match(letters) ||
                    values.propertyNameArabic.match(letters) || (!selectedRoom.match(roomLetter))) {
                    return
                }
                return;
            }
            let formData = createObj(values)

            if (state && propertyId) {
                axios({
                    method: 'put',
                    url: `${baseURL}/${propertyService}/${version1}/property/${propertyId}`,
                    data: formData,
                    headers: { "Content-Type": "multipart/form-data" },

                }).then(res => {
                    if (res.status === 200) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: <FormattedMessage id="propertyUpdated" />,
                            variant: 'alert',
                            alertSeverity: 'success'
                        });
                        navigate(`/../../property/${state.building._id}`, { state: state })
                        return;
                    }
                }).catch((error) => {
                    console.error(error.response)
                    if (error.response && error.response.data.status && error.response.data.message) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: error.response.data.message,
                            variant: 'alert',
                            alertSeverity: 'error'
                        });
                        return;
                    }
                    dispatch({
                        type: SNACKBAR_OPEN,
                        open: true,
                        message: <FormattedMessage id="errorMessage" />,
                        variant: 'alert',
                        alertSeverity: 'error'
                    });
                    return;
                })
            }
            else {
                axios({
                    method: 'post',
                    url: `${baseURL}/${propertyService}/${version1}/property/`,
                    data: formData,
                    headers: { "Content-Type": "multipart/form-data" },
                }).then(res => {
                    if (res.status === 201) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: <FormattedMessage id="propertySaved" />,
                            variant: 'alert',
                            alertSeverity: 'success'
                        });

                        navigate(-1);
                        return;
                    }
                }).catch((error) => {
                    console.error(error.response)
                    if (error.response && error.response.data.status && error.response.data.message) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: error.response.data.message,
                            variant: 'alert',
                            alertSeverity: 'error'
                        });
                        return;
                    }
                    dispatch({
                        type: SNACKBAR_OPEN,
                        open: true,
                        message: <FormattedMessage id="errorMessage" />,
                        variant: 'alert',
                        alertSeverity: 'error'
                    });
                    return;
                })

            }
        }
    });
    const createObj = (values) => {
        let rooms = []
        if (roomsNumber) {
            roomsNumber.forEach(element => {
                let obj = {
                    number: element.number
                }
                rooms.push(obj)
            });
        }
        if (selectedRoom) {

            let obj = {
                number: selectedRoom
            }
            rooms.push(obj)
        }
        let name = {
            "en": values.propertyName,
            "ar": values.propertyNameArabic,

        }
        let description = {
            "en": values.aboutProperty,
            "ar": values.aboutPropertyArabic,
        }
        let formData = new FormData();
        if (state && propertyId) {
            formData.append('name', JSON.stringify(name));
            formData.append('description', JSON.stringify(description));
            formData.append('price', values.price);
            formData.append('propertyType', values.propertyType);
            formData.append('buildingId', state._id);
            formData.append('bedType', values.beds);
            formData.append('amenities', JSON.stringify(selectedAmenities));
            formData.append('valueAddedServices', JSON.stringify(selectedValueAddedServices));
            formData.append('guestCount', values.noOfGuests);
            if (imagePath) {
                formData.append('coverImage', imagePath)
            }
            if (galleryImages) {
                for (let i = 0; i < galleryImages.length; i++) {
                    formData.append('images', galleryImages[i]);
                }
            }
        }
        else {
            formData.append('name', JSON.stringify(name));
            formData.append('description', JSON.stringify(description));
            formData.append('price', values.price);
            formData.append('propertyTypeId', values.propertyType);
            formData.append('buildingId', state);
            formData.append('bedTypeId', values.beds);
            formData.append('rooms', JSON.stringify(rooms))
            formData.append('amenities', JSON.stringify(selectedAmenities));
            formData.append('valueAddedServices', JSON.stringify(selectedValueAddedServices));
            formData.append('guestCount', values.noOfGuests);
            formData.append('coverImage', imagePath);
            for (let i = 0; i < galleryImages.length; i++) {
                formData.append('images', galleryImages[i]);
            }
        }

        return formData
    }

    const handleArabic = () => {
        setArabic(true)
        setEnglish(false)
    }

    const uploadImage = (event) => {
        if (event.target.files && event.target.files[0]) {
            setCoverImage(URL.createObjectURL(event.target.files[0]));
            let path = event.target.files[0]
            setImagePath(path)
        }
    }
    const handleChangeTab = (event, newValue) => {
        setValue(newValue);
        if (newValue === '1') {
            setArabic(false)
            setEnglish(true)
        }
        else if (newValue === '2') {
            setArabic(true)
            setEnglish(false)
        }
    };
    const handleChange = (event, position, id) => {
        if (event.target.checked == true) {
            customValueAddedServices.push(id)



        }
        else {

            for (let i = 0; i < customValueAddedServices.length; i++) {
                if (customValueAddedServices[i] == id) {
                    const index = customValueAddedServices.indexOf(customValueAddedServices[i]);
                    if (index > -1) {
                        customValueAddedServices.splice(index, 1);
                    }
                }
            }
        }
        const updatedCheckedState = checkedState.map((item, index) =>
            index === position ? !item : item
        );
        setCheckedState(updatedCheckedState);
        setSelectedValueAddedServices(customValueAddedServices)

    };

    const uploadGalleryImages = (e) => {
        if (e.target.files.length > 1) {
            fileObj = []
            fileObj.push(e.target.files)
            for (let i = 0; i < fileObj[0].length; i++) {
                fileArray?.push(URL?.createObjectURL(fileObj[0][i]))
                let path = e.target.files[i]
                galleryImages.push(path)
                setGalleryImagePath(path)
            }
            setFile(fileArray)
        }
        else {
            fileObj = []
            fileObj?.push(e.target.files[0])
            fileArray?.push(URL?.createObjectURL(fileObj[0]))
            let path = e.target.files[0]
            fileObj = []
            galleryImages.push(path)
            setGalleryImagePath(path)
            setFile(fileArray)
        }
    }

    const handleEnglish = () => {
        setArabic(false)
        setEnglish(true)
    }
    const handleDeleteFirst = () => {
        setSelectedRoom('')

    }
    const handleDeleteRoom = (id) => {

        setOpen(true)
        setMessage((<FormattedMessage id="deleteMessage" />))
        setHeading(<FormattedMessage id="deleteRoom" />)

        customDelete.push(id)
        setDeleteEmailIds(customDelete)
    }
    const handleCreateRoom = () => {
        var roomLetter = /^[0-9]|([^0-9a-zA-Z]+)$/;
        for (let i = 0; i < roomsNumber.length; i++) {
            if (roomsNumber[i].number == selectedRoom) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="duplicateRoom" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
                return;
            }
        }

        if (!selectedRoom || (!selectedRoom.match(roomLetter))) {

            if (!selectedRoom) {

                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="roomsRequired" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
            }
            else if (!(selectedRoom.match(roomLetter))) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="invalidRoomNumber" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
            }
            //             else if (roomsNumber.includes(selectedRoom))
            //             {
            //                 dispatch({
            //                     type: SNACKBAR_OPEN,
            //                     open: true,
            //                     message: <FormattedMessage id="duplicate" />,
            //                     variant: 'alert',
            //                     alertSeverity: 'success'
            //                 });
            // return
            //             }
            else {
                setErrorRooms(false)
            }
            return
        }
        let obj = {
            "number": selectedRoom,
            "propertyId": state._id
        }
        axios({
            method: 'post',
            url: `${baseURL}/${propertyService}/${version1}/room/`,
            data: obj,
        }).then(res => {
            if (res.status === 201) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="createdRoom" />,
                    variant: 'alert',
                    alertSeverity: 'success'
                });

                loadRooms()
                let array = [];
                array = roomsNumber ?? []

                array.push({
                    "id": _.uniqueId(),
                    "number": selectedRoom,
                })
                array?.concat(
                    <tr>
                        <td>
                            <TextField

                                fullWidth
                                name="room"
                                // label={<FormattedMessage id="room" />}
                                placeholder={customization.locale == "en" ? "room" :"مجال"}
                                defaultValue={selectedRoom}
                                onChange={(e) => setSelectedRoom(e.target.value)}

                            />
                        </td>
                    </tr>
                );

                setRoomsNumber(array)
                setSelectedRoom('')
                return;
            }
        }).catch((error) => {
            console.error(error.response)
            if (error.response && error.response.data.status && error.response.data.message) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: error.response.data.message,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
                return;
            }
            dispatch({
                type: SNACKBAR_OPEN,
                open: true,
                message: 'Error sending request.',
                variant: 'alert',
                alertSeverity: 'error'
            });
            return;
        })
    }
    const handleUpdateRoom = (id) => {
        var roomLetter = /^[A-Za-z0-9].*$/;
        for (let i = 0; i < roomsNumber.length; i++) {
            if (roomsNumber[i].number == roomChange.number) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="duplicateRoom" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
                return;
            }
        }

        if (roomChange === "") {
            dispatch({
                type: SNACKBAR_OPEN,
                open: true,
                message: <FormattedMessage id="pleaseUpdateRoom" />,
                variant: 'alert',
                alertSeverity: 'error'
            });
            return
        }

        else if (!roomChange?.number?.match(roomLetter)) {
            dispatch({
                type: SNACKBAR_OPEN,
                open: true,
                message: <FormattedMessage id="invalidRoomNumber" />,
                variant: 'alert',
                alertSeverity: 'error'
            });
            return
        }

        axios({
            method: 'put',
            url: `${baseURL}/${propertyService}/${version1}/room/${id}`,
            data: roomChange,
        }).then(res => {
            if (res.status === 200) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="updatedRoom" />,
                    variant: 'alert',
                    alertSeverity: 'success'
                });
                setRoomChange('')
                return;
            }
        }).catch((error) => {
            console.error(error.response)
            if (error.response && error.response.data.status && error.response.data.message) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: error.response.data.message,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
                return;
            }
            dispatch({
                type: SNACKBAR_OPEN,
                open: true,
                message: 'Error sending request.',
                variant: 'alert',
                alertSeverity: 'error'
            });
            return;
        })
    }
    const handleOpen = () => {
        if (deleteEmailIds.length >= 1) {
            if (typeof state === 'object') {
                let data = roomsNumber.filter(item => item._id != customDelete[0])
                setOpen(false)
                setRoomsNumber(data)
                setDeleteEmailIds([])

                axios({
                    method: 'delete',
                    url: `${baseURL}/${propertyService}/${version1}/room/${customDelete[0]}`,
                    headers: { "Content-Type": "multipart/form-data" },
                }).then(res => {
                    if (res.status === 200) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: <FormattedMessage id="roomDeleted" />,
                            variant: 'alert',
                            alertSeverity: 'success'
                        });
                        return;
                    }
                }).catch((error) => {
                    console.error(error.response)
                    if (error.response && error.response.data.status && error.response.data.message) {
                        dispatch({
                            type: SNACKBAR_OPEN,
                            open: true,
                            message: error.response.data.message,
                            variant: 'alert',
                            alertSeverity: 'error'
                        });
                        return;
                    }
                    dispatch({
                        type: SNACKBAR_OPEN,
                        open: true,
                        message: 'Error sending request.',
                        variant: 'alert',
                        alertSeverity: 'error'
                    });
                    return;
                })
            }

            else {
                let data = roomsNumber.filter(item => parseInt(item.id) != parseInt(customDelete[0]))
                setOpen(false)
                setRoomsNumber(data)
                setDeleteEmailIds([])
            }
            customDelete = []
        }
    }

    const handleClose = () => {
        setOpen(false)
    }
    const onRoomChange = (e) => {
        let obj = {
            "number": e.target.value
        }
        setRoomChange(obj)
    }
    const handleNewRow = () => {
        let array = [];
        array = roomsNumber ?? []

        for (let i = 0; i < roomsNumber.length; i++) {
            if (roomsNumber[i].number == selectedRoom) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="duplicateRoom" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
                return;
            }
        }

        if (!selectedRoom || selectedRoom < 1) {

            if (!selectedRoom) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="roomFirst" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
            }
            else if (selectedRoom < 1) {
                dispatch({
                    type: SNACKBAR_OPEN,
                    open: true,
                    message: <FormattedMessage id="invalidNumber" />,
                    variant: 'alert',
                    alertSeverity: 'error'
                });
            }
            else {
                return
            }
            return
        }
        array.push({
            "id": parseInt(_.uniqueId()),
            "number": selectedRoom,
        })
        array?.concat(
            <tr>
                <td>
                    <TextField

                        fullWidth
                        name="room"
                        label={<FormattedMessage id="room" />}
                        placeholder={customization.locale == "en" ? "room" :"مجال"}
                        defaultValue={selectedRoom}
                        onChange={(e) => setSelectedRoom(e.target.value)}

                    />
                </td>
            </tr>
        );
        setRoomsNumber(array)
        setSelectedRoom('')
    }
    const loadValueAddedData = () => {
        setLoading(true)
        let newArray = []
        newArray = axios({
            method: 'get',
            url: `${baseURL}/${propertyService}/${version1}/value-added-service`,
        })
            .catch(err => {
                console.error(err);
                setLoading(false)

            });
        return newArray

    }
    const loadAmenitiesData = () => {
        setLoading(true)
        let newArray = []
        newArray = axios({
            method: 'get',
            url: `${baseURL}/${propertyService}/${version1}/amenity`,
        })

            .catch(err => {
                console.error(err);
                setLoading(false)

            });
        return newArray
    }

    const loadPropertyTypes = () => {
        axios({
            method: 'get',
            url: `${baseURL}/${propertyService}/${version1}/property-type`,
        }).then(res => {

            setPropertyType(res.data.propertyTypes)
            // setIsLoading(false)
        }).catch(err => {
            console.error(err);
            // setIsLoading(false);
        });

    }

    const loadBedTypes = () => {

        axios({
            method: 'get',
            url: `${baseURL}/${propertyService}/${version1}/Bed-type`,
        }).then(res => {

            setBedType(res.data.bedTypes)
            // setIsLoading(false)
        }).catch(err => {
            console.error(err);
            // setIsLoading(false);
        });
    }
    const loadSelection = () => {
        let selectedAmenities = []
        state?.amenities?.forEach(element => {
            selectedAmenities.push(element._id)
        });
        setSelectedAmenities(selectedAmenities)
        if (propertyId && state?.coverImage) {
            setCoverImage(state?.coverImage)
        }
        if (propertyId) {
            state?.images?.forEach(element => {
                fileArray.push(element.imageUrl)
            });
            setGallery(fileArray)
        }
    }
    const loadRooms = () => {
        axios({
            method: 'get',
            url: `${baseURL}/${propertyService}/${version1}/room?propertyId=${propertyId}`,
        }).then(res => {
            setRoomsNumber(res.data.rooms)
            // setIsLoading(false)
        }).catch(err => {
            console.error(err);
            // setIsLoading(false);
        });
    }

    useEffect(() => {

        return () => {
            fileArray = []
            galleryImages = []
            customValueAddedServices = []
        }
    }, [])
    useEffect(() => {

        if (propertyService) {
            loadRooms();
        }
    }, []);
    useEffect(() => {
        loadSelection();
    }, []);
    useEffect(() => {
        let changeAmenitiesData = []
        let changeValueAddedData = []
        let amenitiesData = []

        if (typeof state !== 'object') {
            fileArray = []
        }
        loadPropertyTypes();
        loadBedTypes();
        async function fetchData() {
            changeAmenitiesData = await loadAmenitiesData();
            changeValueAddedData = await loadValueAddedData();

            changeAmenitiesData?.data?.amenities?.forEach(element => {
                let obj = {
                    id: element._id,
                    nameEn: element?.name?.en,
                    nameAr: element?.name?.ar
                }
                amenitiesData.push(obj)
            });

            let selectedValueAddedServices = []
            if (typeof state == 'object') {
                state?.valueAddedServices?.forEach(element => {
                    selectedValueAddedServices.push(element._id)
                    customValueAddedServices.push(element._id)
                });
                changeValueAddedData?.data?.valueAddedServices.forEach(element => {
                    element['check'] = selectedValueAddedServices.includes(element._id);
                });
            }
            setSelectedValueAddedServices(selectedValueAddedServices)
            setCheckedState(changeValueAddedData.data.valueAddedServices.map(a => a.check))
            setValueAddedServices(changeValueAddedData.data.valueAddedServices)
            setAmenitiesData(amenitiesData)
            setLoading(false)
        }
        fetchData()
    }, []);

    if (loading) {
        return <Loader />;
        // return <CircularProgress />;
    }
    return (
        <>
            <MainCard className='propertyMain'>
                {state?.checkedPage ?
                    <>
                        <div onClick={() => navigate(`/../../property/${state.building._id}`, { state: state })} className={customization.locale == "en" ? "backDiv" : "backDivAr"}>
                            {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
                            {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
                            <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
                        </div></> :
                    <div onClick={() => navigate(-1)} className={customization.locale == "en" ? "backDiv" : "backDivAr"}>
                        {customization.locale == 'en' && <p ><ArrowBackIcon color="black" /></p>}
                        {customization.locale == 'ar' && <p ><ArrowForwardIcon color="black" /></p>}
                        <p className={customization.locale == "en" ? "back" : "backAr"}><FormattedMessage id="back" /></p>
                    </div>

                }
                <Typography style={{ marginBottom: "15px" }} variant="h3" gutterBottom component="div">
                    {propertyId ? <FormattedMessage id="property-page-title-update" /> :
                        <FormattedMessage id="propertyNew" />
                    }
                </Typography>


<form onSubmit={formik.handleSubmit}>
    <Grid item xs ={12} style={{display:"inline-flex"}}>
        <>
        <Grid item xs={8} style={{float:"left"}}>
                <div className='formProperty'>
                    
                <Box sx={{ width: '100%', typography: 'body1' }}>
                    <TabContext value={value}>
                        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                            <TabList onChange={handleChangeTab} aria-label="lab API tabs example">
                                <Tab label={<FormattedMessage id="englishTab" />} value="1" />
                                <Tab label={<FormattedMessage id="arabicTab" />} value="2" />
                            </TabList>
                        </Box>
                    </TabContext>
                </Box>
                <Divider style={{marginBottom:"30px"}} className='dividers'></Divider>

              
                  
                                {english && <>
                                    <Grid className="left" item xs={12}>
                                        <TextField
                                       className='propertyName'
                                            
                                            fullWidth
                                            id="propertyName"
                                            name="propertyName"
                                            label={<FormattedMessage id="propertyName" />}
                                            placeholder={customization.locale == "en" ? "Property Name" : "اسم الخاصية"}
                                            defaultValue={formik.values.propertyName}
                                            onChange={formik.handleChange}
                                            error={errorPropertyName}
                                            helperText={errorPropertyName}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </Grid>
                                    <Grid className="left" item xs={12}>
                                        <TextField
                                            id="outlined-multiline-static"
                                            label={<FormattedMessage id="aboutProperty" />}
                                            
                                            rows={4}
                                            fullWidth
                                            name="aboutProperty"
                                            placeholder={customization.locale == "en" ? "About Property" : "حول الخاصية"}
                                            defaultValue={formik.values.aboutProperty}
                                            onChange={formik.handleChange}
                                            error={errorAboutProperty}
                                            helperText={errorAboutProperty}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </Grid>
                                </>}

                                {arabic && <> <Grid className="left" item xs={12}>
                                    <TextField
                                        fullWidth
                                        className='propertyName'
                                        id="propertyNameArabic"
                                        name="propertyNameArabic"
                                        label={<FormattedMessage id="propertyName" />}
                                        placeholder={customization.locale == "en" ? "Property Name" : "اسم الخاصية"}
                                        defaultValue={formik.values.propertyNameArabic}
                                        onChange={formik.handleChange}
                                        error={errorPpropertyNameArabic}
                                        helperText={errorPpropertyNameArabic}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                    />
                                </Grid>
                                    <Grid className="left" item xs={12}>
                                        <TextField
                                            id="outlined-multiline-static"
                                            label={<FormattedMessage id="aboutProperty" />}
                                            
                                            rows={4}
                                            fullWidth
                                            name="aboutPropertyArabic"
                                            placeholder={customization.locale == "en" ? "About Property" : "حول الخاصية"}
                                            defaultValue={formik.values.aboutPropertyArabic}
                                            onChange={formik.handleChange}
                                            error={errorAboutPropertyArabic}
                                            helperText={errorAboutPropertyArabic}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </Grid>
                                </>}
                            
                                </div>
                               
                              
                            
                                <Grid item xs={12}>
                                    <Grid style={{ paddingBottom: "20px", paddingLeft: "none" ,marginTop:"20px"}} item xs={6}>
                                        <Typography variant="h4" gutterBottom component="div" style={{marginBottom:"10px"}}>
                                            <FormattedMessage id="cover" />
                                        </Typography>
                                        <div style={{ display: "inline-flex" }}>
                                            {coverImage &&
                                                <img className={customization.locale == "en" ? "marginRight" : "marginLeft"}  style={{ width: "80px",height:"75px" }} src={coverImage} alt="..." />}
                                            <div className='uploadDiv'>
                                                <div className={customization.locale == "en" ? "iconAdd" : "iconAddArabic"}>
                                                    <label htmlFor="icon-button-file"> 
                                                        <Input accept="image/*" id="icon-button-file" type="file" onChange={uploadImage} />
                                                        <IconButton color="primary"  component="span">
                                                            <AddIcon className='uploads' />

                                                        </IconButton>
                                                       
                                                    </label>
                                                </div>

                                                <Typography className={customization.locale == "en" ? "uploadLabel" : "uploadLabelArabic"} variant="subtitle" gutterBottom > <FormattedMessage id="upload" /></Typography>
                                            </div>
                                        </div>
                                        {/* <label htmlFor="icon-button-file">
                                            <Input accept="image/*" id="icon-button-file" type="file" onChange={uploadImage} />
                                            
                                            <IconButton color="primary" aria-label="upload picture" component="span">
                                                <PhotoCamera />
                                            </IconButton>
                                        </label> */}
                                        {errorCoverImage && <Typography className="validationError" variant="body1" gutterBottom >{errorCoverImage}</Typography>}
                                    </Grid>
                                </Grid>

                                <Grid item xs={12}>
                                    <Grid style={{ paddingBottom: "20px", paddingLeft: "none" }} item xs={12}>
                                        <Typography variant="h4" gutterBottom component="div">
                                            <FormattedMessage id="gallery" />
                                        </Typography>
                                        <div style={{ display: "inline-block" }}>
                                            {(fileArray || []).map(url => (
                                                <img className={customization.locale == "en" ? "marginRight" : "marginLeft"} style={{ width: "80px",height:"60px" }} src={url} alt="..." />
                                            ))}

                                            <div className='uploadDivGallery'>
                                                <div className={customization.locale == "en" ? "iconAddGallery" : "iconAddGalleryArabic"}>
                                                    <label htmlFor="contained-button">
                                                        <Input multiple accept="image/*" id="contained-button" type="file" onChange={uploadGalleryImages} />
                                                        <IconButton aria-label="upload picture" component="span">
                                                            <AddIcon className='uploadsGallery' />

                                                        </IconButton>

                                                    </label>
                                                </div>
                                            </div>
                                        </div>



                                        {/* <label htmlFor="contained-button">
                                            <Input multiple accept="image/*" id="contained-button" type="file" onChange={uploadGalleryImages} />
                                            <IconButton color="primary" aria-label="upload picture" component="span">
                                                <PhotoCamera />
                                            </IconButton>
                                        </label> */}
                                        {errorGalleryImages && <Typography className="validationError" variant="body1" gutterBottom >{errorGalleryImages}</Typography>}
                                    </Grid>
                                </Grid>

                                <Grid className='proBeds' container item xs={12}>
                               
                                    <Grid item xs={5.68}>
                                    <FormControl fullWidth >
                                        <InputLabel className={errorPropertyType ? "validation dropdown_font" : "dropdown_font"} id="propertyType"><FormattedMessage id="propertyType" /></InputLabel>
                                        <Select
                                            error={errorPropertyType}
                                            helperText={errorPropertyType}
                                            labelId="propertyType"
                                            id="propertyType"
                                            name="propertyType"
                                            defaultValue={formik.values.propertyType}
                                            value={formik.values.propertyType}
                                            onChange={formik.handleChange}
                                            label={<FormattedMessage id="propertyType" />}
                                        >
                                            {propertyType?.map((type) => (
                                                <MenuItem key={type._id} value={type._id} >{type.name[customization.locale ? customization.locale : "en"]}</MenuItem>
                                            ))}
                                        </Select>
                                        {errorPropertyType && <Typography className="validationError" variant="body1" gutterBottom >{errorPropertyType}</Typography>}
                                        </FormControl>
                                        
                                    </Grid>
                                   
                                    
                                    <Grid item xs={5.68} className={customization.locale == "en" ? "mg-lt" : "mg-rt"} >
                                    <FormControl fullWidth>

                                        <InputLabel className={errorBedtype ? "validation dropdown_font" : "dropdown_font"} id="beds"><FormattedMessage id="beds" /></InputLabel>
                                        <Select
                                            error={errorBedtype}
                                            helperText={errorBedtype}
                                            labelId="beds"
                                            id="beds"
                                            name="beds"
                                            defaultValue={formik.values.beds}
                                            value={formik.values.beds}
                                            onChange={formik.handleChange}
                                            label={<FormattedMessage id="beds" />}
                                        >
                                            {bedType?.map((type) => (
                                                <MenuItem key={type._id} value={type._id} >{type.name[customization.locale ? customization.locale : "en"]}</MenuItem>
                                            ))}
                                        </Select>
                                        {errorBedtype && <Typography className="validationError" variant="body1" gutterBottom >{errorBedtype}</Typography>}
                                        </FormControl>
                                    </Grid>
                                  
                                </Grid>

                                <Grid container item xs={12}>
                                    <Grid item xs={5.9}>
                                        <TextField
                                            type="number"
                                            fullWidth
                                            id="price"
                                            name="price"
                                            label={<FormattedMessage id="price" />}
                                            placeholder={customization.locale == "en" ? "Price" : "السعر"}
                                            defaultValue={formik.values.price}
                                            onChange={formik.handleChange}
                                            error={errorPrice}
                                            helperText={errorPrice}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />

                                    </Grid>
                                    <Grid item xs={5.9} className={customization.locale == "en" ? "mg-lt10" : "mg-rt10"} >
                                        <TextField

                                            type="number"
                                            fullWidth
                                            id="noOfGuests"
                                            name="noOfGuests"
                                            label={<FormattedMessage id="noOfGuests" />}
                                               placeholder={customization.locale == "en" ? "No. Of Guests" : "لا للضيوف"}
                                            defaultValue={formik.values.noOfGuests}
                                            onChange={formik.handleChange}
                                            error={errorNoOfGuests}
                                            helperText={errorNoOfGuests}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </Grid>
                                </Grid>
                            {typeof state !== 'object' && state !== null &&
                                <> <Grid item xs={12}>
                                    <Grid style={{ paddingBottom: "20px", paddingTop: "30px", paddingLeft: "none" }} item xs={12}>
                                        <Typography variant="h4" gutterBottom component="div">
                                            <FormattedMessage id="roomManagment" />
                                        </Typography>


                                        <table style={{ width: "100%" }}>
                                            <tr>
                                                <th className={customization.locale == "en" ? "roomLeft" : "roomRight"} style={{ display: "inline-flex" }}> <FormattedMessage id="roomNo" />
                                                </th>
                                            </tr>

                                            {roomsNumber.map(item => (
                                                <tr
                                                    key={item.id}
                                                >

                                                    <td>
                                                        <TextField
                                                         style={{marginTop:"10px"}}
                                                            fullWidth
                                                            placeholder={customization.locale == "en" ? "Room No" :"غرفة لا"}
                                                            defaultValue={item.number} type="search"
                                                            onChange={onRoomChange}

                                                        />
                                                    </td>
                                                    <td><DeleteForeverIcon
                                                        onClick={() => handleDeleteRoom(item.id)}
                                                    />
                                                        {typeof state === 'object' && <Button onClick={() => handleUpdateRoom(item.id)} variant="contained" >
                                                            <FormattedMessage id="update" />
                                                        </Button>
                                                        }</td>
                                                </tr>
                                            ))}
                                            <tr>
                                                <td>
                                                    <TextField
                                                    style={{marginTop:"10px"}}
                                                        fullWidth
                                                        name="roomNo"
                                                        placeholder={customization.locale == "en" ? "Enter room no" :"أدخل رقم الغرفة"
                                                    }
                                                        value={selectedRoom}
                                                        onChange={(e) => setSelectedRoom(e.target.value)}
                                                    />
                                                </td>

                                                <td>
                                                    <DeleteForeverIcon className="delete" onClick={() => handleDeleteFirst()} />
                                                </td>
                                            </tr>
                                        </table>
                                        <Grid item container xs={12}>
                                            <span> {errorRooms && <Typography className="validationError" variant="body1" gutterBottom >{errorRooms}</Typography>}
                                            </span>
                                        </Grid>
                                    </Grid>
                                </Grid>
                                    <Grid item container xs={12}>
                                        <Grid style={{ marginLeft: "0px" ,marginRight:"0px"}}  item xs={4}>
                                            <div className="addNew" onClick={() => handleNewRow()}>
                                                <AddIcon />
                                                <span style={{ position: "relative", bottom: "5px",fontWeight:"500",textTransform:"uppercase",color:"black" }}> <FormattedMessage id="addNew" /></span>
                                            </div>
                                        </Grid>
                                    </Grid>
                                </>}
                  

</Grid>
                        <Grid style={{float:"left"}} item xs={4}>

                            {loading ?
                                <Box sx={{ display: 'flex' }}>
                                    <CircularProgress />
                                </Box>
                                :
                                <>
                                    <div style={{ width: "100%", height: 400 }}>
                                        <Typography variant="h4" gutterBottom component="div">
                                            <FormattedMessage id="amenities" />
                                        </Typography>
                                        <DataGrid
                                            borderColor="white"
                                            headerHeight={0}
                                            hideFooterPagination
                                            hideFooter
                                            onSelectionModelChange={(newSelectionModel) => {
                                                setSelectedAmenities(newSelectionModel);
                                            }}
                                            selectionModel={selectedAmenities}
                                            checkboxSelection
                                            rows={amenitiesData}
                                            columns={columns}
                                            pageSize={100}
                                        />
                                        {errorAmenities && <Typography className="validationError" variant="body1" gutterBottom >{errorAmenities}</Typography>}

                                    </div>
                                </>
                            }

                            <div style={{ width: "100%", marginTop: "60px" }}>

                                <Typography variant="h4" gutterBottom component="div">
                                    <FormattedMessage id="valueAddedServices" />
                                </Typography>


                                <div style={{ width: "100%", height: "450px", overflowY: "scroll",background: "#FAFAFA",borderRadius:"10px" }}>
                                    <table >


                                        {valueAddedServices?.map((item, index) =>
                                        (
                                            <tr key={item._id}>
                                                <td>
                                                    <Checkbox
                                                        rows={valueAddedServices}
                                                        checked={checkedState[index]}
                                                        onChange={(e) => handleChange(e, index, item._id)}
                                                        inputProps={{ 'aria-label': 'controlled' }}
                                                    />
                                                </td>
                                                <td><img className={customization.locale == "en" ? "valueImages" : "valueImagesAr"} src={item?.image?.imageUrl} /></td>
                                                <td>
                                                    <p className="bold" style={{ color: "blackss" }}>{item.name[customization.locale ? customization.locale : "en"]}
                                                    </p>
                                                    <p>{item.description[customization.locale ? customization.locale : "en"]}</p>
                                                </td>
                                                <td className="bolds2" style={{ color: "#E44057" }}>{formatter.format(item.price) + ' ' + 'SAR'}</td>
                                            </tr>)
                                        )}
                                    </table>
                                </div>
                                {errorValueAddedServices && <Typography className="validationError" variant="body1" gutterBottom >{errorValueAddedServices}</Typography>}
                            </div>
                        </Grid>
                        </>
                        </Grid>
                        <Grid item xs={12}>
                            <Stack direction="row">
                                <AnimateButton>
                                    <Button className='hayyak_btn' style={{ marginRight: "10px" }} variant="contained" type="submit">
                                        <FormattedMessage id="save" />
                                    </Button>
                                    {state?.checkedPage?
                                    <Button onClick={() => navigate(`/../../property/${state.building._id}`, { state: state })} className='cancel_btn'  >
                                        <FormattedMessage id="cancel" />
                                    </Button>
                                    :
                                    <Button onClick={() => navigate(-1)} className='cancel_btn'  >
                                    <FormattedMessage id="cancel" />
                                </Button>
}
                                </AnimateButton>
                            </Stack>
                        </Grid>


                        {typeof state === 'object' && state !== null &&
                            <> <Grid item xs={12}>
                                <Grid style={{ paddingBottom: "20px", paddingTop: "30px", paddingLeft: "none" }} item xs={12}>
                                    <Typography variant="h4" gutterBottom component="div">
                                        <FormattedMessage id="roomManagment" />
                                    </Typography>


                                    <table style={{ width: "100%" }}>
                                        <tr>
                                            <th className={customization.locale == "en" ? "roomLeft" : "roomRight"} style={{ display: "inline-flex" }}> <FormattedMessage id="roomNo" />

                                            </th>
                                        </tr>

                                        {roomsNumber.map(item => (
                                            <tr
                                                key={item._id}
                                            >

                                                <td>
                                                    <TextField
                                                    style={{marginTop:"10px"}}
                                                        fullWidth
                                                        placeholder={customization.locale == "en" ? "Room No." :"رقم الغرفة"
                                                    }
                                                        defaultValue={item.number} type="search"
                                                        onChange={onRoomChange}

                                                    />
                                                    {errorRooms && <Typography className="validationError" variant="body1" gutterBottom >{errorRooms}</Typography>}
                                                </td>
                                                <td><DeleteForeverIcon style={{position:"relative",top:"8px"}}
                                                    onClick={() => handleDeleteRoom(item._id)}
                                                />
                                                    <Button className='hayyak_btnSec' onClick={() => handleUpdateRoom(item._id)} variant="contained" >
                                                        <FormattedMessage id="update" />
                                                    </Button></td>
                                            </tr>
                                        ))}

                                        <tr>
                                            <td >
                                                <TextField style={{marginTop:"10px"}}
                                                    fullWidth
                                                    name="roomNo"
                                                    placeholder={customization.locale == "en" ? "Room No." :"رقم الغرفة"}
                                                    value={selectedRoom}
                                                    onChange={(e) => setSelectedRoom(e.target.value)}
                                                />
                                            </td>

                                            <td><DeleteForeverIcon className="delete"
                                                onClick={() => handleDeleteFirst()}
                                            />
                                                <Button className='hayyak_btnSec' onClick={() => handleCreateRoom()} variant="contained" >
                                                    <FormattedMessage id="create" />
                                                </Button></td>
                                        </tr>
                                    </table>
                                    <Grid item container xs={12}> <span> {errorRooms && <Typography className="validationError" variant="body1" gutterBottom >{errorRooms}</Typography>}
                                    </span></Grid>
                                </Grid>
                            </Grid>
                            </>}
              
                </form>
            </MainCard>
            <AlertDialog
                heading={heading}
                open={open}
                message={message}
                handleOpen={handleOpen}
                handleClose={handleClose}
            />
        </>
    )
};

export default PropertyEdit;
