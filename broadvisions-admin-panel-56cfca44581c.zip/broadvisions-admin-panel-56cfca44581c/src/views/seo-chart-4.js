// ===========================|| WIDGET - SEO 4 CHART ||=========================== //

const chartData = {
    type: 'line',
    height: 30,
    options: {
        chart: {
            id: 'user-analytics-chart',
            sparkline: {
                enabled: true
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'straight',
            width: 2
        },
        yaxis: {
            min: -10,
            max: 12,
            labels: {
                show: false
            }
        },
        tooltip: {
            fixed: {
                enabled: false
            },
            x: {
                show: false
            },
            y: {
                title: 'Analytics '
            },
            marker: {
                show: false
            }
        }
    },
    series: [
        {
            data: [-3, 5,-10,9, 1, 8]
        }
    ]
};
export default chartData;
