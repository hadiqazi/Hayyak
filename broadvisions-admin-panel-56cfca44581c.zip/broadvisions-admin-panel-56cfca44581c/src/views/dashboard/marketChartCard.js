import PropTypes from 'prop-types';

// material-ui
import { useTheme } from '@mui/material/styles';
import { Grid, Box, Typography } from '@mui/material';
import { FormattedMessage } from 'react-intl';
// third party
import Chart from 'react-apexcharts';

// project imports
import MainCard from 'ui-component/cards/MainCard';

// assets
import TrendingDownIcon from '@mui/icons-material/TrendingDown';
import { IconBrandFacebook, IconBrandYoutube, IconBrandTwitter } from '@tabler/icons';

// ===========================|| MARKET SHARE CHART CARD ||=========================== //

const MarketChartCard = (props) => {
    const theme = useTheme();

    return (
        <MainCard sx={{ '&>div': { p: 0, pb: '0px !important' } }}>
            <Box
                sx={{
                    p: 3
                }}
            >
                <Grid container direction="column" spacing={3}>
                    <Grid item container spacing={1} alignItems="center">
                        <Grid item>
                            <Typography variant="h3">  <FormattedMessage id="revenue" /></Typography>
                        </Grid>
                      
                      
                    </Grid>
                </Grid>
            </Box>
            <Chart type='area' options={props.options} series={props.series}  height="350"/>
        </MainCard>
    );
};

MarketChartCard.propTypes = {
    chartData: PropTypes.object
};

export default MarketChartCard;
