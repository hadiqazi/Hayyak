import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
// material-ui
import { useDispatch, useSelector } from 'react-redux';
import { useTheme } from '@mui/material/styles';
import { Box, Divider, Grid, Typography, useMediaQuery } from '@mui/material';

// third party
import Chart from 'react-apexcharts';

// project imports
import MainCard from 'ui-component/cards/MainCard';

// ===========================|| REVENUE CHART CARD ||=========================== //

const RevenueChartCard = (props) => {
    const customization = useSelector((state) => state.customization);

    return (
        <MainCard>

            <Grid container >
                <Grid item xs={12} sm={7} md={12}>
                    <Typography style={{ marginBottom: "40px",fontSize:"20px",fontWeight:"600",color:"black" }} gutterBottom component="div">
                        <FormattedMessage id="bookings" />
                    </Typography>
                    <Chart type='donut' options={props.options} series={props.series} height='200' />
                    <Grid style={{paddingTop:"50px"}} item xs={12} sm={7} md={12}>
                    <Grid style={{display:"flex"}} item xs={12} sm={7} md={12}>
                        <div style={{background:"#E44057"}} className='bookingChartActive'></div>
                    <Typography xs={5} className={customization.locale == "en" ? "bookingChart" : "bookingChartAr"} gutterBottom component="div">
                        <FormattedMessage id="completed" />
                    </Typography>
                    <Typography className={customization.locale == "en" ? "bookingChartPercentage" : "bookingChartPercentageAr"} gutterBottom component="div">
                        {Math.trunc(props.bookingPercentageValues.completed)}%
                    </Typography>   
                    </Grid>
                    <Grid style={{display:"flex"}} item xs={12} sm={7} md={12}>
                    <div style={{background:"#EC7989"}} className='bookingChartActive'></div>
                    <Typography className={customization.locale == "en" ? "bookingChart" : "bookingChartAr"} gutterBottom component="div">
                        <FormattedMessage id="active" />
                    </Typography>
                    <Typography className={customization.locale == "en" ? "bookingChartPercentage" : "bookingChartPercentageAr"} gutterBottom component="div">
                    {Math.trunc(props.bookingPercentageValues.active)}%
                    </Typography>  
                    </Grid>
                    <Grid style={{display:"flex"}} item xs={12} sm={7} md={12}>
                    <div  style={{background:"#FCECEE"}} className='bookingChartActive'></div>
                    <Typography className={customization.locale == "en" ? "bookingChart" : "bookingChartAr"} gutterBottom component="div">
                        <FormattedMessage id="cancelled" />
                    </Typography>
                    <Typography className={customization.locale == "en" ? "bookingChartPercentage" : "bookingChartPercentageAr"} gutterBottom component="div">
                    {Math.trunc(props.bookingPercentageValues.cancelled)}%
                    </Typography>
                    </Grid>

                </Grid></Grid>


            </Grid>
        </MainCard>
    );
};


export default RevenueChartCard;
