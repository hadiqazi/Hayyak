import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
// material-ui
import { useTheme } from '@mui/material/styles';
import { Box, Divider, Grid, Typography, useMediaQuery } from '@mui/material';

// third party
import Chart from 'react-apexcharts';

// project imports
import MainCard from 'ui-component/cards/MainCard';

// ===========================|| REVENUE CHART CARD ||=========================== //

const CircularCard = (props) => {


    return (
        <MainCard>

            <Grid container >
                <Grid item xs={12} sm={7} md={12}>
                    {/* <Typography style={{ marginBottom: "0px",fontSize:"20px",fontWeight:"600",color:"black" }} gutterBottom component="div">
                        <FormattedMessage id="bookings" />
                    </Typography> */}
                    <Chart type="radialBar" options={props.options} series={props.series} />
                </Grid>


            </Grid>
        </MainCard>
    );
};


export default CircularCard;
