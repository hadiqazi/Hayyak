import { FormattedMessage } from 'react-intl';
import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import SeoChartCard from 'ui-component/cards/SeoChartCard';
import Link from '@mui/material/Link';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import RevenueChartCard from '../dashboard/revenueCard';
import Chart from "react-apexcharts";
import axios from 'axios';
import { baseURL, version1 } from 'defaultValues';
import MarketChartCard from '../dashboard/marketChartCard';
import '../../assets/css/style.css'
import {
    CardContent,
    Grid,
    Typography,
    Fab,
} from '@material-ui/core';
import Loader from 'ui-component/Loader';
import MainCard from 'ui-component/cards/MainCard';
import { bookingService } from 'defaultValues';
import { values } from 'lodash';

var seriesChart = []
const lineChartData = {
    type: 'line',
    height: 30,
    options: {
        colors: ['#6FD64C'],
        chart: {
            id: 'user-analytics-chart',
            sparkline: {
                enabled: true
            }
        },
        stroke: {
            curve: 'straight',
            width: 2
        },
        tooltip: {
            enabled: false,
        }
    },
    series: [
        {
            data: [-3, 5, -10, 9, 1, 8]
        }
    ]
};
const lineChartData1 = {
    type: 'line',
    height: 30,
    options: {
        colors: ['#FFC20E'],
        chart: {
            id: 'user-analytics-chart',
            sparkline: {
                enabled: true
            }
        },
        stroke: {
            curve: 'straight',
            width: 2
        },
        tooltip: {
            enabled: false,
        }
    },
    series: [
        {
            data: [-3, 5, -10, 9, 1, 8]
        }
    ]
};

const lineChartData2 = {
    type: 'line',
    height: 30,
    options: {
        colors: ['#205B7D'],
        chart: {
            id: 'user-analytics-chart',
            sparkline: {
                enabled: true
            }
        },
        stroke: {
            curve: 'straight',
            width: 2
        },
        tooltip: {
            enabled: false,
        }
    },
    series: [
        {
            data: [-3, 5, -10, 9, 1, 8]
        }
    ]
};

const lineChartData3 = {
    type: 'line',
    height: 30,
    options: {
        colors: ['#FF2517'],
        chart: {
            id: 'user-analytics-chart',
            sparkline: {
                enabled: true
            }
        },
        stroke: {
            curve: 'straight',
            width: 2
        },
        tooltip: {
            enabled: false,
        }
    },
    series: [
        {
            data: [-3, 5, -10, 9, 1, 8]
        }
    ]
};




const chartData = {

    type: 'donut',
    options: {
        plotOptions: {
            pie: {
                expandOnClick: false,
            }
        },
        fill: {
            colors: ['#EC7989', '#FCECEE', '#E44057']
        },
        colors: ['#EC7989', '#FCECEE', '#E44057'],
        chart: {
            id: 'revenue-chart'
        },
        dataLabels: {
            enabled: false
        },
        // labels: ['Active', 'Completed', 'Cancelled'],
        tooltip: {
            enabled: false
        },
        legend: {
            show: false,
            position: 'bottom',
            fontFamily: 'inherit',
            labels: {

            },

            itemMargin: {
                horizontal: 50,
                vertical: 10
            }
        }
    },
    series: [1258, 975, 500]
};

let radialChartOptions = {
    series: [44.5],
    options: {
        colors: ["#FFFFFF"],
        chart: {
            type: 'radialBar',
            offsetY: -20,
            sparkline: {
                enabled: true
            }
        },
        plotOptions: {
            radialBar: {
                startAngle: -90,
                endAngle: 90,
                track: {
                    background: "#E96679",
                    strokeWidth: '100%',
                    margin: 5, // margin is in pixels
                },
                dataLabels: {
                    name: {
                        offsetY: -20,
                        show: false,
                        color: "#FFFF",
                        fontSize: "13px"
                    },
                    value: {
                        offsetY: 0,
                        fontSize: '20px',
                        fontWeight: "600",
                        color: "#FFF",
                        show: false,
                    },
                }
            }
        },
        grid: {
            padding: {
                top: -10
            }
        },
        fill: {
            type: 'gradient',
            gradient: {
                shade: 'light',
                shadeIntensity: 0.4,
                inverseColors: false,
                opacityFrom: 1,
                opacityTo: 1,
                stops: [0, 50, 53, 91]
            },
        },
    },
};

var formatter = new Intl.NumberFormat();


const Dashboard = () => {

    const [isLoading, setIsLoading] = useState(false);
    const customization = useSelector((state) => state.customization);
    const [data, setData] = useState([]);
    const [circularSeries, setCircularSeries] = useState([]);
    const [circularSeriesRating, setCircularSeriesRating] = useState([]);
    const [bookingPercentageValues, setBookingPercentageValues] = useState([]);
    const [bookingStats, setBookingStats] = useState([]);
    const [salesSeries, setSalesSeries] = useState([]);

    const [time, setTime] = React.useState('WEEK');

    const marketCardData = {

        height: 200,
        type: 'area',
        options: {
            grid: {
                padding: {
                  left: 25,
                  right: 10
                }
              },
              dataLabels: {
                enabled: true,
                style: {
                    fontSize: '11px',
                    fontWeight: 'bold',
                  },
              },
            chart: {
                type: 'area',
                toolbar: {
                    show: false
                },
            },
            xaxis: {
            
                categories: customization.locale == 'en' ? ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUNE', 'JULY', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'] : ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]
            },
         
            colors: ['#E44057'],
            fill: {
                show: false,
                type: 'gradient',
                gradient: {
                    shadeIntensity: 0,
                    opacityFrom: 0,
                    opacityTo: 0,
                    stops: [0, 0, 0]
                }
            },
            legend: {
                show: false
            },
        },
    };
    const handleChange = (event) => {

        setTime(event.target.value);
        loadData(event.target.value);
    };
    const loadData = (event) => {
        let data = [];
        let obj = {
            date: event == undefined ? time : event
        }
        axios({
            method: 'post',
            url: `${baseURL}/${bookingService}/${version1}/dashboard`,
            data: obj
        }).then(res => {
            console.log('res', res)
            res?.data?.stats?.salesGraphData.forEach(element => {
                data.push(element.value)

            })

            seriesChart = [
                {
                    name: "Sales",
                    data,
                },

            ]

            let bookingStatusStatistics = Object.fromEntries(Object.entries(res?.data?.stats?.bookingStatusStats).filter(([key]) => !key.includes('total')));
            let bookingStatusStats = Object.fromEntries(Object.entries(res?.data?.stats?.bookingStatusStats));
            let total = bookingStatusStats.total

            let obj = {
                active: percentage(bookingStatusStats.active, total),
                completed: percentage(bookingStatusStats.completed, total),
                cancelled: percentage(bookingStatusStats.cancelled, total)
            }
            let circularSeriesRating = res?.data?.stats?.ratingAvg / 5 * 100
            let rating=Number(res.data.stats.ratingAvg).toFixed(1)
            console.log('ece',rating)
            setBookingPercentageValues(obj)
            setBookingStats(Object.values(bookingStatusStatistics))
            setData(res?.data?.stats)
            setCircularSeries(circularSeriesRating)
            setCircularSeriesRating(Number(res.data.stats.ratingAvg).toFixed(1))
            setIsLoading(false)
        }).catch(err => {
            console.error(err);
            setIsLoading(false);
        });
    }
    const percentage = (partialValue, totalValue) => {
        return (100 * partialValue) / totalValue;
    }

    useEffect(() => {
        setIsLoading(true)
        loadData();
        return (() => { })
    }, []);

    if (isLoading) {
        return <Loader />;
    }

    return (
        <>
            <MainCard className='' content={false}>
                <CardContent >

                    <Grid xs={12} style={{ display: "flex", marginBottom: "-15px" }}>
                        <Grid xs={9}>
                            <Typography className='dashboard' variant="subtitle" gutterBottom component="div">
                                <FormattedMessage id="dashboard" />
                            </Typography>
                        </Grid>
                        <Grid xs={3} >
                            <Box sx={{ minWidth: 120 }} className={customization.locale == "en" ? "dashboard_dropdown" : "dashboard_dropdownAr"} >
                                <FormControl className={customization.locale == "en" ? "dash_drop" : "dash_dropAr"} >
                                    <InputLabel id="demo-simple-select-label"> <FormattedMessage id="allTime" /></InputLabel>
                                    <Select
                                        labelId="demo-simple-select-label"
                                        id="demo-simple-select-label"
                                        value={time}
                                        label={<FormattedMessage id="allTime" />}
                                        onChange={handleChange}
                                    >
                                        <MenuItem value="WEEK"> <FormattedMessage id="week" /></MenuItem>
                                        <MenuItem value="MONTH"> <FormattedMessage id="month" /></MenuItem>
                                        <MenuItem value="YEAR"> <FormattedMessage id="year" /></MenuItem>
                                    </Select>
                                </FormControl>
                            </Box>
                        </Grid>
                    </Grid>

                    <Grid item container xs={12}>
                        <Grid className='mainDashboard paddingTopDashboard' item xs={12} container >
                            <Grid className={customization.locale == "en" ? "dashboardTopGrids" : "dashboardTopGridsArTop"} item xs={2.8}>
                                <Typography className={customization.locale == "en" ? "dashboardCount" : "dashboardCountAr"} variant="subtitle" gutterBottom component="div">
                                    {data?.bookingCountStats?.active}
                                </Typography>
                                <Typography className={customization.locale == "en" ? "gridLabels" : "gridLabelsAr"} variant="subtitle" gutterBottom component="div">
                                    <FormattedMessage id="activeBookings" />
                                </Typography>
                                <SeoChartCard type={1} chartData={lineChartData} />
                            </Grid>
                            <Grid className={customization.locale == "en" ? "dashboardTopGrids" : "dashboardTopGridsArTop"} item xs={2.8}>
                                <Typography className={customization.locale == "en" ? "dashboardCount" : "dashboardCountAr"} variant="subtitle" gutterBottom component="div">
                                    {data?.bookingCountStats?.checkedIn}
                                </Typography>
                                <Typography className={customization.locale == "en" ? "gridLabels" : "gridLabelsAr"} variant="subtitle" gutterBottom component="div">
                                    <FormattedMessage id="checkedIn" />
                                </Typography>
                                <SeoChartCard type={1} chartData={lineChartData1} />
                            </Grid>
                            <Grid className={customization.locale == "en" ? "dashboardTopGrids" : "dashboardTopGridsArTop"} item xs={2.8}>
                                <Typography className={customization.locale == "en" ? "dashboardCount" : "dashboardCountAr"} variant="subtitle" gutterBottom component="div">
                                    {data?.bookingCountStats?.checkedOut}
                                </Typography>
                                <Typography className={customization.locale == "en" ? "gridLabels" : "gridLabelsAr"} variant="subtitle" gutterBottom component="div">
                                    <FormattedMessage id="checkedOut" />
                                </Typography>
                                <SeoChartCard type={1} chartData={lineChartData2} />
                            </Grid>
                            <Grid style={{ marginRight: "0px" }} className={customization.locale == "en" ? "dashboardTopGrids" : "dashboardTopGridsArTopLast"} item xs={2.8}>
                                <Typography className={customization.locale == "en" ? "dashboardCount" : "dashboardCountAr"} variant="subtitle" gutterBottom component="div">
                                    {data?.bookingCountStats?.cancelled}
                                </Typography>
                                <Typography className={customization.locale == "en" ? "gridLabels" : "gridLabelsAr"} variant="subtitle" gutterBottom component="div">
                                    <FormattedMessage id="cancelBookings" />
                                </Typography>
                                <SeoChartCard type={1} chartData={lineChartData3} />
                            </Grid>
                        </Grid>
                        <Grid item xs={12} container className='paddingTopDashboard' >
                            <Grid className={customization.locale == "en" ? "dashboardTopGrids marketshare" : "dashboardTopGridsAr marketshare"} item xs={customization.locale == "en" ? 8.89 : 8.85}>

                                <MarketChartCard options={marketCardData.options} series={seriesChart} />
                            </Grid>
                            <Grid style={{ marginRight: "0px", marginLeft: "0px" }} className={customization.locale == "en" ? "dashboardTopGrids revenueChart" : "dashboardTopGridsAr revenueChart"} className='dashboardTopGrids revenueChart' item xs={2.8}>
                                <RevenueChartCard bookingPercentageValues={bookingPercentageValues} options={chartData.options} series={bookingStats} />
                            </Grid>
                        </Grid>

                        <Grid item xs={12} container className='paddingTopDashboard' >
                            <Grid style={{ padding: "30px 30px 30px 30px" }} className={customization.locale == "en" ? "dashboardTopGrids" : "dashboardTopGridsAr"} item xs={5.85}>
                                <Grid item xs={12} style={{ display: "flex" }}>
                                    <Grid item xs={6}>
                                        <Typography style={{ width: "100%", fontSize: "20px", fontWeight: "600", color: "black" }} component="div">
                                            <FormattedMessage id="recentBookings" />
                                        </Typography>

                                    </Grid>
                                    <Grid item xs={6} >
                                        <Link className={customization.locale == "en" ? "floatRight" : "floatLeft"} style={{ fontSize: "14px", fontWeight: "400", color: "black" }} href="../../../bookings" underline="none">
                                            <FormattedMessage id="viewAll" />
                                        </Link>

                                    </Grid>

                                </Grid>
                                <table style={{ width: "100%" }}>
                                    {data?.recentBookings?.map(item =>
                                    (
                                        <>
                                            <tr >
                                                <td style={{ width: "11%" }}><img className='bordersValueDashboard' style={{ width: "60px" }} src={item?.property?.coverImage} /></td>
                                                <td>
                                                    <p style={{ marginBottom: "8px", fontWeight: "400", fontSize: "16px", color: "black" }} >{item?.property?.building?.name[customization.locale ? customization.locale : "en"]}
                                                    </p>
                                                    <p style={{
                                                        margin: "0px", fontSize: " 11px",
                                                        fontweight: "400"
                                                    }}>{item?.property?.name[customization.locale ? customization.locale : "en"]}</p>
                                                </td>
                                                <td className={customization.locale == "en" ? "priceDashboard" : "priceDashboardAr"} style={{ fontWeight: "600", fontSize: "18px", color: "#E44057" }}>{formatter.format(item?.cost?.totalBookingCost) + ' ' + 'SAR'}</td>
                                            </tr>
                                        </>
                                    ))}
                                </table>
                            </Grid>
                            <Grid style={{ textAlign: "center", marginRight: "0px", background: "#E44057" }} className='dashboardTopGrids revenueChart circular' item xs={5.85}>
                                <Chart type="radialBar" options={radialChartOptions.options} series={[circularSeries]} />
                                <Typography className='score' component="div">
                                    <FormattedMessage id="totalScore" />
                                </Typography>
                                <Typography className='scoreRating' component="div">
                                    {`${circularSeriesRating}/5.0`}
                                </Typography>
                                <Grid item xs={12} >
                                    <Typography style={{ marginTop: "-35px", fontSize: "20px", fontWeight: "600", color: "#FFFFFF" }} component="div">
                                        <FormattedMessage id="customerSatisfaction" />
                                    </Typography>

                                </Grid>
                                <Grid item xs={12} style={{ marginTop: "10px", paddingBottom: "40px" }}>
                                    <Link style={{ fontSize: "14px", fontWeight: "500", color: "#ffffff", textDecoration: "underline" }} href="../../../reviews" >
                                        <FormattedMessage id="readAllReviews" />
                                    </Link>

                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </CardContent>
            </MainCard>
        </>
    );
};

export default Dashboard;
