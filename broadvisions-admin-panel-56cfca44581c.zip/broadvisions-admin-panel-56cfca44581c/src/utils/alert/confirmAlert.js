import * as React from 'react';
import Button from 'material-ui/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import { FormattedMessage } from 'react-intl';
import DialogContentText from '@mui/material/DialogContentText';
import CancelIcon from '@mui/icons-material/Cancel';
import DialogTitle from '@mui/material/DialogTitle';
import '../../../src/assets/css/style.css'

const AlertDialog = (props) => {
    return (
        <div style={{width:"100%",textAlign:"center"}}>
{/* <Grid item container xs={12}> */}
{/* <Grid item container xs={12}> */}


<Dialog className='cancelDiv' style={{width:"100%",textAlign:"center"}}
                open={props.open}
                onClose={props.handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <div className='cancelIcon'>
                <CancelIcon style={{marginRight:"10px"}} onClick={props.handleClose}/>

                </div>
                
                <DialogTitle style={{fontWeight:"bolder",padding:"5px"}} id="alert-dialog-title">
                    {props.heading}
                </DialogTitle>
                <DialogContent>
                    <DialogContentText style={{color:"black",paddingBottom:"5px"}} id="alert-dialog-description">
                        {props.message}
                    </DialogContentText>
                </DialogContent>
                <DialogActions style={{width:"100%"}}>
                <Button style={{width:"100%"}} className='hayyak_btn_alert' onClick={props.handleOpen} autoFocus>
                    <FormattedMessage id="delete" />
                    </Button>
                    <Button className='cancel_btn' style={{width:"100%",marginLeft:"0px"}} onClick={props.handleClose}> <FormattedMessage id="no" /></Button>
                   
                </DialogActions>
            </Dialog>
    
{/* </Grid> */}
{/* <Grid item container xs={12}>

    
</Grid>
<Grid item container xs={12}>

    
</Grid>
<Grid item container xs={12}>

    
</Grid>

</Grid> */}
          
        </div>
    );
}
export default AlertDialog;