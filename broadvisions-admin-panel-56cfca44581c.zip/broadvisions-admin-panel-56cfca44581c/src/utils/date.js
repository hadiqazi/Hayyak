/* eslint-disable */
import { FormattedMessage } from 'react-intl';
import 'react-confirm-alert/src/react-confirm-alert.css';
import moment from 'moment';
import { makeStyles, useTheme } from '@material-ui/styles';
import { useDispatch, useSelector } from 'react-redux';
import 'moment/locale/ar';
import {

    Typography,
    Fab,
} from '@material-ui/core';


const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    paper: {
        width: '100%',
        marginBottom: theme.spacing(2)
    },
    table: {
        minWidth: 750
    },
    sortSpan: visuallyHidden
}));

const useToolbarStyles = makeStyles((theme) => ({
    root: {
        padding: 0,
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(1)
    },
    highlight: {
        color: theme.palette.secondary.main
    },
    title: {
        flex: '1 1 100%'
    }
}));

const DateFormatter = (props) => {
    const customization = useSelector((state) => state.customization);
    // localLocale.locale('fr'); // set this instance to use French
    // localLocale.format('LLLL'); // dimanche 15 juillet 2012 11:01
    // moment().format('LLLL'); // Sunday, July 15 2012 11:01 AM


    const theme = useTheme();
    return (

        <Typography
            variant="subtitle"
        >
            {
                customization.locale == "en" ?
                    moment(props.date).locale('en').format('ll')
                    :
                    moment(props.date).locale('ar').format('ll')

            }
        </Typography>


        // <>
        // {customization.locale=='en' ?<DateEnglish/> :
        //  <DateArabic/>
        // }




        // </>

    )
}
export default DateFormatter
