import PropTypes from 'prop-types';
import React, { createContext, useEffect, useReducer, useState } from 'react';

import useAuth from 'hooks/useAuth';
// third-party
import jwtDecode from 'jwt-decode';

// reducer - state management
import { ACCOUNT_INITIALIZE, LOGIN, LOGOUT, REMEMBER } from 'store/actions';
import accountReducer from 'store/accountReducer';

// project imports
// import axios from 'utils/axios';
import axios from 'axios';
import Loader from 'ui-component/Loader';
import { baseURL, version1, userService } from 'defaultValues';
// constant
const initialState = {
    isLoggedIn: false,
    isInitialized: false,
    rememberUser: false,
    user: null
};

const verifyToken = (serviceToken) => {
    if (!serviceToken) {
        return false;
    }
    const decoded = jwtDecode(serviceToken);
    return decoded.exp > Date.now() / 1000;
};

const setSession = (serviceToken,checked) => {
    if (serviceToken && checked) {
        console.log('************************in setSession*************');
        localStorage.setItem('serviceToken', serviceToken);
        localStorage.setItem('authToken', serviceToken);
        console.log('serviceToken', serviceToken);
        console.log('token has been set');
        axios.defaults.headers.common.Authorization = `Bearer ${serviceToken}`;
    }
    else if (!checked && serviceToken) {
        window.sessionStorage.setItem("serviceToken", serviceToken);
        window.sessionStorage.setItem("authToken", serviceToken);
    }

    else {
        localStorage.removeItem('serviceToken');
        localStorage.setItem('authToken', serviceToken);
        delete axios.defaults.headers.common.Authorization;
    }
};
const setOtp=(user, otp)=>{
    console.log('otp is',otp)
}
const setUser = (user) => {
    if (user) {
        console.log('************************in setUser*************');
        console.log('user data', user);
        localStorage.setItem('user', JSON.stringify(user));
        console.log('user has been set');
    } else {
        localStorage.removeItem('user');
    }
};

// ===========================|| JWT CONTEXT & PROVIDER ||=========================== //

const JWTContext = createContext({
    ...initialState,
    login: () => Promise.resolve(),
    verifyLogin: () => Promise.resolve(),
    logout: () => { },
    checkPermission: () => { },
});

export const JWTProvider = ({ children }) => {
    const [state, dispatch] = useReducer(accountReducer, initialState);
    const [data, setData] = React.useState([]);

    const checkPermission = (permission) => {
        console.log("user", state.user);
        console.log("permission in", permission);
        if(state.isLoggedIn && state.user && state.user.permissions) {
            let returnStats = state.user.permissions.includes(permission);
            console.log("returning1", returnStats);
            return returnStats;
        }
        else {
            console.log("returning2", false);
            return false;
        }
    }

    const verifyToken = (serviceToken) => {
        if (!serviceToken) {
            return false;
        }
        const decoded = jwtDecode(serviceToken);
        return decoded.exp > Date.now() / 1000;
    };

    const setOtp = (user, otp) => {
        console.log('otp is', otp)
    }

    const setUser = (user, rememberMe) => {
        if (user && rememberMe) {
            console.log('user data', user);
            localStorage.setItem('user', JSON.stringify(user));
            console.log('user has been set');
        }
        else if (user && (!rememberMe)) {
            console.log('user data', user);
            sessionStorage.setItem('user', JSON.stringify(user));
            console.log('user has been set');
        }
        else {
            localStorage.setItem('user', user);
            sessionStorage.setItem('user', user);
        }
    };

    const login = async (email, password) => {
        const response = await axios.post(`${baseURL}/${userService}/${version1}/auth/login-admin`, { email, password });
        console.log('response of login API', response.data);
        setData(response.data)
        if (response?.data?.otp) {
            setOtp(email, response?.data.otp)
        }
    };

    const setSession = (serviceToken, rememberMe) => {
        localStorage.setItem('rememberMe', rememberMe);
        if (serviceToken && rememberMe) {
            console.log('************************in setSession*************');
            localStorage.setItem('authToken', serviceToken);
            console.log('authToken', serviceToken);
            console.log('token has been set');
            axios.defaults.headers.common.Authorization = `Bearer ${serviceToken}`;
        }
        else if (serviceToken && !rememberMe) {
            sessionStorage.setItem("authToken", serviceToken);
            axios.defaults.headers.common.Authorization = `Bearer ${serviceToken}`;
        }

        else {
            localStorage.setItem('authToken', serviceToken);
            sessionStorage.setItem('authToken', serviceToken);
            delete axios.defaults.headers.common.Authorization;
        }
    }

    const verifyLogin = async (response, rememberMe) => {
        const { token, admin, roles, permissions } = response;
        setSession(token, rememberMe);
        const user = { ...admin, roles, permissions };
        setUser(user, rememberMe);
        dispatch({
            type: LOGIN,
            payload: {
                user,
                rememberMe
            }
        });
    }
    const logout = () => {
        console.log('in logout call ++++++++++++++++++++++++++++++++++++++');
        setSession(null, false);
        setUser(null, false);
        dispatch({ type: LOGOUT });

    };

    useEffect(() => {
        const init = async () => {
            try {
                let authToken
                let user
                //get storedRememberMe from localStorage
                let storedRememberMe = localStorage.getItem('rememberMe');
                storedRememberMe = storedRememberMe ? JSON.parse(storedRememberMe) : false;
                if(storedRememberMe != null){
                    if (storedRememberMe) {
                        authToken = localStorage.getItem('authToken');
                        user = localStorage.getItem('user');
                    }
                    else if (!storedRememberMe) {
                        authToken = sessionStorage.getItem('authToken');
                        user = sessionStorage.getItem('user');
                    }
    
                    user = user ? JSON.parse(user) : {};
                    console.log('user data', user);
                    if (authToken && verifyToken(authToken) && user) {
                        axios.defaults.headers.common.Authorization = `Bearer ${authToken}`;
                        dispatch({
                            type: ACCOUNT_INITIALIZE,
                            payload: {
                                isLoggedIn: true,
                                user,
                                storedRememberMe
                            }
                        });
                    } else {
                        dispatch({
                            type: ACCOUNT_INITIALIZE,
                            payload: {
                                isLoggedIn: false,
                                user: null,
                                rememberMe: false
                            }
                        });
                    }
                } else {
                    dispatch({
                        type: ACCOUNT_INITIALIZE,
                        payload: {
                            isLoggedIn: false,
                            user: null,
                            rememberMe: false
                        }
                    });
                }
            } catch (err) {
                console.error(err);
                dispatch({
                    type: ACCOUNT_INITIALIZE,
                    payload: {
                        isLoggedIn: false,
                        user: null
                    }
                });
            }
        };

        init();
    }, []);

    if (!state.isInitialized) {
        return <Loader />;
    }

    return <JWTContext.Provider value={{ ...state, login, logout, verifyLogin, checkPermission }}>{children}</JWTContext.Provider>;
};

JWTProvider.propTypes = {
    children: PropTypes.node.isRequired
};

export default JWTContext;
