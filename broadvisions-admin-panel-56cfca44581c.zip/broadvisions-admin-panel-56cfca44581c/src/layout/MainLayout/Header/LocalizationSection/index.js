

import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import LanguageIcon from '@mui/icons-material/Language';
import Select from '@mui/material/Select';
import '../../../../../src/assets/css/style.css'

import ListItemButton from '@material-ui/core/ListItemButton';

// project imports
import Transitions from 'ui-component/extended/Transitions';
import * as actionTypes from 'store/actions';

// assets
import TranslateTwoToneIcon from '@material-ui/icons/TranslateTwoTone';



// material-ui
import { makeStyles, useTheme } from '@material-ui/styles';
import {
    Avatar,
    Box,
    ButtonBase,
    ClickAwayListener,
    Grid,
    List,
    ListItemText,
    Paper,
    Popper,
    Typography,
    useMediaQuery
} from '@material-ui/core';



// assets


const useStyles = makeStyles((theme) => ({
    navContainer: {
        width: '100%',
        minWidth: '200px',
        maxWidth: '280px',
        backgroundColor: theme.palette.background.paper,
        borderRadius: '10px',
        [theme.breakpoints.down('sm')]: {
            maxWidth: '250px'
        }
    },
    headerAvatar: {
        ...theme.typography.commonAvatar,
        ...theme.typography.mediumAvatar,
        border: '1px solid',
        borderColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.light,
        background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.light,
        color: theme.palette.primary.dark,
        transition: 'all .2s ease-in-out',
        '&[aria-controls="menu-list-grow"],&:hover': {
            borderColor: theme.palette.primary.main,
            background: theme.palette.primary.main,
            color: theme.palette.primary.light
        }
    },
    box: {
        marginLeft: '16px',
        [theme.breakpoints.down('sm')]: {
            marginLeft: '8px'
        }
    }
}));

// ===========================|| LOCALIZATION ||=========================== //

const LocalizationSection = () => {
    const classes = useStyles();
    const customization = useSelector((state) => state.customization);
    const dispatch = useDispatch();
    const [value, setValue] = React.useState('en');
    const theme = useTheme();
    const matchesXs = useMediaQuery(theme.breakpoints.down('sm'));

    const [open, setOpen] = React.useState(false);
    const anchorRef = React.useRef(null);
    const [language, setLanguage] = React.useState(customization.locale);
    const [rtl, setRTL] = React.useState(customization.rtlLayout);

    const handleListItemClick = (event, index) => {
            setLanguage(event.target.value);
            if (event.target.value === "ar") {
                dispatch({ type: actionTypes.THEME_RTL, rtlLayout: true });
                console.log('dispatch',dispatch.type)
                setValue('ar')
                setRTL(true)
            } else {
                dispatch({ type: actionTypes.THEME_RTL, rtlLayout: false });
                setRTL(false)
                setValue('en')
            }
            dispatch({ type: actionTypes.THEME_LOCALE, locale: event.target.value });
            setOpen(false);
        };


 useEffect(() => {

    if (customization.rtlLayout) {
        setValue('ar')
    } else {
        setValue('en')
    }
 
 }, []);
 
 

    const handleToggle = () => {
        setOpen((prevOpen) => !prevOpen);
    };

    const handleClose = (event) => {
        if (anchorRef.current && anchorRef.current.contains(event.target)) {
            return;
        }
        setOpen(false);
    };

    const prevOpen = React.useRef(open);
    React.useEffect(() => {
        if (prevOpen.current === true && open === false) {
            anchorRef.current.focus();
        }
        prevOpen.current = open;
    }, [open]);

    React.useEffect(() => {
        setLanguage(customization.locale);
    }, [customization]);

    return (
        <>
                            <Box className={customization.locale == "en" ? "languageBox" : "languageBoxArabic"}>
                <FormControl fullWidth>
                    <LanguageIcon className={customization.locale == "en" ? "languageIcon" : "languageIconArabic"} />
                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={value}
                        onChange={(event) => handleListItemClick(event)}
                    >
                        <MenuItem value='en'>English</MenuItem>
                        <MenuItem value='ar'>عربى</MenuItem>
                    </Select>
                </FormControl>
            </Box>

            <Popper
                placement={matchesXs ? 'bottom-start' : 'bottom'}
                open={open}
                anchorEl={anchorRef.current}
                role={undefined}
                transition
                disablePortal
                popperOptions={{
                    modifiers: [
                        {
                            name: 'offset',
                            options: {
                                offset: [matchesXs ? 0 : 0, 20]
                            }
                        }
                    ]
                }}
            >
                {({ TransitionProps }) => (
                    <Transitions position="top" in={open} {...TransitionProps}>
                        <Paper elevation={16}>
                            <ClickAwayListener onClickAway={handleClose}>
                            <Box className={customization.locale == "en" ? "languageBox" : "languageBoxArabic"}>
                <FormControl fullWidth>
                    <LanguageIcon className={customization.locale == "en" ? "languageIcon" : "languageIconArabic"} />
                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={value}
                        onChange={(event) => handleListItemClick(event)}
                    >
                        <MenuItem value='en'>English</MenuItem>
                        <MenuItem value='ar'>عربى</MenuItem>
                    </Select>
                </FormControl>
            </Box>

                                {/* <List component="nav" className={classes.navContainer}>
                                    <ListItemButton selected={language === 'en'} onClick={(event) => handleListItemClick(event, 'en')}>
                                        <ListItemText
                                            primary={
                                                <Grid container>
                                                    <Typography color="textPrimary">English</Typography>
                                                    <Typography variant="caption" color="textSecondary" sx={{ ml: '8px' }}>
                                                        (UK)
                                                    </Typography>
                                                </Grid>
                                            }
                                        />
                                    </ListItemButton>
                                    <ListItemButton selected={language === 'ar'} onClick={(event) => handleListItemClick(event, 'ar')}>
                                        <ListItemText
                                            primary={
                                                <Grid container>
                                                    <Typography color="textPrimary">عربي</Typography>
                                                    <Typography variant="caption" color="textSecondary" sx={{ ml: '8px' }}>
                                                        (Arabic)
                                                    </Typography>
                                                </Grid>
                                            }
                                        />
                                    </ListItemButton> */}
                                {/* </List> */}
                            </ClickAwayListener>
                        </Paper>
                    </Transitions>
                )}
            </Popper>
        </>
    );
};

export default LocalizationSection;
