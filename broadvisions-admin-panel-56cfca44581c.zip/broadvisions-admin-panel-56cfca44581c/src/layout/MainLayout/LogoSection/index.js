import React from 'react';
import { Link } from 'react-router-dom';

// material-ui
import { ButtonBase } from '@material-ui/core';
import { useTheme } from '@material-ui/core/styles';
// project imports
import config from 'config';
import Logo from 'ui-component/Logo';
import { useDispatch } from 'react-redux';
import { useState } from 'react';
import { Avatar, Chip, ListItemIcon, ListItemText, Typography, useMediaQuery } from '@material-ui/core';
import { MENU_OPEN, SET_MENU } from 'store/actions';

// ===========================|| MAIN LOGO ||=========================== //

const LogoSection = () => {
    const theme = useTheme();
    const dispatch = useDispatch();
    const matchesSM = useMediaQuery(theme.breakpoints.down('md'));
   
    const toggleClass = () => {
        if (config.defaultPath) {
            dispatch({ type: MENU_OPEN, id: 'dashboard' });
            if (matchesSM) dispatch({ type: SET_MENU, opened: false });
        }
    }

    return (

        <ButtonBase onClick={toggleClass} disableipple component={Link} to={config.defaultPath}>
            <Logo />
        </ButtonBase>
    );
}
export default LogoSection;
