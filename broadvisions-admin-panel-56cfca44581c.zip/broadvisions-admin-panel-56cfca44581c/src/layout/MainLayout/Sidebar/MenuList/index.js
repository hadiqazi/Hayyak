import React from 'react';

// material-ui
import { Typography } from '@material-ui/core';

// project imports
import NavGroup from './NavGroup';
import menuItem from 'menu-items';
import useAuth from 'hooks/useAuth';

// ===========================|| SIDEBAR MENU LIST ||=========================== //

const MenuList = () => {
    let menuItemsArray = [];

    let rememberUser = localStorage.getItem('rememberMe');
    rememberUser = rememberUser ? JSON.parse(rememberUser) : false;
    let user;
    if (rememberUser)
    {
         user = localStorage.getItem('user');
    }
    else if (!rememberUser){
         user = sessionStorage.getItem('user');
    }
    user = user ? JSON.parse(user) : {};
    
    menuItemsArray = menuItem.items;
    let menuItemChildren = [];
    for(let singleChildItem of menuItemsArray[0].children){
        if(user?.permissions && user?.permissions?.includes(singleChildItem?.id) || singleChildItem?.id === "dashboard"){
            menuItemChildren.push(singleChildItem);
        }
        
    }
    menuItemsArray[0].children = menuItemChildren;

    const navItems = menuItemsArray.map((item) => {
        switch (item.type) {
            case 'group':
                return <NavGroup key={item.id} item={item} />;
            default:
                return (
                    <Typography key={item.id} variant="h6" color="error" align="center">
                        Menu Items Error
                    </Typography>
                );
        }
    });

    return navItems;
};

export default MenuList;
