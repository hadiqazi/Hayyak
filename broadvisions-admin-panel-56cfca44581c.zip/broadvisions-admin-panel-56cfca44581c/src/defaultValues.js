/* eslint-disable */
// export const baseURL = 'https://dev.feedy.se:8080';
let url = 'https://hayyak.feedy.se:8081'
// if (process.env.REACT_APP_NODE_ENV?.trim() === 'development') {
//     url = 'http://hayyak.feedy.se:8081'
// }
// else if (process.env.REACT_APP_NODE_ENV?.trim() === 'staging') {
//     url = 'https://staging.hayyak.com.sa:8080'
// }
export const baseURL = url; //STAGING
export const userService = 'hayyak-user-service';
export const propertyService = 'hayyak-property-service';
export const bookingService = 'hayyak-booking-service';
export const version1 = 'v1';