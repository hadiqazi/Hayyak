import other from './other';
import admin from './admin';

// ===========================|| MENU ITEMS ||=========================== //

const menuItems = {
    items: [admin]
};

export default menuItems;
