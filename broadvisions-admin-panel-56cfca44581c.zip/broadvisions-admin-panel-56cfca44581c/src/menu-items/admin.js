import React from 'react';


// third-party
import { FormattedMessage } from 'react-intl';

// assets

import { DashboardIcon } from '@tabler/icons';
import { IconCalendarStats, IconAward, IconHome, IconBuildingArch, IconBrandBooking, IconUsers, IconPackage, IconBoxMultiple0, IconMessage } from '@tabler/icons';
import AddIcon from '@material-ui/icons/AddTwoTone';
// constant
const icons = { IconMessage, IconCalendarStats, IconAward, IconHome, IconBuildingArch, IconBrandBooking, IconBuildingArch, IconUsers, IconPackage, IconBoxMultiple0 };

// ===========================|| SAMPLE PAGE & DOCUMENTATION MENU ITEMS ||=========================== //


const other = {

  id: 'admin',
  type: 'group',

  children: [

    {
      id: 'dashboard',
      title: <FormattedMessage id="dashboard" />,
      type: 'item',
      url: '/dashboard',
      icon: icons.IconHome,
      breadcrumbs: false
    },

    {
      id: 'READ_ROLE',
      title: <FormattedMessage id="roles" />,
      type: 'item',
      url: '/roles',
      icon: icons.IconAward,
      breadcrumbs: false
    },
    {

      id: 'READ_BUILDING',
      title: <FormattedMessage id="buildings" />,
      type: 'item',
      url: '/buildings',
      icon: icons.IconBuildingArch,
      breadcrumbs: false
    },
    {
      id: 'READ_BOOKING',
      title: <FormattedMessage id="bookings" />,
      type: 'item',
      url: '/bookings',
      icon: icons.IconCalendarStats,
      breadcrumbs: false
    },
    {
      id: 'READ_REVIEW',
      title: <FormattedMessage id="reviews" />,
      type: 'item',
      url: '/reviews',
      icon: icons.IconMessage,
      breadcrumbs: false
    },
    {
      id: 'READ_ADMIN',
      title: <FormattedMessage id="staff" />,
      type: 'item',
      url: '/staff',
      icon: icons.IconUsers,
      breadcrumbs: false
    },
    {
      id: 'READ_AMENITY',
      title: <FormattedMessage id="amenity" />,
      type: 'item',
      url: '/amenity',
      icon: icons.IconBoxMultiple0,
      breadcrumbs: false
    },
    {

      id: 'READ_VAS',
      title: <FormattedMessage id="value-added-services" />,
      type: 'item',
      url: '/value-added-services',
      icon: icons.IconPackage,
      breadcrumbs: false
    },
  ]
};

export default other;
