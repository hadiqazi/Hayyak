import React, { lazy } from 'react';
import { useRoutes, Navigate } from 'react-router-dom';

// project imports
import MainRoutes from './MainRoutes';
import LoginRoutes from './LoginRoutes';
import useAuth from 'hooks/useAuth';

import MainLayout from 'layout/MainLayout';
import Loadable from 'ui-component/Loadable';
import AuthGuard from 'utils/route-guard/AuthGuard';

const Dashboard = Loadable(lazy(() => import('views/dashboard')));
const AmenityListing = Loadable(lazy(() => import('views/pages/amenity-pages/AmenityListing')));
const RoleListing = Loadable(lazy(() => import('views/pages/roles-pages/RoleListing')));
const RoleAddAndEdit = Loadable(lazy(() => import('views/pages/roles-pages/RoleAddAndEdit')));
const AmenityAddAndEdit = Loadable(lazy(() => import('views/pages/amenity-pages/AmenityAddAndEdit')));
const AddOnListing = Loadable(lazy(() => import('views/pages/add-on/addOnListing')));
const AddAndEditAddOn = Loadable(lazy(() => import('views/pages/add-on/AddAndEditAddOn')));
const BuildingListing = Loadable(lazy(() => import('views/pages/building/BuildingListing')));
const AddAndEditBuilding = Loadable(lazy(() => import('views/pages/building/AddAndEditBuilding')));
const PropertyListing = Loadable(lazy(() => import('views/pages/property/PropertyListing')));
const AddAndEditProperty = Loadable(lazy(() => import('views/pages/property/AddAndEditProperty')));
const PropertyDetails = Loadable(lazy(() => import('views/pages/property/PropertyDetails')));
const StaffListing = Loadable(lazy(() => import('views/pages/staff/StaffListing')));
const AddAndEditStaff = Loadable(lazy(() => import('views/pages/staff/StaffAddAndEdit')));
const ReviewsListing = Loadable(lazy(() => import('views/pages/reviews/ReviewsListing')));
// const AddAndEditReviews = Loadable(lazy(() => import('views/pages/reviews/ReviewsAddAndEdit')));
const BookingListing = Loadable(lazy(() => import('views/pages/booking/BookingListing')));
const BookingDetails = Loadable(lazy(() => import('views/pages/booking/BookingDetails')));

// ===========================|| ROUTING RENDER ||=========================== //

export default function ThemeRoutes() {

    const { isLoggedIn, user, checkPermission } = useAuth();

    let OtherRoutes = {
        path: '/',
        element: (
            <AuthGuard>
                <MainLayout />
            </AuthGuard>
        ),
        children: [{
            path: '/dashboard',
            element: <Dashboard />
        }]
    };

    if (checkPermission("READ_AMENITY")) {
        OtherRoutes.children.push({
            path: '/amenity',
            element: <AmenityListing />
        });
    }
    if (checkPermission("CREATE_AMENITY")) {
        OtherRoutes.children.push({
            path: '/amenity/add',
            element: <AmenityAddAndEdit />
        });
    }
    if (checkPermission("UPDATE_AMENITY")) {
        OtherRoutes.children.push({
            path: '/amenity/edit/:amenityId',
            element: <AmenityAddAndEdit />
        });
    }
    if (checkPermission("READ_VAS")) {
        OtherRoutes.children.push({
            path: '/value-added-services',
            element: <AddOnListing />
        });
    }

    if (checkPermission("UPDATE_VAS")) {
        OtherRoutes.children.push({
            path: '/value-added-services/edit/:addOnId',
            element: <AddAndEditAddOn />
        });
    }


    if (checkPermission("CREATE_VAS")) {
        OtherRoutes.children.push({
            path: '/value-added-services/add',
            element: <AddAndEditAddOn />
        });
    }

    if (checkPermission("READ_BUILDING")) {
        OtherRoutes.children.push({
            path: '/buildings',
            element: <BuildingListing />
        });
    }
    if (checkPermission("UPDATE_BUILDING")) {
        OtherRoutes.children.push({
            path: '/buildings/edit/:buildingId',
            element: <AddAndEditBuilding />
        });
    }
    if (checkPermission("CREATE_BUILDING")) {
        OtherRoutes.children.push({
            path: '/buildings/add',
            element: <AddAndEditBuilding />
        });
    }
    if (checkPermission("READ_SINGLE_PROPERTY")) {
        OtherRoutes.children.push({
            path: '/property/details/:propertyId',
            element: <PropertyDetails />
        });
    }
    if (checkPermission("READ_PROPERTY")) {
        OtherRoutes.children.push({
            path: '/property/:propertyId',
            element: <PropertyListing />
        });

    }
    if (checkPermission("CREATE_PROPERTY")) {
        OtherRoutes.children.push({
            path: '/property/add',
            element: <AddAndEditProperty />
        });
    }
    if (checkPermission("UPDATE_PROPERTY")) {
        OtherRoutes.children.push({
            path: '/property/edit/:propertyId',
            element: <AddAndEditProperty />
        });
    }
    if (checkPermission("READ_REVIEW")) {
        OtherRoutes.children.push({
            path: '/reviews',
            element: <ReviewsListing />
        });
    }
    if (checkPermission("READ_ADMIN")) {
        OtherRoutes.children.push({
            path: '/staff',
            element: <StaffListing />
        });
    }

    if (checkPermission("UPDATE_ADMIN")) {
        OtherRoutes.children.push({
            path: '/staff/edit/:staffId',
            element: <AddAndEditStaff />
        });
    }
    if (checkPermission("CREATE_ADMIN")) {
        OtherRoutes.children.push({
            path: '/staff/add',
            element: <AddAndEditStaff />
        });
    }
    if (checkPermission("READ_ROLE")) {
        OtherRoutes.children.push({
            path: '/roles',
            element: <RoleListing />
        });
    }
    if (checkPermission("CREATE_ROLE")) {
        OtherRoutes.children.push({
            path: '/roles/add',
            element: <RoleAddAndEdit />
        });
    }
    if (checkPermission("UPDATE_ROLE")) {
        OtherRoutes.children.push({
            path: '/roles/edit/:roleId',
            element: <RoleAddAndEdit />
        });
    }
    if (checkPermission("READ_BOOKING")) {
        OtherRoutes.children.push({
            path: '/bookings',
            element: <BookingListing />
        });
    }
    if (checkPermission("DETAIL_BOOKING")) {
        OtherRoutes.children.push({
            path: '/bookings/details/:bookingId',
            element: <BookingDetails />
        });
    }

    OtherRoutes.children.push({
        path: '/*',
        element: <Navigate to="/dashboard" />
    });

    return useRoutes([LoginRoutes, OtherRoutes]);
}
