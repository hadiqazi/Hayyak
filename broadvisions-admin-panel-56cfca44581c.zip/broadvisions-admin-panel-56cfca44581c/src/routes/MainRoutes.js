import React, { lazy } from 'react';
import MainLayout from 'layout/MainLayout';
import Loadable from 'ui-component/Loadable';
import AuthGuard from 'utils/route-guard/AuthGuard';

const Dashboard = Loadable(lazy(() => import('views/dashboard')));
const AmenityListing = Loadable(lazy(() => import('views/pages/amenity-pages/AmenityListing')));
const RoleListing = Loadable(lazy(() => import('views/pages/roles-pages/RoleListing')));
const RoleAddAndEdit = Loadable(lazy(() => import('views/pages/roles-pages/RoleAddAndEdit')));
const AmenityAddAndEdit = Loadable(lazy(() => import('views/pages/amenity-pages/AmenityAddAndEdit')));
const AddOnListing = Loadable(lazy(() => import('views/pages/add-on/addOnListing')));
const AddAndEditAddOn = Loadable(lazy(() => import('views/pages/add-on/AddAndEditAddOn')));
const BuildingListing = Loadable(lazy(() => import('views/pages/building/BuildingListing')));
const AddAndEditBuilding = Loadable(lazy(() => import('views/pages/building/AddAndEditBuilding')));
const PropertyListing = Loadable(lazy(() => import('views/pages/property/PropertyListing')));
const AddAndEditProperty = Loadable(lazy(() => import('views/pages/property/AddAndEditProperty')));
const PropertyDetails = Loadable(lazy(() => import('views/pages/property/PropertyDetails')));
const StaffListing = Loadable(lazy(() => import('views/pages/staff/StaffListing')));
const AddAndEditStaff = Loadable(lazy(() => import('views/pages/staff/StaffAddAndEdit')));
const ReviewsListing = Loadable(lazy(() => import('views/pages/reviews/ReviewsListing')));
// const AddAndEditReviews = Loadable(lazy(() => import('views/pages/reviews/ReviewsAddAndEdit')));
const BookingListing = Loadable(lazy(() => import('views/pages/booking/BookingListing')));
const BookingDetails = Loadable(lazy(() => import('views/pages/booking/BookingDetails')));

const MainRoutes = {
    path: '/',
    element: (
        <AuthGuard>
            <MainLayout />
        </AuthGuard>
    ),
    children: [
        {
            path: '/dashboard',
            element: <Dashboard />
        },

        {
            path: '/amenity',
            element: <AmenityListing />
        },
        {
            path: '/amenity/edit/:amenityId',
            element: <AmenityAddAndEdit />
        },
        {
            path: '/amenity/add',
            element: <AmenityAddAndEdit />
        },
        {
            path: '/roles',
            element: <RoleListing />
        },
        {
            path: '/roles/add',
            element: <RoleAddAndEdit />
        },
        {
            path: '/roles/edit/:roleId',
            element: <RoleAddAndEdit />
        },
        {
            path: '/value-added-services',
            element: <AddOnListing />
        },
        {
            path: '/value-added-services/edit/:addOnId',
            element: <AddAndEditAddOn />
        },
        {
            path: '/value-added-services/add',
            element: <AddAndEditAddOn />
        },

        {
            path: '/buildings',
            element: <BuildingListing />
        },

        {
            path: '/buildings/edit/:buildingId',
            element: <AddAndEditBuilding />
        },
        {
            path: '/buildings/add',
            element: <AddAndEditBuilding />
        },
        {
            path: '/property/:propertyId',
            element: <PropertyListing />
        },
        {
            path: '/property/add',
            element: <AddAndEditProperty />
        },
        {
            path: '/property/edit/:propertyId',
            element: <AddAndEditProperty />
        },
        {
            path: '/property/details/:propertyId',
            element: <PropertyDetails />
        },
        {
            path: '/reviews',
            element: <ReviewsListing />
        },

        {
            path: '/staff',
            element: <StaffListing />
        },
        {
            path: '/staff/edit/:staffId',
            element: <AddAndEditStaff />
        },
        {
            path: '/staff/add',
            element: <AddAndEditStaff />
        },
        {
            path: '/bookings',
            element: <BookingListing />
        },
        {
            path: '/bookings/details/:bookingId',
            element: <BookingDetails />
        },


    ]
};

export default MainRoutes;
