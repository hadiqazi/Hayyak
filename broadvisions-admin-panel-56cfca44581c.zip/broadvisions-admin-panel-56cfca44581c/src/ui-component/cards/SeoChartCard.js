import PropTypes from 'prop-types';
import React from 'react';

// material-ui
import { useTheme } from '@material-ui/styles';
import { Box, Grid, Typography, useMediaQuery } from '@material-ui/core';

// third party
import Chart from 'react-apexcharts';

// project imports
import MainCard from './MainCard';

// =============================|| SEO CHART CARD ||============================= //

const SeoChartCard = ({ chartData, value, title, icon, type }) => {
    const theme = useTheme();
    const matchDownMd = useMediaQuery(theme.breakpoints.down('md'));

    return (
        <MainCard>
            <Grid container justifyContent="space-between" spacing={2}>
        
                    <Grid item xs={12}>
                        <Chart {...chartData} />
                    </Grid>
             
            </Grid>
        </MainCard>
    );
};

export default SeoChartCard;
