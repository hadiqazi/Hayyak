// action - state management
import { ACCOUNT_INITIALIZE, LOGIN, LOGOUT, REMEMBER } from './actions';

// ===========================|| ACCOUNT REDUCER ||=========================== //

const accountReducer = (state, action) => {
    switch (action.type) {
        case ACCOUNT_INITIALIZE: {
            const { isLoggedIn, user, rememberMe } = action.payload;
            return {
                ...state,
                isLoggedIn,
                isInitialized: true,
                user,
                rememberMe
            };
        }
        case LOGIN: {
            const { user, rememberMe } = action.payload;
            return {
                ...state,
                isLoggedIn: true,
                user,
                rememberMe
            };
        }
 
        case LOGOUT: {
            return {
                ...state,
                isLoggedIn: false,
                user: null,
                rememberMe: false
            };
        }
        default: {
            return { ...state };
        }
    }
};

export default accountReducer;
