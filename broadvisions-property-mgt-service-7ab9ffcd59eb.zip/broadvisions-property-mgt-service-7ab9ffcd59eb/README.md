### Backend REST APIs
This is the private repository for the RESTFUL APIs.

### How to run this project

1. npm install
2. npm start
