module.exports = {
  mongodb:
    process.env.MONGO_CONNECTION_STRING ||
    "mongodb+srv://dbuser:dbuser123@dev.utgx0.mongodb.net/hayyak-dev?retryWrites=true&w=majority",
};
