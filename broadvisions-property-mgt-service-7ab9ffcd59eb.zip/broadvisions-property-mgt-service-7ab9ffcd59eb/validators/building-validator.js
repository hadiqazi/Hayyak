const Joi = require("joi")

class BuildingValidator {
    create() {
        return Joi.object({
            name: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2).required(),
            description: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2),
            address: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2),
            city: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2).required(),
            state: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2).required(),
            country: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2).required(),
            location: Joi.object({
                coordinates: Joi.array().min(2).max(2).items(Joi.number()).required()
            }).required(),
            zip: Joi.string().min(5).required(),
            checkInTime: Joi.string().regex(/^([01]*\d|2[0-3]):([0-5]\d)$/).required(),
            checkOutTime: Joi.string().regex(/^([01]*\d|2[0-3]):([0-5]\d)$/).required(),
        }).options({ abortEarly: false });
    }

    update() {
        return Joi.object({
            id: Joi.string().required(),
            name: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            description: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            address: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            city: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            state: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            country: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            location: Joi.object({
                coordinates: Joi.array().min(2).max(2).items(Joi.number())
            }),
            zip: Joi.string().min(5),
            checkInTime: Joi.string().regex(/^([01]*\d|2[0-3]):([0-5]\d)$/),
            checkOutTime: Joi.string().regex(/^([01]*\d|2[0-3]):([0-5]\d)$/),
        }).options({ abortEarly: false });
    }

    delete() {
        return Joi.object({
            id: Joi.string().required()
        })
    }
}

module.exports = new BuildingValidator()