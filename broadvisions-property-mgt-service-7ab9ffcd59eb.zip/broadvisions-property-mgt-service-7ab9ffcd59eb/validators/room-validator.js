const Joi = require("joi");

class RoomValidator {
    create() {
        return Joi.object({
            number: Joi.string().required(),
            propertyId: Joi.string().required()
        }).options({ abortEarly: false });
    }

    update() {
        return Joi.object({
            id: Joi.string().required(),
            number: Joi.string(),
        }).options({ abortEarly: false });
    }

    delete() {
        return Joi.object({
            id: Joi.string().required()
        })
    }
}

module.exports = new RoomValidator()