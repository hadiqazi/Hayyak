const AmenityValidator = require("./amenity-validator")
const VASValidator = require("./vas-validator")
const BuildingValidator = require("./building-validator")
const PropertyValidator = require("./property-validator")
const RoomValidator = require("./room-validator")
const RatingValidator = require('./rating.validator')

module.exports = {
    AmenityValidator,
    VASValidator,
    BuildingValidator,
    PropertyValidator,
    RoomValidator,
    RatingValidator
};