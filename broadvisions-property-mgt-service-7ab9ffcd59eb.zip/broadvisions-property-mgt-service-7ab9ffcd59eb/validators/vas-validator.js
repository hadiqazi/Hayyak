const Joi = require("joi");

class VASValidator {
    create() {
        return Joi.object({
            name: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2).required(),
            price: Joi.number().required(),
            description: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2),
            image: Joi.object().required()
        }).options({ abortEarly: false });
    }

    update() {
        return Joi.object({
            id: Joi.string().required(),
            name: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            price: Joi.number(),
            description: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            image: Joi.object()
        }).options({ abortEarly: false });
    }

    delete() {
        return Joi.object({
            id: Joi.string().required()
        })
    }

    multiple() {
        return Joi.object({
            ids: Joi.array().required(),
        })
    }
}

module.exports = new VASValidator()