const Joi = require("joi");

class AmenityValidator {
    create() {
        return Joi.object({
            name: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2).required(),
            typeId: Joi.string().required()
        }).options({ abortEarly: false });
    }

    update() {
        return Joi.object({
            id: Joi.string().required(),
            name: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
        }).options({ abortEarly: false });
    }

    delete() {
        return Joi.object({
            id: Joi.string().required()
        })
    }
}

module.exports = new AmenityValidator()