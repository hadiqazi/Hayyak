const Joi = require("joi");

class RatingValidator {
  create() {
    return Joi.object({
      rating: Joi.number().min(1).max(5).required(),
      comment: Joi.string().allow(null, ""),
      // buildingId: Joi.string().required(),
      propertyId: Joi.string().required(),
      bookingId: Joi.string().required(),
    });
  }

  filter() {
    return Joi.object({
      propertyId: Joi.string(),
      buildingId: Joi.string(),
      bookingId: Joi.string(),
      status: Joi.string(),
    });
  }

  status() {
    return Joi.object({
      id: Joi.string().required(),
      status: Joi.string().valid("REJECT", "ACCEPT").required(),
    });
  }

  lookup() {
    return Joi.object({
      userId: Joi.string().required(),
      propertyId: Joi.string().required(),
    });
  }

  update() {
    return Joi.object({
      id: Joi.string().required(),
      review: Joi.string().allow(null, ""),
      rating: Joi.number().min(1).max(5),
    });
  }
}

module.exports = new RatingValidator();
