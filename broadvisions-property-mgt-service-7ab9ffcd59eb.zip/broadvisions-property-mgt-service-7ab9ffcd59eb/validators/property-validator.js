const Joi = require("joi");

class PropertyValidator {
    create() {
        return Joi.object({
            name: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2).required(),
            propertyTypeId: Joi.string().required(),
            buildingId: Joi.string().required(),
            bedTypeId: Joi.string().required(),
            price: Joi.number().required(),
            description: Joi.object().keys({
                en: Joi.string().required(),
                ar: Joi.string()
            }).unknown(true).min(2),
            rooms: Joi.array().items(Joi.object().keys({
                number: Joi.string().required(),
            })).min(1).required(),
            coverImage: Joi.object().required(),
            images: Joi.array().items(Joi.object()),
            amenities: Joi.array().items(Joi.string()),
            valueAddedServices: Joi.array().items(Joi.string()),
            guestCount: Joi.number().required(),
        }).options({ abortEarly: false });
    }

    update() {
        return Joi.object({
            id: Joi.string().required(),
            name: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            propertyType: Joi.string(),
            buildingId: Joi.string(),
            bedType: Joi.string(),
            price: Joi.number(),
            description: Joi.object().keys({
                en: Joi.string(),
                ar: Joi.string()
            }).unknown(true).min(2),
            coverImage: Joi.object(),
            images: Joi.array().items(Joi.object()),
            deletedImages: Joi.array().items(Joi.string()),
            amenities: Joi.array().items(Joi.string()),
            valueAddedServices: Joi.array().items(Joi.string()),
            guestCount: Joi.number(),
        }).options({ abortEarly: false });
    }

    delete() {
        return Joi.object({
            id: Joi.string().required()
        })
    }

    filter() {
        return Joi.object({
            noOfRooms: Joi.number().required(),
            coordinates: Joi.object({
                lat: Joi.number().required(),
                lng: Joi.number().required(),
            }).required(),
            bedType: Joi.string(),
            roomType: Joi.string(),
            minPrice: Joi.number(),
            maxPrice: Joi.number(),
            amenities: Joi.array(),
            checkIn: Joi.string().required(),
            checkOut: Joi.string().required(),
            vas: Joi.array(),
            noOfGuests: Joi.number(),
            rating: Joi.number().min(0).max(5),
            page: Joi.number(),
            sortOrder: Joi.string().valid("ASC", "DESC"),
            sortColumn: Joi.string(),
            searchText: Joi.string()
        })
    }

    multipleProperties() {
        return Joi.object({
            ids: Joi.array().required(),
            attributes: Joi.array(),
            populateRooms: Joi.boolean()
        })
    }

    topRated() {
        return Joi.object({
            days: Joi.number(),
            limit: Joi.number(),
        })
    }

    bookingCost() {
        return Joi.object({
            noOfRooms: Joi.number().required(),
            propertyId: Joi.string().required(),
            services: Joi.array().items(Joi.object().keys({
                id: Joi.string().required(),
                quantity: Joi.number().required()
            }))
        })
    }
}

module.exports = new PropertyValidator()