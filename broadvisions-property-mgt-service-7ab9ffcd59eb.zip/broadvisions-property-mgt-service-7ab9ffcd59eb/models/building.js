const mongoose = require("mongoose");

const geoSchema = mongoose.Schema({
  type: {
    type: String,
    default: "Point",
  },
  coordinates: {
    type: [Number],
  },
});

const buildingSchema = mongoose.Schema(
  {
    name: {
      type: Object,
      required: true,
    },
    description: {
      type: Object,
      trim: true,
    },
    location: {
      type: geoSchema,
      index: "2dsphere",
    },
    address: {
      type: Object,
      trim: true,
    },
    city: {
      type: Object,
      trim: true,
    },
    state: {
      type: Object,
      trim: true,
    },
    zip: {
      type: String,
      trim: true,
    },
    country: {
      type: Object,
      trim: true,
    },
    checkInTime: {
      type: String,
    },
    checkOutTime: {
      type: String,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

buildingSchema.statics.findWithLanguage = async (language, options = {}) => {
  const buildings = await Building.find({ ...options });
  // .populate("ratings", "_id rate")
  // .populate({
  //   path: "reviews",
  //   select: "review",
  //   match: { "review.status": "ACCEPT" },
  //   options: {
  //     limit: 5,
  //     sort: { createdAt: -1 },
  //   },
  // });
  let finalBuildings = [];

  if (language) {
    buildings.forEach((building) => {
      finalBuildings.push(building.getLanguageBasedModel(language));
    });
  } else {
    finalBuildings = buildings;
  }

  return finalBuildings;
};

buildingSchema.methods.getLanguageBasedModel = function (language) {
  if (language) {
    const supportedLanguages = process.env.SUPPORTED_LANGUAGES.split(",");
    if (!supportedLanguages.includes(language)) {
      language = process.env.DEFAULT_LANGUAGE;
    }
  }

  let building = { ...this._doc };
  building.name = this.name[language];
  if (this.description) building.description = this.description[language];
  if (this.address) building.address = this.address[language];
  building.city = this.city[language];
  building.state = this.state[language];
  building.country = this.country[language];

  return building;
};

const Building = mongoose.model("building", buildingSchema);
module.exports = Building;
