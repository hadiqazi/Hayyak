const mongoose = require("mongoose")

const roomSchema = mongoose.Schema({
    number: {
        type: String,
        required: true
    },
    property: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'property',
        required: true
    },
}, {
    timestamps: true,
    strict: true,
})

roomSchema.index({ number: 1, property: 1 }, { unique: true });

const Room = mongoose.model('room', roomSchema)
module.exports = Room