const mongoose = require("mongoose")

const propertyTypeSchema = mongoose.Schema({
    name: {
        type: Object,
        unique: true,
        required: true
    },
}, {
    timestamps: true,
    strict: true,
})

propertyTypeSchema.statics.findWithLanguage = async(language) => {
    const propertyTypes = await PropertyType.find()
    let finalTypes = [];

    if (language) {
        propertyTypes.forEach((propertyType) => {
            finalTypes.push(propertyType.getLanguageBasedModel(language))
        })
    } else {
        finalTypes = propertyTypes
    }

    return finalTypes
}

propertyTypeSchema.methods.getLanguageBasedModel = function(language) {
    if (language) {
        const supportedLanguages = process.env.SUPPORTED_LANGUAGES.split(",")
        if (!supportedLanguages.includes(language)) {
            language = process.env.DEFAULT_LANGUAGE
        }
    }

    let propertyType = {...this._doc }
    propertyType.name = this.name[language]

    return propertyType
}

const PropertyType = mongoose.model("property_type", propertyTypeSchema)
module.exports = PropertyType