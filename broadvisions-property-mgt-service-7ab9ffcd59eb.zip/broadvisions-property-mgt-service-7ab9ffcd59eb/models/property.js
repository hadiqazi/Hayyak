const mongoose = require("mongoose")

const propertySchema = mongoose.Schema({
    name: {
        type: Object,
        required: true
    },
    propertyType: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'property_type',
        required: true
    },
    building: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'building',
        required: true
    },
    bedType: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'bed_type',
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    description: {
        type: Object,
        trim: true
    },
    coverImage: {
        type: Object,
        required: true
    },
    images: [{
        type: Object
    }],
    amenities: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'amenity'
    }],
    valueAddedServices: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'value_added_service'
    }],
    reviews: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: "rating",
        },
      ],
    average: {
        type: Object
    },
    guestCount: {
        type: Number
    },
    isDeleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true,
    strict: true,
})

propertySchema.virtual('rooms', {
    ref: 'room',
    localField: '_id',
    foreignField: 'property',
})

propertySchema.statics.findWithLanguage = async(language, criteria = {}, options) => {
    const properties = await Property.find(criteria).populate('propertyType').populate('building')
        .populate('bedType').populate('amenities').populate('valueAddedServices').populate('rooms') 
        .populate({
            path: "reviews",
            select: "review",
            match: { "review.status": "ACCEPT" },
            options: {
              limit: 3,
              sort: { createdAt: -1 },
            },
          }).exec()
    let finalProperties = [];

    properties.forEach((property) => {
        let finalProperty

        if (language) {
            finalProperty = property.getLanguageBasedModel(language)
            finalProperty.propertyType = property.propertyType.getLanguageBasedModel(language)
            finalProperty.building = property.building.getLanguageBasedModel(language)
            finalProperty.bedType = property.bedType.getLanguageBasedModel(language)

            let amenities = []
            property.amenities.forEach((amenity) => {
                const amenityDoc = amenity.getLanguageBasedModel(language)

                // Get language based name of amenityType as populate won't consider 'language' param
                amenityDoc.amenityType = amenityDoc.amenityType.getLanguageBasedModel(language)

                amenities.push(amenityDoc)
            })
            finalProperty.amenities = amenities

            let vasArray = []
            property.valueAddedServices.forEach((vas) => {
                vasArray.push(vas.getLanguageBasedModel(language))
            })
            finalProperty.valueAddedServices = vasArray
        }

        finalProperty = finalProperty || {...property._doc }

        // Add room count
        finalProperty.roomCount = property.rooms.length
        finalProperty['coverImage'] = property.coverImage ? property.coverImage['imageUrl'] : null;

        // Add rooms array
        if (options && options.populateRooms) {
            finalProperty.rooms = property.rooms.map(r => ({ _id: r._id, number: r.number, }))
        }
        if(options && options.attributes && options.attributes.length > 0) {
            let obj = {}
            options.attributes.forEach((attr) => {
                obj[attr] = finalProperty[attr]
            })
            finalProperty = obj;
        }

        finalProperties.push(finalProperty)
    })

    return finalProperties
}

propertySchema.statics.findWithFilter = async(language, criteria = {}, {coordinates, noOfRooms }, options, { pagination, sort }) => {
    const properties = await Property.find(criteria, [], pagination).sort(sort).populate('propertyType').populate({path:'building', match: {
            location: {
                $near: {
                    $maxDistance: 3000,
                    $geometry: {
                        type: "Point",
                        coordinates: [coordinates.lng, coordinates.lat]
                      }
                }
            }
        }})
        .populate('bedType').populate('amenities').populate('valueAddedServices').populate('rooms')
        .populate({
            path: "reviews",
            select: "review",
            match: { "review.status": "ACCEPT" },
            options: {
            //   limit: 5,
              sort: { createdAt: -1 },
            },
          }).exec()

    let finalProperties = [];

    properties.forEach((property) => {
        let finalProperty
        if(property.building && property.rooms && property.rooms.length >= noOfRooms) { //noOfRooms should be greater or equal to input
            if (language) {
                finalProperty = property.getLanguageBasedModel(language)
                finalProperty.propertyType = property.propertyType.getLanguageBasedModel(language)
                finalProperty.building = property.building.getLanguageBasedModel(language)
                finalProperty.bedType = property.bedType.getLanguageBasedModel(language)
                finalProperty.reviewCount = property.reviews.length
                delete finalProperty['reviews']
    
                let amenities = []
                property.amenities.forEach((amenity) => {
                    const amenityDoc = amenity.getLanguageBasedModel(language)
    
                    // Get language based name of amenityType as populate won't consider 'language' param
                    amenityDoc.amenityType = amenityDoc.amenityType.getLanguageBasedModel(language)
    
                    amenities.push(amenityDoc)
                })
                finalProperty.amenities = amenities
    
                let vasArray = []
                property.valueAddedServices.forEach((vas) => {
                    vasArray.push(vas.getLanguageBasedModel(language))
                })
                finalProperty.valueAddedServices = vasArray
            }
    
            finalProperty = finalProperty || {...property._doc }
    
            // Add room count
            finalProperty.roomCount = property.rooms.length
    
            // Add rooms array
            if (options && options.populateRooms) {
                finalProperty.rooms = property.rooms.map(r => ({ _id: r._id, number: r.number, }))
            }
    
            finalProperties.push(finalProperty)
        }
    })
    return finalProperties
}

propertySchema.methods.getLanguageBasedModel = function(language) {
    if (language) {
        const supportedLanguages = process.env.SUPPORTED_LANGUAGES.split(",")
        if (!supportedLanguages.includes(language)) {
            language = process.env.DEFAULT_LANGUAGE
        }
    }

    let property = {...this._doc }
    property.name = this.name[language]
    if (this.description)
        property.description = this.description[language]

    return property
}

const Property = mongoose.model("property", propertySchema)
module.exports = Property