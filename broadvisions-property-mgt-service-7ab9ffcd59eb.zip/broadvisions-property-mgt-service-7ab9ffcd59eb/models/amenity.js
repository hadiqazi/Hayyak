const mongoose = require("mongoose")

const amenitySchema = mongoose.Schema({
    name: {
        type: Object,
        unique: true,
        required: true
    },
    amenityType: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'amenity_type',
        required: true
    },
}, {
    timestamps: true,
    strict: true,
})

amenitySchema.pre('find', async function(next) {
    this.populate('amenityType')
    next()
})

amenitySchema.statics.findWithLanguage = async(language) => {
    const amenities = await Amenity.find()
    let finalAmenities = [];

    amenities.forEach((amenity) => {
        let finalAmenity

        if (language) {
            finalAmenity = amenity.getLanguageBasedModel(language)
            finalAmenity.amenityType = amenity.amenityType.getLanguageBasedModel(language)
        }
        finalAmenities.push(finalAmenity || amenity)
    })

    return finalAmenities
}

amenitySchema.methods.getLanguageBasedModel = function(language) {
    if (language) {
        const supportedLanguages = process.env.SUPPORTED_LANGUAGES.split(",")
        if (!supportedLanguages.includes(language)) {
            language = process.env.DEFAULT_LANGUAGE
        }
    }

    let amenity = {...this._doc }
    amenity.name = this.name[language]

    return amenity
}

const Amenity = mongoose.model("amenity", amenitySchema)
module.exports = Amenity