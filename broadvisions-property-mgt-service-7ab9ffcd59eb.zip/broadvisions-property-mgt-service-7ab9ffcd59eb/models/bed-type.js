const mongoose = require("mongoose")

const bedTypeSchema = mongoose.Schema({
    name: {
        type: Object,
        unique: true,
        required: true
    },
}, {
    timestamps: true,
    strict: true,
})

bedTypeSchema.statics.findWithLanguage = async(language) => {
    const bedTypes = await BedType.find()
    let finalTypes = [];

    if (language) {
        bedTypes.forEach((bedType) => {
            finalTypes.push(bedType.getLanguageBasedModel(language))
        })
    } else {
        finalTypes = bedTypes
    }

    return finalTypes
}

bedTypeSchema.methods.getLanguageBasedModel = function(language) {
    if (language) {
        const supportedLanguages = process.env.SUPPORTED_LANGUAGES.split(",")
        if (!supportedLanguages.includes(language)) {
            language = process.env.DEFAULT_LANGUAGE
        }
    }

    let bedType = {...this._doc }
    bedType.name = this.name[language]

    return bedType
}

const BedType = mongoose.model("bed_type", bedTypeSchema)
module.exports = BedType