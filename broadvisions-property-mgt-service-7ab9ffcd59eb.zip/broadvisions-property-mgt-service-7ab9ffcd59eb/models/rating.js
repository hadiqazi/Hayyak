const mongoose = require("mongoose");

const reviewSchema = mongoose.Schema({
  status: {
    type: String,
  },
  comment: {
    type: String,
  },
});

const ratingSchema = mongoose.Schema(
  {
    building: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "building",
    },
    property: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "property",
    },
    bookingId: {
      type: String,
    },
    rate: {
      type: Number,
      required: true,
    },
    review: {
      type: reviewSchema,
    },
    user: {
      type: String,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

const Rating = mongoose.model("rating", ratingSchema);
module.exports = Rating;
