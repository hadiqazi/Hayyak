const AmenityType = require("./amenity-type");
const Amenity = require("./amenity");
const VAS = require("./value-added-service");
const Building = require("./building");
const BedType = require("./bed-type");
const PropertyType = require("./property-type");
const Property = require("./property");
const Room = require("./room");
const Rating = require("./rating");

module.exports = {
  AmenityType,
  Amenity,
  VAS,
  Building,
  BedType,
  PropertyType,
  Property,
  Room,
  Rating,
};
