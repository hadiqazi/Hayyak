const mongoose = require('mongoose')

const vasSchema = mongoose.Schema({
    name: {
        type: Object,
        unique: true,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    description: {
        type: Object,
        trim: true
    },
    image: {
        type: Object,
        required: true
    }
}, {
    timestamps: true,
    strict: true
})

vasSchema.methods.getLanguageBasedModel = function(language) {
    if (language) {
        const supportedLanguages = process.env.SUPPORTED_LANGUAGES.split(",")
        if (!supportedLanguages.includes(language)) {
            language = process.env.DEFAULT_LANGUAGE
        }
    }

    let vas = {...this._doc }
    vas.name = this.name[language]
    vas.description = this.description[language]

    return vas
}

vasSchema.statics.findWithLanguage = async(language) => {
    const valueAddedServices = await VAS.find()
    let finalServices = []

    if (language) {
        valueAddedServices.forEach((vas) => {
            finalServices.push(vas.getLanguageBasedModel(language))
        })
    } else {
        finalServices = valueAddedServices
    }

    return finalServices
}

const VAS = mongoose.model('value_added_service', vasSchema)
module.exports = VAS