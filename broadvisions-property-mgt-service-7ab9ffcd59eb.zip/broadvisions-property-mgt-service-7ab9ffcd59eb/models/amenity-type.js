const mongoose = require("mongoose")

const amenityTypeSchema = mongoose.Schema({
    name: {
        type: Object,
        unique: true,
        required: true
    },
}, {
    timestamps: true,
    strict: true,
})

amenityTypeSchema.statics.findWithLanguage = async(language) => {
    const amenityTypes = await AmenityType.find()
    let finalTypes = [];

    if (language) {
        amenityTypes.forEach((amenityType) => {
            finalTypes.push(amenityType.getLanguageBasedModel(language))
        })
    } else {
        finalTypes = amenityTypes
    }

    return finalTypes
}

amenityTypeSchema.methods.getLanguageBasedModel = function(language) {
    if (language) {
        const supportedLanguages = process.env.SUPPORTED_LANGUAGES.split(",")
        if (!supportedLanguages.includes(language)) {
            language = process.env.DEFAULT_LANGUAGE
        }
    }

    let amenityType = {...this._doc }
    amenityType.name = this.name[language]

    return amenityType
}

const AmenityType = mongoose.model("amenity_type", amenityTypeSchema)
module.exports = AmenityType