const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { AmenityService } = require("../../../services/v1")
const { AmenityValidator } = require("../../../validators");
const { authenticate } = require('../../middlewares/auth')

router.post("/", authenticate("CREATE_AMENITY"), async(req, resp) => {
    try {
        await AmenityValidator.create().validateAsync(req.body)

        AmenityService.createAmenity(req.body).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.get('/', authenticate("READ_AMENITY,CUSTOMER"), async(req, resp) => {
    try {
        AmenityService.getAllAmenities(req.headers.language).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.put('/:id', authenticate("UPDATE_AMENITY"), async(req, resp) => {
    try {
        await AmenityValidator.update().validateAsync({
            ...req.params,
            ...req.body
        })

        AmenityService.updateAmenity(req.params.id, req.body).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.delete('/:id', authenticate("DELETE_AMENITY"), async(req, resp) => {
    try {
        await AmenityValidator.delete().validateAsync(req.params)

        AmenityService.deleteAmenity(req.params.id).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

module.exports = router