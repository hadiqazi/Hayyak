const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { RoomService } = require("../../../services/v1")
const { RoomValidator } = require("../../../validators");
const { authenticate } = require('../../middlewares/auth')

router.post("/", authenticate("CREATE_ROOM"), async(req, resp) => {
    try {
        await RoomValidator.create().validateAsync(req.body)

        RoomService.createRoom(req.body).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.get('/', authenticate("READ_ROOM"), async(req, resp) => {
    try {
        RoomService.getRooms(req.query.propertyId).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.put('/:id', authenticate("UPDATE_ROOM"), async(req, resp) => {
    try {
        await RoomValidator.update().validateAsync({
            ...req.params,
            ...req.body
        })

        RoomService.updateRoom(req.params.id, req.body).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.delete('/:id', authenticate("DELETE_ROOM"), async(req, resp) => {
    try {
        await RoomValidator.delete().validateAsync(req.params)

        RoomService.deleteRoom(req.params.id).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

module.exports = router