const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { AmenityTypeService, BedTypeService, PropertyTypeService } = require("../../../services/v1")
const { authenticate } = require('../../middlewares/auth')

router.get("/getAllTypes", authenticate("READ_ALL_TYPES,IS_SERVICE"), async(req, resp) => {
    try {
        const language = req.headers.language

        const [amenityTypeRes, bedTypeRes, propertyTypeRes] = await Promise.all([
            AmenityTypeService.getAllAmenityTypes(language),
            BedTypeService.getAllBedTypes(language),
            PropertyTypeService.getAllPropertyTypes(language)
        ])

        resp.status(200).send({
            status: 200,
            message: __("data.found"),
            amenityTypes: amenityTypeRes.amenityTypes,
            bedTypes: bedTypeRes.bedTypes,
            propertyTypes: propertyTypeRes.propertyTypes
        })
    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: "Error",
            error,
        });
    }
})

module.exports = router