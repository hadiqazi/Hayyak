const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { BedTypeService } = require("../../../services/v1")
const { authenticate } = require('../../middlewares/auth')

router.get("/", authenticate("READ_BED_TYPE"), async(req, resp) => {
    try {
        BedTypeService.getAllBedTypes(req.headers.language)
            .then((result) => {
                resp.status(result.status).send(result);
            })
            .catch(handleRouteError(resp));
    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
});

module.exports = router