const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { AmenityTypeService } = require("../../../services/v1")
const { authenticate } = require('../../middlewares/auth')

router.get("/", authenticate("READ_AMENITY_TYPE"), async(req, resp) => {
    try {
        AmenityTypeService.getAllAmenityTypes(req.headers.language)
            .then((result) => {
                resp.status(result.status).send(result);
            })
            .catch(handleRouteError(resp));
    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
});

module.exports = router