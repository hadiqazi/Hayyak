const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { PropertyTypeService } = require("../../../services/v1")
const { authenticate } = require('../../middlewares/auth')

router.get("/", authenticate("READ_PROPERTY_TYPE"), async(req, resp) => {
    try {
        PropertyTypeService.getAllPropertyTypes(req.headers.language)
            .then((result) => {
                resp.status(result.status).send(result);
            })
            .catch(handleRouteError(resp));
    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
});

module.exports = router