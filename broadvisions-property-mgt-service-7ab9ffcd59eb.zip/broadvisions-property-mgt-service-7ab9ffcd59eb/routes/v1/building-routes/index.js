const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { BuildingService } = require("../../../services/v1")
const { BuildingValidator } = require("../../../validators");
const { authenticate } = require('../../middlewares/auth')

router.post("/", authenticate("CREATE_BUILDING"), async(req, resp) => {
    try {
        await BuildingValidator.create().validateAsync(req.body)

        BuildingService.createBuilding(req.body).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

// router.post("/coordinates", async(req, resp) => {
//     try {
//         // await BuildingValidator.create().validateAsync(req.body)

//         BuildingService.findByCoordinated(req.body).then((result) => {
//             resp.status(result.status).send(result)
//         }).catch(handleRouteError(resp))

//     } catch (error) {
//         handleRouteError(resp)({
//             status: 400,
//             message: __("mandatory.fields"),
//             error,
//         });
//     }
// })

router.get("/", authenticate("READ_BUILDING"), async(req, resp) => {
    try {
        BuildingService.getBuildings(req.headers.language).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.put("/:id", authenticate("UPDATE_BUILDING"), async(req, resp) => {
    try {
        await BuildingValidator.update().validateAsync({
            ...req.params,
            ...req.body
        })

        BuildingService.updateBuilding(req.params.id, req.body).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.delete("/:id", authenticate("DELETE_BUILDING"), async(req, resp) => {
    try {
        await BuildingValidator.delete().validateAsync(req.params)

        BuildingService.deleteBuilding(req.params.id).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

module.exports = router