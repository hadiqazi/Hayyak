const { Router } = require("express");
const router = Router();
const { handleRouteError, multer } = require("../../../utils/common-utils");
const { VASService } = require("../../../services/v1")
const { VASValidator } = require("../../../validators");
const { authenticate } = require('../../middlewares/auth')

router.post("/", multer.single("image"), authenticate("CREATE_VAS"), async(req, resp) => {
    try {
        // Convert json strings in multipart request to json objects
        req.body = convertRequestToJson(req.body)

        const image = req.file
        await VASValidator.create().validateAsync({...req.body, image })

        VASService.createValueAddedService(req.body, image).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.get("/", authenticate("READ_VAS,CUSTOMER"), async(req, resp) => {
    try {
        VASService.getValueAddedServices(req.headers.language).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.put("/:id", multer.single("image"), authenticate("UPDATE_VAS"), async(req, resp) => {
    try {
        // Convert json strings in multipart request to json objects
        req.body = convertRequestToJson(req.body)

        const image = req.file
        await VASValidator.update().validateAsync({
            ...req.params,
            ...req.body,
            image
        })

        VASService.updateValueAddedService(req.params.id, req.body, image).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.delete("/:id", authenticate("DELETE_VAS"), async(req, resp) => {
    try {
        await VASValidator.delete().validateAsync(req.params)

        VASService.deleteValueAddedService(req.params.id).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})


router.post("/multiple", authenticate("READ_MULTIPLE_VAS,IS_SERVICE"), async(req, resp) => {
    try {
        await VASValidator.multiple().validateAsync({
            ...req.body,
        })
        VASService.getMultipleVas(req.body, req.headers).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

const convertRequestToJson = (request) => {
    if (request.name)
        request.name = JSON.parse(request.name)
    if (request.description)
        request.description = JSON.parse(request.description)

    return request
}

module.exports = router