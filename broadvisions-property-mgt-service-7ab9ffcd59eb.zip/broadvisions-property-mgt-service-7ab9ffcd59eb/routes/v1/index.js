const { Router } = require("express");

const lookupRoutes = require("./lookup-routes")
const amenityTypeRoutes = require("./amenity-type-routes")
const amenityRoutes = require("./amenity-routes")
const vasRoutes = require("./vas-routes")
const buildingRoutes = require("./building-routes")
const bedTypeRoutes = require("./bed-type-routes")
const propertyTypeRoutes = require("./property-type-routes")
const propertyRoutes = require("./property-routes")
const roomRoutes = require("./room-routes")
const ratingRoutes = require('./rating-routes')

const setup = (app) => {
    const router = Router();

    router.use("/lookup", lookupRoutes);
    router.use("/amenity-type", amenityTypeRoutes);
    router.use("/amenity", amenityRoutes);
    router.use("/value-added-service", vasRoutes);
    router.use("/building", buildingRoutes);
    router.use("/bed-type", bedTypeRoutes);
    router.use("/property-type", propertyTypeRoutes);
    router.use("/property", propertyRoutes);
    router.use("/room", roomRoutes);
    router.use("/rating", ratingRoutes);

    // this should be the last line
    app.use("/v1", router);
};

module.exports = setup;