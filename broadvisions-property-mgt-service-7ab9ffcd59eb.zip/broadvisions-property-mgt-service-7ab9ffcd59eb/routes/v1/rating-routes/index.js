const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { RatingService } = require("../../../services/v1");
const { RatingValidator } = require("../../../validators");
const { authenticate } = require("../../middlewares/auth");

router.post("/", authenticate("CREATE_REVIEW,CUSTOMER"), async (req, resp) => {
  try {
    const {
      jwt: { user },
    } = req;
    await RatingValidator.create().validateAsync({
      ...req.body,
    });
    RatingService.createRating({ ...req.body, userId: user._id })
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 400,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/filter-customer", authenticate("CUSTOMER"), async (req, resp) => {
  try {
    const { jwt } = req;

    let userId = jwt.user._id;
    await RatingValidator.filter().validateAsync({
      ...req.body,
    });

    RatingService.filterRatingCustomer(
      req.query,
      { ...req.body, userId },
      req.headers
    )
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    console.log("ERROR ", error);
    handleRouteError(resp)({
      status: 400,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/filter", authenticate("FILTER_RATING,READ_REVIEW"), async (req, resp) => {
  try {
    await RatingValidator.filter().validateAsync({
      ...req.body,
    });

    RatingService.filterRatingAdmin(req.query, req.body, req.headers)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    console.log("ERROR ", error);
    handleRouteError(resp)({
      status: 400,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/status", authenticate("STATUS_RATING,UPDATE_REVIEW"), async (req, resp) => {
  try {
    await RatingValidator.status().validateAsync({
      ...req.query,
      ...req.body,
    });
    RatingService.statusRating(req.body, req.query)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 400,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.get(
  "/booking-to-review",
  authenticate("BOOKING_TO_REVIEW,CUSTOMER,IS_SERVICE"),
  async (req, resp) => {
    try {
      await RatingValidator.lookup().validateAsync({
        ...req.query,
      });
      RatingService.reviewLookUp(req.query, req.headers)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 400,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.put("/:id", authenticate("CUSTOMER"), async (req, resp) => {
  try {
    await RatingValidator.update().validateAsync({
      ...req.params,
      ...req.body,
    });

    const {
      jwt: { user },
    } = req;

    RatingService.updateRating({ ...req.body, userId: user._id }, req.params)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 400,
      message: __("mandatory.fields"),
      error,
    });
  }
});

module.exports = router;
