const { Router } = require("express");
const router = Router();
const { handleRouteError, multer } = require("../../../utils/common-utils");
const { PropertyService } = require("../../../services/v1")
const { PropertyValidator } = require("../../../validators");
const { authenticate } = require('../../middlewares/auth')
const multerOptions = [{ name: 'coverImage', maxCount: 1 }, { name: 'images' }]


router.post("/", multer.fields(multerOptions), authenticate("CREATE_PROPERTY"), async(req, resp) => {
    try {
        // Convert json strings in multipart request to json objects
        req.body = convertRequestToJson(req.body)

        let coverImage
        if (req.files.coverImage)
            coverImage = req.files.coverImage[0]

        const images = req.files.images
        await PropertyValidator.create().validateAsync({...req.body, coverImage, images })

        PropertyService.createProperty(req.body, coverImage, images).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})


router.get('/', authenticate("READ_PROPERTY"), async(req, resp) => {
    try {
        const criteria = {}
        if (req.query.buildingId) {
            criteria.building = req.query.buildingId
        }

        PropertyService.getAllProperties(req.headers.language, criteria).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})



router.get('/:id', authenticate("READ_SINGLE_PROPERTY,CUSTOMER"), async(req, resp) => {
    try {
        const id = req.params.id

        PropertyService.getProperty(id, req.headers.language).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.get('/rating/avg', authenticate("IS_SERVICE"), async(req, resp) => {
    try {
        PropertyService.getPropertiesAverage(req.query).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))
    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})


router.put('/:id', authenticate("UPDATE_PROPERTY"), multer.fields(multerOptions), async(req, resp) => {
    try {
        // Convert json strings in multipart request to json objects
        req.body = convertRequestToJson(req.body)

        let coverImage
        if (req.files.coverImage)
            coverImage = req.files.coverImage[0]

        const images = req.files.images

        await PropertyValidator.update().validateAsync({
            ...req.params,
            ...req.body,
            coverImage,
            images
        })

        PropertyService.updateProperty(req.params.id, req.body, coverImage, images).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.delete('/:id', authenticate("DELETE_PROPERTY"), async(req, resp) => {
    try {
        await PropertyValidator.delete().validateAsync(req.params)

        PropertyService.deleteProperty(req.params.id).then((result) => {
            resp.status(result.status).send(result)
        }).catch(handleRouteError(resp))

    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.post("/filter", authenticate("FILTER_PROPERTY,CUSTOMER"), async(req, resp) => {
    try {
        await PropertyValidator.filter().validateAsync({
            ...req.body,
            ...req.query
        })
        PropertyService.filter(req.body, req.headers, req.query)
        .then((result) => {
            resp.status(result.status).send(result);
        }) .catch(handleRouteError(resp));
    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.post("/multiple", authenticate("READ_MULTIPLE_PROPERTY,IS_SERVICE"), async(req, resp) => {
    try {
        await PropertyValidator.multipleProperties().validateAsync({
            ...req.body,
        })
        PropertyService.getMultipleProperties(req.body, req.headers)
        .then((result) => {
            resp.status(result.status).send(result);
        }) .catch(handleRouteError(resp));
    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.post("/booking/cost", authenticate("BOOKING_COST"), async(req, resp) => {
    try {
        await PropertyValidator.bookingCost().validateAsync({
            ...req.body,
        })
        PropertyService.getBookingCost(req.body, req.headers)
        .then((result) => {
            resp.status(result.status).send(result);
        }) .catch(handleRouteError(resp));
    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

router.post("/top-rated", authenticate("CUSTOMER"), async(req, resp) => {
    try {
        await PropertyValidator.topRated().validateAsync({
            ...req.body,
        })
        PropertyService.getPopularProperties(req.body, req.headers)
        .then((result) => {
            resp.status(result.status).send(result);
        }) .catch(handleRouteError(resp));
    } catch (error) {
        handleRouteError(resp)({
            status: 400,
            message: __("mandatory.fields"),
            error,
        });
    }
})

// router.post("/available-room", async(req, resp) => {
//     try {
//         // await PropertyValidator.filter().validateAsync({
//         //     ...req.body,
//         // })
//         PropertyService.getAvailableRoom(req.body, req.headers)
//         .then((result) => {
//             resp.status(result.status).send(result);
//         }) .catch(handleRouteError(resp));
//     } catch (error) {
//         handleRouteError(resp)({
//             status: 400,
//             message: __("mandatory.fields"),
//             error,
//         });
//     }
// })


const convertRequestToJson = (request) => {
    if (request.name)
        request.name = JSON.parse(request.name)
    if (request.description)
        request.description = JSON.parse(request.description)
    if (request.rooms)
        request.rooms = JSON.parse(request.rooms)
    if (request.amenities)
        request.amenities = JSON.parse(request.amenities)
    if (request.valueAddedServices)
        request.valueAddedServices = JSON.parse(request.valueAddedServices)
    if (request.deletedImages)
        request.deletedImages = JSON.parse(request.deletedImages)

    return request
}


module.exports = router