const seeder = require("mongoose-seed");
const { mongodb } = require("../config/keys");

const getSeedingData = async () => {
  try {
    return [
      {
        model: "property",
        documents: data,
      },
    ];
  } catch (err) {
    console.log("Error while seeding ", err);
    return [];
  }
};

seeder.connect(mongodb, function () {
  seeder.loadModels(["models/property.js"]);
  seeder.clearModels(["property"], async () => {
    seeder.populateModels(await getSeedingData(), function () {
      seeder.disconnect();
    });
  });
});

// Data array containing seed data - documents organized by Model
var data = [
  {
    images: [
      {
        uuid: "0790ba8a-4e8f-44cc-87a6-c23dece6d14a.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0790ba8a-4e8f-44cc-87a6-c23dece6d14a.jpg",
      },
      {
        uuid: "da7cf948-966e-48c8-b99b-6245228b9a4f.jpeg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/da7cf948-966e-48c8-b99b-6245228b9a4f.jpeg",
      },
    ],
    amenities: ["619e4de7c5dfd966585a477b", "619f1b68c5dfd966585a47a4"],
    valueAddedServices: ["61602c47267dc41a25ef3486"],
    reviews: [],
    name: {
      en: "Single Room",
      ar: "Cap غرفة للأفراد s",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 135,
    description: {
      en: "Standard single bed room",
      ar: "غرفة فاخرة بسرير مفرد",
    },
    guestCount: 4,
    coverImage: "undefined",
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "71dd6f1e-f751-48ce-9e8a-2bd226452731.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/71dd6f1e-f751-48ce-9e8a-2bd226452731.jpg",
      },
      {
        uuid: "21370805-5484-465c-8173-94194fa9cfd4.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/21370805-5484-465c-8173-94194fa9cfd4.jpg",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328", "619b41b7c5dfd966585a4381"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "White Room",
      ar: "arabic white غرفة للأفراد",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61b1ed941916e75150a0804a",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 120,
    description: {
      en: "Standard single bed room",
      ar: "غرفة فاخرة بسرير مفرد",
    },
    guestCount: 2,
    coverImage: "undefined",
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "f0ad4e3e-7f8a-4f8f-bae6-fa54e172f206.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f0ad4e3e-7f8a-4f8f-bae6-fa54e172f206.jpg",
      },
    ],
    amenities: [
      "618236bbde7dd058e94a0328",
      "6182370ade7dd058e94a032e",
      "6188d5a5de7dd058e94a0986",
      "619b41b7c5dfd966585a4381",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "Deluxe Room",
      ar: "arabic deluxe غرفة للأفراد",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61b1ed941916e75150a0804a",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 115,
    description: {
      en: "Deluxe single bed room",
      ar: "غرفة فاخرة بسرير مفرد",
    },
    guestCount: 2,
    coverImage: "undefined",
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "8ba08085-8566-4870-bbd6-6c86e076508a.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/8ba08085-8566-4870-bbd6-6c86e076508a.png",
      },
    ],
    amenities: [
      "618236bbde7dd058e94a0328",
      "6182370ade7dd058e94a032e",
      "6188d5a5de7dd058e94a0986",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "new one",
      ar: "sadsadsa",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: -125,
    description: {
      en: "trsteseseftvftcfcvgg",
      ar: "dsadsadad",
    },
    guestCount: -9,
    coverImage: "undefined",
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "9fba6924-92ca-4889-9eac-86e0a825b8e9.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9fba6924-92ca-4889-9eac-86e0a825b8e9.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e", "6188d5a5de7dd058e94a0986"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "news",
      ar: "dsffd",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61b1ed941916e75150a0804a",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 2222,
    description: {
      en: "lkljl",
      ar: "jnkjn",
    },
    guestCount: 22,
    coverImage: {
      uuid: "f8c663b3-9ddb-4e9a-9c3e-7b20ebe8faa5.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f8c663b3-9ddb-4e9a-9c3e-7b20ebe8faa5.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "24caedb3-4918-4e97-81b3-12a586a543b9.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/24caedb3-4918-4e97-81b3-12a586a543b9.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328", "6182370ade7dd058e94a032e"],
    valueAddedServices: [
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "test12test",
      ar: "test",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 50,
    description: {
      en: "test",
      ar: "testh",
    },
    guestCount: 5,
    coverImage: "undefined",
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "9c667c42-45d9-4702-951b-c9805de2d304.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9c667c42-45d9-4702-951b-c9805de2d304.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "newLast",
      ar: "dfdsds",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 100,
    description: {
      en: " mn dsf",
      ar: "sdfdsfdsf",
    },
    guestCount: 1,
    coverImage: "undefined",
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "14fe1e85-df76-4961-9b93-b9328fa92fc4.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/14fe1e85-df76-4961-9b93-b9328fa92fc4.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328", "61c0390975de0b6fb3fb2194"],
    valueAddedServices: ["618bb978cd534fbe42940e53"],
    reviews: [],
    name: {
      en: "dsfdsf",
      ar: "sadsd",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 2222,
    description: {
      en: "sadsdsa",
      ar: "sadsad",
    },
    guestCount: 2,
    coverImage: {
      uuid: "0a5d42e5-4fb1-4aea-993e-4f65be385813.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0a5d42e5-4fb1-4aea-993e-4f65be385813.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "f92389b7-ec27-41d8-b607-4eb13079918d.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f92389b7-ec27-41d8-b607-4eb13079918d.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["61602c47267dc41a25ef3486"],
    reviews: [],
    name: {
      en: "dadsad",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 2222,
    description: {
      en: "sadsad",
      ar: "sadsad",
    },
    guestCount: 2,
    coverImage: {
      uuid: "6058dae5-6a97-4924-b5a8-50ead984129a.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/6058dae5-6a97-4924-b5a8-50ead984129a.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "5bab0a00-d4e4-43b3-b555-1520e78f4d49.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5bab0a00-d4e4-43b3-b555-1520e78f4d49.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "roomcheck",
      ar: "sadsad",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 100,
    description: {
      en: "sdsad",
      ar: "sadsad",
    },
    guestCount: 2,
    coverImage: {
      uuid: "4a8d380a-1e6c-45ad-9c25-f2d33e4478f5.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4a8d380a-1e6c-45ad-9c25-f2d33e4478f5.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "711386f3-581c-4f00-bd04-cafdf2a535c5.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/711386f3-581c-4f00-bd04-cafdf2a535c5.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["618bb978cd534fbe42940e53"],
    reviews: [],
    name: {
      en: "roomtest",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 100,
    description: {
      en: "sadsad",
      ar: "sadsad",
    },
    guestCount: 2,
    coverImage: {
      uuid: "d0fe63b3-8ba5-4f77-84cd-daef8d3041ae.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d0fe63b3-8ba5-4f77-84cd-daef8d3041ae.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "34dca043-f905-4faf-b9a0-913a816a9ea0.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/34dca043-f905-4faf-b9a0-913a816a9ea0.png",
      },
    ],
    amenities: ["619e4de7c5dfd966585a477b"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "room1",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 100,
    description: {
      en: "sdfasds",
      ar: "sadsadsad",
    },
    guestCount: 2,
    coverImage: {
      uuid: "97708d19-d7b1-4c43-856e-ea7a1aa513b8.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/97708d19-d7b1-4c43-856e-ea7a1aa513b8.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "cae7500d-1936-4f01-8f0f-eda6a8598ca6.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/cae7500d-1936-4f01-8f0f-eda6a8598ca6.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["618bb978cd534fbe42940e53"],
    reviews: [],
    name: {
      en: "roomFINAL",
      ar: "SADSAD",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 2222,
    description: {
      en: "SADSAD",
      ar: "SADSAD",
    },
    guestCount: 2,
    coverImage: {
      uuid: "ae365224-c22f-422f-93d8-5ed17f706a2b.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ae365224-c22f-422f-93d8-5ed17f706a2b.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "0a0de235-a7dc-45b3-9a02-5be2c63cc203.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0a0de235-a7dc-45b3-9a02-5be2c63cc203.png",
      },
    ],
    amenities: ["6188d5a5de7dd058e94a0986"],
    valueAddedServices: ["618bb978cd534fbe42940e53"],
    reviews: [],
    name: {
      en: "ROOMFIANLONE",
      ar: "DSFDSF",
    },
    propertyType: "617252f1cd73fafd8c482105",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 100,
    description: {
      en: "DSFDSF",
      ar: "DSFDSF",
    },
    guestCount: 3,
    coverImage: {
      uuid: "9f78f4c7-2158-40d9-9eeb-ece7931e5662.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9f78f4c7-2158-40d9-9eeb-ece7931e5662.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["6182370ade7dd058e94a032e", "61c0390975de0b6fb3fb2194"],
    valueAddedServices: ["61602c47267dc41a25ef3486"],
    reviews: [],
    name: {
      en: "ROOM 2",
      ar: "SADSAD",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 100,
    description: {
      en: "SADSAD",
      ar: "SADSADSA",
    },
    guestCount: 3,
    coverImage: {
      uuid: "14353fb5-758f-4e47-8c7c-076db4f6b319.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/14353fb5-758f-4e47-8c7c-076db4f6b319.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "ee597b4c-1ad6-4292-ae3f-122565005385.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ee597b4c-1ad6-4292-ae3f-122565005385.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["618bb978cd534fbe42940e53"],
    reviews: [],
    name: {
      en: "addition",
      ar: "asdsad",
    },
    propertyType: "617252f1cd73fafd8c482105",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 100,
    description: {
      en: "sadsad",
      ar: "sadsad",
    },
    guestCount: 0,
    coverImage: {
      uuid: "5988b76f-fcbb-4202-898f-3599345c6c17.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5988b76f-fcbb-4202-898f-3599345c6c17.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "14a0109d-8e37-4791-9699-dc49162bf43c.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/14a0109d-8e37-4791-9699-dc49162bf43c.png",
      },
      {
        uuid: "57ab981c-1134-47da-837b-d87b7c695ad5.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/57ab981c-1134-47da-837b-d87b7c695ad5.jpg",
      },
      {
        uuid: "2818b4bd-e53a-4d20-ad3f-1728af6636ab.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2818b4bd-e53a-4d20-ad3f-1728af6636ab.png",
      },
      {
        uuid: "92343dcc-0513-42e2-9c9f-c6d9512931a4.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/92343dcc-0513-42e2-9c9f-c6d9512931a4.png",
      },
    ],
    amenities: [
      "619b80eaea0a4894dbeb1e6b",
      "61a06f3ee0edf66c5def85a3",
      "61bc3dd575de0b6fb3fb1ef4",
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
      "61c40ccec3d13e7f0020e1cf",
      "61c40ee4cca5462cc38db9d0",
      "61c4682f2031f43c133cee13",
      "61c4685e2031f43c133cee35",
      "61c468852031f43c133cee5c",
      "61c468a82031f43c133cee72",
      "61c474662031f43c133cf4cb",
      "61c54fb12031f43c133cf546",
      "61c54fe82031f43c133cf54c",
      "61c5500d2031f43c133cf557",
      "61c550252031f43c133cf55d",
      "61c55fac2031f43c133cfb9e",
      "61c55fb62031f43c133cfba4",
      "61c560a32031f43c133cfbac",
      "61c5616a2031f43c133cfbb2",
      "61c561b12031f43c133cfbb8",
      "61c561d62031f43c133cfbbe",
      "61c5622f7d5a3155ed9ad0be",
      "61c5623c7d5a3155ed9ad0c7",
      "61c562c77d5a3155ed9ad0db",
      "61c563667d5a3155ed9ad0e1",
      "61c563ce7d5a3155ed9ad101",
      "61c575087d5a3155ed9ad5b4",
    ],
    valueAddedServices: [
      "61c565f57d5a3155ed9ad114",
      "61c475a02031f43c133cf4d9",
    ],
    reviews: [],
    name: {
      en: "Capsule Roomx11",
      ar: "Cap غرفة للأفراد111",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c2c5cf3031396275ae1a3c",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 123,
    description: {
      en: "Standard single bed roomx111",
      ar: "غرفة فاخرة بسرير مفرد111",
    },
    guestCount: 66,
    coverImage: {
      uuid: "fdd8c72f-30eb-4e5a-a3cf-7f506ad622d9.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/fdd8c72f-30eb-4e5a-a3cf-7f506ad622d9.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "17c34c8e-103a-4ab3-841b-7e6a47004b8f.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/17c34c8e-103a-4ab3-841b-7e6a47004b8f.png",
      },
      {
        uuid: "05e5da1e-00a7-4191-9dd0-329356b7f3f6.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/05e5da1e-00a7-4191-9dd0-329356b7f3f6.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328", "619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "new",
      ar: "sdsadsad",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 2222,
    description: {
      en: "ssadsad",
      ar: "sdsads",
    },
    guestCount: 1,
    coverImage: "undefined",
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "51bb0465-6b82-4825-b5a7-e6d3e5866c69.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/51bb0465-6b82-4825-b5a7-e6d3e5866c69.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["61602c47267dc41a25ef3486"],
    reviews: [],
    name: {
      en: "dfds",
      ar: "dfsads",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 100,
    description: {
      en: "fdsfd",
      ar: "dsasds",
    },
    guestCount: 3,
    coverImage: {
      uuid: "c2b69849-e69f-44c3-ba19-64917a23255b.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c2b69849-e69f-44c3-ba19-64917a23255b.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "eeae170b-59f2-4348-9fba-2708f7980be6.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/eeae170b-59f2-4348-9fba-2708f7980be6.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328", "6182370ade7dd058e94a032e"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "testing1",
      ar: "dsfdsfd",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 2,
    description: {
      en: "dsffdsds",
      ar: "fdsfdsf",
    },
    guestCount: 3,
    coverImage: {
      uuid: "74e55037-8287-461e-a612-ad2dded9f426.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/74e55037-8287-461e-a612-ad2dded9f426.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "abe045c7-7e15-45b2-af7e-530a9100a8d2.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/abe045c7-7e15-45b2-af7e-530a9100a8d2.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "testing finalchecl",
      ar: "wqewechecl",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61b1ed1e1916e75150a0803d",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 5478,
    description: {
      en: "sadsdsssschecl",
      ar: "wqewqechecl",
    },
    guestCount: 5,
    coverImage: "undefined",
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "0440213e-4a02-4d90-9b94-164fc1cfbaa3.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0440213e-4a02-4d90-9b94-164fc1cfbaa3.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "sadsad",
      ar: "sadsda",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 4,
    description: {
      en: "sadsadsad",
      ar: "sadsadd",
    },
    guestCount: 4,
    coverImage: {
      uuid: "0b902818-04c4-4b53-82a0-a89c399253e0.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0b902818-04c4-4b53-82a0-a89c399253e0.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "70ac0b74-cedc-4bd0-9b39-b4db6a95d1c7.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/70ac0b74-cedc-4bd0-9b39-b4db6a95d1c7.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["61602c47267dc41a25ef3486"],
    reviews: [],
    name: {
      en: "sadsad",
      ar: "sadsd",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 100,
    description: {
      en: "dsadsdsadsad",
      ar: "sadsad",
    },
    guestCount: 6,
    coverImage: {
      uuid: "939cb9f8-c1ca-4a50-9047-31fc5a51e998.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/939cb9f8-c1ca-4a50-9047-31fc5a51e998.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "1555ac54-6f29-4a5e-b95e-9eb68e600d9b.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/1555ac54-6f29-4a5e-b95e-9eb68e600d9b.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["61bc3e4175de0b6fb3fb1f02"],
    reviews: [],
    name: {
      en: "asdsadsad",
      ar: "sasadd",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 4,
    description: {
      en: "sadsadsa",
      ar: "dsads",
    },
    guestCount: 3,
    coverImage: {
      uuid: "3097b35c-76ef-4b78-8bc2-f33e50ab391e.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/3097b35c-76ef-4b78-8bc2-f33e50ab391e.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "b18eb1cb-1af0-4703-980c-3638756a44cd.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b18eb1cb-1af0-4703-980c-3638756a44cd.png",
      },
      {
        uuid: "5d28a451-d9a4-4d24-81e6-68c254ac9209.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5d28a451-d9a4-4d24-81e6-68c254ac9209.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["61602c47267dc41a25ef3486"],
    reviews: [],
    name: {
      en: "ewre",
      ar: "ewrewr",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 5,
    description: {
      en: "ewrewr",
      ar: "ewrewr",
    },
    guestCount: 3,
    coverImage: {
      uuid: "3cde5232-0fff-4684-8a4b-2f7bd55a9219.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/3cde5232-0fff-4684-8a4b-2f7bd55a9219.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "newss",
      ar: "dsfdsf",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 4,
    description: {
      en: "sdfd",
      ar: "dsfdsf",
    },
    guestCount: 3,
    coverImage: {
      uuid: "149098d9-c5b6-4a76-a339-2e991fdc7335.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/149098d9-c5b6-4a76-a339-2e991fdc7335.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["618236bbde7dd058e94a0328", "6182370ade7dd058e94a032e"],
    valueAddedServices: ["618bb978cd534fbe42940e53"],
    reviews: [],
    name: {
      en: "wqewqe",
      ar: "asdsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 11,
    description: {
      en: "szsdsad",
      ar: "sadasd",
    },
    guestCount: 3,
    coverImage: {
      uuid: "2b242906-d481-4ff6-80f0-d040fc64481b.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2b242906-d481-4ff6-80f0-d040fc64481b.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["618bb978cd534fbe42940e53"],
    reviews: [],
    name: {
      en: "sadsd",
      ar: "sadasd",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 100,
    description: {
      en: "asdsd",
      ar: "sadasd",
    },
    guestCount: 3,
    coverImage: {
      uuid: "1bbaf91a-ece9-453c-9344-8d1e3308282a.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/1bbaf91a-ece9-453c-9344-8d1e3308282a.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["61bc3e4175de0b6fb3fb1f02"],
    reviews: [],
    name: {
      en: "asdsa",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 3,
    description: {
      en: "dsadad",
      ar: "sadasd",
    },
    guestCount: 3,
    coverImage: {
      uuid: "398ea50f-7471-42d3-b54e-da866b6872e2.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/398ea50f-7471-42d3-b54e-da866b6872e2.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "dsffd",
      ar: "dsfdsf",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 3,
    description: {
      en: "fdsfdff",
      ar: "sdfdsf",
    },
    guestCount: 1,
    coverImage: {
      uuid: "301e34c5-da46-4c63-a996-488864bee41f.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/301e34c5-da46-4c63-a996-488864bee41f.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "4eb3da6f-4c63-4828-9d54-5e8c36f17fa1.jpg",
        imageUrl:
          "https://feedy-dev.s3.eu-north-1.amazonaws.com//4eb3da6f-4c63-4828-9d54-5e8c36f17fa1.jpg",
      },
      {
        uuid: "4626d207-45a0-46dd-ad04-c3a478a47acd.jpg",
        imageUrl:
          "https://feedy-dev.s3.eu-north-1.amazonaws.com//4626d207-45a0-46dd-ad04-c3a478a47acd.jpg",
      },
      {
        uuid: "b6f5ec88-f7d4-46da-98b9-5a504054ab1c.png",
        imageUrl:
          "https://feedy-dev.s3.eu-north-1.amazonaws.com//b6f5ec88-f7d4-46da-98b9-5a504054ab1c.png",
      },
      {
        uuid: "4e7bc946-a734-4dc4-85f7-4d3d8b25e23f.jpg",
        imageUrl:
          "https://feedy-dev.s3.eu-north-1.amazonaws.com//4e7bc946-a734-4dc4-85f7-4d3d8b25e23f.jpg",
      },
      {
        uuid: "f13ebc63-12d3-485b-9690-47cb569abf98.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f13ebc63-12d3-485b-9690-47cb569abf98.jpg",
      },
      {
        uuid: "b4a11470-449b-4da0-98c4-10e6ad9cf3b7.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b4a11470-449b-4da0-98c4-10e6ad9cf3b7.jpg",
      },
    ],
    amenities: ["61c18d663031396275adfee6"],
    valueAddedServices: ["61bc3e4175de0b6fb3fb1f02"],
    reviews: ["61d7e8e9ff545d08cb998d14"],
    name: {
      en: "Capsule RoomK",
      ar: "Cap غرفة للأفراد",
    },
    propertyType: "617252f1cd73fafd8c482105",
    building: "61c2c5cf3031396275ae1a3c",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 135,
    description: {
      en: "Standard single bed roomK",
      ar: "غرفة فاخرة بسرير مفرد",
    },
    guestCount: 4,
    coverImage: {
      uuid: "fd3dd939-e853-4b38-ad1c-4a016733e3be.jpg",
      imageUrl:
        "https://feedy-dev.s3.eu-north-1.amazonaws.com//fd3dd939-e853-4b38-ad1c-4a016733e3be.jpg",
    },
    average: {
      overall: 1,
      five_star: 0,
      four_star: 0,
      three_star: 1,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "e056d466-c682-45cd-adfe-3524c581d248.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e056d466-c682-45cd-adfe-3524c581d248.jfif",
      },
      {
        uuid: "f4362ef3-52e9-4c06-83be-68ba18581370.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f4362ef3-52e9-4c06-83be-68ba18581370.jfif",
      },
      {
        uuid: "43e7188f-2bcc-4177-85e2-5bd7a891a0f4.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/43e7188f-2bcc-4177-85e2-5bd7a891a0f4.jpg",
      },
      {
        uuid: "e3ed4556-0d30-4884-a332-66bbb46a4d4c.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e3ed4556-0d30-4884-a332-66bbb46a4d4c.jfif",
      },
    ],
    amenities: [
      "618236bbde7dd058e94a0328",
      "619b80eaea0a4894dbeb1e6b",
      "61bc3dd575de0b6fb3fb1ef4",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "tester321",
      ar: "gjhgfh",
    },
    propertyType: "617252f1cd73fafd8c482105",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 2451,
    description: {
      en: "hcgshgsa",
      ar: "vnvhgfgfhd",
    },
    guestCount: 5,
    coverImage: {
      uuid: "df814367-1aa9-405f-b47b-876add7677ce.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/df814367-1aa9-405f-b47b-876add7677ce.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "070eaa41-2a4d-4be2-858b-237db3735e1c.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/070eaa41-2a4d-4be2-858b-237db3735e1c.png",
      },
    ],
    amenities: ["6188d5a5de7dd058e94a0986"],
    valueAddedServices: ["61602c47267dc41a25ef3486"],
    reviews: [],
    name: {
      en: "dsfsf",
      ar: "sdfdsf",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 4,
    description: {
      en: "kjhkkj",
      ar: "dsfds",
    },
    guestCount: 2,
    coverImage: {
      uuid: "4529ce7d-82d9-4e98-8a89-c77d411ea4e4.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4529ce7d-82d9-4e98-8a89-c77d411ea4e4.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "3cfa0128-ae22-466a-9c98-b003cd967079.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/3cfa0128-ae22-466a-9c98-b003cd967079.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "hellotherer",
      ar: "dfdsfs",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 3,
    description: {
      en: "herwe",
      ar: "dsfsdf",
    },
    guestCount: 4,
    coverImage: {
      uuid: "496d6f00-1d7a-445f-9b01-3853bf269533.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/496d6f00-1d7a-445f-9b01-3853bf269533.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "3be5d111-5613-43a2-80e3-67e60c1dd669.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/3be5d111-5613-43a2-80e3-67e60c1dd669.jfif",
      },
      {
        uuid: "1c68fbe7-e363-41fa-b35d-0ea67a1f6520.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/1c68fbe7-e363-41fa-b35d-0ea67a1f6520.jfif",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b", "61a06f3ee0edf66c5def85a3"],
    valueAddedServices: ["61c565f57d5a3155ed9ad114"],
    reviews: [],
    name: {
      en: "xyz12345",
      ar: "sdfdsf",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 12458,
    description: {
      en: "dgfdgd",
      ar: "dfdsfvdsf",
    },
    guestCount: 2,
    coverImage: {
      uuid: "ecebe29b-22c3-4af3-8cd0-eb68b3b54750.jfif",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ecebe29b-22c3-4af3-8cd0-eb68b3b54750.jfif",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "b38acd3b-b3ae-4627-b4b8-27e1b60e661c.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b38acd3b-b3ae-4627-b4b8-27e1b60e661c.png",
      },
      {
        uuid: "25f51008-066e-498f-8ec0-57a234f22322.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/25f51008-066e-498f-8ec0-57a234f22322.jfif",
      },
    ],
    amenities: [
      "618236bbde7dd058e94a0328",
      "6182370ade7dd058e94a032e",
      "6188d5a5de7dd058e94a0986",
      "619b80eaea0a4894dbeb1e6b",
      "61a06f3ee0edf66c5def85a3",
      "61bc3dd575de0b6fb3fb1ef4",
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
      "61c40ccec3d13e7f0020e1cf",
      "61c40ee4cca5462cc38db9d0",
      "61c4682f2031f43c133cee13",
      "61c4685e2031f43c133cee35",
      "61c468852031f43c133cee5c",
      "61c468a82031f43c133cee72",
      "61c474662031f43c133cf4cb",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
      "61bc3e4175de0b6fb3fb1f02",
      "61c40d11c3d13e7f0020e1df",
      "61c40d86c3d13e7f0020e1f5",
      "61c40f16cca5462cc38db9f3",
      "61c469292031f43c133ceec0",
      "61c475a02031f43c133cf4d9",
    ],
    reviews: [],
    name: {
      en: "sadsdaa1234",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 6,
    description: {
      en: "sadsad",
      ar: "sadsad",
    },
    guestCount: 4,
    coverImage: {
      uuid: "c70c2ea5-97a9-4244-bddc-e436f711a65b.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c70c2ea5-97a9-4244-bddc-e436f711a65b.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "fb524263-6043-4f40-aaa8-2e96534e5710.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/fb524263-6043-4f40-aaa8-2e96534e5710.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "zzaz",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 2222,
    description: {
      en: "sadsa",
      ar: "sadsad",
    },
    guestCount: 4,
    coverImage: {
      uuid: "5e4bf1db-7b6c-45d2-b4c1-f167ab6a3f35.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5e4bf1db-7b6c-45d2-b4c1-f167ab6a3f35.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "5488cc06-cffd-4adf-bbe8-5ee85b21e6a0.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5488cc06-cffd-4adf-bbe8-5ee85b21e6a0.jpg",
      },
    ],
    amenities: [
      "618236bbde7dd058e94a0328",
      "6182370ade7dd058e94a032e",
      "6188d5a5de7dd058e94a0986",
      "619b80eaea0a4894dbeb1e6b",
      "61a06f3ee0edf66c5def85a3",
      "61bc3dd575de0b6fb3fb1ef4",
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
      "61c40ccec3d13e7f0020e1cf",
      "61c40ee4cca5462cc38db9d0",
      "61c4682f2031f43c133cee13",
      "61c4685e2031f43c133cee35",
      "61c468852031f43c133cee5c",
      "61c468a82031f43c133cee72",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
      "61bc3e4175de0b6fb3fb1f02",
      "61c40d11c3d13e7f0020e1df",
      "61c40d86c3d13e7f0020e1f5",
      "61c40f16cca5462cc38db9f3",
      "61c469292031f43c133ceec0",
    ],
    reviews: [],
    name: {
      en: "create",
      ar: "hgshshsvdgvdgvdg",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b76e3031396275ae0dc6",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 400,
    description: {
      en: "test4",
      ar: "hjdhbdhdh",
    },
    guestCount: 2,
    coverImage: {
      uuid: "d9105541-1048-4cbd-bc73-44b66ada6798.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d9105541-1048-4cbd-bc73-44b66ada6798.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "607fc6ad-f91b-493e-9681-a038a51914d1.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/607fc6ad-f91b-493e-9681-a038a51914d1.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328", "6188d5a5de7dd058e94a0986"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "addinglast",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 100,
    description: {
      en: "sdsda",
      ar: "sadsad",
    },
    guestCount: 2,
    coverImage: {
      uuid: "06d7418d-0604-465c-8425-52165cdd5c74.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/06d7418d-0604-465c-8425-52165cdd5c74.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "4e888882-090a-45ae-af85-6c838dce5487.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4e888882-090a-45ae-af85-6c838dce5487.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["61602c47267dc41a25ef3486"],
    reviews: [],
    name: {
      en: "lastings",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 100,
    description: {
      en: "sadsda",
      ar: "sad",
    },
    guestCount: 1,
    coverImage: {
      uuid: "0b357879-a5aa-420b-a5c9-a7848d20213c.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0b357879-a5aa-420b-a5c9-a7848d20213c.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "de83fc79-9d11-40d3-a5fc-2910c948bb06.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/de83fc79-9d11-40d3-a5fc-2910c948bb06.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "sdsds",
      ar: "sadsd",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 100,
    description: {
      en: "asddsa",
      ar: "sadsa",
    },
    guestCount: 4,
    coverImage: {
      uuid: "b0ecb5ed-8ab7-420d-b69b-80d1b97f5dff.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b0ecb5ed-8ab7-420d-b69b-80d1b97f5dff.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "ee6a9af3-a5eb-4a96-b461-20419f3f176a.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ee6a9af3-a5eb-4a96-b461-20419f3f176a.jfif",
      },
      {
        uuid: "36af6e41-3488-4c2c-9cbe-f45e772a0a4b.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/36af6e41-3488-4c2c-9cbe-f45e772a0a4b.jpg",
      },
      {
        uuid: "a058e499-a33d-4260-a09e-ef6ff83ccd04.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a058e499-a33d-4260-a09e-ef6ff83ccd04.jfif",
      },
      {
        uuid: "c381b67e-fc8a-459a-ab72-61a025fcfb35.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c381b67e-fc8a-459a-ab72-61a025fcfb35.jfif",
      },
    ],
    amenities: [
      "618236bbde7dd058e94a0328",
      "6182370ade7dd058e94a032e",
      "6188d5a5de7dd058e94a0986",
      "619b80eaea0a4894dbeb1e6b",
      "61a06f3ee0edf66c5def85a3",
      "61bc3dd575de0b6fb3fb1ef4",
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
      "61c40ccec3d13e7f0020e1cf",
      "61c40ee4cca5462cc38db9d0",
      "61c4682f2031f43c133cee13",
      "61c4685e2031f43c133cee35",
      "61c468852031f43c133cee5c",
      "61c468a82031f43c133cee72",
      "61c474662031f43c133cf4cb",
      "61c54fb12031f43c133cf546",
      "61c54fe82031f43c133cf54c",
      "61c5500d2031f43c133cf557",
      "61c550252031f43c133cf55d",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
      "61c40f16cca5462cc38db9f3",
      "61c469292031f43c133ceec0",
      "61c475a02031f43c133cf4d9",
      "61c556302031f43c133cf684",
      "61c557e42031f43c133cf723",
    ],
    reviews: [],
    name: {
      en: "12235455",
      ar: "54564",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 2569,
    description: {
      en: "ghjghg",
      ar: "jhvfg",
    },
    guestCount: 6,
    coverImage: {
      uuid: "45cc7f61-01f7-40fd-bd20-19784cd50e47.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/45cc7f61-01f7-40fd-bd20-19784cd50e47.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "4a05e341-d8c8-4bc8-a7ae-edc5ab2a777f.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4a05e341-d8c8-4bc8-a7ae-edc5ab2a777f.jpg",
      },
      {
        uuid: "b5fb0f9a-d009-441d-9d76-2b2090048cb9.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b5fb0f9a-d009-441d-9d76-2b2090048cb9.png",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: [
      "61c565f57d5a3155ed9ad114",
      "61c565f57d5a3155ed9ad114",
      "61c565f57d5a3155ed9ad114",
      "61c565f57d5a3155ed9ad114",
      "61c565f57d5a3155ed9ad114",
      "61c565f57d5a3155ed9ad114",
      "615eb9b8fd5315d7911fa20f",
      "615eb9b8fd5315d7911fa20f",
      "615eb9b8fd5315d7911fa20f",
      "615eb9b8fd5315d7911fa20f",
      "61c565f57d5a3155ed9ad114",
    ],
    reviews: [],
    name: {
      en: "test",
      ar: "haza",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b8173031396275ae0de6",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 400,
    description: {
      en: "test 3",
      ar: "test",
    },
    guestCount: 6,
    coverImage: {
      uuid: "a21303dc-1f86-4bdc-9d9c-6a8dd26df719.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a21303dc-1f86-4bdc-9d9c-6a8dd26df719.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "a2777b6b-2b70-456b-a2dd-74284d478d7d.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a2777b6b-2b70-456b-a2dd-74284d478d7d.png",
      },
    ],
    amenities: ["61c40ee4cca5462cc38db9d0"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "sadsad",
      ar: "sadsadsd",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 4,
    description: {
      en: "sadsad",
      ar: "sadsad",
    },
    guestCount: 4,
    coverImage: {
      uuid: "537ba974-d562-4ff2-a4a8-aa85acd8e69b.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/537ba974-d562-4ff2-a4a8-aa85acd8e69b.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "sadsa",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b6833031396275ae0db0",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 6,
    description: {
      en: "sadsa",
      ar: "sadsad",
    },
    guestCount: 4,
    coverImage: {
      uuid: "d4b60554-68c8-4f98-b40e-8d836da3c62f.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d4b60554-68c8-4f98-b40e-8d836da3c62f.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "sadad",
      ar: "sadsa",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b6833031396275ae0db0",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 2222,
    description: {
      en: "dsadsad",
      ar: "sadsad",
    },
    guestCount: 3,
    coverImage: {
      uuid: "3c6dddc3-8d88-473e-ae73-ce99b82838e9.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/3c6dddc3-8d88-473e-ae73-ce99b82838e9.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: [
      "61c2e995c3d13e7f0020ccde",
      "61c18d663031396275adfee6",
      "61c4682f2031f43c133cee13",
      "61c4685e2031f43c133cee35",
    ],
    valueAddedServices: [
      "61c475a02031f43c133cf4d9",
      "61c565f57d5a3155ed9ad114",
      "61c5988d7d5a3155ed9ad875",
      "61d6d7e106fc0f116ef4de0c",
    ],
    reviews: [],
    name: {
      en: "sadsad45",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c2c5cf3031396275ae1a3c",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 4,
    description: {
      en: "dsasad",
      ar: "sadsad",
    },
    guestCount: 2,
    coverImage: {
      uuid: "2b90dfe8-3185-426d-8aa8-d100b34bbd80.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2b90dfe8-3185-426d-8aa8-d100b34bbd80.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "dfdsf",
      ar: "dsfdsf",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c2c5cf3031396275ae1a3c",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 3,
    description: {
      en: "dsfdsf",
      ar: "dsfdsf",
    },
    guestCount: 4,
    coverImage: {
      uuid: "684820e4-ad8a-4ad2-877b-3cccbd8cbc3b.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/684820e4-ad8a-4ad2-877b-3cccbd8cbc3b.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "new",
      ar: "xzcxzc",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b6833031396275ae0db0",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 3,
    description: {
      en: "xzcxzc",
      ar: "xzcxz",
    },
    guestCount: 5,
    coverImage: {
      uuid: "addebb51-0e09-4dbb-934d-5d5fd7621e27.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/addebb51-0e09-4dbb-934d-5d5fd7621e27.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "6895e674-f705-4ca8-b729-92d7eb614c6f.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/6895e674-f705-4ca8-b729-92d7eb614c6f.png",
      },
      {
        uuid: "7a647603-2c58-4343-92ff-65fe69fab5c9.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7a647603-2c58-4343-92ff-65fe69fab5c9.png",
      },
      {
        uuid: "d0d77a01-c4bf-4a0f-a008-fd336981a475.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d0d77a01-c4bf-4a0f-a008-fd336981a475.png",
      },
      {
        uuid: "9b281ab1-0add-453d-bb70-440f750abd84.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9b281ab1-0add-453d-bb70-440f750abd84.png",
      },
      {
        uuid: "2865812b-517f-4661-b0c3-5e0083968c96.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2865812b-517f-4661-b0c3-5e0083968c96.png",
      },
      {
        uuid: "26ad56a0-dfeb-45d5-b9e6-bacc54bf537a.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/26ad56a0-dfeb-45d5-b9e6-bacc54bf537a.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "sim",
      ar: "sadsda",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b6833031396275ae0db0",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 100,
    description: {
      en: "sdsadsa",
      ar: "sadsa",
    },
    guestCount: 4,
    coverImage: {
      uuid: "2382771c-5cb1-49f3-916b-6d53f4a0bf3e.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2382771c-5cb1-49f3-916b-6d53f4a0bf3e.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "70871c74-8404-4c87-919f-3a4ac363777e.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/70871c74-8404-4c87-919f-3a4ac363777e.png",
      },
      {
        uuid: "ccd89ada-2270-495f-b003-9369c7dee1b5.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ccd89ada-2270-495f-b003-9369c7dee1b5.png",
      },
      {
        uuid: "9dd854c9-fa73-4dba-b951-beabe7b85c89.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9dd854c9-fa73-4dba-b951-beabe7b85c89.png",
      },
      {
        uuid: "70ebd42c-693d-4157-bde9-7c11a4b41d63.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/70ebd42c-693d-4157-bde9-7c11a4b41d63.png",
      },
      {
        uuid: "f342b9ec-3656-43cf-9011-317be07d45c6.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f342b9ec-3656-43cf-9011-317be07d45c6.png",
      },
      {
        uuid: "2b450915-630b-4753-8cc9-72ba4d365970.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2b450915-630b-4753-8cc9-72ba4d365970.png",
      },
      {
        uuid: "791d1fb0-fd20-4288-83c8-f98e8d31946d.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/791d1fb0-fd20-4288-83c8-f98e8d31946d.png",
      },
      {
        uuid: "4eddedc4-60ad-487f-946a-5096ae9e1218.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4eddedc4-60ad-487f-946a-5096ae9e1218.png",
      },
    ],
    amenities: ["618236bbde7dd058e94a0328"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "adding new",
      ar: "saddsa",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b6833031396275ae0db0",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 6,
    description: {
      en: "sadsad",
      ar: "sadsad",
    },
    guestCount: 3,
    coverImage: {
      uuid: "4cf1d6bd-8a17-492b-900f-5bdae9ecd976.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4cf1d6bd-8a17-492b-900f-5bdae9ecd976.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "329d8be8-fd7b-4612-8356-e994a321f585.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/329d8be8-fd7b-4612-8356-e994a321f585.png",
      },
      {
        uuid: "cd57f9e4-3069-413b-915c-b784bec95e0d.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/cd57f9e4-3069-413b-915c-b784bec95e0d.png",
      },
      {
        uuid: "cbe6766f-cb5a-4e2e-93c3-3d191b6a29d8.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/cbe6766f-cb5a-4e2e-93c3-3d191b6a29d8.png",
      },
      {
        uuid: "fe2a7e57-158a-4fc2-ad97-c96bbd9ac1dc.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/fe2a7e57-158a-4fc2-ad97-c96bbd9ac1dc.png",
      },
    ],
    amenities: [
      "618236bbde7dd058e94a0328",
      "6182370ade7dd058e94a032e",
      "6188d5a5de7dd058e94a0986",
      "619b80eaea0a4894dbeb1e6b",
      "61a06f3ee0edf66c5def85a3",
      "61bc3dd575de0b6fb3fb1ef4",
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
      "61c40ccec3d13e7f0020e1cf",
      "61c40ee4cca5462cc38db9d0",
      "61c4682f2031f43c133cee13",
      "61c4685e2031f43c133cee35",
      "61c468852031f43c133cee5c",
      "61c468a82031f43c133cee72",
      "61c474662031f43c133cf4cb",
      "61c54fb12031f43c133cf546",
      "61c54fe82031f43c133cf54c",
      "61c5500d2031f43c133cf557",
      "61c550252031f43c133cf55d",
      "61c55fac2031f43c133cfb9e",
      "61c55fb62031f43c133cfba4",
      "61c560a32031f43c133cfbac",
      "61c5616a2031f43c133cfbb2",
      "61c561b12031f43c133cfbb8",
      "61c561d62031f43c133cfbbe",
      "61c5622f7d5a3155ed9ad0be",
      "61c5623c7d5a3155ed9ad0c7",
      "61c562c77d5a3155ed9ad0db",
      "61c563667d5a3155ed9ad0e1",
      "61c563ce7d5a3155ed9ad101",
      "61c575087d5a3155ed9ad5b4",
      "61c5acb29237275c46aa09fb",
      "61c5acf69237275c46aa0a05",
      "61c5ad6a9237275c46aa0a2d",
    ],
    valueAddedServices: [
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "salma",
      ar: "salma",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b6833031396275ae0db0",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 150,
    description: {
      en: "salma",
      ar: "salma",
    },
    guestCount: 5,
    coverImage: {
      uuid: "20e656c9-5f68-4b9e-8e31-ca302496e1f0.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/20e656c9-5f68-4b9e-8e31-ca302496e1f0.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "a0ba9b95-5c73-4a43-9dfc-3d4a3a661f24.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a0ba9b95-5c73-4a43-9dfc-3d4a3a661f24.jpg",
      },
      {
        uuid: "05fdbbc1-094c-4afe-a413-863e7040717e.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/05fdbbc1-094c-4afe-a413-863e7040717e.jfif",
      },
      {
        uuid: "2009be8c-9259-44d5-9054-b3e2bb080dc1.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2009be8c-9259-44d5-9054-b3e2bb080dc1.jfif",
      },
    ],
    amenities: [
      "618236bbde7dd058e94a0328",
      "6182370ade7dd058e94a032e",
      "6188d5a5de7dd058e94a0986",
      "619b80eaea0a4894dbeb1e6b",
      "61a06f3ee0edf66c5def85a3",
      "61bc3dd575de0b6fb3fb1ef4",
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
      "61c40ccec3d13e7f0020e1cf",
      "61c40ee4cca5462cc38db9d0",
      "61c4682f2031f43c133cee13",
      "61c4685e2031f43c133cee35",
      "61c468852031f43c133cee5c",
      "61c468a82031f43c133cee72",
      "61c474662031f43c133cf4cb",
      "61c54fb12031f43c133cf546",
      "61c54fe82031f43c133cf54c",
      "61c5500d2031f43c133cf557",
      "61c550252031f43c133cf55d",
      "61c55fac2031f43c133cfb9e",
      "61c55fb62031f43c133cfba4",
      "61c560a32031f43c133cfbac",
      "61c5616a2031f43c133cfbb2",
      "61c561b12031f43c133cfbb8",
      "61c561d62031f43c133cfbbe",
      "61c5622f7d5a3155ed9ad0be",
      "61c5623c7d5a3155ed9ad0c7",
      "61c562c77d5a3155ed9ad0db",
      "61c563667d5a3155ed9ad0e1",
      "61c563ce7d5a3155ed9ad101",
      "61c575087d5a3155ed9ad5b4",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
      "61c40f16cca5462cc38db9f3",
      "61c469292031f43c133ceec0",
      "61c475a02031f43c133cf4d9",
      "61c556302031f43c133cf684",
      "61c557e42031f43c133cf723",
      "61c5649d7d5a3155ed9ad107",
      "61c565f57d5a3155ed9ad114",
      "61c566737d5a3155ed9ad117",
      "61c568687d5a3155ed9ad186",
      "61c5988d7d5a3155ed9ad875",
    ],
    reviews: [],
    name: {
      en: "12345",
      ar: "ghjhjghjgj",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 2564,
    description: {
      en: "ghjfgccgh",
      ar: "vgghghvv",
    },
    guestCount: 7,
    coverImage: {
      uuid: "3cd72f3b-ef44-4bd6-a73b-a10f7cf2b9d4.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/3cd72f3b-ef44-4bd6-a73b-a10f7cf2b9d4.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "e8fa54c4-6e53-4ef2-ae7a-1317615f3b89.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e8fa54c4-6e53-4ef2-ae7a-1317615f3b89.jpg",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b", "61a06f3ee0edf66c5def85a3"],
    valueAddedServices: [
      "618bb978cd534fbe42940e53",
      "61c475a02031f43c133cf4d9",
    ],
    reviews: [],
    name: {
      en: "123",
      ar: "123",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b76e3031396275ae0dc6",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 122,
    description: {
      en: "1321",
      ar: "22",
    },
    guestCount: 213,
    coverImage: {
      uuid: "a6a35f8a-e3b3-4c2c-882b-904e58bf6322.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a6a35f8a-e3b3-4c2c-882b-904e58bf6322.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "e89c0465-feab-4357-b441-6de79015033f.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e89c0465-feab-4357-b441-6de79015033f.jpg",
      },
      {
        uuid: "82749d41-1cb9-46b4-bad5-8c898c8fb5e4.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/82749d41-1cb9-46b4-bad5-8c898c8fb5e4.jpg",
      },
    ],
    amenities: [
      "6182370ade7dd058e94a032e",
      "6188d5a5de7dd058e94a0986",
      "619b80eaea0a4894dbeb1e6b",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "commerical",
      ar: "com",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b8d23031396275ae0df4",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 399,
    description: {
      en: "commercial details",
      ar: "romcom",
    },
    guestCount: 30,
    coverImage: {
      uuid: "66856ebf-241b-4f82-8a47-baffcb0a4553.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/66856ebf-241b-4f82-8a47-baffcb0a4553.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "cd8bfceb-3382-4cd7-b1a7-86020c4c57d5.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/cd8bfceb-3382-4cd7-b1a7-86020c4c57d5.jpg",
      },
    ],
    amenities: ["6188d5a5de7dd058e94a0986", "619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: [
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "tess",
      ar: "w",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b76e3031396275ae0dc6",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 150,
    description: {
      en: "test",
      ar: "w",
    },
    guestCount: 5,
    coverImage: {
      uuid: "3b7b6c39-80a7-416f-ab01-b291db675019.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/3b7b6c39-80a7-416f-ab01-b291db675019.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "350c02b6-cb9e-4d02-b37b-40cf5dfad8a3.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/350c02b6-cb9e-4d02-b37b-40cf5dfad8a3.jpg",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e", "6188d5a5de7dd058e94a0986"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "233",
      ar: "WW",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b76e3031396275ae0dc6",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 22,
    description: {
      en: "ETST",
      ar: "22",
    },
    guestCount: 2,
    coverImage: {
      uuid: "f128c2f7-99b0-4437-b71e-143839fed63d.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f128c2f7-99b0-4437-b71e-143839fed63d.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "372b92c6-4d9a-49ce-8532-25a6283d8f06.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/372b92c6-4d9a-49ce-8532-25a6283d8f06.jpg",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: [
      "61c475a02031f43c133cf4d9",
      "615eb9b8fd5315d7911fa20f",
    ],
    reviews: [],
    name: {
      en: "test2",
      ar: "kk",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b8173031396275ae0de6",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 48,
    description: {
      en: "test2",
      ar: "kk",
    },
    guestCount: 1,
    coverImage: {
      uuid: "dbcc99aa-8a62-49bc-a505-8776037d5e8e.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/dbcc99aa-8a62-49bc-a505-8776037d5e8e.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "a767622f-79ea-4f2b-830d-999f52b1a3e7.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a767622f-79ea-4f2b-830d-999f52b1a3e7.png",
      },
    ],
    amenities: ["61c2e995c3d13e7f0020ccde"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "2132aa",
      ar: "2213aa",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 4,
    description: {
      en: "sadads",
      ar: "asdds",
    },
    guestCount: 3,
    coverImage: {
      uuid: "baf01a88-624a-4422-85b5-1e23eb57ebd3.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/baf01a88-624a-4422-85b5-1e23eb57ebd3.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "4b01aac2-a729-4203-bcea-769a5e39c786.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4b01aac2-a729-4203-bcea-769a5e39c786.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e", "6188d5a5de7dd058e94a0986"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "213213",
      ar: "213123",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 3,
    description: {
      en: "qwewe",
      ar: "qwewe",
    },
    guestCount: 2,
    coverImage: {
      uuid: "78991837-aa66-49b3-9d18-6e7cb683bd04.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/78991837-aa66-49b3-9d18-6e7cb683bd04.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "77076700-3393-44fa-9531-37a19b4d50ed.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/77076700-3393-44fa-9531-37a19b4d50ed.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "aa",
      ar: "aa",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 3,
    description: {
      en: "wdwqewqe",
      ar: "qwewqe",
    },
    guestCount: 2,
    coverImage: {
      uuid: "e9383e5f-d6dd-478f-b536-4608101c2c3a.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e9383e5f-d6dd-478f-b536-4608101c2c3a.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "dc962fec-6bf5-4dbe-9662-0d2baacddb7f.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/dc962fec-6bf5-4dbe-9662-0d2baacddb7f.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e", "6188d5a5de7dd058e94a0986"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "sadsadss",
      ar: "sadsda",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 3,
    description: {
      en: "sadsadad",
      ar: "sadsadsad",
    },
    guestCount: 7,
    coverImage: {
      uuid: "e141cf48-2bae-42e2-bda9-ffdc0dda5478.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e141cf48-2bae-42e2-bda9-ffdc0dda5478.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "9042153c-8dd7-43eb-a75f-9a225e1ed909.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9042153c-8dd7-43eb-a75f-9a225e1ed909.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e", "6188d5a5de7dd058e94a0986"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "sadsadaa",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 3,
    description: {
      en: "sadsad",
      ar: "sadsad",
    },
    guestCount: 3,
    coverImage: {
      uuid: "845d3b88-4ba2-42b0-9586-97586d94616b.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/845d3b88-4ba2-42b0-9586-97586d94616b.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "d1384595-faa4-4175-ba82-1c183135a9e7.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d1384595-faa4-4175-ba82-1c183135a9e7.jpg",
      },
      {
        uuid: "9600edc9-b15b-47f8-9b82-10a7b5aa02c2.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9600edc9-b15b-47f8-9b82-10a7b5aa02c2.jfif",
      },
      {
        uuid: "d88a3301-2bdd-467c-9e66-d997accca61c.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d88a3301-2bdd-467c-9e66-d997accca61c.jfif",
      },
    ],
    amenities: [
      "6182370ade7dd058e94a032e",
      "6188d5a5de7dd058e94a0986",
      "619b80eaea0a4894dbeb1e6b",
      "61a06f3ee0edf66c5def85a3",
      "61bc3dd575de0b6fb3fb1ef4",
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
      "61c40ccec3d13e7f0020e1cf",
      "61c40ee4cca5462cc38db9d0",
      "61c4682f2031f43c133cee13",
      "61c4685e2031f43c133cee35",
      "61c468852031f43c133cee5c",
      "61c468a82031f43c133cee72",
      "61c474662031f43c133cf4cb",
      "61c54fb12031f43c133cf546",
      "61c54fe82031f43c133cf54c",
      "61c5500d2031f43c133cf557",
      "61c550252031f43c133cf55d",
      "61c55fac2031f43c133cfb9e",
      "61c55fb62031f43c133cfba4",
      "61c560a32031f43c133cfbac",
      "61c5616a2031f43c133cfbb2",
      "61c561b12031f43c133cfbb8",
      "61c561d62031f43c133cfbbe",
      "61c5622f7d5a3155ed9ad0be",
      "61c5623c7d5a3155ed9ad0c7",
      "61c562c77d5a3155ed9ad0db",
      "61c563667d5a3155ed9ad0e1",
      "61c563ce7d5a3155ed9ad101",
      "61c575087d5a3155ed9ad5b4",
      "61c5acb29237275c46aa09fb",
      "61c5acf69237275c46aa0a05",
      "61c5ad6a9237275c46aa0a2d",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
      "61c40f16cca5462cc38db9f3",
      "61c475a02031f43c133cf4d9",
      "61c5649d7d5a3155ed9ad107",
      "61c565f57d5a3155ed9ad114",
      "61c566737d5a3155ed9ad117",
      "61c568687d5a3155ed9ad186",
      "61c5988d7d5a3155ed9ad875",
      "61c5a5ab9237275c46aa057d",
    ],
    reviews: [],
    name: {
      en: "tetnet123456",
      ar: "1323456",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b6833031396275ae0db0",
    bedType: "615fdbd73d18f435ccb3e529",
    price: 4,
    description: {
      en: "rdfsaweq",
      ar: "hghggh",
    },
    guestCount: 3,
    coverImage: {
      uuid: "10414190-6d5a-436d-8efc-4252432db998.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/10414190-6d5a-436d-8efc-4252432db998.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["6188d5a5de7dd058e94a0986"],
    valueAddedServices: ["618bb978cd534fbe42940e53"],
    reviews: [],
    name: {
      en: "DSFDAFDA",
      ar: "DFSADSA",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 4,
    description: {
      en: "DFDSFDSFS",
      ar: "SADSADA",
    },
    guestCount: 4,
    coverImage: {
      uuid: "996e308d-3d53-4b52-8727-bf63d53f500a.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/996e308d-3d53-4b52-8727-bf63d53f500a.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "f8f4d403-b714-4fe4-a3a9-4419558c36fa.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f8f4d403-b714-4fe4-a3a9-4419558c36fa.png",
      },
    ],
    amenities: ["6188d5a5de7dd058e94a0986"],
    valueAddedServices: ["61602c47267dc41a25ef3486"],
    reviews: [],
    name: {
      en: "dsfdsfdsf",
      ar: "dsfdsf",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 3,
    description: {
      en: "dsfdsfdsf",
      ar: "dsffds",
    },
    guestCount: 3,
    coverImage: {
      uuid: "6d5d0ad0-7b7a-4972-9690-18ca97c517e3.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/6d5d0ad0-7b7a-4972-9690-18ca97c517e3.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "31683c0a-ce79-4c05-92d0-1c3ac6c5ae32.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/31683c0a-ce79-4c05-92d0-1c3ac6c5ae32.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "dsfdsfds",
      ar: "dsfdsf",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 100,
    description: {
      en: "dsfdsfds",
      ar: "fdsf",
    },
    guestCount: 5,
    coverImage: {
      uuid: "e8702c76-74d7-4fe6-8a38-0288fdd6bd6e.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e8702c76-74d7-4fe6-8a38-0288fdd6bd6e.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [],
    amenities: ["61a06f3ee0edf66c5def85a3"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "sadsadsad",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 5,
    description: {
      en: "asdsada",
      ar: "sadsad",
    },
    guestCount: 4,
    coverImage: {
      uuid: "19f7bb57-ac12-4789-b7fb-77331e93ca5d.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/19f7bb57-ac12-4789-b7fb-77331e93ca5d.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "bb4a2f18-0eb0-43fa-b997-8a87c9f2e064.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/bb4a2f18-0eb0-43fa-b997-8a87c9f2e064.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e", "619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "DSFDFDSF",
      ar: "DSFDSF",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 3,
    description: {
      en: "DSFDSFS",
      ar: "DSFDSF",
    },
    guestCount: 3,
    coverImage: {
      uuid: "ed5c7de6-87aa-42c5-932e-ee87c3ed5759.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ed5c7de6-87aa-42c5-932e-ee87c3ed5759.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "91544f9f-c6b3-4a96-8d64-747b38dcb52f.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/91544f9f-c6b3-4a96-8d64-747b38dcb52f.png",
      },
    ],
    amenities: ["6188d5a5de7dd058e94a0986", "619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
      "618bb978cd534fbe42940e53",
      "61c475a02031f43c133cf4d9",
      "61c565f57d5a3155ed9ad114",
    ],
    reviews: [],
    name: {
      en: "TEST",
      ar: "TTST",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c5d1509237275c46aa10c0",
    bedType: "615fdbd73d18f435ccb3e529",
    price: 500,
    description: {
      en: "TEST",
      ar: "HH",
    },
    guestCount: 7,
    coverImage: {
      uuid: "ad42b715-ceb5-40c1-acd2-405eef9ebd48.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ad42b715-ceb5-40c1-acd2-405eef9ebd48.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "b19ba75d-4c4a-4849-af3e-11cd30ff52ef.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b19ba75d-4c4a-4849-af3e-11cd30ff52ef.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e", "6188d5a5de7dd058e94a0986"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61602c47267dc41a25ef3486",
    ],
    reviews: [],
    name: {
      en: "sadsad",
      ar: "sadsadassss",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 4,
    description: {
      en: "sadsad",
      ar: "sadsa",
    },
    guestCount: 4,
    coverImage: {
      uuid: "b6537d9b-5ff2-42ec-b040-72e356683612.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b6537d9b-5ff2-42ec-b040-72e356683612.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "62a82c96-154f-4c2d-a8df-8d7aa0dad665.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/62a82c96-154f-4c2d-a8df-8d7aa0dad665.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "new22",
      ar: "dsfdf",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 4,
    description: {
      en: "sdffd",
      ar: "dsfsdf",
    },
    guestCount: 4,
    coverImage: {
      uuid: "790564a0-0db4-434e-9910-68cbd9e121c1.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/790564a0-0db4-434e-9910-68cbd9e121c1.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "7c9b51b8-a538-494d-b39d-b695d95606a0.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7c9b51b8-a538-494d-b39d-b695d95606a0.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "618bb978cd534fbe42940e53",
    ],
    reviews: [],
    name: {
      en: "2sdaas",
      ar: "dsfdf",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 4,
    description: {
      en: "sdffd",
      ar: "dsfsdf",
    },
    guestCount: 4,
    coverImage: {
      uuid: "68030702-be82-4564-999b-5f3144a56bfe.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/68030702-be82-4564-999b-5f3144a56bfe.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "7b1e2c2c-fbe5-4cd2-95fe-827de52b3cac.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7b1e2c2c-fbe5-4cd2-95fe-827de52b3cac.jpg",
      },
      {
        uuid: "4b33be62-20cd-4651-bbda-3da511aeaf33.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4b33be62-20cd-4651-bbda-3da511aeaf33.jpg",
      },
    ],
    amenities: ["61c18d663031396275adfee6"],
    valueAddedServices: ["61c5a5ab9237275c46aa057d"],
    reviews: [],
    name: {
      en: "Capsule Roomw",
      ar: "Cap غرفة للأفراد",
    },
    propertyType: "617252f1cd73fafd8c482105",
    building: "61c5d1509237275c46aa10c0",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 135,
    description: {
      en: "Standard single bed roomw",
      ar: "غرفة فاخرة بسرير مفرد",
    },
    guestCount: 4,
    coverImage: {
      uuid: "a39d5335-33c4-4d8f-8316-76801276863a.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a39d5335-33c4-4d8f-8316-76801276863a.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "4da41fdf-b542-46db-a9f4-81d7b646be5b.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4da41fdf-b542-46db-a9f4-81d7b646be5b.png",
      },
    ],
    amenities: ["6182370ade7dd058e94a032e"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "created",
      ar: "sadsad",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b76e3031396275ae0dc6",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 3,
    description: {
      en: "sadsd",
      ar: "sadsad",
    },
    guestCount: 3,
    coverImage: {
      uuid: "ec019232-9e4c-4d73-b2ec-36c98fd795f3.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ec019232-9e4c-4d73-b2ec-36c98fd795f3.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "41144d21-45b2-407a-bee4-8dda84ea70fd.jpg",
        imageUrl:
          "https://feedy-dev.s3.eu-north-1.amazonaws.com//41144d21-45b2-407a-bee4-8dda84ea70fd.jpg",
      },
      {
        uuid: "9b88b950-c53f-44c2-a690-1ad09822bfc8.jpg",
        imageUrl:
          "https://feedy-dev.s3.eu-north-1.amazonaws.com//9b88b950-c53f-44c2-a690-1ad09822bfc8.jpg",
      },
    ],
    amenities: ["61c18d663031396275adfee6"],
    valueAddedServices: ["61c5a5ab9237275c46aa057d"],
    reviews: [],
    name: {
      en: "Capsule RoomwX",
      ar: "Cap غرفة للأفرادX",
    },
    propertyType: "617252f1cd73fafd8c482105",
    building: "61c5d1509237275c46aa10c0",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 135,
    description: {
      en: "Standard single bed roomw",
      ar: "غرفة فاخرة بسرير مفرد",
    },
    guestCount: 4,
    coverImage: {
      uuid: "2702d36c-5ab2-47a7-a9a0-bec5129bcb2d.jpg",
      imageUrl:
        "https://feedy-dev.s3.eu-north-1.amazonaws.com//2702d36c-5ab2-47a7-a9a0-bec5129bcb2d.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "7eebc5ac-9c3c-4daf-8409-04b093bd3d0f.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7eebc5ac-9c3c-4daf-8409-04b093bd3d0f.png",
      },
    ],
    amenities: [
      "619b80eaea0a4894dbeb1e6b",
      "61a06f3ee0edf66c5def85a3",
      "61c468a82031f43c133cee72",
    ],
    valueAddedServices: ["61c475a02031f43c133cf4d9"],
    reviews: [],
    name: {
      en: "sdsadsad",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 100,
    description: {
      en: "sadsad",
      ar: "sadas",
    },
    guestCount: 2,
    coverImage: {
      uuid: "05e8308b-7064-4b76-bb62-d3d3e6b0bf2b.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/05e8308b-7064-4b76-bb62-d3d3e6b0bf2b.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "d7fad373-38b2-49d6-afaf-e0fc1a88079b.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d7fad373-38b2-49d6-afaf-e0fc1a88079b.png",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: [
      "61c566737d5a3155ed9ad117",
      "61c568687d5a3155ed9ad186",
      "61c5a5ab9237275c46aa057d",
    ],
    reviews: [],
    name: {
      en: "addd",
      ar: "w",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b8173031396275ae0de6",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 3,
    description: {
      en: "sads",
      ar: "w",
    },
    guestCount: 1,
    coverImage: {
      uuid: "2ea396be-01ba-4e28-90de-80f35bf716db.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2ea396be-01ba-4e28-90de-80f35bf716db.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "488b0535-bc29-4bd5-aeac-f28b89184039.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/488b0535-bc29-4bd5-aeac-f28b89184039.png",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b", "61bc3dd575de0b6fb3fb1ef4"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "618bb978cd534fbe42940e53",
      "61c568687d5a3155ed9ad186",
      "61c5988d7d5a3155ed9ad875",
      "61c565f57d5a3155ed9ad114",
      "61c566737d5a3155ed9ad117",
    ],
    reviews: [],
    name: {
      en: "addhotel",
      ar: "sads",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b8173031396275ae0de6",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 3,
    description: {
      en: "sddsf",
      ar: "asds",
    },
    guestCount: 3,
    coverImage: {
      uuid: "5a759229-680c-4606-b095-584d455763a0.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5a759229-680c-4606-b095-584d455763a0.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "2f004a7a-0d80-4382-9b12-2820a5425b8c.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2f004a7a-0d80-4382-9b12-2820a5425b8c.png",
      },
    ],
    amenities: [
      "619b80eaea0a4894dbeb1e6b",
      "61bc3dd575de0b6fb3fb1ef4",
      "61a06f3ee0edf66c5def85a3",
    ],
    valueAddedServices: [
      "618bb978cd534fbe42940e53",
      "61c475a02031f43c133cf4d9",
      "618bb978cd534fbe42940e53",
      "61c475a02031f43c133cf4d9",
      "615eb9b8fd5315d7911fa20f",
    ],
    reviews: [],
    name: {
      en: "addinghotel2",
      ar: "sadsd",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b8173031396275ae0de6",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 3,
    description: {
      en: "asdsd",
      ar: "sadsa",
    },
    guestCount: 6,
    coverImage: {
      uuid: "7b6fe8bd-a282-406c-ba38-6200b3883cee.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7b6fe8bd-a282-406c-ba38-6200b3883cee.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "b46e9cef-2510-4bbd-ad5c-2f5b8edfa95f.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b46e9cef-2510-4bbd-ad5c-2f5b8edfa95f.png",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b", "61bc3dd575de0b6fb3fb1ef4"],
    valueAddedServices: [
      "61c5649d7d5a3155ed9ad107",
      "615eb9b8fd5315d7911fa20f",
      "61c5649d7d5a3155ed9ad107",
      "615eb9b8fd5315d7911fa20f",
      "61c475a02031f43c133cf4d9",
      "61c5649d7d5a3155ed9ad107",
      "61c475a02031f43c133cf4d9",
      "61c475a02031f43c133cf4d9",
      "615eb9b8fd5315d7911fa20f",
      "615eb9b8fd5315d7911fa20f",
      "615eb9b8fd5315d7911fa20f",
      "61c475a02031f43c133cf4d9",
      "61c5649d7d5a3155ed9ad107",
    ],
    reviews: [],
    name: {
      en: "addinghotel3",
      ar: "xczc",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b8173031396275ae0de6",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 4,
    description: {
      en: "zxcxc",
      ar: "zcc",
    },
    guestCount: 7,
    coverImage: {
      uuid: "0b3023d8-fd3d-4b37-887f-5b212e95aa43.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0b3023d8-fd3d-4b37-887f-5b212e95aa43.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "9f3bc4d2-84fa-42fe-9ff8-2291b58eac30.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9f3bc4d2-84fa-42fe-9ff8-2291b58eac30.png",
      },
    ],
    amenities: ["61bc3dd575de0b6fb3fb1ef4"],
    valueAddedServices: ["61c5649d7d5a3155ed9ad107"],
    reviews: [],
    name: {
      en: "hellobeverly",
      ar: "sadsad",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b8d23031396275ae0df4",
    bedType: "615fdbb83d18f435ccb3a7f2",
    price: 4,
    description: {
      en: "dsfdsfdf",
      ar: "sadsad",
    },
    guestCount: 1,
    coverImage: {
      uuid: "137efe2e-5b80-448a-8601-7306d1fef5a1.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/137efe2e-5b80-448a-8601-7306d1fef5a1.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "7c50785b-0eec-4d59-88c0-2a7fffa98d44.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7c50785b-0eec-4d59-88c0-2a7fffa98d44.jpg",
      },
      {
        uuid: "aa3d866c-60c5-4917-96f4-57e23ca19b5f.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/aa3d866c-60c5-4917-96f4-57e23ca19b5f.jpg",
      },
      {
        uuid: "fce2e998-aae6-402e-9191-91ab80c25981.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/fce2e998-aae6-402e-9191-91ab80c25981.jpg",
      },
      {
        uuid: "ed434872-2cfe-48b9-bdce-278e5e7793d9.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ed434872-2cfe-48b9-bdce-278e5e7793d9.jpg",
      },
    ],
    amenities: ["61c0390975de0b6fb3fb2194", "61c2e995c3d13e7f0020ccde"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61c475a02031f43c133cf4d9",
    ],
    reviews: [],
    name: {
      en: "new property",
      ar: "ksjs",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b8d23031396275ae0df4",
    bedType: "615fdbd73d18f435ccb3e529",
    price: 222,
    description: {
      en: "yes",
      ar: "ijij",
    },
    guestCount: 2,
    coverImage: {
      uuid: "f2d6304f-78be-45d4-9bea-34703aed7880.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f2d6304f-78be-45d4-9bea-34703aed7880.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "958c972b-48d2-44a9-ab31-aecd259f44d1.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/958c972b-48d2-44a9-ab31-aecd259f44d1.jpg",
      },
      {
        uuid: "4539a3ed-99b1-4f8b-af17-c68f23acdd05.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4539a3ed-99b1-4f8b-af17-c68f23acdd05.jpg",
      },
    ],
    amenities: [
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61c475a02031f43c133cf4d9",
      "61c565f57d5a3155ed9ad114",
    ],
    reviews: [],
    name: {
      en: "dance",
      ar: "wwww",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b8d23031396275ae0df4",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 33,
    description: {
      en: "dance",
      ar: "www",
    },
    guestCount: 3,
    coverImage: {
      uuid: "e71a64ff-39f1-4a82-aae1-937e8b0d675b.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e71a64ff-39f1-4a82-aae1-937e8b0d675b.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "bf80a6ea-e600-48e3-82cb-ae4d9ecc06ed.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/bf80a6ea-e600-48e3-82cb-ae4d9ecc06ed.jpg",
      },
      {
        uuid: "502c51bf-454d-45f2-9554-eb727a90c2d2.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/502c51bf-454d-45f2-9554-eb727a90c2d2.jpg",
      },
    ],
    amenities: ["61a06f3ee0edf66c5def85a3", "61bc3dd575de0b6fb3fb1ef4"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61c475a02031f43c133cf4d9",
    ],
    reviews: [],
    name: {
      en: "sss",
      ar: "ssw",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b8d23031396275ae0df4",
    bedType: "615fdbd73d18f435ccb3e529",
    price: 1,
    description: {
      en: "www",
      ar: "wee",
    },
    guestCount: 4,
    coverImage: {
      uuid: "b07773e0-f658-48b5-ab42-af2a9dd3636d.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b07773e0-f658-48b5-ab42-af2a9dd3636d.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "07560665-f64e-41e4-83ed-890302a9aabe.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/07560665-f64e-41e4-83ed-890302a9aabe.jpg",
      },
      {
        uuid: "066ebc86-6727-4965-8b70-18271ed5ed86.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/066ebc86-6727-4965-8b70-18271ed5ed86.jpg",
      },
    ],
    amenities: ["61bc3dd575de0b6fb3fb1ef4", "61c18d663031396275adfee6"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "testQuad",
      ar: "dhu",
    },
    propertyType: "617252f1cd73fafd8c482105",
    building: "61c1b8d23031396275ae0df4",
    bedType: "615fdbd73d18f435ccb3e529",
    price: 399,
    description: {
      en: "quad",
      ar: "uhrud",
    },
    guestCount: 3,
    coverImage: {
      uuid: "2d959b98-ba15-4d75-b722-dc4607b4aa93.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2d959b98-ba15-4d75-b722-dc4607b4aa93.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "edff6346-67d5-4b57-9e97-5a0b4fce9d6e.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/edff6346-67d5-4b57-9e97-5a0b4fce9d6e.jpg",
      },
      {
        uuid: "ff5a1544-9977-4552-94be-5fd89ea92f3d.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ff5a1544-9977-4552-94be-5fd89ea92f3d.jpg",
      },
      {
        uuid: "7d422010-9dd1-4c49-8938-49afc72f1b9d.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7d422010-9dd1-4c49-8938-49afc72f1b9d.jpg",
      },
      {
        uuid: "5e038fc3-e857-45d4-8b47-a544cb9a1170.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5e038fc3-e857-45d4-8b47-a544cb9a1170.jpg",
      },
      {
        uuid: "c18b8c12-f233-495b-beb4-da4948f090f1.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c18b8c12-f233-495b-beb4-da4948f090f1.jpg",
      },
      {
        uuid: "a73e8ebe-eb99-4aa8-9ca8-74dc1483f0d3.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a73e8ebe-eb99-4aa8-9ca8-74dc1483f0d3.jpg",
      },
      {
        uuid: "25e918f0-9ab4-47b8-b102-67a9b8f68aaa.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/25e918f0-9ab4-47b8-b102-67a9b8f68aaa.jpg",
      },
      {
        uuid: "c7a8c799-199b-4a24-94cb-a5de4bb76f65.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c7a8c799-199b-4a24-94cb-a5de4bb76f65.jpg",
      },
    ],
    amenities: ["61c0390975de0b6fb3fb2194"],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61c475a02031f43c133cf4d9",
    ],
    reviews: [],
    name: {
      en: "wjjwjwjw",
      ar: "wkwi",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61e52ff61030ad7bda40a262",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 74,
    description: {
      en: "ssh",
      ar: "jidj",
    },
    guestCount: 2,
    coverImage: {
      uuid: "2093a3c1-832a-4365-b68e-1c93a7776ab5.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2093a3c1-832a-4365-b68e-1c93a7776ab5.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "6211625a-5878-4cff-925a-8e9c0e7b5b72.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/6211625a-5878-4cff-925a-8e9c0e7b5b72.jpg",
      },
      {
        uuid: "e1d4f61d-6b30-446a-a324-9a12d16c335b.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e1d4f61d-6b30-446a-a324-9a12d16c335b.jpg",
      },
      {
        uuid: "5e5f7bdc-86e6-42d9-a05d-40bae4bad91f.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5e5f7bdc-86e6-42d9-a05d-40bae4bad91f.jpg",
      },
      {
        uuid: "116dca8c-479a-46f5-9929-30abfba9f54b.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/116dca8c-479a-46f5-9929-30abfba9f54b.jpg",
      },
      {
        uuid: "24fc92d1-a954-48fa-9ea9-a384188f814c.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/24fc92d1-a954-48fa-9ea9-a384188f814c.jpg",
      },
    ],
    amenities: ["61bc3dd575de0b6fb3fb1ef4", "61c0390975de0b6fb3fb2194"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "testss",
      ar: "yesy",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61e52ff61030ad7bda40a262",
    bedType: "615fdbd73d18f435ccb3e528",
    price: 234,
    description: {
      en: "test",
      ar: "yeys",
    },
    guestCount: 3,
    coverImage: {
      uuid: "41d34f0e-842d-4f3a-91ad-561a01751d29.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/41d34f0e-842d-4f3a-91ad-561a01751d29.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "c4fb1d5f-d4fc-4424-ab36-d71046a9d247.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c4fb1d5f-d4fc-4424-ab36-d71046a9d247.jfif",
      },
      {
        uuid: "55de703f-4b9c-4c7a-af27-2e559704614b.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/55de703f-4b9c-4c7a-af27-2e559704614b.jfif",
      },
    ],
    amenities: [
      "619b80eaea0a4894dbeb1e6b",
      "61bc3dd575de0b6fb3fb1ef4",
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
      "61c40ccec3d13e7f0020e1cf",
      "61c40ee4cca5462cc38db9d0",
      "61c4682f2031f43c133cee13",
      "61c4685e2031f43c133cee35",
      "61c468a82031f43c133cee72",
      "61c474662031f43c133cf4cb",
      "61c54fb12031f43c133cf546",
      "61c54fe82031f43c133cf54c",
      "61c560a32031f43c133cfbac",
      "61c5616a2031f43c133cfbb2",
      "61c561b12031f43c133cfbb8",
    ],
    valueAddedServices: [
      "615eb9b8fd5315d7911fa20f",
      "61c475a02031f43c133cf4d9",
      "61c566737d5a3155ed9ad117",
      "61c5988d7d5a3155ed9ad875",
      "61c5a5ab9237275c46aa057d",
      "61d6d7e106fc0f116ef4de0c",
      "61deb172f295c24df9d22f96",
      "61e11247edc4e00fafba33f9",
    ],
    reviews: [],
    name: {
      en: "qwerty",
      ar: "fgfgf",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b76e3031396275ae0dc6",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 1245,
    description: {
      en: "dfgfdgfdgfd",
      ar: "fhgfhgdshcgdsh",
    },
    guestCount: 5,
    coverImage: {
      uuid: "0e575945-32a1-475a-ab74-deccff4370b1.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0e575945-32a1-475a-ab74-deccff4370b1.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "6d2fef41-cfd7-47af-a86f-1e41b782ef07.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/6d2fef41-cfd7-47af-a86f-1e41b782ef07.png",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "test",
      ar: "dsfdsf",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61c1b5fc3031396275ae0da5",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 3,
    description: {
      en: "xcdsdfdf",
      ar: "dsf",
    },
    guestCount: 2,
    coverImage: {
      uuid: "bffa96ea-bbbd-4416-9573-c134e9d5869b.png",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/bffa96ea-bbbd-4416-9573-c134e9d5869b.png",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "413a97ad-a22a-40b0-91be-df2f7f2b4fd3.jfif",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/413a97ad-a22a-40b0-91be-df2f7f2b4fd3.jfif",
      },
    ],
    amenities: [
      "61a06f3ee0edf66c5def85a3",
      "61bc3dd575de0b6fb3fb1ef4",
      "61c0390975de0b6fb3fb2194",
      "61c18d663031396275adfee6",
      "61c2e995c3d13e7f0020ccde",
      "61c40ccec3d13e7f0020e1cf",
      "61c40ee4cca5462cc38db9d0",
      "61c550252031f43c133cf55d",
      "61c55fac2031f43c133cfb9e",
    ],
    valueAddedServices: [
      "61c475a02031f43c133cf4d9",
      "61c565f57d5a3155ed9ad114",
      "61c566737d5a3155ed9ad117",
      "61c5a5ab9237275c46aa057d",
      "61d6d7e106fc0f116ef4de0c",
      "61deb172f295c24df9d22f96",
      "61e11247edc4e00fafba33f9",
    ],
    reviews: [],
    name: {
      en: "test12345",
      ar: "jhjhhg",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b76e3031396275ae0dc6",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 45128,
    description: {
      en: "ghjfhg",
      ar: "kjnk5465",
    },
    guestCount: 8,
    coverImage: {
      uuid: "3cffe8ae-05b6-4c9e-ab21-13ca5a25a537.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/3cffe8ae-05b6-4c9e-ab21-13ca5a25a537.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "7c7525fb-5042-44cb-a5d4-7b8eaa97ae36.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7c7525fb-5042-44cb-a5d4-7b8eaa97ae36.jpg",
      },
      {
        uuid: "55dc7d2d-d215-497e-96f1-5f7f4304764f.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/55dc7d2d-d215-497e-96f1-5f7f4304764f.jpg",
      },
      {
        uuid: "10f1dd1a-2c75-4d84-8b43-0675be100669.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/10f1dd1a-2c75-4d84-8b43-0675be100669.jpg",
      },
      {
        uuid: "dfc79aec-2334-447d-adc3-5e60eed773a7.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/dfc79aec-2334-447d-adc3-5e60eed773a7.jpg",
      },
      {
        uuid: "f2c22dd4-619b-4ffe-8efa-e160bb3546cf.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f2c22dd4-619b-4ffe-8efa-e160bb3546cf.jpg",
      },
      {
        uuid: "63271ebc-31aa-4389-9685-76331f717795.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/63271ebc-31aa-4389-9685-76331f717795.jpg",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "jj",
      ar: "nj",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61e52ff61030ad7bda40a262",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 44,
    description: {
      en: "jj",
      ar: "jj",
    },
    guestCount: 4,
    coverImage: {
      uuid: "8fcd80f6-c5dc-4ba4-95b2-e2eaa63a3285.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/8fcd80f6-c5dc-4ba4-95b2-e2eaa63a3285.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "b7f50717-b879-4a7f-bb37-142f71e8bdd9.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b7f50717-b879-4a7f-bb37-142f71e8bdd9.jpg",
      },
      {
        uuid: "1c5b1a3e-3469-4267-8a6a-532390ab52b4.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/1c5b1a3e-3469-4267-8a6a-532390ab52b4.jpg",
      },
      {
        uuid: "1d861ed4-04fd-4d74-bb18-9b4f6e619065.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/1d861ed4-04fd-4d74-bb18-9b4f6e619065.jpg",
      },
      {
        uuid: "42eb4a52-83e0-4c68-b4e5-4c5c741f484d.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/42eb4a52-83e0-4c68-b4e5-4c5c741f484d.jpg",
      },
      {
        uuid: "c105c9ac-145d-4667-be52-c693644d8229.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c105c9ac-145d-4667-be52-c693644d8229.jpg",
      },
      {
        uuid: "099d1a46-6770-47e6-9434-d1e9d9971d8d.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/099d1a46-6770-47e6-9434-d1e9d9971d8d.jpg",
      },
      {
        uuid: "dca1bc8e-3c2c-4c5b-a580-c90795810b5a.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/dca1bc8e-3c2c-4c5b-a580-c90795810b5a.jpg",
      },
      {
        uuid: "ebbe1134-f8ba-4e58-bc8a-a3921c773f9c.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ebbe1134-f8ba-4e58-bc8a-a3921c773f9c.jpg",
      },
      {
        uuid: "aebeb68f-0081-4ba7-a4a1-591e7c49ebbd.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/aebeb68f-0081-4ba7-a4a1-591e7c49ebbd.jpg",
      },
      {
        uuid: "513c43dc-f7f2-469f-b120-2f7b785091c2.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/513c43dc-f7f2-469f-b120-2f7b785091c2.jpg",
      },
      {
        uuid: "998c89da-ff8d-41ca-b792-7ddab2c64d30.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/998c89da-ff8d-41ca-b792-7ddab2c64d30.jpg",
      },
      {
        uuid: "c8c1143f-e1d0-4795-b5a8-71561303d2e8.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c8c1143f-e1d0-4795-b5a8-71561303d2e8.jpg",
      },
      {
        uuid: "a6fa0f7d-d92c-4164-b23a-673903cdac36.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a6fa0f7d-d92c-4164-b23a-673903cdac36.jpg",
      },
      {
        uuid: "8e536b36-1b85-44d7-b580-b0ea4b5ee3a7.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/8e536b36-1b85-44d7-b580-b0ea4b5ee3a7.jpg",
      },
      {
        uuid: "0cfacad3-3d7b-4029-a394-d06408f16636.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0cfacad3-3d7b-4029-a394-d06408f16636.jpg",
      },
      {
        uuid: "030ba81d-0579-4fc9-bf0b-8e77dfd62726.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/030ba81d-0579-4fc9-bf0b-8e77dfd62726.jpg",
      },
      {
        uuid: "52e7850f-bd32-4fd3-9527-10139a8b6839.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/52e7850f-bd32-4fd3-9527-10139a8b6839.jpg",
      },
      {
        uuid: "15534ec3-99e9-4a63-9d1b-e6eb32e9df7a.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/15534ec3-99e9-4a63-9d1b-e6eb32e9df7a.jpg",
      },
      {
        uuid: "b79a0876-cb9b-469b-af4d-02d8bb43d11d.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b79a0876-cb9b-469b-af4d-02d8bb43d11d.jpg",
      },
      {
        uuid: "06ad9d87-f3ce-4ff2-a0ee-3f606f678013.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/06ad9d87-f3ce-4ff2-a0ee-3f606f678013.jpg",
      },
      {
        uuid: "665e34c3-e25d-400e-9aca-6c03af7f9c81.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/665e34c3-e25d-400e-9aca-6c03af7f9c81.jpg",
      },
      {
        uuid: "54e7c1f6-2266-4cd8-a7c8-1d7e7a677ceb.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/54e7c1f6-2266-4cd8-a7c8-1d7e7a677ceb.jpg",
      },
      {
        uuid: "4bb54c07-63fe-4551-b119-5f9698c7e3d9.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4bb54c07-63fe-4551-b119-5f9698c7e3d9.jpg",
      },
      {
        uuid: "8ec958f5-0bfd-47f0-9427-4632d817104d.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/8ec958f5-0bfd-47f0-9427-4632d817104d.jpg",
      },
      {
        uuid: "a5a9966a-a986-40ac-9f3b-0a979c33be08.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a5a9966a-a986-40ac-9f3b-0a979c33be08.jpg",
      },
      {
        uuid: "7e478b2f-fac4-4236-ad38-273ee4850672.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7e478b2f-fac4-4236-ad38-273ee4850672.jpg",
      },
      {
        uuid: "1bb27dcf-38f6-46ec-adb7-549d3534c3a8.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/1bb27dcf-38f6-46ec-adb7-549d3534c3a8.jpg",
      },
      {
        uuid: "0bb10186-4bd7-47a5-b266-c3104a0ba974.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0bb10186-4bd7-47a5-b266-c3104a0ba974.jpg",
      },
    ],
    amenities: ["61bc3dd575de0b6fb3fb1ef4", "61c40ee4cca5462cc38db9d0"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "ssssss",
      ar: "sssssssss",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61e6a01b0be2db25f080f7f8",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 777777,
    description: {
      en: "s",
      ar: "fff",
    },
    guestCount: 7,
    coverImage: {
      uuid: "baff1056-b587-47a2-8171-3cfb6faf4cdd.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/baff1056-b587-47a2-8171-3cfb6faf4cdd.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "c7692af9-7de3-4085-b149-d4922f349e75.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c7692af9-7de3-4085-b149-d4922f349e75.jpg",
      },
      {
        uuid: "5e4e724b-3b3a-4a2d-9c09-6d7183f772e7.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5e4e724b-3b3a-4a2d-9c09-6d7183f772e7.jpg",
      },
      {
        uuid: "a9ce6787-8e5e-41d7-b80d-dfd164a4966c.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a9ce6787-8e5e-41d7-b80d-dfd164a4966c.jpg",
      },
      {
        uuid: "bf61add4-06da-4627-85a7-9494ce77521c.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/bf61add4-06da-4627-85a7-9494ce77521c.jpg",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b", "61a06f3ee0edf66c5def85a3"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "trr",
      ar: "dfd",
    },
    propertyType: "617252c4cd73fafd8c47d9a3",
    building: "61e6a01b0be2db25f080f7f8",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 3344,
    description: {
      en: "rrr",
      ar: "ffs",
    },
    guestCount: 33,
    coverImage: {
      uuid: "673d1d2d-b9f5-466c-9006-780b7902176b.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/673d1d2d-b9f5-466c-9006-780b7902176b.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "f122f70e-b415-4777-b793-9ebd8eca86b6.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f122f70e-b415-4777-b793-9ebd8eca86b6.jpg",
      },
      {
        uuid: "cd7eb23a-92af-45b4-a0bf-365a1fdaf4b6.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/cd7eb23a-92af-45b4-a0bf-365a1fdaf4b6.jpg",
      },
      {
        uuid: "0424d1cd-2172-43af-b313-b730371f0d4e.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/0424d1cd-2172-43af-b313-b730371f0d4e.jpg",
      },
      {
        uuid: "b9749ec8-5f0a-4720-9f49-5bb82a2be95e.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b9749ec8-5f0a-4720-9f49-5bb82a2be95e.jpg",
      },
      {
        uuid: "2835ad49-d06c-458b-8441-74a5e0b23f7e.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/2835ad49-d06c-458b-8441-74a5e0b23f7e.jpg",
      },
      {
        uuid: "84444091-823b-4dcd-a50b-251abc441735.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/84444091-823b-4dcd-a50b-251abc441735.jpg",
      },
      {
        uuid: "67e6318c-0e47-4bc6-9666-3a82e34938f0.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/67e6318c-0e47-4bc6-9666-3a82e34938f0.jpg",
      },
      {
        uuid: "50e87aa1-762d-4f94-9848-a3bd27e65482.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/50e87aa1-762d-4f94-9848-a3bd27e65482.jpg",
      },
      {
        uuid: "33541817-9f01-4185-ad7e-9736bba6f5e1.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/33541817-9f01-4185-ad7e-9736bba6f5e1.jpg",
      },
      {
        uuid: "a6d67295-dd46-48bf-aea7-611e2e2bd33d.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/a6d67295-dd46-48bf-aea7-611e2e2bd33d.jpg",
      },
      {
        uuid: "c3bf803e-d492-40e2-bb6d-938e9d82d911.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/c3bf803e-d492-40e2-bb6d-938e9d82d911.jpg",
      },
      {
        uuid: "32892201-e09d-45d9-8120-db14dcbafca3.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/32892201-e09d-45d9-8120-db14dcbafca3.jpg",
      },
      {
        uuid: "5a428824-2e88-4c58-8c88-f28d83ceaa5d.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5a428824-2e88-4c58-8c88-f28d83ceaa5d.jpg",
      },
      {
        uuid: "63570476-908a-4e1e-a39e-ec38f6a52bf2.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/63570476-908a-4e1e-a39e-ec38f6a52bf2.jpg",
      },
      {
        uuid: "de36f6ab-fc88-4355-b416-b183db995670.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/de36f6ab-fc88-4355-b416-b183db995670.jpg",
      },
      {
        uuid: "f5eb7b75-ccb7-479d-be0c-4fc2ceba10ae.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f5eb7b75-ccb7-479d-be0c-4fc2ceba10ae.jpg",
      },
      {
        uuid: "b99c2df8-3211-49f2-8669-8b9147211a77.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/b99c2df8-3211-49f2-8669-8b9147211a77.jpg",
      },
      {
        uuid: "4a182fcc-9959-4db9-a9b8-426db98dab9e.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4a182fcc-9959-4db9-a9b8-426db98dab9e.jpg",
      },
      {
        uuid: "88010976-9505-46e1-a8a8-38522930fea7.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/88010976-9505-46e1-a8a8-38522930fea7.jpg",
      },
      {
        uuid: "d02a5968-b683-4c23-80f9-48a49cbb1477.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d02a5968-b683-4c23-80f9-48a49cbb1477.jpg",
      },
      {
        uuid: "6ca863a0-1ce9-4d4e-8894-74039b46f85d.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/6ca863a0-1ce9-4d4e-8894-74039b46f85d.jpg",
      },
      {
        uuid: "6aa69d57-8fdc-4506-853d-c6208965a845.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/6aa69d57-8fdc-4506-853d-c6208965a845.jpg",
      },
      {
        uuid: "30b40f9e-0a1d-4b75-ac4d-7cf5b8bf8581.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/30b40f9e-0a1d-4b75-ac4d-7cf5b8bf8581.jpg",
      },
      {
        uuid: "215ddc44-9ef0-463c-89f6-7ab5e7d82c24.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/215ddc44-9ef0-463c-89f6-7ab5e7d82c24.jpg",
      },
      {
        uuid: "18acd9c1-abb6-44d8-8517-7c97e6d502e4.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/18acd9c1-abb6-44d8-8517-7c97e6d502e4.jpg",
      },
      {
        uuid: "f93b545b-12ae-4c27-a7c0-d6d6a29134f6.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f93b545b-12ae-4c27-a7c0-d6d6a29134f6.jpg",
      },
      {
        uuid: "e1f387d0-7c01-4d30-871d-ec185063bd45.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/e1f387d0-7c01-4d30-871d-ec185063bd45.jpg",
      },
      {
        uuid: "d50ebaa2-4ba0-4b36-a89f-a095319d52dd.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d50ebaa2-4ba0-4b36-a89f-a095319d52dd.jpg",
      },
      {
        uuid: "f219aac0-3e1e-48e5-9248-045ab3f1ee4c.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f219aac0-3e1e-48e5-9248-045ab3f1ee4c.jpg",
      },
      {
        uuid: "f8a2e10e-e62f-4ca5-8eb2-b5468e605129.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f8a2e10e-e62f-4ca5-8eb2-b5468e605129.jpg",
      },
      {
        uuid: "4c3ff899-99b1-401a-9450-716d9a9660e1.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4c3ff899-99b1-401a-9450-716d9a9660e1.jpg",
      },
      {
        uuid: "1afd8487-628f-4500-82eb-2208914a2a75.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/1afd8487-628f-4500-82eb-2208914a2a75.jpg",
      },
      {
        uuid: "bab9676e-1fb4-4e67-9252-ddb2e7eb2858.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/bab9676e-1fb4-4e67-9252-ddb2e7eb2858.jpg",
      },
      {
        uuid: "7fa86ba5-e5fa-41b6-8187-e3b681e0877e.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/7fa86ba5-e5fa-41b6-8187-e3b681e0877e.jpg",
      },
      {
        uuid: "1a39d417-c4df-4e67-b7e0-ff752fddcbd3.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/1a39d417-c4df-4e67-b7e0-ff752fddcbd3.jpg",
      },
      {
        uuid: "ca64896e-12ee-4149-81f7-85816ac213b8.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/ca64896e-12ee-4149-81f7-85816ac213b8.jpg",
      },
      {
        uuid: "f3e10c47-bdbb-4b95-ac64-5e11c1b66354.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/f3e10c47-bdbb-4b95-ac64-5e11c1b66354.jpg",
      },
      {
        uuid: "360cd57e-8bf5-438d-8cf7-2be92d4716cb.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/360cd57e-8bf5-438d-8cf7-2be92d4716cb.jpg",
      },
      {
        uuid: "19d3bfa1-3d83-4c9e-b638-4b5662e138b3.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/19d3bfa1-3d83-4c9e-b638-4b5662e138b3.jpg",
      },
      {
        uuid: "5f7ba4fd-41b3-4721-9494-a99254d73268.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/5f7ba4fd-41b3-4721-9494-a99254d73268.jpg",
      },
      {
        uuid: "d36c3177-7cc6-44bf-b80b-e2e3369d1089.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/d36c3177-7cc6-44bf-b80b-e2e3369d1089.jpg",
      },
      {
        uuid: "4ccb9fee-decf-43c9-b128-ecb45b472399.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4ccb9fee-decf-43c9-b128-ecb45b472399.jpg",
      },
      {
        uuid: "721f0e02-02f7-4e3c-b613-768f832c7f50.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/721f0e02-02f7-4e3c-b613-768f832c7f50.jpg",
      },
      {
        uuid: "9509fa8a-f7d2-4936-98e5-664666117437.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9509fa8a-f7d2-4936-98e5-664666117437.jpg",
      },
      {
        uuid: "4c119b77-049e-4ad1-94c8-c99dcf5f66e5.jpg",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/4c119b77-049e-4ad1-94c8-c99dcf5f66e5.jpg",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "test",
      ar: "eeeeeee",
    },
    propertyType: "617252f1cd73fafd8c482105",
    building: "61e6a8904d86312cdc7dea85",
    bedType: "615fdbcc3d18f435ccb3cd97",
    price: 1,
    description: {
      en: "test",
      ar: "e",
    },
    guestCount: 8,
    coverImage: {
      uuid: "25c53435-d094-472b-8031-9f82a39d768b.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/25c53435-d094-472b-8031-9f82a39d768b.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
  {
    images: [
      {
        uuid: "898c5ef4-af23-4e60-a3be-c1abb2a473d9.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/898c5ef4-af23-4e60-a3be-c1abb2a473d9.png",
      },
      {
        uuid: "40586318-321a-41cf-b925-209ec585bbe9.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/40586318-321a-41cf-b925-209ec585bbe9.png",
      },
      {
        uuid: "261c9d84-0513-49c8-b1db-c689546eca84.png",
        imageUrl:
          "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/261c9d84-0513-49c8-b1db-c689546eca84.png",
      },
    ],
    amenities: ["619b80eaea0a4894dbeb1e6b"],
    valueAddedServices: ["615eb9b8fd5315d7911fa20f"],
    reviews: [],
    name: {
      en: "test",
      ar: "test",
    },
    propertyType: "617252e0cd73fafd8c480460",
    building: "61c1b76e3031396275ae0dc6",
    bedType: "615fdbd73d18f435ccb3e527",
    price: 56,
    description: {
      en: "test",
      ar: "test",
    },
    guestCount: 5,
    coverImage: {
      uuid: "9b2195cf-7dec-48b1-912f-b872344771d9.jpg",
      imageUrl:
        "https://hayyak-dev.s3.eu-north-1.amazonaws.com/images-properties/9b2195cf-7dec-48b1-912f-b872344771d9.jpg",
    },
    average: {
      overall: 0,
      five_star: 0,
      four_star: 0,
      three_star: 0,
      two_star: 0,
      one_star: 0,
    },
    isDeleted: false,
    __v: 0,
  },
];
