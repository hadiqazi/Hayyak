const seeder = require("mongoose-seed");
const { mongodb } = require("../config/keys");

const getSeedingData = async () => {
  try {
    return [
      {
        model: "building",
        documents: data,
      },
    ];
  } catch (err) {
    console.log("Error while seeding ", err);
    return [];
  }
};

seeder.connect(mongodb, function () {
  seeder.loadModels(["models/building.js"]);
  seeder.clearModels(["building"], async () => {
    seeder.populateModels(await getSeedingData(), function () {
      seeder.disconnect();
    });
  });
});

// Data array containing seed data - documents organized by Model
var data = [
  {
    name: {
      en: "Park Lane Hotel",
      ar: "فندق بارك لين",
    },
    description: {
      en: "good ",
      ar: "حسن",
    },
    location: {
      type: "Point",
      coordinates: [74.1943058, 31.4831569],
      _id: "61deb1b0f295c24df9d22fa3",
    },
    address: {
      en: "107 MM Alam Rd, Block B3 Block B 3 Gulberg III",
      ar: "107 ملم طريق علم ، بلوك B3 ، بلوك ب 3 ، جولبرج 3",
    },
    city: {
      en: "Lahore",
      ar: "لاهور",
    },
    state: {
      en: "Punjab ",
      ar: "البنجاب",
    },
    zip: "540024",
    country: {
      en: "Saudia Arabia",
      ar: "Saudia Arabia",
    },
    checkInTime: "00:00",
    checkOutTime: "21:46",
    isDeleted: false,
    __v: 0,
  },
  {
    name: {
      en: "Maisonette Hotels & Resorts",
      ar: "فنادق ومنتجعات ميزونيت",
    },
    description: {
      en: "luxurious",
      ar: "فاخر",
    },
    location: {
      type: "Point",
      coordinates: [74.4414880653182, 31.1185453643265],
      _id: "61e6aa5d4d86312cdc7debcf",
    },
    address: {
      en: "51-C2،, Ghalib Rd, Block C 2 Gulberg III, Lahore, Punjab",
      ar: "1-C2 ، طريق غالب ، بلوك سي 2 غولبرغ III ، لاهور ، البنجاب",
    },
    city: {
      en: " Lahore",
      ar: "لاهور",
    },
    state: {
      en: "Punjab",
      ar: "البنجاب",
    },
    zip: "54100",
    country: {
      en: "Saudia Arabia",
      ar: "Saudia Arabia",
    },
    checkInTime: "05:26",
    checkOutTime: "04:32",
    isDeleted: false,
    __v: 0,
  },
  {
    name: {
      en: "Hotel One",
      ar: "فندق وان",
    },
    description: {
      en: "comfortable",
      ar: "مريح",
    },
    location: {
      type: "Point",
      coordinates: [74.1943058, 31.4831569],
      _id: "61c1b8173031396275ae0de7",
    },
    address: {
      en: "A, Ali Kasuri 40, 2 Lajpat Rd, Lahore",
      ar: "أ ، علي قصوري 40 ، 2 طريق لاجبات ، لاهور",
    },
    city: {
      en: "Lahore",
      ar: "لاهور",
    },
    state: {
      en: "Punjab",
      ar: "البنجاب",
    },
    zip: "54002",
    country: {
      en: "Saudia Arabia",
      ar: "Saudia Arabia",
    },
    checkInTime: "07:30",
    checkOutTime: "05:29",
    isDeleted: false,
    __v: 0,
  },
  {
    name: {
      en: "Beverly Inn Hotel",
      ar: "فندق بيفرلي إن",
    },
    description: {
      en: "stay for holidays",
      ar: "البقاء لقضاء العطلات",
    },
    location: {
      type: "Point",
      coordinates: [74.1774517148503, 31.3711549930923],
      _id: "61c559f92031f43c133cf817",
    },
    address: {
      en: "Airport Road, near Metro Cash & Carry, Eden Avenue, Lahore, Punjab 54000",
      ar: "طريق المطار ، بالقرب من مترو كاش آند كاري ، شارع إيدن ، لاهور ، بنجاب",
    },
    city: {
      en: " Lahore",
      ar: "لاهور",
    },
    state: {
      en: " Punjab",
      ar: "بنجاب",
    },
    zip: "54000",
    country: {
      en: "Saudia Arabia",
      ar: "Saudia Arabia",
    },
    checkInTime: "03:21",
    checkOutTime: "17:26",
    isDeleted: false,
    __v: 0,
  },
  {
    name: {
      en: "New Haly tower",
      ar: "new",
    },
    description: {
      en: "business offices",
      ar: "business offices",
    },
    location: {
      type: "Point",
      coordinates: [74.4013415537968, 31.4754940698668],
      _id: "61cd69356eba28286a5c8a64",
    },
    address: {
      en: "dha phase 2",
      ar: "new",
    },
    city: {
      en: "lahore",
      ar: "nrw",
    },
    state: {
      en: "punjab",
      ar: "nre",
    },
    zip: "54000",
    country: {
      en: "Saudia Arabia",
      ar: "Saudia Arabia",
    },
    checkInTime: "00:00",
    checkOutTime: "20:40",
    isDeleted: false,
    __v: 0,
  },
  {
    name: {
      en: "test",
      ar: "www",
    },
    description: {
      en: "test",
      ar: "wwwwww",
    },
    location: {
      type: "Point",
      coordinates: [74.4606586629294, 31.1972250056199],
      _id: "61e6a8904d86312cdc7dea86",
    },
    address: {
      en: "test",
      ar: "ww",
    },
    city: {
      en: "est",
      ar: "ww",
    },
    state: {
      en: "test",
      ar: "ww",
    },
    zip: "63372",
    country: {
      en: "Saudia Arabia",
      ar: "Saudia Arabia",
    },
    checkInTime: "04:21",
    checkOutTime: "05:27",
    isDeleted: false,
    __v: 0,
  },
];
