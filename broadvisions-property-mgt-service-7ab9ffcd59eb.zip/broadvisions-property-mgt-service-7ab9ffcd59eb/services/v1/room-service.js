const { Room, Property } = require("../../models");
const _ = require("lodash");

class RoomService {
    async createRoom({ number, propertyId }) {
        try {
            const property = await Property.findById(propertyId)
            if (!property) {
                return Promise.reject({
                    status: 404,
                    messageCode: "property.not.found"
                })
            }

            return this.createRoomWithProperty({ number, property })

        } catch (error) {
            console.log(error)
            let status = 500;
            let messageCode = "server.error";

            if (error.name && error.name === "MongoError" && error.code === 11000) {
                messageCode = "room.duplicate";
                status = 409
            }

            return Promise.reject({
                status,
                messageCode,
                error,
            })
        }
    }

    async createRoomWithProperty({ number, property }) {
        let room = await Room.create({ number, property: property._id })

        let finalRoom = {...room._doc }
        finalRoom.propertyId = property._id
        delete finalRoom.property

        return {
            status: 201,
            message: __("room.create"),
            room: finalRoom
        }
    }

    async getRooms(propertyId) {
        try {
            let filter = propertyId ? { property: propertyId } : {}
            const rooms = await Room.find(filter)

            return {
                status: 200,
                message: __("roooms.found"),
                rooms
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    async updateRoom(id, data) {
        try {
            const room = await Room.findByIdAndUpdate(id, data, { new: true })
            if (!room)
                throw new Error()

            let finalRoom = {...room._doc }
            delete finalRoom.property

            return {
                status: 200,
                message: __("room.update"),
                room: finalRoom
            }
        } catch (error) {
            console.log(error)
            return {
                status: 404,
                message: __("room.not.found"),
            }
        }
    }

    async deleteRoom(id) {
        try {
            const room = await Room.findByIdAndRemove(id)
            if (!room)
                throw new Error()

            return {
                status: 200,
                message: __("room.delete"),
                room
            }
        } catch (error) {
            console.log(error)
            return {
                status: 404,
                message: __("room.not.found"),
            }
        }
    }
}

module.exports = new RoomService()