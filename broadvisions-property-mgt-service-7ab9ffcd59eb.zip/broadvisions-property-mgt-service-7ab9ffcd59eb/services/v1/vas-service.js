const ImageService = require("./image-service")
const { VAS, Property } = require("../../models");
const _ = require("lodash");

class VASService {
    async createValueAddedService({ name, price, description }, image) {
        try {
            // Upload image
            const uploadResult = await ImageService.uploadSingleImage(process.env.BUCKET_SERVICES, image)

            if (!uploadResult) {
                return Promise.reject({
                    status: 500,
                    messageCode: 'image.upload.failed',
                })
            }

            // Insert in DB
            const valueAddedService = await VAS.create({ name, price, description, image: uploadResult })

            return {
                status: 201,
                message: __("vas.create"),
                valueAddedService
            }
        } catch (error) {
            console.log(error)
            let status = 500;
            let messageCode = "server.error";

            if (error.name && error.name === "MongoError" && error.code === 11000) {
                messageCode = "vas.duplicate";
                status = 409
            }

            return Promise.reject({
                status,
                messageCode,
                error,
            })
        }
    }

    async getValueAddedServices(language) {
        try {
            const valueAddedServices = await VAS.findWithLanguage(language)

            return {
                status: 200,
                message: __("vas.found"),
                valueAddedServices
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    async updateValueAddedService(id, data, image) {
        try {
            const valueAddedService = await VAS.findById(id)
            if (!valueAddedService)
                throw new Error()

            if (image) {
                // Upload image
                const uploadResult = await ImageService.uploadSingleImage(process.env.BUCKET_SERVICES, image)

                if (!uploadResult) {
                    return Promise.reject({
                        status: 500,
                        messageCode: 'image.upload.failed',
                    })
                }

                // Delete the previous image
                await ImageService.deleteSingleImage(process.env.BUCKET_SERVICES, valueAddedService.image.uuid)

                data.image = uploadResult
            }

            // Update document in database
            const updatedVas = await VAS.findByIdAndUpdate(id, data, { new: true })

            return {
                status: 200,
                message: __("vas.update"),
                valueAddedService: updatedVas
            }
        } catch (error) {
            console.log(error)
            return {
                status: 404,
                message: __("vas.not.found"),
            }
        }
    }

    async deleteValueAddedService(id) {
        try {
            const valueAddedService = await VAS.findByIdAndRemove(id)
            if (!valueAddedService)
                throw new Error()
            
            await Property.updateMany({}, {$pull: {valueAddedServices: id}});

            // Delete the associated image
            await ImageService.deleteSingleImage(process.env.BUCKET_SERVICES, valueAddedService.image.uuid)

            return {
                status: 200,
                message: __("vas.delete"),
                valueAddedService
            }
        } catch (error) {
            console.log(error)
            return {
                status: 404,
                message: __("vas.not.found"),
            }
        }
    }

    getMultipleVas = async ({ids = []}) => {
        try {
            let vas = await VAS.find({
                _id: ids
            })
        
            return {
                status: 200,
                message: 'multiple.services.found',
                vas
            }

        } catch(error){
            console.log('Error ', error)
            return Promise.reject({
                status: 500,
                messageCode,
                error,
            })
        }
    }
}

module.exports = new VASService()