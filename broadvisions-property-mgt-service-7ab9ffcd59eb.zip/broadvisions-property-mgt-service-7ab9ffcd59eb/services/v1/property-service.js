const ImageService = require("./image-service")
const RoomService = require("./room-service")
const { Property, PropertyType, Building, BedType, Amenity, VAS, Rating } = require("../../models")
const _ = require("lodash")
const mongoose = require('mongoose')
const axios = require('../../utils/axios')
const JWT = require('../jwt.service')

class PropertyService {
    async createProperty({
        name,
        propertyTypeId,
        buildingId,
        bedTypeId,
        price,
        description,
        rooms,
        amenities,
        valueAddedServices,
        guestCount
    }, coverImage, images) {
        try {
            const [propertyType, building, bedType, amenitiesArray, vasArray] = await Promise.all([
                PropertyType.findById(propertyTypeId),
                Building.findOne({_id: buildingId, isDeleted: false}),
                BedType.findById(bedTypeId),
                Amenity.find({}, '_id').where('_id').in(amenities).exec(),
                VAS.find({}, '_id').where('_id').in(valueAddedServices).exec()
            ])

            let error;

            if (!propertyType) {
                error = 'property.type.not.found'
            }
            if (!building) {
                error = 'building.not.found'
            }
            if (!bedType) {
                error = 'bed.type.not.found'
            }
            if (error) {
                return Promise.reject({
                    status: 404,
                    messageCode: error
                })
            }

            let isExist = await Property.findOne({
                name,
                building: buildingId,
                isDeleted: false
            })
            if(isExist)
                return {
                    status: 400,
                    message: __("property.already.exist"),
                    property: isExist
                }


            // Upload images
            let hasImages = images && images.length > 0;
            let imagesUploadResult;

            const coverUploadResult = await ImageService.uploadSingleImage(process.env.BUCKET_PROPERTIES, coverImage)
            if (hasImages) {
                imagesUploadResult = await ImageService.uploadMultipleImages(process.env.BUCKET_PROPERTIES, images)
            }

            if (!coverUploadResult || (hasImages && !imagesUploadResult)) {
                return Promise.reject({
                    status: 500,
                    messageCode: 'image.upload.failed',
                })
            }

            const amenityIds = amenitiesArray ? amenitiesArray.map((amenity) => amenity._id) : []
            const vasIds = vasArray ? vasArray.map((vas) => vas._id) : []

     
            // Insert in DB
            let property = await Property.create({
                name,
                propertyType: propertyTypeId,
                building: buildingId,
                bedType: bedTypeId,
                price,
                description,
                guestCount,
                amenities: amenityIds,
                valueAddedServices: vasIds,
                coverImage: coverUploadResult,
                images: imagesUploadResult,
                average: {
                    overall: 0,
                    five_star: 0,
                    four_star: 0,
                    three_star: 0,
                    two_star: 0,
                    one_star: 0,
                }
            })

            // Insert all rooms
            let finalRooms = []
            for (const roomInfo of rooms) {
                try {
                    let response = await RoomService.createRoomWithProperty({ number: roomInfo.number, property })
                    if (response && response.status === 201) {
                        let room = response.room
                        delete room.propertyId
                        finalRooms.push(room)
                    }
                } catch (e) {
                    console.log(e)
                }
            }

            // Put objects in the response
            let finalProperty = {...property._doc };
            finalProperty.propertyType = propertyType
            finalProperty.building = building
            finalProperty.bedType = bedType
            finalProperty.rooms = finalRooms

            return {
                status: 201,
                message: __("property.create"),
                property: finalProperty
            }
        } catch (error) {
            console.log(error)
            let status = 500;
            let messageCode = "server.error";

            if (error.name && error.name === "MongoError" && error.code === 11000) {
                messageCode = "property.duplicate";
                status = 409
            }

            return Promise.reject({
                status,
                messageCode,
                error,
            })
        }
    }

    async getAllProperties(language, criteria = {}) {
        try {
            const properties = await Property.findWithLanguage(language, {...criteria, isDeleted: false})

            return {
                status: 200,
                message: __("properties.found"),
                properties
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    async getProperty(propertyId, language) {
        try {
            const properties = await Property.findWithLanguage(language, { _id: propertyId }, { populateRooms: true })
            let ratingCounts = {
                totalRatings: 0,
                totalReviews: 0,
                pendingReviews: 0,
            }

            let reviewProperty = await Property.findOne({_id: propertyId}).populate('reviews').exec()

            if(reviewProperty && reviewProperty.reviews) {
                reviewProperty.reviews.forEach((review) => {
                    ratingCounts['totalRatings'] = ratingCounts['totalRatings'] + 1
                    if(review.review.status === 'PENDING')
                        ratingCounts['pendingReviews'] = ratingCounts['pendingReviews'] + 1
                    if(review.review.comment)
                        ratingCounts['totalReviews'] = ratingCounts['totalReviews'] + 1
                })
            }

            if (properties.length > 0) {
                return {
                    status: 200,
                    message: __("property.found"),
                    property: {
                        ...properties[0],
                        ratingCounts
                    }
                }
            } else {
                return {
                    status: 400,
                    message: __("property.not.found"),
                }
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    async updateProperty(id, data, coverImage, images) {
        try {
            const property = await Property.findOne({_id: id, isDeleted: false})
            if (!property)
                return Promise.reject({
                    status: 404,
                    messageCode: 'property.not.found',
                });
                
            if(data && data.name) {
                let isNameExist = await Property.findOne({
                    name: data.name,
                    building: property.building,
                    isDeleted: false
                })

                if(isNameExist && !isNameExist._id.equals(id))
                    return {
                        status: 404,
                        message: __("property.name.already.exist"),
                    }
            }

            // Upload images
            let hasImages = images && images.length > 0;
            let coverUploadResult, imagesUploadResult;

            if (coverImage) {
                coverUploadResult = await ImageService.uploadSingleImage(process.env.BUCKET_PROPERTIES, coverImage)
            }
            if (hasImages) {
                imagesUploadResult = await ImageService.uploadMultipleImages(process.env.BUCKET_PROPERTIES, images)
            }

            if ((coverImage && !coverUploadResult) || (hasImages && !imagesUploadResult)) {
                return Promise.reject({
                    status: 500,
                    messageCode: 'image.upload.failed',
                })
            }

            // Aggregate the images to delete
            const hasDeletedImages = data.deletedImages && data.deletedImages.length > 0
            let toBeDeleted = []
            if (coverImage)
                toBeDeleted.push(property.coverImage.uuid)
            if (hasDeletedImages)
                toBeDeleted.push(...data.deletedImages)

            // Delete images
            await ImageService.deleteMultipleImages(process.env.BUCKET_PROPERTIES, toBeDeleted)

            // Update images in data
            if (coverImage) {
                // If coverImage was supplied, add coverUploadResult in data
                data.coverImage = coverUploadResult
            }

            let finalImages = [...property.images] || []
            if (hasDeletedImages) {
                // If deletedImages were supplied in data, remove deletedImages from property model
                finalImages = _.filter(finalImages, function(image) {
                    let keep = true
                    data.deletedImages.forEach(deleted => {
                        if (image.uuid === deleted) {
                            keep = false
                        }
                    });
                    return keep
                })
            }
            if (hasImages) {
                // If new images were supplied, add imagesUploadResult in property model
                finalImages.push(...imagesUploadResult)
            }

            // Update images array in the data
            data.images = finalImages

            // Update document in database
            const updatedProperty = await Property.findByIdAndUpdate(id, data, { new: true })

            return {
                status: 200,
                message: __("property.update"),
                property: updatedProperty
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    async deleteProperty(id) {
        try {
            // const property = await Property.findByIdAndRemove(id)
            const property = await Property.findById(id).populate('rooms').exec()
            if (!property)
                return Promise.reject({
                    status: 404,
                    messageCode: 'property.not.found',
                });

            // Delete the property
            const removeProperty = await Property.findByIdAndUpdate(id, {isDeleted: true}, { new: true })
            await Rating.updateMany({property: id}, {$set: {isDeleted: true}})
            // await property.remove()
            console.log('Property deleted.')

            // Delete the associated rooms
            // for (const room of property.rooms) {
            //     await RoomService.deleteRoom(room._id)
            //     console.log('Delete room with id: ', room._id)
            // }

            // Aggregate all associated images
            // let toBeDeleted = [property.coverImage.uuid]
            // if (property.images) {
            //     toBeDeleted.push(...property.images.map((image) => image.uuid))
            // }
            // Delete the associated images
            // await ImageService.deleteMultipleImages(process.env.BUCKET_SERVICES, toBeDeleted)

            return {
                status: 200,
                message: __("property.delete"),
                property: removeProperty
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    async getMultipleProperties({ids, attributes = [], populateRooms = false }, { language }) {
        try {
            let properties = await Property.findWithLanguage(language, {_id: ids}, {attributes, populateRooms});
            return {
                status: 200,
                message: __("property.found"),
                properties,
            };
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    async filter(
        {
          bedType,
          roomType,
          minPrice,
          maxPrice,
          amenities,
          coordinates,
          noOfRooms,
          checkIn,
          checkOut,
          vas,
          rating,
          noOfGuests,
          searchText
        },
        { language = "en" }, 
        { page = 1, sortOrder = 'DESC', sortColumn = "" },
      ) {
        try {
          const token = await JWT.createOwnJWT()
          let limit = +process.env.PAGE_LIMIT;
          let skip = limit * (page - 1);

          let accumArr = [];

          let sort = {createdAt: -1}
          if(sortColumn) {
              if(sortColumn === 'name') {
                  let str =   `name.${language}`;
                  sort = {[str]: sortOrder === 'ASC' ? 1 : -1}
              }
              else if(sortColumn === 'description') {
                if(sortColumn === 'description') {
                    let str =   `description.${language}`;
                    sort = {[str]: sortOrder === 'ASC' ? 1 : -1}
                }
              } else
                 sort = {[sortColumn]: sortOrder === 'ASC' ? 1 : -1}
          }

        //   let allVas = [];
          if(vas) vas.forEach((v) => accumArr.push({
              "valueAddedServices": v
          }))

        //   let allAmeneties = []
          if(amenities) amenities.forEach((am) => accumArr.push({
            "amenities": am
          }))

          let filters = [];
          if (bedType) filters.push({ bedType: bedType });
    
          if (roomType)
            filters.push({ propertyType: roomType });
            // filters.push({ "name.en": { $regex: ".*" + roomType + ".*" } });
    
          if ((minPrice || minPrice === 0) && maxPrice)
            filters.push({ price: { $gte: minPrice, $lte: maxPrice } });
    
        //   if (amenities) filters.push({ "$and": allAmeneties });
        //   if (amenities) filters.push({ amenities: { $in: amenities } });

          if(noOfGuests) filters.push({ guestCount: {$gte: noOfGuests}  });

          if(rating) filters.push({ "average.overall": {$gte: rating} });

        //   if(vas) filters.push({ valueAddedServices: {$in: vas} });
        //   if(vas) filters.push({ "$and": allVas });

          if(accumArr && accumArr.length > 0) filters.push({ "$and": accumArr });
    
          if(searchText) filters.push({ [`name.${language}`]: { $regex: ".*" + searchText + ".*" } });

          let updatedFilters = {};
          filters.forEach((filter) => updatedFilters = {...updatedFilters, ...filter})

          let search = { ...updatedFilters, isDeleted: false };


          let properties = await Property.findWithFilter(
            language,
            filters.length > 0 ? search : {isDeleted: false},
            { coordinates, noOfRooms },
            { populateRooms: true },
            {pagination: {skip, limit}, sort}
          );

          let filteredProperties = []
          let obj = {
            noOfRooms,
            properties,
            checkIn,
            checkOut
          }

          try {
              let filteredProperty = await axios.post(
                `${process.env.BOOKING_URL}/booking/property-filter`,
                // `${process.env.NOTIFICATION_BASE_URL}/v1/notification/custom-email`,
                JSON.stringify(obj),
                {
                  method: "POST",
                  headers: {
                    Accept: "application/json, text/plain, */*",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                  },
                }
              );

              const {data } = filteredProperty
              if(data && data.status == 200)
                filteredProperties = data.properties

          } catch(error){
              console.log('ERROR ', error)
              throw error;
          }


          let propertyCount = await Property.countDocuments(filters.length > 0 ? search : {isDeleted: false});
    
          return {
            status: 200,
            message: __("property.found"),
            properties: filteredProperties,
            pagination: {
                total: propertyCount,
                size: limit,
                page: +page,
              },
          };
        } catch (error) {
          console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
      }

    async getBookingCost ({propertyId, noOfRooms, services = []}, {language}) {
        try {
            const property = await Property.findWithLanguage(language, { _id: propertyId })

            if(property && property.length > 0) {

                if(services && services.length > 0) {
                    let servicesTotal = 0
                    let serviceArr = []
                    let servicesIds = [];
                    services.forEach((service) => servicesIds.push(service.id))
    
                    let all_value_service = await VAS.find({_id: servicesIds})
                    if(all_value_service && all_value_service.length > 0) {
                        all_value_service.forEach((service) => {
                            services.forEach((nestedService) => {
                                if(service._id == nestedService.id) {
                                    serviceArr.push({
                                        name: service.name[language],
                                        pice: service.price,
                                        quantity: nestedService.quantity,
                                        totalCost: service.price * nestedService.quantity,
                                    })
                                    servicesTotal = servicesTotal + service.price * nestedService.quantity
                                }
                            })
                        })
    
                    }
                    
                    return {
                        status: 200,
                        cost: {
                            noOfRooms,
                            roomCharges: property[0].price,
                            totalRoomCharges: noOfRooms * property[0].price,
                            serviceList: serviceArr,
                            servicesTotal,
                            total: servicesTotal + (noOfRooms * property[0].price)
                        },
                    }
                } else {
                    return {
                        status: 200,
                        cost: {
                            noOfRooms,
                            roomCharges: property[0].price,
                            totalRoomCharges: noOfRooms * property[0].price,
                            total: (noOfRooms * property[0].price)
                        },
                    }

                }

            }
            else return {
                status: 400,
                message: 'no.proeprty.found'
            }

        } catch(error){
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    getPropertiesAverage = async ({ date }) => {
        try {
            let response = {
                status: 200,
                avg: 0
            }

            let avg = await Rating.aggregate([
                { $match: { isDeleted: false, createdAt: { $gte: new Date(date) } } },
                {
                    $group: {
                        "_id": "_id",
                        avg:{$avg: "$rate"}
                    }
                }
            ])
            if(avg && avg.length > 0) {
                response.avg = parseFloat(avg[0].avg.toFixed(2))
            }

            // let avg = await Property.aggregate([
            // { $match: { createdAt: { $gte: new Date(date) } } },
            // {
            //     $group: {
            //         "_id": "_id",
            //         avg:{$avg: "$average.overall"}
            //     }
            // }])
            // if(avg && avg.length > 0) {
            //     response.avg = avg[0].avg.toFixed(2)
            // }
            return response
        } catch(error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    getPopularProperties = async ({days = 30, limit = 10}, {language}) => {
        try {
            let properties = [];
            let sortedProperties = [];
            const token = await JWT.createOwnJWT()

            console.log('DAYS OBJECT ', {
                days,
                limit
            })
            
            let bookings = await axios.post(
                `${process.env.BOOKING_URL}/booking/top-rated`,
                JSON.stringify({
                    days,
                    limit
                }),
                {
                  method: "POST",
                  headers: {
                    Accept: "application/json, text/plain, */*",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                  },
                }
              );

              const { data } = bookings;
              if(data && data.bookings && data.bookings.length > 0) {
                data.bookings.forEach((property) => {
                    properties.push(property._id)
                }) 
              }

              console.log('properties ', properties)

              let allProperties = await Property.findWithLanguage(language, {_id: properties});

              // TODO: This part need to be optimized

              if(allProperties && allProperties.length > 0) {
                properties.forEach((bookingProp) => {
                    allProperties.forEach((property) => {
                        if(property._id.equals(bookingProp))
                            sortedProperties.push(property)
                    })
                })}

              return {
                  status: 200,
                  body: sortedProperties
              }
        } catch(error){
            console.log(error)
            return Promise.reject({
                status: 500,
                message: "server.error",
                error,
            })
        }
    }
}

module.exports = new PropertyService()