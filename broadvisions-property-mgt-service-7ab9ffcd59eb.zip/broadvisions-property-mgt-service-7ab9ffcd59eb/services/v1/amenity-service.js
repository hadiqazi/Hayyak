const { Amenity, AmenityType, Property } = require("../../models");
const _ = require("lodash");

class AmenityService {
    async createAmenity({ name, typeId }) {
        try {
            const amenityType = await AmenityType.findById(typeId)
            if (!amenityType) {
                return Promise.reject({
                    status: 404,
                    messageCode: "amenity.type.not.found"
                })
            }

            let amenity = await Amenity.create({ name, amenityType: typeId })

            let finalAmenity = {...amenity._doc };
            finalAmenity.amenityType = amenityType

            return {
                status: 201,
                message: __("amenity.create"),
                amenity: finalAmenity
            }
        } catch (error) {
            console.log(error)
            let status = 500;
            let messageCode = "server.error";

            if (error.name && error.name === "MongoError" && error.code === 11000) {
                messageCode = "amenity.duplicate";
                status = 409
            }

            return Promise.reject({
                status,
                messageCode,
                error,
            })
        }
    }

    async getAllAmenities(language) {
        try {
            const amenities = await Amenity.findWithLanguage(language)

            return {
                status: 200,
                message: __("amenities.found"),
                amenities
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    async updateAmenity(id, data) {
        try {
            const amenity = await Amenity.findByIdAndUpdate(id, data, { new: true })
            if (!amenity)
                throw new Error()

            let finalAmenity = {...amenity._doc }
            delete finalAmenity.amenityType

            return {
                status: 200,
                message: __("amenity.update"),
                amenity: finalAmenity
            }
        } catch (error) {
            console.log(error)
            return {
                status: 404,
                message: __("amenity.not.found"),
            }
        }
    }

    async deleteAmenity(id) {
        try {
            const amenity = await Amenity.findByIdAndRemove(id)
            if (!amenity)
                throw new Error()

            await Property.updateMany({}, {$pull: {amenities: id}});

            return {
                status: 200,
                message: __("amenity.delete"),
                amenity
            }
        } catch (error) {
            console.log(error)
            return {
                status: 404,
                message: __("amenity.not.found"),
            }
        }
    }
}

module.exports = new AmenityService()