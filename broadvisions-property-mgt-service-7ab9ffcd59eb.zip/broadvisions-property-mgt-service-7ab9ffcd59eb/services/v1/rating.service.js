const { Rating, Building, Property } = require("../../models");
const axios = require("../../utils/axios");
const JWT = require("../jwt.service");

class RatingService {
  createRating = async ({
    rating,
    userId,
    comment = "",
    propertyId,
    bookingId,
  }) => {
    let response = {
      status: 409,
      message: "review.and.rating.already.exist",
    };

    let isDeleted = false;

    let status = "PENDING";
    if (!comment) status = "ACCEPT";

    let key = "";
    if (rating === 5) key = "five";
    if (rating === 4) key = "four";
    if (rating === 3) key = "three";
    if (rating === 2) key = "two";
    if (rating === 1) key = "one";

    const val = `average.${key}_star`;

    let property = await Property.findOne({
      _id: propertyId,
    })
      .select("building average isDeleted")
      .populate({
        path: "reviews",
        select: "review",
        match: {
          user: userId,
        },
        options: {
          limit: 1,
          sort: { createdAt: -1 },
        },
      });

    if (!property)
      return {
        status: 400,
        message: "no.property.exists",
      };

    if (property && property.reviews && property.reviews.length > 0)
      return response;

    if (property.isDeleted) isDeleted = true;

    let createRating = await Rating.create({
      rate: rating,
      user: userId,
      review: {
        status,
        comment,
      },
      building: property.building,
      property: propertyId,
      bookingId,
      isDeleted,
    });
    let avgRating = await this.calculateAverage({
      average: property.average,
      rating,
    });

    await Property.findOneAndUpdate(
      { _id: propertyId },
      {
        $push: { reviews: createRating._id },
        $inc: {
          [val]: 1,
        },
        "average.overall": avgRating,
      }
    );

    return {
      status: 200,
      message: "rating.created",
      rating: createRating,
    };
  };

  fetchMultipleUsers = async (ids) => {
    try {
      const token = await JWT.createOwnJWT();
      let multiUsers = await axios.post(
        `${process.env.USER_URL}/user/multiple-user`,
        JSON.stringify({ ids }),
        {
          method: "POST",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const { data } = multiUsers;

      if (data && data.status == 200) return data.users;
      else return false;
    } catch (error) {
      return false;
    }
  };

  filterRating = async ({
    page = 1,
    language,
    filter = {},
    populateUsers = false,
  }) => {
    let limit = +process.env.PAGE_LIMIT;
    let skip = limit * (page - 1);
    let ratingsUpdate = [];

    let ratings = await Rating.find(
      {
        ...filter,
      },
      [],
      { skip, limit }
    )
      .populate("building", "_id name")
      .populate("property", "_id name coverImage")
      .exec();

    if (language) {
      ratings.forEach((rating) => {
        ratingsUpdate.push({
          ...rating.toObject(),
          property: {
            _id: rating.property._id,
            name: rating.property.name[language],
            coverImage: rating.property.coverImage,
          },
          building: {
            _id: rating.building._id,
            name: rating.building.name[language],
          },
        });
      });
    } else
      ratings.forEach((rating) => ratingsUpdate.push({ ...rating.toObject() }));

    if (populateUsers) {
      let ids = [];
      let tempArr = [];
      ratingsUpdate.forEach((rating) => {
        ids.push(rating.user);
      });
      let uniqueIds = [...new Set(ids)];

      let users = await this.fetchMultipleUsers(uniqueIds);

      if (users) {
        ratingsUpdate.forEach((rating) => {
          users.forEach((user) => {
            if (rating.user === user._id) {
              const { firstName, profileImage = "", _id } = user;
              tempArr.push({
                ...rating,
                user: { _id, firstName, profileImage },
              });
            }
          });
        });
      }
      ratingsUpdate = tempArr;
    }

    let count = await Rating.countDocuments(filter);

    return {
      status: 200,
      message: "rating.filtered",
      ratings: ratingsUpdate,
      pagination: {
        total: count,
        size: limit,
        page: +page,
      },
    };
  };

  filterRatingAdmin = async (
    { page = 1 },
    { status, propertyId, buildingId },
    { language }
  ) => {
    try {
      let filter = {
        "review.comment": { $ne: "" },
        isDeleted: false,
      };

      if (status) filter["review.status"] = status;
      if (propertyId) filter["property"] = propertyId;

      if (buildingId && !propertyId) {
        let properties = await Property.find({ building: buildingId });
        if (properties && properties.length > 0) {
          let ids = [];
          properties.forEach((property) => {
            ids.push(property._id);
          });

          filter["property"] = { $in: ids };
        } else
          return {
            status: 200,
            message: "no.properties.exists",
            ratings: [],
          };
      }

      console.log('FILTER ', filter)

      let rev = await this.filterRating({
        page,
        language,
        filter,
        populateUsers: true,
      });

      return rev;
    } catch (error) {
      console.log("error ", error);
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  };

  filterRatingCustomer = async (
    { page = 1 },
    { propertyId, bookingId, userId },
    { language = "en" }
  ) => {
    try {
      let filter = {
        user: userId,
        isDeleted: false,
      };
      let populateUser = false;

      if (bookingId) {
        filter["bookingId"] = bookingId;
        delete filter["isDeleted"];
      }

      if (propertyId) {
        filter["property"] = propertyId;
        filter["review.comment"] = { $ne: "" };
        filter["review.status"] = "ACCEPT";
        delete filter["user"];
        populateUser = true;
      }

      let rev = await this.filterRating({
        page,
        language,
        filter,
        populateUsers: populateUser,
      });

      return rev;
    } catch (error) {
      console.log("error ", error);
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  };

  statusRating = async ({ status }, { id }) => {
    let ratings = await Rating.findByIdAndUpdate(
      {
        _id: id,
      },
      { "review.status": status },
      { new: true }
    );

    return {
      status: 200,
      message: "rating.status.updated",
      ratings,
    };
  };

  calculateAverage = async ({ average, rating }) => {
    let sum = 0;
    let totalReviews = 0;

    sum =
      sum +
      (rating === 5 ? average["five_star"] + 1 : average["five_star"]) * 5;

    sum =
      sum +
      (rating === 4 ? average["four_star"] + 1 : average["four_star"]) * 4;

    sum =
      sum +
      (rating === 3 ? average["three_star"] + 1 : average["three_star"] * 3);

    sum =
      sum + (rating === 2 ? average["two_star"] + 1 : average["two_star"] * 2);

    sum =
      sum + (rating === 1 ? average["one_star"] + 1 : average["one_star"] * 1);

    totalReviews =
      totalReviews +
      (rating === 5 ? average["five_star"] + 1 : average["five_star"]) +
      (rating === 4 ? average["four_star"] + 1 : average["four_star"]) +
      (rating === 3 ? average["three_star"] + 1 : average["three_star"]) +
      (rating === 2 ? average["two_star"] + 1 : average["two_star"]) +
      (rating === 1 ? average["one_star"] + 1 : average["one_star"]);

    let avg = sum / totalReviews;

    return avg;
  };

  reviewLookUp = async ({ userId, propertyId }, { language }) => {
    try {
      let property = await Property.findOne({
        _id: propertyId,
      })
        .select("_id name coverImage building")
        .populate({
          path: "reviews",
          match: {
            user: userId,
          },
          options: {
            limit: 1,
            sort: { createdAt: -1 },
          },
        });

      if (property && property.reviews && property.reviews.length === 0) {
        return {
          status: 200,
          response: {
            propertyId: property._id,
            name: property.name[language],
            coverImage: property.coverImage,
            buildingId: property.building,
          },
        };
      }

      return {
        status: 200,
        response: null,
      };
    } catch (error) {
      console.log("ERROR ", error);
      return {
        status: 400,
        message: "error.in.booking",
      };
    }
  };

  getKeyValueForRating = (rating) => {
    if (rating) {
      let key = "";
      if (rating === 5) key = "five";
      if (rating === 4) key = "four";
      if (rating === 3) key = "three";
      if (rating === 2) key = "two";
      if (rating === 1) key = "one";

      const val = `average.${key}_star`;
      return val;
    }
    return null;
  };

  updatePropertyRating = async ({
    propertyId,
    rating,
    avg = null,
    isAdd = true,
  }) => {
    try {
      let res = this.getKeyValueForRating(rating);
      if (res) {
        let updateObj = {
          $inc: {
            [res]: isAdd ? 1 : -1,
          },
        };

        if (avg !== null) updateObj["average.overall"] = avg;

        if (res)
          await Property.findOneAndUpdate({ _id: propertyId }, updateObj);
        return true;
      }
      return false;
    } catch (error) {
      console.log("ERR ", error);
      throw "Error while updating property avg";
    }
  };

  updateRating = async ({ rating, review = "", userId }, { id }) => {
    try {
      let update = {};

      let prevRating = await Rating.findOne({ _id: id });

      if (!prevRating)
        return {
          status: 401,
          message: "no.rating.exist",
        };

      if (rating) update["rate"] = rating;
      update.review = {
        comment: "",
        status: "ACCEPT",
      };

      if (review) {
        update.review["comment"] = review;
        update.review["status"] = prevRating.review.status;
        if (prevRating.review.comment !== review)
          update.review["status"] = "PENDING";
      }

      if (prevRating) {
        let updatRating = await Rating.findOneAndUpdate(
          { _id: id, user: userId },
          update,
          { new: true }
        );

        if (!updatRating)
          return {
            status: 401,
            message: "Unauthorised",
            rating: null,
          };

        if (rating) {
          // Removing previous rating
          await this.updatePropertyRating({
            rating: prevRating.rate,
            isAdd: false,
            propertyId: prevRating.property,
          });

          // Adding new rating
          let property = await Property.findOne({ _id: prevRating.property });
          let avg = await this.calculateAverage({
            average: property.average,
            rating,
          });

          await this.updatePropertyRating({
            rating: rating,
            propertyId: prevRating.property,
            isAdd: true,
            avg,
          });
        }

        return {
          status: 200,
          message: "rating.updated",
          rating: updatRating,
        };
      }

      return {
        status: 404,
        message: "no.rating.found",
        rating: null,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  };
}

module.exports = new RatingService();
