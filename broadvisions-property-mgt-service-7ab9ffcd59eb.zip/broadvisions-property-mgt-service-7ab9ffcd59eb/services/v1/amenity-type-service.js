const AmenityType = require("../../models").AmenityType;
const _ = require("lodash");

class AmenityTypeService {
    async getAllAmenityTypes(language) {
        try {
            const amenityTypes = await AmenityType.findWithLanguage(language)

            return {
                status: 200,
                message: __("amenity.types.found"),
                amenityTypes
            }
        } catch (error) {
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }
}

module.exports = new AmenityTypeService()