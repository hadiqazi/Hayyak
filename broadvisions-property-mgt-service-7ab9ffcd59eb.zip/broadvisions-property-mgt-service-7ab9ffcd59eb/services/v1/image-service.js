const _ = require("lodash");
const S3Service = require("./s3-service");

class ImageService {
    async uploadSingleImage(imageType, image) {
        try {
            let uploadedImage = await S3Service.uploadFileOnS3(imageType, image);
            console.log("Uploaded image", uploadedImage);

            if (uploadedImage.status === 200) {
                return {
                    uuid: uploadedImage.uuid,
                    imageUrl: uploadedImage.file_url
                }
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            });
        }
    }

    async uploadMultipleImages(imageType, images) {
        try {
            let uploadList = []
            images.forEach(image => {
                uploadList.push(this.uploadSingleImage(imageType, image))
            })

            const uploadedList = await Promise.all(uploadList)
            return uploadedList

        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            });
        }
    }

    async deleteSingleImage(imageType, imageUuid) {
        try {
            let result = await S3Service.deleteFileFromS3(imageType, imageUuid)
            console.log("Deleted image", result);

            if (result.status === 200) {
                return {
                    status: result.status,
                    message: "Image deleted",
                    uuid: result.uuid
                }
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            });
        }
    }

    async deleteMultipleImages(imageType, imageIds) {
        try {
            let result = await S3Service.deleteFilesFromS3(imageType, imageIds)
            console.log("Deleted images", result);

            if (result.status === 200) {
                return {
                    status: result.status,
                    message: "Image deleted",
                    uuid: result.uuid
                }
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            });
        }
    }
}

module.exports = new ImageService()