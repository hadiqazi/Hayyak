const { Building, Property, Rating } = require("../../models");
const _ = require("lodash");

class BuildingService {
    async createBuilding(data) {
        try {

            let isExist = await Building.findOne({
                name: data.name,
                isDeleted: false
            })

            if(isExist)
                return {
                    status: 400,
                    message: __("building.already.exist"),
                    building: isExist
                }

            const building = await Building.create({
                name: data.name,
                description: data.description,
                location: data.location,
                address: data.address,
                city: data.city,
                state: data.state,
                zip: data.zip,
                country: data.country,
                checkInTime: data.checkInTime,
                checkOutTime: data.checkOutTime
            })

            return {
                status: 201,
                message: __("building.create"),
                building
            }
        } catch (error) {
            console.log(error)
            let status = 500;
            let messageCode = "server.error";

            if (error.name && error.name === "MongoError" && error.code === 11000) {
                messageCode = "building.duplicate";
                status = 409
            }

            return Promise.reject({
                status,
                messageCode,
                error,
            })
        }
    }

    async getBuildings(language) {
        try {
            const buildings = await Building.findWithLanguage(language, {isDeleted: false})

            return {
                status: 200,
                message: __("buildings.found"),
                buildings
            }
        } catch (error) {
            console.log(error)
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }

    async updateBuilding(id, data) {
        try {

            let isExist = await Building.findOne({
                _id: id,
                isDeleted: true
            })

            if(isExist)
                return {
                    status: 400,
                    message: __("building.not.found"),
                }

            if(data && data.name) {
                let isNameExist = await Building.findOne({
                    name: data.name,
                    isDeleted: false
                })

                if(isNameExist && !isNameExist._id.equals(id))
                    return {
                        status: 400,
                        message: __("building.name.already.exist"),
                    }
            }

            const building = await Building.findByIdAndUpdate(id, data, { new: true })
            if (!building)
                throw new Error()

            return {
                status: 200,
                message: __("building.update"),
                building
            }
        } catch (error) {
            console.log(error)
            return {
                status: 404,
                message: __("building.not.found"),
            }
        }
    }

    async deleteBuilding(id) {
        try {
            const building = await Building.findByIdAndUpdate(id, {isDeleted: true}, { new: true })
            if (!building)
                throw new Error()
            // Removing All Related Properties
            await Property.updateMany({building: id}, {$set: {isDeleted: true}})
            await Rating.updateMany({building: id}, {$set: {isDeleted: true}})
            return {
                status: 200,
                message: __("building.delete"),
                building
            }
        } catch (error) {
            console.log(error)
            return {
                status: 404,
                message: __("building.not.found"),
            }
        }
    }
}

module.exports = new BuildingService()