const BedType = require("../../models").BedType;
const _ = require("lodash");

class BedTypeService {
    async getAllBedTypes(language) {
        try {
            const bedTypes = await BedType.findWithLanguage(language)

            return {
                status: 200,
                message: __("bed.types.found"),
                bedTypes
            }
        } catch (error) {
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }
}

module.exports = new BedTypeService()