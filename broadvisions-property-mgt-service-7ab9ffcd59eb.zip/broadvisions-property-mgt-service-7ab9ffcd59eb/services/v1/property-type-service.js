const PropertyType = require("../../models").PropertyType;
const _ = require("lodash");

class PropertyTypeService {
    async getAllPropertyTypes(language) {
        try {
            const propertyTypes = await PropertyType.findWithLanguage(language)

            return {
                status: 200,
                message: __("property.types.found"),
                propertyTypes
            }
        } catch (error) {
            return Promise.reject({
                status: 500,
                messageCode: "server.error",
                error,
            })
        }
    }
}

module.exports = new PropertyTypeService()