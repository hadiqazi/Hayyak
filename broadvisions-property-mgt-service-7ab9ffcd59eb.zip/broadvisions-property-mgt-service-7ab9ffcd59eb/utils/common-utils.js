const _ = require('lodash');
const multer = require('multer');

const GENERAL_ERROR_CODE = "server.error";
const BAD_REQ_ERROR_CODE = "bad.request";

const handleRouteError = (resp) => {
    return (error) => {
        logErrorDetails(error);

        if (isBadRequestError(error)) {
            sendBadRequestResponse(error, resp);
        } else {
            sendGeneralErrorResponse(resp);
        }
    };
};

const logErrorDetails = (error) => {
    console.error(error);
};

const isBadRequestError = (error) => {
    return !_.isEmpty(error) && _.isFinite(error.status) && error.status >= 400 && error.status < 500;
};

const sendBadRequestResponse = (error, resp) => {
    const messageCode = _.isEmpty(error.messageCode) ? BAD_REQ_ERROR_CODE : error.messageCode;
    resp.status(error.status).send({ status: error.status, message: __(messageCode), error });
    // resp.status(error.status).send({status: error.status, message: 'BAD_REQUEST', error});
};

const sendGeneralErrorResponse = (resp) => {
    // resp.status(500).send({status: 500, message: resp.__(GENERAL_ERROR_CODE)});
    resp.status(500).send({ status: 500, message: 'GENERAL_ERROR' });
};

const upload = multer({
    storage: multer.memoryStorage(),
    fileFilter: (req, file, cb) => {
        if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            cb(null, false);
            return cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
        }
    }
});

module.exports = {
    handleRouteError,
    multer: upload
};