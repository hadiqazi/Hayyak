const seeder = require("mongoose-seed");
const { mongodb } = require("../config/keys");

const getSeedingData = async () => {
  try {
    return [
      {
        model: "permission",
        documents: data,
      },
    ];
  } catch (err) {
    console.log("Error while seeding ", err);
    return [];
  }
};

seeder.connect(mongodb, function () {
  seeder.loadModels(["models/permission.js"]);
  seeder.clearModels(["permission"], async () => {
    seeder.populateModels(await getSeedingData(), function () {
      seeder.disconnect();
    });
  });
});

// Data array containing seed data - documents organized by Model
var data = [
  {
    _id: "618e1e729403d02665fe53e2",
    name: "Customer",
    authText: "CUSTOMER",
  },
  {
    _id: "61e657a1d7aa550595d93ba8",
    name: "Create Amenity",
    authText: "CREATE_AMENITY",
  },
  {
    _id: "61e657bdd7aa550595d93baa",
    name: "Update Amenity",
    authText: "UPDATE_AMENITY",
  },
  {
    _id: "61e657d5d7aa550595d93bac",
    name: "Read Amenity",
    authText: "READ_AMENITY",
  },
  {
    _id: "61e657fad7aa550595d93bae",
    name: "Delete Amenity",
    authText: "DELETE_AMENITY",
  },
  {
    _id: "61e6586dd7aa550595d93bb0",
    name: "Read Amenity Type",
    authText: "READ_AMENITY_TYPE",
  },
  {
    _id: "61e65891d7aa550595d93bb2",
    name: "Read Bed Type",
    authText: "READ_BED_TYPE",
  },
  {
    _id: "61e658add7aa550595d93bb4",
    name: "Create Building",
    authText: "CREATE_BUILDING",
  },
  {
    _id: "61e658c2d7aa550595d93bb6",
    name: "Update Building",
    authText: "UPDATE_BUILDING",
  },
  {
    _id: "61e658d8d7aa550595d93bb8",
    name: "Read Building",
    authText: "READ_BUILDING",
  },
  {
    _id: "61e658ebd7aa550595d93bba",
    name: "Delete Building",
    authText: "DELETE_BUILDING",
  },
  {
    _id: "61e65935d7aa550595d93bbc",
    name: "Get All Types",
    authText: "READ_ALL_TYPES",
  },
  {
    _id: "61e6594ad7aa550595d93bbe",
    name: "Read Property Type",
    authText: "READ_PROPERTY_TYPE",
  },
  {
    _id: "61e6599fd7aa550595d93bc0",
    name: "Create VAS",
    authText: "CREATE_VAS",
  },
  {
    _id: "61e659b2d7aa550595d93bc2",
    name: "Update VAS",
    authText: "UPDATE_VAS",
  },
  {
    _id: "61e659c6d7aa550595d93bc4",
    name: "Read VAS",
    authText: "READ_VAS",
  },
  {
    _id: "61e659d8d7aa550595d93bc6",
    name: "Delete VAS",
    authText: "DELETE_VAS",
  },
  {
    _id: "61e659f0d7aa550595d93bc8",
    name: "Multiple VAS",
    authText: "READ_MULTIPLE_VAS",
  },
  {
    _id: "61e65a02d7aa550595d93bca",
    name: "Create Room",
    authText: "CREATE_ROOM",
  },
  {
    _id: "61e65a13d7aa550595d93bcc",
    name: "Update Room",
    authText: "UPDATE_ROOM",
  },
  {
    _id: "61e65a23d7aa550595d93bce",
    name: "Read Room",
    authText: "READ_ROOM",
  },
  {
    _id: "61e65a36d7aa550595d93bd0",
    name: "Delete Room",
    authText: "DELETE_ROOM",
  },
  {
    _id: "61e65ddbd7aa550595d93bd2",
    name: "Filter Rating",
    authText: "FILTER_RATING",
  },
  {
    _id: "61e65defd7aa550595d93bd4",
    name: "Read Rating By Status",
    authText: "STATUS_RATING",
  },
  {
    _id: "61e65e02d7aa550595d93bd6",
    name: "Create Property",
    authText: "CREATE_PROPERTY",
  },
  {
    _id: "61e65e13d7aa550595d93bd8",
    name: "Read Property",
    authText: "READ_PROPERTY",
  },
  {
    _id: "61e65e23d7aa550595d93bda",
    name: "Read Single Property",
    authText: "READ_SINGLE_PROPERTY",
  },
  {
    _id: "61e65e34d7aa550595d93bdc",
    name: "Update Property",
    authText: "UPDATE_PROPERTY",
  },
  {
    _id: "61e65e45d7aa550595d93bde",
    name: "Delete Property",
    authText: "DELETE_PROPERTY",
  },
  {
    _id: "61e65e5bd7aa550595d93be0",
    name: "Filter Property",
    authText: "FILTER_PROPERTY",
  },
  {
    _id: "61e65ebcd7aa550595d93be2",
    name: "Create Permission",
    authText: "CREATE_PERMISSION",
  },
  {
    _id: "61e65ecdd7aa550595d93be4",
    name: "Read Permission",
    authText: "READ_PERMISSION",
  },
  {
    _id: "61e65eded7aa550595d93be6",
    name: "Update Permission",
    authText: "UPDATE_PERMISSION",
  },
  {
    _id: "61e65ef1d7aa550595d93be8",
    name: "Delete Permission",
    authText: "DELETE_PERMISSION",
  },
  {
    _id: "61e65f03d7aa550595d93bea",
    name: "Create Role",
    authText: "CREATE_ROLE",
  },
  {
    _id: "61e65f18d7aa550595d93bec",
    name: "Read Role",
    authText: "READ_ROLE",
  },
  {
    _id: "61e65f2ad7aa550595d93bee",
    name: "Update Role",
    authText: "UPDATE_ROLE",
  },
  {
    _id: "61e65f3bd7aa550595d93bf0",
    name: "Read Single Role",
    authText: "READ_SINGLE_ROLE",
  },
  {
    _id: "61e65f4cd7aa550595d93bf2",
    name: "Delete Role",
    authText: "DELETE_ROLE",
  },
  {
    _id: "61e65f5ed7aa550595d93bf4",
    name: "Create Admin",
    authText: "CREATE_ADMIN",
  },
  {
    _id: "61e65f6fd7aa550595d93bf6",
    name: "Read Admin",
    authText: "READ_ADMIN",
  },
  {
    _id: "61e65f7ed7aa550595d93bf8",
    name: "Update Admin",
    authText: "UPDATE_ADMIN",
  },
  {
    _id: "61e65f8dd7aa550595d93bfa",
    name: "Delete Admin",
    authText: "DELETE_ADMIN",
  },
  {
    _id: "61e65f9fd7aa550595d93bfc",
    name: "Read Booking",
    authText: "READ_BOOKING",
  },
  {
    _id: "61e65fb5d7aa550595d93bfe",
    name: "Detail Booking",
    authText: "DETAIL_BOOKING",
  },
  {
    _id: "61e65fc7d7aa550595d93c00",
    name: "Cancel Booking",
    authText: "CANCEL_BOOKING",
  },
  {
    _id: "61e69fbc43e64325ae6e38c7",
    name: "Filter Booking",
    authText: "FILTER_BOOKING",
  },
];
