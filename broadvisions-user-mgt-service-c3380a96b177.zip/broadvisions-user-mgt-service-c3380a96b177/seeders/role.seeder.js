const seeder = require("mongoose-seed");
const { mongodb } = require("../config/keys");

const getSeedingData = async () => {
  try {
    return [
      {
        model: "role",
        documents: data,
      },
    ];
  } catch (err) {
    console.log("Error while seeding ", err);
    return [];
  }
};

seeder.connect(mongodb, function () {
  seeder.loadModels(["models/role.js"]);
  seeder.clearModels(["role"], async () => {
    seeder.populateModels(await getSeedingData(), function () {
      seeder.disconnect();
    });
  });
});

// Data array containing seed data - documents organized by Model
var data = [
  {
    _id : "6197415ab17c8366129532dc",
    permissions : [ 
        "61e65ebcd7aa550595d93be2", 
        "61e65ecdd7aa550595d93be4", 
        "61e65eded7aa550595d93be6", 
        "61e65ef1d7aa550595d93be8", 
        "61e65f03d7aa550595d93bea", 
        "61e65f18d7aa550595d93bec", 
        "61e65f2ad7aa550595d93bee", 
        "61e65f3bd7aa550595d93bf0", 
        "61e65f4cd7aa550595d93bf2", 
        "61e65f5ed7aa550595d93bf4", 
        "61e65f6fd7aa550595d93bf6", 
        "61e65f7ed7aa550595d93bf8", 
        "61e65f8dd7aa550595d93bfa", 
        "61e65f9fd7aa550595d93bfc", 
        "61e65fb5d7aa550595d93bfe", 
        "61e65fc7d7aa550595d93c00", 
        "61e657a1d7aa550595d93ba8", 
        "61e657bdd7aa550595d93baa", 
        "61e657d5d7aa550595d93bac", 
        "61e657fad7aa550595d93bae", 
        "61e6586dd7aa550595d93bb0", 
        "61e65891d7aa550595d93bb2", 
        "61e658add7aa550595d93bb4", 
        "61e658c2d7aa550595d93bb6", 
        "61e658d8d7aa550595d93bb8", 
        "61e658ebd7aa550595d93bba", 
        "61e65935d7aa550595d93bbc", 
        "61e6594ad7aa550595d93bbe", 
        "61e6599fd7aa550595d93bc0", 
        "61e659b2d7aa550595d93bc2", 
        "61e659c6d7aa550595d93bc4", 
        "61e659d8d7aa550595d93bc6", 
        "61e659f0d7aa550595d93bc8", 
        "61e65a02d7aa550595d93bca", 
        "61e65a13d7aa550595d93bcc", 
        "61e65a23d7aa550595d93bce", 
        "61e65a36d7aa550595d93bd0", 
        "61e65ddbd7aa550595d93bd2", 
        "61e65defd7aa550595d93bd4", 
        "61e65e02d7aa550595d93bd6", 
        "61e65e13d7aa550595d93bd8", 
        "61e65e23d7aa550595d93bda", 
        "61e65e34d7aa550595d93bdc", 
        "61e65e45d7aa550595d93bde", 
        "61e65e5bd7aa550595d93be0", 
        "61e69fbc43e64325ae6e38c7", 
        "6213369ed3d9d17d56d6271f", 
        "62133fb2d3d9d17d56d6273d"
    ],
    name : "Platform Admin",
    roleText : "PLATFORM_ADMIN",
  },
  {
    _id : "61c1a309a06f336231b34975",
    permissions : [ 
      "618e1e729403d02665fe53e2"
    ],
    name : "Customer",
    roleText : "CUSTOMER"
  }
];