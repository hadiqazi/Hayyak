const seeder = require("mongoose-seed");
const { mongodb } = require("../config/keys");

const getSeedingData = async () => {
  try {
    return [
      {
        model: "admin",
        documents: data,
      },
    ];
  } catch (err) {
    console.log("Error while seeding ", err);
    return [];
  }
};

seeder.connect(mongodb, function () {
  seeder.loadModels(["models/admin.js"]);
  seeder.clearModels(["admin"], async () => {
    seeder.populateModels(await getSeedingData(), function () {
      seeder.disconnect();
    });
  });
});

// Data array containing seed data - documents organized by Model
var data = [
  {
    type: "ADMIN",
    firstName: "Hayyak",
    lastName: "Admin",
    email: "hayyak@dev.co",
    password: "$2b$10$OgKNKRmBv0xcuGftlFz7zeoZvzXZec9vy4T8Km0OWSfZegIbQKkra",
    role: "6197415ab17c8366129532dc",
    isActive: true,
    __v: 0,
  },
  {
    type: "ADMIN",
    firstName: "Twos",
    lastName: "Too",
    email: "saad.shahid@broadvisions.neta",
    password: "$2b$10$xDBK85VQ7kDhw2YWFQ53WuyCnxtkLLk2BayehRZ46HJPG.pFyNsfe",
    role: "6197415ab17c8366129532dc",
    isActive: true,
    __v: 0,
  },
  {
    type: "ADMIN",
    firstName: "Two",
    lastName: "Too",
    email: "hayyak@dev.coabcd",
    password: "$2b$10$96roBMYjFs.Txx0CVlCHqeXbCNj5mGucP66/M0ip9QO8HusktMdky",
    role: "6197415ab17c8366129532dc",
    isActive: true,
    __v: 0,
  },
  {
    type: "ADMIN",
    firstName: "Shahzaib",
    lastName: "saimss",
    email: "shahzasub123@gmail.com",
    password: "$2b$10$p.SVmxg0GSGfS7pckosr2O3SqCqjF4ZXwnjhIe717EcJyloFZC.tm",
    role: "61c1a309a06f336231b34975",
    isActive: true,
    __v: 0,
  },
  {
    type: "ADMIN",
    firstName: "test",
    lastName: "test2",
    email: "test@test.com",
    password: "$2b$10$k4LHG0wRe7BkuyJsXAGLaOsfmaBygSzqexOzAazFoLoREMHkvQTyW",
    role: "6197415ab17c8366129532dc",
    isActive: true,
    __v: 0,
  },
  {
    type: "ADMIN",
    firstName: "Saaad",
    lastName: "Shahid",
    email: "saad.shahid@broadvisions.net",
    password: "$2b$10$TFTWXytnj1aL46iO6YmFfuZxq6LOXNpmkkAn8I3bGoPiNavIbzyLy",
    role: "6197415ab17c8366129532dc",
    isActive: true,
    __v: 0,
  },
];
