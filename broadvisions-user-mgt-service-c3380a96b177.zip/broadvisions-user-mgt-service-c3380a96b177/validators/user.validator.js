const Joi = require("joi");

class UserValidator {
  create() {
    return Joi.object({
      name: Joi.string().required(),
      email: Joi.string().required(),
      password: Joi.string().required(),
      phone: Joi.string().required(),
      emailOTP: Joi.string().required(),
      phoneOTP: Joi.string().required(),
    });
  }

  remove() {
    return Joi.object({
      id: Joi.string().required(),
    });
  }

  update() {
    return Joi.object({
      id: Joi.string().required(),
      name: Joi.string(),
      role: Joi.string(),
      language: Joi.string(),
      country: Joi.string(),
      dateOfBirth: Joi.string()
    });
  }

  updatePassword() {
    return Joi.object({
      oldPassword: Joi.string().required(),
      newPassword: Joi.string().required(),
    });
  }

  password() {
    return Joi.object({
      email: Joi.string().required(),
    });
  }

  fetchMultiple() {
    return Joi.object({
      ids: Joi.array().required(),
    });
  }

  lookup() {
    return Joi.object({
      userId: Joi.string().required(),
    });
  }
}

module.exports = new UserValidator();
