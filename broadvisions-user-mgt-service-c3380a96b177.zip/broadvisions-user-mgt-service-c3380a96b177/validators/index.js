const PermissionValidator = require("./permission-validator");
const RoleValidator = require("./role-validator");
const AdminValidator = require("./admin-validator");
const AuthValidator = require("./auth-validator");
const UserValidator = require("./user.validator");
const VerificationValidator = require("./verification-validator");

module.exports = {
  PermissionValidator,
  RoleValidator,
  AdminValidator,
  AuthValidator,
  UserValidator,
  VerificationValidator,
};
