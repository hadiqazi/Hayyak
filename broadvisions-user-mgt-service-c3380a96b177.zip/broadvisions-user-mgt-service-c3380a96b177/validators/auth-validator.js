const Joi = require("joi");

class AuthValidator {
  loginAdmin() {
    return Joi.object({
      email: Joi.string().required(),
      password: Joi.string().required(),
    });
  }

  loginAdminOtp() {
    return Joi.object({
      email: Joi.string().required(),
      otp: Joi.string().required(),
    });
  }

  loginUser() {
    return Joi.object({
      email: Joi.string().required(),
      password: Joi.string().required(),
    });
  }

  passwordTemplate() {
    return Joi.object({
      language: Joi.string().valid("en", "ar").required(),
      token: Joi.string().required(),
    });
  }

  signupUser() {
    return Joi.object({
      name: Joi.string().required(),
      email: Joi.string().required(),
      password: Joi.string().required(),
      phone: Joi.string().required(),
      emailOTP: Joi.string().required(),
      phoneOTP: Joi.string().required(),
      language: Joi.string().required(),
    });
  }

  socialSignup() {
    return Joi.object({
      type: Joi.string().valid("GOOGLE", "FACEBOOK", "APPLE").required(),
      token: Joi.string().required(),
      name: Joi.string().required(),
      phone: Joi.string().required(),
      language: Joi.string().required(),
      emailOTP: Joi.string().required(),
      phoneOTP: Joi.string().required(),
    });
  }

  socialSignin() {
    return Joi.object({
      type: Joi.string().valid("GOOGLE", "FACEBOOK", "APPLE").required(),
      token: Joi.string().required(),
    });
  }
}

module.exports = new AuthValidator();
