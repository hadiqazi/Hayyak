const Joi = require("joi");

class VerificationValidator {
  request() {
    return Joi.object({
      email: Joi.string().required(),
      phone: Joi.string().required(),
    });
  }

  verify() {
    return Joi.object({
      email: Joi.string().required(),
      phone: Joi.string().required(),
      emailOTP: Joi.number().required(),
      phoneOTP: Joi.number().required(),
    });
  }
}

module.exports = new VerificationValidator();
