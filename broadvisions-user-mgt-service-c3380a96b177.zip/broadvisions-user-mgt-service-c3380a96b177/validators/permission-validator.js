const Joi = require("joi");

class PermissionValidator {
  create() {
    return Joi.object({
      name: Joi.string().required(),
      authText: Joi.string().required(),
    });
  }

  remove() {
    return Joi.object({
      id: Joi.string().required(),
    });
  }

  update() {
    return Joi.object({
      id: Joi.string().required(),
      name: Joi.string(),
      authText: Joi.string(),
    });
  }
}

module.exports = new PermissionValidator();
