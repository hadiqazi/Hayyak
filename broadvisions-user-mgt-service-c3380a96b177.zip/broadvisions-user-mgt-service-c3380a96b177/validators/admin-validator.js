const Joi = require("joi");

class AdminValidator {
  create() {
    return Joi.object({
      firstName: Joi.string(),
      lastName: Joi.string().required(),
      email: Joi.string().required(),
      phone: Joi.string().required(),
      role: Joi.string().required(),
    });
  }

  remove() {
    return Joi.object({
      id: Joi.string().required(),
    });
  }

  updatePassword() {
    return Joi.object({
      email: Joi.string().required(),
    });
  }

  update() {
    return Joi.object({
      id: Joi.string().required(),
      firstName: Joi.string(),
      lastName: Joi.string(),
      email: Joi.string(),
      phone: Joi.string(),
      role: Joi.string(),
      isActive: Joi.boolean(),
    });
  }
}

module.exports = new AdminValidator();
