const Joi = require("joi");

class RoleValidator {
  create() {
    return Joi.object({
      name: Joi.string().required(),
      roleText: Joi.string().required(),
      permissions: Joi.array().required().items(Joi.string()),
    });
  }

  remove() {
    return Joi.object({
      id: Joi.string().required(),
    });
  }

  update() {
    return Joi.object({
      id: Joi.string().required(),
      name: Joi.string().required(),
      roleText: Joi.string().required(),
      permissions: Joi.array().required().items(Joi.string()),
    });
  }
}

module.exports = new RoleValidator();
