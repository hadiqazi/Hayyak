const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { RoleService } = require("../../../services/v1");
const { RoleValidator } = require("../../../validators");
const { authenticate } = require("../../middlewares/auth");

router.post("/", authenticate("CREATE_ROLE"), async (req, resp) => {
  try {
    await RoleValidator.create().validateAsync(req.body);
    RoleService.createRole(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.put("/:id", authenticate("UPDATE_ROLE"), async (req, resp) => {
  try {
    await RoleValidator.update().validateAsync({
      ...req.body,
      ...req.params,
    });
    RoleService.updateRole(req.params, req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.get("/", authenticate("READ_ROLE"), async (req, resp) => {
  try {
    RoleService.getAllRoles()
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.get("/:roleId", authenticate("READ_SINGLE_ROLE"), async (req, resp) => {
  try {
    RoleService.getSingleRole(req.params.roleId)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.delete("/:id", authenticate("DELETE_ROLE"), async (req, resp) => {
  try {
    await RoleValidator.remove().validateAsync(req.params);
    RoleService.deleteRole(req.params)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

module.exports = router;
