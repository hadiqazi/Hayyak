const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { UserService } = require("../../../services/v1");
const { UserValidator } = require("../../../validators");
const { authenticate } = require("../../middlewares/auth");
const { authenticatePassword } = require("../../middlewares/password-auth");
const multer = require('multer')

// router.post("/", async (req, resp) => {
//   try {
//     await UserValidator.create().validateAsync(req.body);
//     UserService.createUser(req.body)
//       .then((result) => {
//         resp.status(result.status).send(result);
//       })
//       .catch(handleRouteError(resp));
//   } catch (error) {
//     handleRouteError(resp)({
//       status: 403,
//       message: __("mandatory.fields"),
//       error,
//     });
//   }
// });

router.put("/:id", authenticate("UPDATE_USER,CUSTOMER"), multer({ storage: multer.memoryStorage() }).single('profileImage'), async (req, resp) => {
  try {
    await UserValidator.update().validateAsync({
      ...req.body,
      ...req.params,
    });
    UserService.updateUser(req.params, req.body, req)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.get("/", authenticate("READ_USER"), async (req, resp) => {
  try {
    UserService.getAllUsers()
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.delete("/:id", authenticate("DELETE_USER"), async (req, resp) => {
  try {
    await UserValidator.remove().validateAsync(req.params);
    UserService.deleteUser(req.params)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post(
  "/reset-password",
  authenticate("RESET_PASSWORD_USER,CUSTOMER"),
  async (req, resp) => {
    try {
      const {
        jwt: { user },
      } = req;

      await UserValidator.updatePassword().validateAsync(req.body);
      UserService.resetPassword({
        id: user._id,
        ...req.body,
        language: user.language
      })
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.get(
  "/lookup",
  authenticate("LOOKUP_USER,CUSTOMER"),
  async (req, resp) => {
    try {
      const {
        jwt: { user },
      } = req;

      await UserValidator.lookup().validateAsync({
        userId: user._id,
      });
      UserService.lookup({ userId: user._id }, req.headers)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.post("/update-password-user", async (req, resp) => {
  try {
    await UserValidator.password().validateAsync(req.body);
    UserService.updatePassword(req.body, req.headers)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post(
  "/password-patch-user",
  authenticatePassword(""),
  async (req, resp) => {
    try {
      // await UserValidator.password().validateAsync(req.body);
      const { jwt } = req;
      UserService.passwordPatch(jwt, req.body)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.post("/multiple-user", authenticate("IS_SERVICE"), async (req, resp) => {
  try {
    await UserValidator.fetchMultiple().validateAsync(req.body);
    UserService.getMultipleUsers(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

module.exports = router;
