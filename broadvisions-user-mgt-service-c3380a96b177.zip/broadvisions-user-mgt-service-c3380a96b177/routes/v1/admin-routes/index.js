const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { AdminService } = require("../../../services/v1");
const { AdminValidator } = require("../../../validators");
const { authenticate } = require("../../middlewares/auth");
const { authenticatePassword } = require("../../middlewares/password-auth");

router.post("/", authenticate("CREATE_ADMIN"), async (req, resp) => {
  try {
    await AdminValidator.create().validateAsync(req.body);
    AdminService.createAdmin(req.body, req.headers)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.put("/:id", authenticate("UPDATE_ADMIN"), async (req, resp) => {
  try {
    await AdminValidator.update().validateAsync({
      ...req.body,
      ...req.params,
    });
    AdminService.updateAdmin(req.params, req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.get("/", authenticate("READ_ADMIN"), async (req, resp) => {
  try {
    AdminService.getAllAdmins()
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.delete("/:id", authenticate("DELETE_ADMIN"), async (req, resp) => {
  try {
    await AdminValidator.remove().validateAsync(req.params);
    AdminService.deleteAdmin(req.params)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/update-password-admin", async (req, resp) => {
  try {
    await AdminValidator.updatePassword().validateAsync(req.body);
    AdminService.updatePassword(req.body, req.headers)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post(
  "/password-patch-admin",
  authenticatePassword(""),
  async (req, resp) => {
    try {
      // await UserValidator.password().validateAsync(req.body);
      const { jwt } = req;
      AdminService.passwordPatch(jwt, req.body)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

module.exports = router;
