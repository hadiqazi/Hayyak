// const _ = require('lodash');
const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { PermissionService } = require("../../../services/v1");
const { PermissionValidator } = require("../../../validators");
const { authenticate } = require("../../middlewares/auth");

router.post("/", authenticate("CREATE_PERMISSION"), async (req, resp) => {
  try {
    await PermissionValidator.create().validateAsync(req.body);
    PermissionService.createPermission(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.put("/:id", authenticate("UPDATE_PERMISSION"), async (req, resp) => {
  try {
    await PermissionValidator.update().validateAsync({
      ...req.body,
      ...req.params,
    });
    PermissionService.updatePermission(req.params, req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.get("/", authenticate("READ_PERMISSION"), async (req, resp) => {
  try {
    PermissionService.getAllPermissions()
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.delete("/:id", authenticate("DELETE_PERMISSION"), async (req, resp) => {
  try {
    await PermissionValidator.remove().validateAsync(req.params);
    PermissionService.deletePermission(req.params)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

module.exports = router;
