const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { AuthService } = require("../../../services/v1");
const { AuthValidator } = require("../../../validators");

router.post("/signup-user", async (req, resp) => {
  try {
    await AuthValidator.signupUser().validateAsync(req.body);
    AuthService.signupUser(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/login-admin-otp", async (req, resp) => {
  try {
    await AuthValidator.loginAdminOtp().validateAsync(req.body);
    AuthService.loginAdminOtp(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/login-admin", async (req, resp) => {
  try {
    await AuthValidator.loginAdmin().validateAsync(req.body);
    AuthService.loginAdmin(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/login-user", async (req, resp) => {
  try {
    await AuthValidator.loginUser().validateAsync(req.body);
    AuthService.loginUser(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.get("/reset-password-template", async (req, resp) => {
  try {
    await AuthValidator.passwordTemplate().validateAsync(req.query);
    let body = await AuthService.getResetPasswordTemplate(req.query);
    resp.send(body);
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/social-signup", async (req, resp) => {
  try {
    await AuthValidator.socialSignup().validateAsync(req.body);
    AuthService.socialSignup(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/social-signin", async (req, resp) => {
  try {
    await AuthValidator.socialSignin().validateAsync(req.body);
    AuthService.socialSignin(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

module.exports = router;
