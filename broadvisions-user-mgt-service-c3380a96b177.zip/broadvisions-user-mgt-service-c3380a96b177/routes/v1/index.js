const { Router } = require("express");

const permissionRoutes = require("./permission-routes");
const roleRoutes = require("./role-routes");
const adminRoutes = require("./admin-routes");
const authRoutes = require("./auth-routes");
const userRoutes = require("./user-routes");
const verificationRoutes = require("./verification-routes");

const setup = (app) => {
  const router = Router();

  router.use("/permission", permissionRoutes);
  router.use("/role", roleRoutes);
  router.use("/admin", adminRoutes);
  router.use("/auth", authRoutes);
  router.use("/user", userRoutes);
  router.use("/otp", verificationRoutes);

  // this should be the last line
  app.use("/v1", router);
};

module.exports = setup;
