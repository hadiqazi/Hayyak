const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const { VerificationService } = require("../../../services/v1");
const { VerificationValidator } = require("../../../validators");

router.post("/request", async (req, resp) => {
  try {
    await VerificationValidator.request().validateAsync(req.body);
    VerificationService.requestOtp(req.body, req.headers)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/verify", async (req, resp) => {
  try {
    await VerificationValidator.verify().validateAsync(req.body);
    VerificationService.verifyOtp(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

module.exports = router;
