const Admin = require("../../models").Admin;
const EmailService = require("./email.service");
const _ = require("lodash");
const { generateEncryptedPassword } = require("../../utils/common-utils");
const JWT = require("../jwt.service");

class AdminService {
  async getAllAdmins() {
    try {
      let admins = await Admin.find({}).select("-password").populate("role");

      return {
        status: 200,
        message: __("admins.found"),
        admins,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async getAdminsWithPassword(where) {
    try {
      let admin = await Admin.findOne(where).populate("role");
      if (!admin) return null;

      return {
        status: 200,
        message: __("admins.found"),
        admin,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async createAdmin({ firstName, lastName, email, phone, role }, { language }) {
    try {
      let password = await generateEncryptedPassword({});

      let admn = await Admin.findOne({ $or: [{ email }, { phone }] });
      if (admn)
        return {
          messageCode: "admin.duplicate",
          status: 409,
        };

      console.log(password);
      let admin = await Admin.create({
        firstName,
        lastName,
        email,
        phone,
        password: password.encrypt,
        role,
      });

      delete admin._doc.password;

      let sent = await EmailService.sendEmail({
        language: "en",
        obj: {
          action: "ADMIN_WELCOME",
          data: {
            to: email,
            password: password.decrypt,
            url: process.env.ADMIN_URL,
          },
        },
      });

      return {
        status: 200,
        message: __("admin.create"),
        admin,
      };
    } catch (error) {
      let status = 500;
      let messageCode = "server.error";

      if (error.name && error.name === "MongoError") {
        if (error.code === 11000) {
          messageCode = "admin.duplicate";
          status = 409;
        }
      }

      return Promise.reject({
        status,
        messageCode,
        error,
      });
    }
  }

  async deleteAdmin({ id }) {
    try {
      let admin = await Admin.findByIdAndRemove(id);
      return {
        status: 200,
        message: __("admin.delete"),
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async updateAdmin({ id }, req) {
    try {
      let pass = null;
      const { password } = req;
      if (password) {
        pass = await generateEncryptedPassword({ password: password });
      }

      let admin = await Admin.findByIdAndUpdate(
        id,
        pass ? { ...req, password: pass.encrypt } : req,
        { new: true }
      );

      delete admin._doc.password;

      return {
        status: 200,
        message: __("admin.update"),
        admin,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async updatePassword({ email }, { language }) {
    try {
      let admin = await Admin.findOne({ email });

      if (!admin)
        return {
          status: 400,
          message: "admin.not.found",
        };

      let token = await JWT.returnJWT({
        id: admin._id,
        role: "ADMIN",
      });

      let sent = await EmailService.sendEmail({
        language,
        obj: {
          action: "RESET_PASSWORD",
          data: {
            token: token,
            to: email,
            url: `${process.env.BASE_URL}/hayyak-user-service/v1/auth/reset-password-template`,
          },
        },
      });

      return {
        status: 200,
        response: sent,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async passwordPatch({ id }, { password }) {
    try {
      if (id) {
        let pass = await generateEncryptedPassword({ password: password });
        let admin = await Admin.findByIdAndUpdate(
          id,
          { password: pass.encrypt },
          { new: true }
        ).populate("role");

        if (admin)
          return {
            status: 200,
            message: "updated",
          };
      }

      return {
        status: 400,
        message: "not.updated",
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }
}

module.exports = new AdminService();
