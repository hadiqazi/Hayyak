const AdminService = require("./admin-service");
const UserService = require("./user.service");
const VerificationService = require("./verification.service");
const EmailService = require("./email.service");
const _ = require("lodash");
const bcrypt = require("bcrypt");
const JWTService = require("../jwt.service");
const Role = require("../../models").Role;
const User = require("../../models").User;
const path = require("path");
const { generateEncryptedPassword } = require("../../utils/common-utils");
const axios = require("../../utils/axios");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const qs = require("qs");
const jwt_decode = require("jwt-decode");

class AuthService {
  async signupUser({
    type = "EMAIL",
    name,
    email,
    phone = "123456",
    password = "",
    emailOTP,
    phoneOTP,
    language = "en",
    picture = "",
  }) {
    try {
      let pass = null;

      let userExist = await User.findOne({ email });
      if (userExist)
        return {
          status: 403,
          message: "user.already.exists",
        };

      let verification = await VerificationService.verifyOtp({
        email,
        phone,
        emailOTP,
        phoneOTP,
      });

      if (!verification)
        return {
          status: 400,
          message: __("OTPS.not.verified"),
        };

      pass = await generateEncryptedPassword({ password });

      let getRole = await Role.findOne({
        roleText: "CUSTOMER",
      });

      if (!getRole)
        return {
          status: 400,
          message: __("no.role.found"),
        };

      let nameParse = name.split(" ");

      let user = await User.create({
        loginType: type,
        firstName: nameParse[0],
        lastName: nameParse.length > 1 ? nameParse[1] : null,
        email,
        password: pass.encrypt,
        phone,
        language,
        isActive: true,
        isVerified: false,
        isDeleted: false,
        role: getRole._doc._id,
        profileImage: picture === "" ? null : picture,
      });

      let loginUser = await this.loginUser({
        email,
        password,
        isSocialMedia: type,
      });

      EmailService.sendEmail({
        language,
        obj: {
          action: "WELCOME_USER",
          data: {
            to: email,
          },
        },
      });

      return loginUser;

      // return {
      //   status: 200,
      //   message: __("user.create"),
      //   user: loginUser,
      // };
    } catch (error) {
      console.log("ERROR ", error);
      let status = 500;
      let message = "server.error";

      if (error.name && error.name === "MongoError") {
        if (error.code === 11000) {
          message = "user.duplicate";
          status = 409;
        }
      }

      return Promise.reject({
        status,
        message,
        error,
      });
    }
  }

  async loginUser({
    email,
    password,
    isSocialMedia = "EMAIL",
    refreshToken = null,
  }) {
    try {
      let userResult = await UserService.getUserWithPassword({ email });

      if (!userResult) {
        if (isSocialMedia === "EMAIL")
          return {
            status: 401,
            message: "invalid.credentials",
          };
        if (isSocialMedia === "APPLE")
          return {
            status: 404,
            message: "user.not.found",
            refreshToken,
          };

        return {
          status: 404,
          message: "user.not.found",
        };
      }

      if (isSocialMedia === "EMAIL") {
        let passwordResult = bcrypt.compareSync(
          password,
          userResult.user.password
        );
        if (!passwordResult) {
          return Promise.reject({
            status: 401,
            message: "invalid.credentials",
          });
        }
      }

      if (isSocialMedia !== "EMAIL") {
        if (userResult.user.loginType !== isSocialMedia)
          return {
            status: 999,
            message: "social.login.mismatch",
          };
      }

      let roles = [];
      let permissions = [];

      for (let permission of userResult.user.role.permissions) {
        permissions.push(permission.authText);
      }
      roles.push(userResult.user.role.roleText);

      delete userResult.user._doc.password;
      delete userResult.user._doc.role;

      let tokenData = {
        user: userResult.user,
        roles,
        permissions,
      };

      let token = await JWTService.returnJWT(tokenData);

      return {
        status: 200,
        message: __("user.created.login"),
        token,
        ...tokenData,
      };
    } catch (error) {
      console.log("error ", error);
      return Promise.reject({
        status: 500,
        message: "server.error",
        error,
      });
    }
  }

  async loginAdmin({ email, password }) {
    try {
      let adminResult = await AdminService.getAdminsWithPassword({ email });
      if (!adminResult)
        return {
          status: 401,
          message: "invalid.credentials",
        };

      if (!adminResult.admin.isActive)
        return {
          status: 401,
          message: "Your account has been disabled.",
        };

      let passwordResult = bcrypt.compareSync(
        password,
        adminResult.admin.password
      );
      if (!passwordResult) {
        return Promise.reject({
          status: 401,
          message: "invalid.credentials",
        });
      }

      let otp = await VerificationService.requestAdminOtp({
        phone: adminResult.admin.phone,
      });

      if (otp)
        return {
          status: 200,
          message: "otp.generated.successfully",
          otp,
        };

      return {
        status: 400,
        message: "failed.to.generate.otp",
      };

      // let roles = [];
      // let permissions = [];

      // for (let permission of adminResult.admin.role.permissions) {
      //   permissions.push(permission.authText);
      // }
      // roles.push(adminResult.admin.role.roleText);

      // delete adminResult.admin._doc.password;
      // delete adminResult.admin._doc.role;

      // let tokenData = {
      //   admin: adminResult.admin,
      //   roles,
      //   permissions,
      // };

      // let token = await JWTService.returnJWT({
      //   user: adminResult.admin,
      //   roles,
      //   permissions,
      // });
      // return {
      //   status: 200,
      //   message: __("admin.login.successfully"),
      //   token,
      //   ...tokenData,
      // };
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "server.error",
        error,
      });
    }
  }

  async loginAdminOtp({ email, otp }) {
    try {
      let adminResult = await AdminService.getAdminsWithPassword({ email });
      if (!adminResult)
        return {
          status: 401,
          message: "invalid.credentials",
        };

      let verifyOtp = await VerificationService.verifyAdminOtp({
        phone: adminResult.admin.phone,
        otp,
      });

      if (verifyOtp) {
        let roles = [];
        let permissions = [];

        for (let permission of adminResult.admin.role.permissions) {
          permissions.push(permission.authText);
        }
        roles.push(adminResult.admin.role.roleText);

        delete adminResult.admin._doc.password;
        delete adminResult.admin._doc.role;

        let tokenData = {
          admin: adminResult.admin,
          roles,
          permissions,
        };

        let token = await JWTService.returnJWT({
          user: adminResult.admin,
          roles,
          permissions,
        });
        return {
          status: 200,
          message: __("admin.login.successfully"),
          token,
          ...tokenData,
        };
      }

      return {
        status: 401,
        message: "invalid.otp",
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "server.error",
        error,
      });
    }
  }

  async getResetPasswordTemplate({ language = "en", token }) {
    try {
      let jwtData = jwt.decode(token);
      const template = `../../utils/templates/password_reset_${language}.html`;
      let html = fs.readFileSync(path.join(__dirname, "/", template), "utf8");

      if (jwtData.role === "USER")
        html = html.replace(
          "##BASE_URL##",
          `${process.env.BASE_URL}/hayyak-user-service/v1/user/password-patch-user`
        );
      else if (jwtData.role === "ADMIN")
        html = html.replace(
          "##BASE_URL##",
          `${process.env.BASE_URL}/hayyak-user-service/v1/admin/password-patch-admin`
        );

      html = html.replace("##TOKEN##", `Bearer ${token}`);

      return html;
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "server.error",
        error,
      });
    }
  }

  getGmailAccessTokenInfo = async ({ token }) => {
    try {
      let userInfo = await axios.get(
        `https://www.googleapis.com/oauth2/v2/userinfo`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (userInfo && userInfo.data) {
        return {
          email: userInfo.data.email,
          picture: userInfo.data.picture,
        };
      }

      return null;
    } catch (error) {
      console.log("ERROR ", error);
      return null;
    }
  };

  getFacebookAccessTokenInfo = async ({ token }) => {
    try {
      let userInfo = await axios.get(
        `https://graph.facebook.com/me?fields=id,email,first_name,last_name,picture&access_token=${token}`,
        {
          method: "GET",
          headers: {},
        }
      );
      if (userInfo && userInfo.data) {
        return {
          email: userInfo.data.email,
          picture: userInfo.data.picture.data.url,
        };
      }

      return null;
    } catch (error) {
      console.log("ERROR ", error);
      return null;
    }
  };

  getAppleInfoViaToken = async ({ token }) => {
    try {
      let data = qs.stringify({
        client_id: process.env.APPLE_CLIENT_ID,
        client_secret: process.env.APPLE_CLIENT_SECRET,
        code: token,
        grant_type: "authorization_code",
      });

      let userInfo = await axios.post(
        "https://appleid.apple.com/auth/token",
        data,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      if (userInfo && userInfo.data) {
        let decode = jwt_decode(userInfo.data.id_token);
        return {
          email: decode.email,
          picture: "",
          refreshToken: userInfo.data.refresh_token,
        };
      }

      return null;
    } catch (error) {
      console.log("ERROR ", error);
      return null;
    }
  };

  getAppleInfoViaTokenRefresh = async ({ token }) => {
    try {
      let data = qs.stringify({
        client_id: process.env.APPLE_CLIENT_ID,
        client_secret: process.env.APPLE_CLIENT_SECRET,
        refresh_token: token,
        grant_type: "refresh_token",
      });

      let userInfo = await axios.post(
        "https://appleid.apple.com/auth/token",
        data,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      if (userInfo && userInfo.data) {
        let decode = jwt_decode(userInfo.data.id_token);
        return {
          email: decode.email,
          picture: "",
          refreshToken: userInfo.data.refresh_token,
        };
      }

      return null;
    } catch (error) {
      console.log("ERROR ", error);
      return null;
    }
  };

  socialSignup = async ({
    type,
    token,
    name,
    phone,
    emailOTP,
    phoneOTP,
    language,
  }) => {
    try {
      let res = null;
      if (type === "GOOGLE") {
        res = await this.getGmailAccessTokenInfo({ token });
      } else if (type === "FACEBOOK") {
        res = await this.getFacebookAccessTokenInfo({ token });
      } else if (type === "APPLE") {
        res = await this.getAppleInfoViaTokenRefresh({ token });
        console.log("RES ", res);
      }

      if (!res)
        return {
          status: 404,
          message: "user.authorization.failed",
        };

      res = await this.signupUser({
        name,
        email: res.email,
        phone,
        language,
        type,
        emailOTP,
        phoneOTP,
        picture: res.picture,
      });

      return res;
    } catch (error) {
      console.log("ERRROR ", error);
      return Promise.reject({
        status: 500,
        message: "server.error",
        error,
      });
    }
  };

  socialSignin = async ({ type, token }) => {
    try {
      let res = null;
      if (type === "GOOGLE") {
        res = await this.getGmailAccessTokenInfo({ token });
      } else if (type === "FACEBOOK") {
        res = await this.getFacebookAccessTokenInfo({ token });
      } else if (type === "APPLE") {
        res = await this.getAppleInfoViaToken({ token });
        console.log("RES ", res);
      }

      if (!res)
        return {
          status: 404,
          message: "user.authorization.failed",
        };

      res = await this.loginUser({
        email: res.email,
        isSocialMedia: type,
        refreshToken: res.refreshToken,
      });
      return res;
    } catch (error) {
      console.log("ERRROR ", error);
      return Promise.reject({
        status: 500,
        message: "server.error",
        error,
      });
    }
  };
}

module.exports = new AuthService();
