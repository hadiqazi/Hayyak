const Permission = require("../../models").Permission;
const Role = require("../../models").Role;
const _ = require("lodash");

class PermissionService {
  async getAllPermissions() {
    try {
      let permissions = await Permission.find({});

      return {
        status: 200,
        message: __("permissions.found"),
        permissions,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async createPermission({ name, authText }) {
    try {
      let permission = await Permission.create({
        name,
        authText,
      });

      return {
        status: 200,
        message: __("permissions.create"),
        permission,
      };
    } catch (error) {
      let status = 500;
      let messageCode = "server.error";

      if (error.name && error.name === "MongoError") {
        if (error.code === 11000) {
          messageCode = "permissions.duplicate";
          status = 409;
        }
      }

      return Promise.reject({
        status,
        messageCode,
        error,
      });
    }
  }

  async deletePermission({ id }) {
    try {
      let isExist = await Role.find({
        permissions: { $in: [id] },
      });

      if (isExist && isExist.length > 0)
        return {
          status: 400,
          message: __("role.cannot.deleted"),
          roles: isExist,
        };

      let permission = await Permission.findByIdAndRemove(id);
      return {
        status: 200,
        message: __("permissions.delete"),
        permission,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async updatePermission({ id }, req) {
    try {
      console.log(req);

      let permission = await Permission.findByIdAndUpdate(id, req, {
        new: true,
      });

      return {
        status: 200,
        message: __("permissions.update"),
        permission,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }
}

module.exports = new PermissionService();
