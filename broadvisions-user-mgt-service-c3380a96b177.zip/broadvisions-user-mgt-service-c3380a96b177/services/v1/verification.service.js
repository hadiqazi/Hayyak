const EmailOtp = require("../../models").EmailOtp;
const PhoneOtp = require("../../models").PhoneOtp;
const User = require("../../models").User;
const { randomNumber } = require("../../utils/common-utils");
const _ = require("lodash");
const axios = require("../../utils/axios");

class VerificationService {
  async requestOtp({ email, phone }, { language = "en" }) {
    try {
      let user = await User.findOne({ $or: [{ email }, { phone }] });
      if (user)
        return {
          status: 409,
          messageCode: "user.duplicate",
        };

      // Find Update and Generate Email OTP
      let eotp = randomNumber();
      await new EmailOtp().generateOTP({
        email: email,
        otp: eotp,
      });

      // Find Update and Generate Phone OTP
      let potp = randomNumber();
      await new PhoneOtp().generateOTP({
        phone: phone,
        otp: potp,
      });

      // Generating Response
      let otps = {
        phoneOTP: potp,
        emailOTP: eotp,
      };

      try {
        await axios.post(
          `${process.env.NOTIFICATION_URL}/notification/custom-email`,
          // `${process.env.NOTIFICATION_BASE_URL}/v1/notification/custom-email`,
          JSON.stringify({
            action: "REGISTER",
            data: {
              to: email,
              smsotp: otps.phoneOTP,
              emailotp: otps.emailOTP,
            },
          }),
          {
            method: "POST",
            headers: {
              Accept: "application/json, text/plain, */*",
              "Content-Type": "application/json",
              language,
            },
          }
        );
      } catch (error) {
        throw error;
      }

      return {
        status: 200,
        message: __("otp.generated"),
        OTP:
          process.env.NODE_ENV === "saad" ||
          process.env.NODE_ENV === "development"
            ? otps
            : [],
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async verifyOtp({ email, phone, emailOTP, phoneOTP }) {
    try {
      let emailUser = await EmailOtp.findOne({
        email: email,
        emailOtp: emailOTP,
      });

      let phoneUser = await PhoneOtp.findOne({
        phone: phone,
        phoneOtp: phoneOTP,
      });

      if (emailUser && phoneUser) {
        await EmailOtp.remove({ email: email, emailOtp: emailOTP });
        await PhoneOtp.remove({ phone: phone, phoneOtp: phoneOTP });
        return true;
      }

      return false;
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async requestAdminOtp({ phone }) {
    try {
      if (!phone) return null;

      let potp = randomNumber();
      // let otpExist = await PhoneOtp.findOne({
      //   phone,
      // });

      // if (otpExist) return otpExist.phoneOtp;

      await new PhoneOtp().generateOTP({
        phone: phone,
        otp: potp,
      });

      return potp;
    } catch (error) {
      console.log("err ", error);
      return null;
    }
  }

  async verifyAdminOtp({ phone, otp }) {
    try {
      if (!phone) return null;

      let otpExist = await PhoneOtp.findOne({
        phone,
        phoneOtp: otp,
      });

      if (otpExist) {
        await PhoneOtp.remove({
          phone,
          phoneOtp: otp,
        });
        return true;
      }

      return null;
    } catch (error) {
      console.log("err ", error);
      return null;
    }
  }
}

module.exports = new VerificationService();
