const axios = require("../../utils/axios");

class EmailService {
  async sendEmail({ obj, language = "en" }) {
    try {
      let email = await axios.post(
        // `${process.env.BASE_URL}/feedy-notification-service/v1/notification/custom-email`,
        `${process.env.NOTIFICATION_URL}/notification/custom-email`,
        JSON.stringify(obj),
        {
          method: "POST",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            language,
          },
        }
      );

      const { data } = email;

      console.log(data);

      if (data && data.status === 200) return true;
      else return false;
    } catch (error) {
      console.error(error);
      return false;
    }
  }
}

module.exports = new EmailService();
