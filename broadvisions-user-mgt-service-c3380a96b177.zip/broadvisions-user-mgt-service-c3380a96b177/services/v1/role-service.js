const Role = require("../../models").Role;
const User = require("../../models").User;
const Admin = require("../../models").Admin;

const _ = require("lodash");

class RoleService {
  async getAllRoles() {
    try {
      let roles = await Role.find({
        roleText: {$ne: "CUSTOMER"}
      }).populate("permissions", "-__v -roles");

      return {
        status: 200,
        message: __("roles.found"),
        roles,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async getSingleRole(roleId) {
    try {
      let role = await Role.findById(roleId).populate("permissions", "-__v -roles");

      return {
        status: 200,
        message: __("roles.found"),
        role,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async createRole({ name, roleText, permissions }) {
    try {
      let role = await Role.create({
        name,
        roleText,
        permissions
      });

      return {
        status: 200,
        message: __("role.create"),
        role
      };
    } catch (error) {
      let status = 500;
      let messageCode = "server.error";

      if(error.name && error.name === "MongoError"){
        if(error.code === 11000){
          messageCode = "role.duplicate";
          status = 409
        }
      }

      return Promise.reject({
        status,
        messageCode,
        error,
      });
    }
  }

  async deleteRole({ id }) {
    try {
      let isUserExist = await User.find({
        role: id
      })

      if(isUserExist && isUserExist.length > 0)
        return {
          status: 400,
          message: 'role.cannot.deleted'
        }

      let isAdminExist = await Admin.find({
        role: id
      })

      if(isAdminExist && isAdminExist.length > 0)
      return {
        status: 400,
        message: 'role.cannot.deleted'
      }

      let role = await Role.findByIdAndRemove(id);
      return {
        status: 200,
        message: __("role.delete"),
        role,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async updateRole({ id }, req) {
    try {
      let role = await Role.findByIdAndUpdate(
        id, 
        req,
        { new: true }
      );

      return {
        status: 200,
        message: __("role.update"),
        role,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }
}

module.exports = new RoleService();
