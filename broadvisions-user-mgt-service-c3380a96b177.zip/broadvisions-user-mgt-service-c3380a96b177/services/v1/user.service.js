const User = require("../../models").User;
const Role = require("../../models").Role;
const _ = require("lodash");
const { generateEncryptedPassword } = require("../../utils/common-utils");
const VerificationService = require("./verification.service");
const bcrypt = require("bcrypt");
const EmailService = require("./email.service");
const axios = require("../../utils/axios");
const JWT = require("../jwt.service");
const S3Service = require("../s3.service");

class UserService {
  async getAllUsers() {
    try {
      let users = await User.find({
        isDeleted: false,
      })
        .select("-password")
        .populate("role");

      return {
        status: 200,
        message: __("users.found"),
        users,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async getUserWithPassword(where) {
    try {
      let user = await User.findOne(where).populate("role");

      if (!user) return null;

      return {
        status: 200,
        message: __("users.found"),
        user,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async deleteUser({ id }) {
    try {
      let user = await User.findByIdAndUpdate(
        id,
        {
          isDeleted: true,
        },
        { new: true }
      );
      return {
        status: 200,
        message: __("user.delete"),
        user,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async updateUser({ id }, req, { file }) {
    try {
      let pass = null;
      let obj = {
        ...req,
      };

      if (file) {
        let img = await S3Service.uploadFileOnS3("", file);
        if (img) obj["profileImage"] = img.file_url;
      }

      const { password } = req;
      if (password) {
        pass = await generateEncryptedPassword({ password: password });
        obj["password"] = pass.encrypt;
      }

      let nameParse = null;

      if (req["name"]) {
        if (req["name"].indexOf(" ") > -1) {
          obj["firstName"] = req["name"]
            .substr(0, req["name"].indexOf(" "))
            .trim();
          obj["lastName"] = req["name"]
            .substr(req["name"].indexOf(" ") + 1)
            .trim();
        } else {
          obj["firstName"] = req["name"];
          obj["lastName"] = "";
        }
      }

      let user = await User.findByIdAndUpdate(id, obj, { new: true }).populate(
        "role"
      );

      delete user._doc.password;

      return {
        status: 200,
        message: __("user.update"),
        user,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async resetPassword({ id, oldPassword, newPassword, language }) {
    try {
      let user = await User.findOne({ _id: id });

      if (!user)
        return {
          status: 401,
          message: __("no.user.found"),
        };

      let password = bcrypt.compareSync(oldPassword, user.password);
      if (!password) {
        return Promise.resolve({
          status: 401,
          messageCode: "invalid.credentials",
        });
      }

      let pass = await generateEncryptedPassword({ password: newPassword });
      let userUpdate = await User.findByIdAndUpdate(
        user.id,
        {
          password: pass.encrypt,
        },
        { new: true }
      );

      delete userUpdate._doc.password;

      EmailService.sendEmail({
        language,
        obj: {
          action: "UPDATE_USER_PASSWORD",
          data: {
            to: user.email,
          },
        },
      });

      return {
        status: 200,
        message: __("user.password.updated"),
        user: userUpdate,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  lookup = async ({ userId }, { language = "en" }) => {
    try {
      const token = await JWT.createOwnJWT();

      const response = {
        user: null,
        amenityTypes: null,
        bedTypes: null,
        propertyTypes: null,
        freeCancellationBefore: null,
      };

      let user = await User.findOne({
        _id: userId,
      }).populate("role");

      if (!user)
        return Promise.reject({
          status: 401,
          messageCode: "invalid.user",
        });

      let roles = [];
      let permissions = [];

      for (let permission of user.role.permissions) {
        permissions.push(permission.authText);
      }
      roles.push(user.role.roleText);

      delete user._doc.password;
      delete user._doc.role;

      let tokenData = {
        user,
        roles,
        permissions,
        bookingToBeReviewed: null,
      };

      // Fetch Property LookUp
      let types = await axios.get(
        `${process.env.PROPERTY_URL}/lookup/getAllTypes`,
        {
          method: "GET",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            language: language,
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (types && types.status === 200 && types.data) {
        const { data } = types;
        tokenData["amenityTypes"] = data.amenityTypes;
        tokenData["bedTypes"] = data.bedTypes;
        tokenData["propertyTypes"] = data.propertyTypes;
      }

      // Fetch Booking Cancellation
      let cancel = await axios.get(
        `${process.env.BOOKING_URL}/booking/free-cancel`,
        {
          method: "GET",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (cancel && cancel.status === 200 && cancel.data) {
        const { data } = cancel;
        tokenData["cancellationPolicy"] = data.cancellationPolicy;
      }

      try {
        let toBeReviewed = await axios.get(
          `${process.env.BOOKING_URL}/booking/booking-to-review?userId=${user.id}`,
          {
            method: "GET",
            headers: {
              Accept: "application/json, text/plain, */*",
              "Content-Type": "application/json",
              language: language,
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (toBeReviewed) {
          const { data } = toBeReviewed;
          if (data && data.status === 200)
            tokenData.bookingToBeReviewed = data.response;
        }
      } catch (error) {
        console.log("ERR ", error);
      }

      return {
        status: 200,
        ...tokenData,
      };
    } catch (error) {
      console.log("ERROR ", error);
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  };

  async updatePassword({ email }, { language }) {
    try {
      let user = await User.findOne({ email });

      if (!user)
        return {
          status: 400,
          message: "user.not.found",
        };

      let token = await JWT.returnJWT({
        id: user._id,
        role: "USER",
      });

      let sent = await EmailService.sendEmail({
        language,
        obj: {
          action: "RESET_PASSWORD",
          data: {
            token: token,
            to: email,
            url: `${process.env.BASE_URL}/hayyak-user-service/v1/auth/reset-password-template`,
          },
        },
      });

      return {
        status: 200,
        response: sent,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async passwordPatch({ id }, { password }) {
    try {
      if (id) {
        let pass = await generateEncryptedPassword({ password: password });
        let user = await User.findByIdAndUpdate(
          id,
          { password: pass.encrypt },
          { new: true }
        ).populate("role");

        if (user)
          return {
            status: 200,
            message: "updated",
          };
      }

      return {
        status: 400,
        message: "not.updated",
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }

  async getMultipleUsers({ ids = [] }) {
    try {
      let users = await User.find({ _id: ids }).select("-password");
      if (users) {
        return {
          status: 200,
          users,
        };
      }

      return {
        status: 400,
        message: "no.user.found",
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }
}

module.exports = new UserService();
