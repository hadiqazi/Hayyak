var AWS = require("aws-sdk");
const uuid = require("uuid");

const BUCKET = process.env.BUCKET;
const REGION = process.env.REGION;
const ACCESS_KEY = process.env.ACCESS_KEY;
const SECRET_KEY = process.env.SECRET_KEY;

AWS.config.update({
  accessKeyId: ACCESS_KEY,
  secretAccessKey: SECRET_KEY,
  region: REGION,
});

class S3Service {
  constructor(height, width) {
    this.S3 = new AWS.S3();
  }

  async uploadFileOnS3(subBucket = "", file) {
    try {
      let ext = file.originalname.split(".").pop();
      let fileName = uuid() + "." + ext;

      const params = {
        Bucket: BUCKET + `/${subBucket}`,
        Key: fileName, // File name to save as in S3
        Body: file.buffer,
        ACL: "public-read",
      };

      let uploadResult = await this.S3.upload(params).promise();

      return {
        status: 200,
        uuid: fileName,
        file_url: uploadResult.Location,
        ext,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "Server Error Occurred.",
        error,
      });
    }
  }

  async deleteFileFromS3(subBucket = "", fileId) {
    try {
      const params = {
        Bucket: BUCKET + `/${subBucket}`,
        Key: fileId,
      };

      await this.S3.deleteObject(params);

      return {
        status: 200,
        uuid: fileId,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "Server Error Occurred.",
        error,
      });
    }
  }

  async deleteFilesFromS3(subBucket = "", fileIds) {
    try {
      if (!fileIds) throw new Error();

      const keys = [];
      fileIds.forEach((fileId) => {
        keys.push({ Key: fileId });
      });

      const params = {
        Bucket: BUCKET + `/${subBucket}`,
        Delete: { Objects: keys },
      };

      await this.S3.deleteObjects(params);

      return {
        status: 200,
        uuid: fileIds,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "Server Error Occurred.",
        error,
      });
    }
  }
}

module.exports = new S3Service();
