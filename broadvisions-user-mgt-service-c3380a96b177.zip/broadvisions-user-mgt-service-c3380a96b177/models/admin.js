const mongoose = require("mongoose");

const AdminSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
    },
    email: {
      type: String,
      unique: true,
      required: true,
    },
    phone: {
      type: String,
      unique: true,
    },
    password: {
      type: String,
      unique: false,
      required: true,
    },
    type: {
      type: String,
      enum: ["ADMIN", "PROPERTY_ADMIN"],
      default: "ADMIN",
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    role: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "role",
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

module.exports = mongoose.model("admin", AdminSchema);
