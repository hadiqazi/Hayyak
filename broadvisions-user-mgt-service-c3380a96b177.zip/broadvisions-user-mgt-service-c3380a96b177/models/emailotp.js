const mongoose = require("mongoose");

const EmailOtp = new mongoose.Schema(
  {
    email: {
      type: String,
      unique: true,
      required: true,
    },
    emailOtp: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

EmailOtp.methods.generateOTP = async ({ email, otp = "" }) => {
  try {
    let emailUser = await mongoose.model("emailotp").findOne({
      email: email,
    });

    if (!emailUser)
      await mongoose.model("emailotp").create({
        email: email,
        emailOtp: otp.toString(),
      });
    else
      await mongoose.model("emailotp").findOneAndUpdate(
        { email: email },
        {
          emailOtp: otp.toString(),
        },
        { new: true }
      );
    return emailUser;
  } catch (error) {
    throw error;
  }
};

module.exports = mongoose.model("emailotp", EmailOtp);
