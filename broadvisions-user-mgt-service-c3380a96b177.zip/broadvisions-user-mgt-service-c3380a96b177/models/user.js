const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
    },
    email: {
      type: String,
      unique: true,
      required: true,
    },
    phone: {
      type: String,
      unique: true,
      required: true,
    },
    password: {
      type: String,
      unique: false,
      required: true,
    },
    profileImage: {
      type: String,
    },
    dateOfBirth: {
      type: Date,
    },
    country: {
      type: String,
    },
    language: {
      type: String,
      default: "en",
    },
    loginType: {
      type: String,
      default: "EMAIL",
    },
    isActive: {
      type: Boolean,
    },
    isVerified: {
      type: Boolean,
    },
    isDeleted: {
      type: Boolean,
    },
    identityDocuments: { type: Array, default: [] },
    role: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "role",
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

module.exports = mongoose.model("user", UserSchema);
