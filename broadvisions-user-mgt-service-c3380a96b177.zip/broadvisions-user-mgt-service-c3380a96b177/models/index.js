const Permission = require("./permission");
const Role = require("./role");
const Admin = require("./admin");
const User = require("./user");
const EmailOtp = require("./emailotp");
const PhoneOtp = require("./phoneotp");

module.exports = {
  Permission,
  Role,
  Admin,
  User,
  EmailOtp,
  PhoneOtp,
};
