const mongoose = require("mongoose");

const roleSchema = new mongoose.Schema(
  {
    name: {
      type: String, 
      unique: true,
      required: true,
    },
    roleText: {
      type: String, 
      unique: true,
      required: true,
    },
    permissions: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: "permission"
    }],
  },
  {
    timestamps: true,
    strict: true,
  }
);

var autoPopulatePermissions = function(next) {
  this.populate('permissions');
  next();
};

roleSchema
.pre('find', autoPopulatePermissions)

module.exports = mongoose.model("role", roleSchema);
