const mongoose = require("mongoose");

const PhoneOtp = new mongoose.Schema(
  {
    phone: {
      type: String,
      unique: true,
      required: true,
    },
    phoneOtp: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

PhoneOtp.methods.generateOTP = async ({ phone, otp = "" }) => {
  try {
    let phoneUser = await mongoose.model("phoneotp").findOne({
      phone: phone,
    });

    if (!phoneUser)
      await mongoose.model("phoneotp").create({
        phone: phone,
        phoneOtp: otp.toString(),
      });
    else
      await mongoose.model("phoneotp").findOneAndUpdate(
        { phone: phone },
        {
          phoneOtp: otp.toString(),
        },
        { new: true }
      );
    return phoneUser;
  } catch (error) {
    throw error;
  }
};

module.exports = mongoose.model("phoneotp", PhoneOtp);
