const _ = require("lodash");

const GENERAL_ERROR_CODE = "server.error";
const BAD_REQ_ERROR_CODE = "bad.request";

const bcrypt = require("bcrypt");

const handleRouteError = (resp) => {
  return (error) => {
    logErrorDetails(error);

    if (isBadRequestError(error)) {
      sendBadRequestResponse(error, resp);
    } else {
      sendGeneralErrorResponse(resp);
    }
  };
};

const logErrorDetails = (error) => {
  console.error(error);
};

const generateEncryptedPassword = async ({ password = "" }) => {
  try {
    if (!password) {
      if (process.env.NODE_ENV === "development")
        password = process.env.DEFAULT_PASSWORD;
      else password = Math.random().toString(36).slice(-8);
    }

    let encryptedPassword = await new Promise((resolve, reject) => {
      bcrypt.hash(password, +process.env.SALT_ROUNDS, function (err, hash) {
        if (err) reject(err);
        resolve(hash);
      });
    });
    return encryptedPassword;
  } catch (error) {
    return "";
  }
};

const randomNumber = (min = 1000, max = 9999) =>
  Math.floor(Math.random() * (max - min)) + min;

const isBadRequestError = (error) => {
  return (
    !_.isEmpty(error) &&
    _.isFinite(error.status) &&
    error.status >= 400 &&
    error.status < 500
  );
};

const sendBadRequestResponse = (error, resp) => {
  const messageCode = _.isEmpty(error.messageCode)
    ? BAD_REQ_ERROR_CODE
    : error.messageCode;
  resp
    .status(error.status)
    .send({ status: error.status, message: __(messageCode), error });
  // resp.status(error.status).send({status: error.status, message: 'BAD_REQUEST', error});
};

const sendGeneralErrorResponse = (resp) => {
  // resp.status(500).send({status: 500, message: resp.__(GENERAL_ERROR_CODE)});
  resp.status(500).send({ status: 500, message: "GENERAL_ERROR" });
};

const dateDifference = (start, end) => {
  const diffInMs = new Date(start) - new Date(end);
  const diffInDays = diffInMs / (1000 * 60 * 60 * 24);
  return Math.round(diffInDays);
};

module.exports = {
  handleRouteError,
  generateEncryptedPassword,
  randomNumber,
  dateDifference,
};
