const { Router } = require("express");
const router = Router();
const { BookingService } = require("../../../services/v1");
const { handleRouteError } = require("../../../utils/common-utils");
const { BookingValidator } = require("../../../validators");
const { authenticate } = require("../../middlewares/auth");

router.get("/", authenticate("READ_BOOKING"), async (req, resp) => {
  try {
    BookingService.getAllBookings()
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.get(
  "/detail",
  authenticate("DETAIL_BOOKING,CUSTOMER"),
  async (req, resp) => {
    try {
      BookingService.getDetailBooking(req.query, req.headers)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.post("/", authenticate("CREATE_BOOKING,CUSTOMER"), async (req, resp) => {
  try {
    const {
      jwt: {
        user: { _id, firstName, lastName, email, profileImage, language },
      },
    } = req;

    await BookingValidator.create().validateAsync({
      ...req.body,
    });
    BookingService.createBooking(
      {
        ...req.body,
        user: {
          id: _id,
          name: `${firstName} ${lastName}`,
          email,
          profileImage,
          language
        },
      },
      req.headers
    )
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.patch(
  "/cancel",
  authenticate("CANCEL_BOOKING,CUSTOMER"),
  async (req, resp) => {
    try {
      await BookingValidator.cancel().validateAsync({
        ...req.body,
        ...req.query,
      });

      const {
        jwt,
        jwt: { user },
      } = req;

      BookingService.onCancelBooking(req.query, {
        ...req.body,
        by: user._id,
        byCustomer: jwt.roles.includes("CUSTOMER") ? true : false,
        language: user.language ? user.language : 'en'
      })
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.delete("/", authenticate("DELETE_BOOKING"), async (req, resp) => {
  try {
    await BookingValidator.remove().validateAsync({
      ...req.query,
    });

    BookingService.removeBooking(req.query)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post(
  "/filter",
  authenticate("FILTER_BOOKING,CUSTOMER"),
  async (req, resp) => {
    try {
      await BookingValidator.filter().validateAsync({
        ...req.query,
        ...req.body,
      });

      let body = {
        ...req.body,
      };

      const { jwt } = req;
      if (jwt.roles.includes("CUSTOMER")) {
        body["userId"] = jwt.user._id;
      }
      BookingService.getFilterBookings(req.query, { ...body }, req.headers)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.post(
  "/service",
  authenticate("ADD_SERVICE,CUSTOMER"),
  async (req, resp) => {
    try {
      await BookingValidator.addService().validateAsync({
        ...req.body,
      });

      BookingService.addService(req.body, req.headers)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.post(
  "/property-filter",
  authenticate("PROPERTY_FILTER,CUSTOMER,IS_SERVICE"),
  async (req, resp) => {
    try {
      await BookingValidator.propertyFilter().validateAsync({
        ...req.body,
      });
      BookingService.getPropertiesFilter(req.body)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.get(
  "/booking-to-review",
  authenticate("IS_SERVICE"),
  async (req, resp) => {
    try {
      // const {
      //   jwt: { user },
      // } = req;
      await BookingValidator.lookup().validateAsync({
        // userId: user._id,
        ...req.query,
      });
      BookingService.bookingLookUp(req.query, req.headers)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.get(
  "/calculate-cancel",
  authenticate("CALCULATE_CANCEL,CUSTOMER"),
  async (req, resp) => {
    try {
      await BookingValidator.calculateCancel().validateAsync({
        ...req.query,
      });
      BookingService.calculateCancellationCharges(req.query)
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.get(
  "/free-cancel",
  authenticate("FREE_CANCEL,IS_SERVICE"),
  async (req, resp) => {
    try {
      BookingService.getCancellationDays()
        .then((result) => {
          resp.status(result.status).send(result);
        })
        .catch(handleRouteError(resp));
    } catch (error) {
      handleRouteError(resp)({
        status: 403,
        message: __("mandatory.fields"),
        error,
      });
    }
  }
);

router.post("/top-rated", authenticate("IS_SERVICE"), async (req, resp) => {
  try {
    await BookingValidator.topBookings().validateAsync({
      ...req.body,
    });
    BookingService.getTopRatingBookingProperties(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});
module.exports = router;
