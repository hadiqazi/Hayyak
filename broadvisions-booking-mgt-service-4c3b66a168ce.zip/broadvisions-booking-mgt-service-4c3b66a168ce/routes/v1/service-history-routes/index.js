const { Router } = require("express");
const router = Router();
const { HistoryService } = require("../../../services/v1");
const { handleRouteError } = require("../../../utils/common-utils");

router.get("/",  async (req, resp) => {
  try {
    // HistoryService.getAll()
    //   .then((result) => {
    //     resp.status(result.status).send(result);
    //   })
    //   .catch(handleRouteError(resp));
    resp.status(200).send({
      body: null,
    });
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

module.exports = router;
