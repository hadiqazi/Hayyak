const { Router } = require("express");

const BookingRoutes = require("./booking-routes");
const ServiceHistoryRoutes = require("./service-history-routes");
const DashboardRoutes = require("./dashboard-routes");

const setup = (app) => {
  const router = Router();

  router.use("/booking", BookingRoutes);
  router.use("/service-history", ServiceHistoryRoutes);
  router.use("/dashboard", DashboardRoutes);

  // this should be the last line
  app.use("/v1", router);
};

module.exports = setup;
