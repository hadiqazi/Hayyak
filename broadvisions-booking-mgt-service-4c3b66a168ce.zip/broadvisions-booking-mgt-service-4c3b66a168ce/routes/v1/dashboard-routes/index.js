const { Router } = require("express");
const router = Router();
const { DashboardService } = require("../../../services/v1");
const { handleRouteError } = require("../../../utils/common-utils");
const { DashboardValidator } = require("../../../validators");
const { authenticate } = require("../../middlewares/auth");

router.post("/", authenticate(""), async (req, resp) => {
  try {
    await DashboardValidator.stats().validateAsync({
      ...req.body,
    });

    DashboardService.getDashboardStats(req.body, req.headers)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

module.exports = router;
