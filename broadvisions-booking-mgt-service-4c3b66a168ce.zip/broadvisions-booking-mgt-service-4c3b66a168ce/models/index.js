const Booking = require("./booking");
const ServiceHistory = require("./servicehistory");
const BookingPolicy = require("./bookingpolicy");
const CancelPolicy = require("./cancelpolicy");

module.exports = {
  Booking,
  ServiceHistory,
  BookingPolicy,
  CancelPolicy,
};
