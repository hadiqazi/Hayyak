const mongoose = require("mongoose");

const BookingSchema = new mongoose.Schema(
  {
    propertyId: {
      type: String,
    },
    propertyPrice: {
      type: Number,
    },
    checkIn: {
      type: Date,
      default: Date.now,
      required: true,
    },
    checkOut: {
      type: Date,
      default: Date.now,
      required: true,
    },
    rooms: [
      {
        type: Object,
      },
    ],
    user: {
      type: Object,
    },
    bookingId: {
      type: Number,
      unique: true
    },
    guest: {
      type: Object,
    },
    status: {
      type: String,
      required: true,
    },
    isDeleted: {
      type: Boolean,
    },
    reviewServed: {
      type: Boolean,
    },
    services: [
      {
        type: Object,
      },
    ],
    serviceHistory: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "servicehistory",
      },
    ],
    cancel: {
      type: Object,
    },
    cost: {
      type: Object,
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

module.exports = mongoose.model("booking", BookingSchema);
