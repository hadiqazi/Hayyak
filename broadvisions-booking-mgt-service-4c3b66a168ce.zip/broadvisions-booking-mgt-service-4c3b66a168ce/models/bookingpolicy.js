const mongoose = require("mongoose");

const BookingPolicy = new mongoose.Schema(
  {
    days: {
      type: Number,
    },
    deductionPercentage: {
      type: Number,
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

module.exports = mongoose.model("cancel_booking_policy", BookingPolicy);
