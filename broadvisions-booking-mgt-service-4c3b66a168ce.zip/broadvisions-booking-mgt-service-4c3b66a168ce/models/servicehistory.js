const mongoose = require("mongoose");

const ServiceHistorySchema = new mongoose.Schema(
  {
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "booking",
    },
    service: {
      type: Object,
    },
    isAdded: {
      type: Boolean,
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

module.exports = mongoose.model("servicehistory", ServiceHistorySchema);
