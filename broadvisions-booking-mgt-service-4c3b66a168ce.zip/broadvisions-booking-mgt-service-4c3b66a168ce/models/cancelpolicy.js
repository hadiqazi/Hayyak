const mongoose = require("mongoose");

const CancelPolicy = new mongoose.Schema(
  {
    cutOffDays: {
      type: Number,
    },
    resetTimeToMidnight: {
      type: Boolean,
    },
    freeHoursInsideCutoff: {
      type: Number,
    },
    freeHoursOutsideCutoff: {
      type: Number,
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

module.exports = mongoose.model("cancel_policy", CancelPolicy);
