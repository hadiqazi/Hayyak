require("dotenv").config();
const express = require("express");
const logger = require("morgan");
require("./config/db-mongo");
const setupRoutes = require("./routes");
const setupMiddleware = require("./routes/middlewares/middleware");
const systemConfig = require("./config/system-config");
const SCHEDULER = require("./schedulers");

require("./cloud-config")(systemConfig.appName, systemConfig.port);

// SCHEDULER.bookingStatusAccept.start();

if (process.env.NODE_ENV !== "local")
  for (const [key, value] of Object.entries(SCHEDULER)) {
    value.start();
  }

// Set up the express app
const app = express();
// Log requests to the console.
app.use(logger("dev"));

setupMiddleware(app);
setupRoutes(app);

app.listen(systemConfig.port, () => {
  console.info(
    `App '${systemConfig.appName}' started on port ${systemConfig.port}`
  );
});
