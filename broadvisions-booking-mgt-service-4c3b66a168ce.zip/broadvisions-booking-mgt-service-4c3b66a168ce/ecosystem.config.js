module.exports = {
    apps: [{
        name: 'hayyak-booking-service',
        script: 'app.js',
        // Options reference: https://pm2.io/doc/en/runtime/reference/ecosystem-file/
        args: 'one two',
        instances: 1,
        autorestart: true,
        watch: false,
        max_memory_restart: '1G',
        env: {
            APP_NAME:'hayyak-booking-service',
            PORT: 9003,
            NODE_ENV: "development",
            EUREKA_URL:"http://localhost:8761/eureka",
            PUBLIC_KEY_PATH:'/etc/keys/hayyak_public.key',
            PRIVATE_KEY_PATH:'/etc/keys/hayyak.key',
            MONGO_CONNECTION_STRING: "mongodb+srv://dbuser:dbuser123@dev.utgx0.mongodb.net/hayyak-dev?retryWrites=true&w=majority",
            BASE_URL:'https://dev.feedy.se:8080/',
            DEFAULT_LANGUAGE:"en",
            SUPPORTED_LANGUAGES:"en,arabic",
            PROPERTY_URL:"hayyak-property-service/v1",
            NOTIFICATION_URL: "hayyak-notification-service/v1",
            PAGE_LIMIT:12
        },
        env_development: {
            APP_NAME:'hayyak-booking-service',
            PORT: 9003,
            NODE_ENV: "development",
            EUREKA_URL:"http://localhost:8761/eureka",
            PUBLIC_KEY_PATH:'/etc/keys/hayyak_public.key',
            PRIVATE_KEY_PATH:'/etc/keys/hayyak.key',
            MONGO_CONNECTION_STRING: "mongodb+srv://dbuser:dbuser123@dev.utgx0.mongodb.net/hayyak-dev?retryWrites=true&w=majority",
            BASE_URL:'https://dev.feedy.se:8080/',
            DEFAULT_LANGUAGE:"en",
            SUPPORTED_LANGUAGES:"en,arabic",
            PROPERTY_URL:"hayyak-property-service/v1",
            NOTIFICATION_URL: "hayyak-notification-service/v1",
            PAGE_LIMIT:12
        }
    }],
    deploy: {
    }
}