const Booking = require("../../models").Booking;
const BookingPolicy = require("../../models").BookingPolicy;
const CancelPolicy = require("../../models").CancelPolicy;
const axios = require("../../utils/axios");
const HistoryService = require("./service.history.service");
const { dateDifference } = require("../../utils/common-utils");
const moment = require("moment");
const JWT = require("../jwt.service");
const EmailService = require("./email.service");

class BookingService {
  getAllBookings = async () => {
    let booking = await Booking.find({}).populate("serviceHistory").exec();
    return {
      status: 200,
      bookings: booking,
    };
  };

  getMultipleProperties = async ({
    ids = [],
    language,
    attributes = [],
    isSingle = false,
    populateRooms = false,
  }) => {
    try {
      const token = await JWT.createOwnJWT();

      let multiple = await axios.post(
        `${process.env.PROPERTY_URL}/property/multiple`,
        JSON.stringify({
          ids,
          attributes,
          populateRooms,
        }),
        {
          method: "POST",
          headers: language
            ? {
                Accept: "application/json, text/plain, */*",
                "Content-Type": "application/json",
                language,
                Authorization: `Bearer ${token}`,
              }
            : {
                Accept: "application/json, text/plain, */*",
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
              },
        }
      );

      if (
        multiple &&
        multiple.status === 200 &&
        multiple.data.properties &&
        multiple.data.properties.length > 0
      ) {
        const { data } = multiple;
        if (isSingle) return data.properties[0];
        return data.properties;
      } else return null;
    } catch (error) {
      return null;
    }
  };

  getPropertyInfo = async (
    id,
    book = null,
    language = "en",
    isDetail = false
  ) => {
    try {
      let singleProperty = await axios.get(
        `${process.env.PROPERTY_URL}/property/${id}`,
        // `${process.env.NOTIFICATION_BASE_URL}/v1/notification/custom-email`,
        {
          method: "GET",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            language: language,
          },
        }
      );

      if (singleProperty) {
        const { data } = singleProperty;
        if (data && data.property) {
          if (book) {
            const {
              propertyPrice,
              checkIn,
              checkOut,
              rooms,
              user,
              status,
              cost,
              createdAt,
              services,
              serviceHistory,
              _id,
            } = book;

            const hasCoverImage = () => {
              return Object.keys(data.property.coverImage).length > 5
                ? null
                : data.property.coverImage["imageUrl"];
            };

            let newbook = {
              _id,
              property: isDetail
                ? {
                    _id: data.property._id,
                    name: data.property.name,
                    coverImage: hasCoverImage(),
                    building: data.property.building,
                    propertyType: data.property.propertyType,
                    bedType: data.property.bedType,
                    average: data.property.average,
                  }
                : {
                    _id: data.property._id,
                    name: data.property.name,
                    coverImage: hasCoverImage(),
                  },
              propertyPrice,
              checkIn,
              checkOut,
              rooms,
              user,
              status,
              cost,
              createdAt,
            };

            if (isDetail) {
              let uservice = services.map((serve) => {
                serve.service["name"] = serve.service["name"][language];
                serve.service["description"] =
                  serve.service["description"][language];
                return serve;
              });

              let userviceHist = serviceHistory.map((serve) => {
                serve.service["name"] = serve.service["name"][language];
                serve.service["description"] =
                  serve.service["description"][language];
                return serve;
              });
              newbook["services"] = uservice;
              newbook["serviceHistory"] = userviceHist;
            }
            return newbook;
          }
          return data.property;
        }
      }

      return null;
    } catch (error) {
      console.log("ERROR while fetching Property ", error);
    }
  };

  getMultipleVAS = async ({ vas = [] }) => {
    try {
      const token = await JWT.createOwnJWT();
      let ids = [];
      vas.forEach((value) => {
        ids.push(value.id);
      });

      let multiple = await axios.post(
        `${process.env.PROPERTY_URL}/value-added-service/multiple`,
        // `${process.env.NOTIFICATION_BASE_URL}/v1/notification/custom-email`,
        JSON.stringify({
          ids,
        }),
        {
          method: "POST",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (multiple) {
        const { data } = multiple;
        if (data && data.vas) {
          let customvas = [];

          vas.forEach((org) => {
            data.vas.forEach((v) => {
              if (org.id === v._id)
                customvas.push({
                  ...v,
                  dates: org.dates,
                });
            });
          });

          return customvas;
        } else return null;
      }

      return null;
    } catch (error) {
      console.log("ERROR ", error);
    }
  };

  validateVasDates = (checkIn, checkOut, dates = []) => {
    try {
      let checkin = new Date(checkIn);
      let checkout = new Date(checkOut);
      let check = true;
      dates.dates.forEach((date) => {
        let middate = new Date(date);

        if (!(checkin <= middate && checkout >= middate)) {
          check = false;
        }
      });

      return check;
    } catch (error) {
      console.log("ERROR ", error);
      return false;
    }
  };

  createBooking = async (
    { propertyId, checkIn, checkOut, rooms, user, guest, vas = [] },
    { language = "en" }
  ) => {
    try {
      let bookingId = 10000;

      vas.forEach((v) => {
        let bool = this.validateVasDates(checkIn, checkOut, v);
        if (!bool) throw { status: 403, message: "invalid.vas.dates" };
      });

      const diffInMs = new Date(checkOut) - new Date(checkIn);
      const diffInDays = diffInMs / (1000 * 60 * 60 * 24);

      let cost = {};

      // let data = await this.getPropertyInfo(propertyId);
      let data = await this.getMultipleProperties({
        ids: [propertyId],
        isSingle: true,
        populateRooms: true,
      });

      if (data) {
        cost["roomCost"] = data.price * diffInDays;

        let availableRooms = await this.getPropertyRooms(
          data,
          rooms,
          checkIn,
          checkOut
        );
        if (!availableRooms)
          return {
            status: 404,
            message: "required.rooms.not.available",
            booking: null,
          };

        let latestBooking = await Booking.findOne()
          .sort({ bookingId: -1 })
          .select("bookingId");
        if (latestBooking) bookingId = latestBooking.bookingId + 1;

        let booking = await Booking.create({
          propertyId,
          bookingId: bookingId,
          propertyPrice: data.price,
          checkIn,
          checkOut,
          rooms: availableRooms.rooms.slice(0, rooms),
          user,
          guest,
          status: "ACTIVE",
          isDeleted: false,
          reviewServed: false,
        });

        let multiple = await this.getMultipleVAS({ vas });
        if (multiple) {
          let multiplePromises = [];

          let totalService = 0;

          multiple.forEach((vasOrg) => {
            totalService = totalService + vasOrg.price * vasOrg.dates.length;

            multiplePromises.push(
              this.addService(
                {
                  bookingId: booking._id,
                  service: vasOrg,
                },
                {
                  language: user.language,
                }
              )
            );
          });

          await Promise.all(multiplePromises);

          cost["servicesCost"] = totalService;
          cost["totalBookingCost"] = cost["servicesCost"] + cost["roomCost"];

          let updatedBooking = await Booking.findOneAndUpdate(
            {
              _id: booking._id,
            },
            {
              cost,
            },
            { new: true }
          );

          await EmailService.sendEmail({
            obj: {
              action: "BOOKING_CREATED",
              data: {
                to: user.email,
                orderId: "12345",
              },
            },
            language: user.language ? user.language : "en",
          });

          return {
            status: 200,
            booking: updatedBooking,
          };
        }

        return {
          status: 200,
          booking: booking,
        };
      } else {
        return {
          status: 400,
          message: "no.property.exists",
          booking: null,
        };
      }
    } catch (error) {
      console.log("ERROR while fetching Property ", error);
      if (error.status) {
        return error;
      }

      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  };

  removeBooking = async ({ id }) => {
    let booking = await Booking.findByIdAndUpdate(
      id,
      {
        isDeleted: true,
      },
      { new: true }
    );

    return {
      status: 200,
      booking: booking,
    };
  };

  search = async () => {};

  getDetailBooking = async ({ id }, { language }) => {
    let object = null;
    let booking = await Booking.findOne({
      _id: id,
    })
      .populate("serviceHistory")
      .exec();

    if (booking) {
      let property = await this.getMultipleProperties({
        ids: [booking.propertyId],
        language,
        attributes: [
          "_id",
          "name",
          "images",
          "amenities",
          "valueAddedServices",
          "coverImage",
          "building",
          "propertyType",
          "bedType",
          "average",
          "rooms",
          "guestCount",
        ],
        isSingle: true,
        populateRooms: true,
      });

      let bookingObj = booking.toObject();

      if (language) {
        let uservice = bookingObj.services.map((serve) => {
          serve.service["name"] = serve.service["name"][language];
          serve.service["description"] = serve.service["description"][language];
          return serve;
        });

        let userviceHist = bookingObj.serviceHistory.map((serve) => {
          serve.service["name"] = serve.service["name"][language];
          serve.service["description"] = serve.service["description"][language];
          return serve;
        });

        bookingObj["services"] = uservice;
        bookingObj["serviceHistory"] = userviceHist;
      }

      // let property = await this.getPropertyInfo(
      //   booking.propertyId,
      //   booking,
      //   language,
      //   true
      // );
      if (property) {
        object = {
          ...bookingObj,
          propertyId: property,
        };
      }
    }

    return {
      status: 200,
      messgae: "booking.found",
      booking: object,
    };
  };

  getFilterBookings = async (
    { page = 1, sortOrder = "DESC", sortColumn = "createdAt" },
    { bookingId, status = "", userId },
    { language }
  ) => {
    let limit = +process.env.PAGE_LIMIT;
    let skip = limit * (page - 1);
    let sort = { [sortColumn]: sortOrder === "ASC" ? 1 : -1 };
    let filter = {};

    if (userId) filter["user.id"] = userId;

    if (bookingId) filter["bookingId"] = bookingId;
    filter["isDeleted"] = false;

    if (status) {
      let currentDate = new Date().toISOString();
      if (status === "UPCOMING") {
        filter["checkIn"] = {
          $gt: new Date(currentDate),
        };
      } else if (status === "CURRENT") {
        filter["checkIn"] = {
          $lte: new Date(currentDate),
        };
      } else {
        filter["status"] = status;
      }
    }

    let bookings = await Booking.find(
      filter,
      [
        "propertyId",
        "bookingId",
        "propertyPrice",
        "checkIn",
        "checkOut",
        "rooms",
        "user",
        "guest",
        "status",
        "cost",
        "createdAt",
      ],
      { skip, limit }
    ).sort(sort);

    // let filteProp = [];
    let updatedBooking = [];
    if (bookings && bookings.length > 0) {
      let propertyIds = [];
      bookings.forEach((booking) => {
        propertyIds.push(booking.propertyId);
      });

      let attr = ["_id", "name", "coverImage"];
      if (!language) attr.push("building");

      let uniqueIds = [...new Set(propertyIds)];
      let properties = await this.getMultipleProperties({
        ids: uniqueIds,
        language,
        attributes: attr,
      });

      if (properties && properties.length > 0) {
        bookings.map((book) => {
          properties.forEach((prop) => {
            if (book.propertyId === prop._id) {
              updatedBooking.push({
                ...book.toObject(),
                property: {
                  ...prop,
                },
              });
            }
          });
        });
      }

      // let promiseArr = [];
      // bookings.map((book) => {
      //   promiseArr.push(this.getPropertyInfo(book.propertyId, book, language));
      // });
      // filteProp = await Promise.all(promiseArr);
    }

    let bookingCount = await Booking.countDocuments(filter);

    return {
      status: 200,
      booking: updatedBooking,
      pagination: {
        total: bookingCount,
        size: limit,
        page: +page,
      },
    };
  };

  addService = async ({ bookingId, service }, { language = "en" }) => {
    // TODO: ONLY GET SERVICE ID AND QUANTITY FROM THE API, FETCH SERVICE INFO FROM PROPERTY MGT SERVICE VIA API
    let booking = null;
    let col = `services.service.name.${language}`;
    booking = await Booking.findOne({
      _id: bookingId,
      [col]: service.name[language],
    });

    let total = service.price * service.dates.length;

    if (!booking) {
      await Booking.findOneAndUpdate(
        { _id: bookingId },
        {
          $push: {
            services: {
              bookingId,
              service,
              dates: service.dates,
              totalQuantity: service.dates.length,
              total: total,
            },
          },
        }
      );

      await HistoryService.create({ bookingId, service, isAdded: true });

      return {
        status: 200,
        message: "service.added",
        booking,
      };
    } else {
      let singleService = booking.services.filter((item) => {
        if (item.service.name[language] === service.name[language]) return item;
      });

      if (singleService && singleService.length === 1) {
        let totalQuantity = singleService[0].totalQuantity + service.quantity;
        let finalTotal = singleService[0].total + total;

        let updatedBooking = await Booking.findOneAndUpdate(
          { _id: bookingId },
          {
            $set: {
              services: {
                bookingId,
                service,
                dates: service.dates,
                totalQuantity: totalQuantity,
                total: finalTotal,
              },
            },
          },
          { new: true }
        );

        await HistoryService.create({ bookingId, service, isAdded: true });

        return {
          status: 200,
          message: "service.updated",
          booking: updatedBooking,
        };
      }
    }

    return {
      status: 200,
      message: "service.updated",
      booking,
    };
  };

  getPropertyRooms = async (singleProperty, noOfRooms, checkIn, checkOut) => {
    try {
      if (
        singleProperty &&
        singleProperty.rooms &&
        singleProperty.rooms.length < noOfRooms
      )
        return null;

      let bookings = await Booking.aggregate([
        {
          $match: {
            propertyId: singleProperty._id,
            // checkIn: { $gte: new Date(checkIn) },
            // checkOut: { $lte: new Date(checkOut) },
            $or: [
              {
                checkIn: {
                  $gte: new Date(checkIn),
                  $lte: new Date(checkOut),
                },
              },
              {
                checkOut: {
                  $gte: new Date(checkIn),
                  $lte: new Date(checkOut),
                },
              },
            ],
          },
        },
        {
          $group: {
            _id: "$property",
            obj: { $push: { rooms: "$rooms" } },
          },
        },
      ]);

      console.log("BOOKINGS ", bookings);

      let rooms = [];
      if (bookings && bookings.length > 0) {
        bookings[0].obj.forEach((item) => {
          if (item.rooms && item.rooms.length > 0)
            item.rooms.forEach((room) => {
              rooms.push(JSON.stringify(room));
            });
        });
        let uniqueSet = [...new Set(rooms)];
        let unBookedRooms = [];

        singleProperty.rooms.forEach((propertyRoom) => {
          if (!uniqueSet.includes(JSON.stringify(propertyRoom)))
            unBookedRooms.push(propertyRoom);
        });

        if (unBookedRooms.length >= noOfRooms) {
          let prop = singleProperty;
          prop.rooms = unBookedRooms;
          return prop;
        }
      } else return singleProperty;
    } catch (error) {
      console.log("ERROR IN PROPERTY ROOM", error);
      return null;
    }
  };

  getPropertiesFilter = async ({
    noOfRooms,
    checkIn,
    checkOut,
    properties,
  }) => {
    try {
      let props = [];

      properties.forEach(async (singleProperty) => {
        props.push(
          this.getPropertyRooms(singleProperty, noOfRooms, checkIn, checkOut)
        );
      });

      // TODO: NAME CHANGE OF availRoom TO AVAILABLE PROPERTIES
      let availRoom = [];
      let filterProps = await Promise.all(props);
      if (filterProps) {
        filterProps.forEach((item) => {
          if (item) availRoom.push(item);
        });
      }

      return {
        status: 200,
        message: "rooms.available",
        properties: availRoom,
      };
    } catch (error) {
      console.log("ERROR ", error);
      return {
        status: 400,
        error,
      };
    }
  };

  bookingLookUp = async ({ userId }, { language = "en" }) => {
    try {
      const token = await JWT.createOwnJWT();

      let booking = await Booking.findOne({
        "user.id": userId,
        status: "COMPLETED",
        reviewServed: false,
      })
        .sort({ createdAt: -1 })
        .limit(1)
        .select("_id propertyId checkIn checkOut");

      if (!booking)
        return {
          status: 404,
          message: "no.booking.found",
          response: null,
        };

      let property = await axios.get(
        `${process.env.PROPERTY_URL}/rating/booking-to-review?userId=${userId}&propertyId=${booking.propertyId}`,
        {
          method: "GET",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            language: language,
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (
        property &&
        property.status === 200 &&
        property.data &&
        property.data.response
      ) {
        const { data } = property;
        const res = {
          bookingId: booking["_id"],
          checkIn: booking["checkIn"],
          checkOut: booking["checkOut"],
          propertyId: data.response["propertyId"],
          propertyName: data.response["name"],
          propertyCoverImage: data.response["coverImage"],
          buildingId: data.response["buildingId"],
        };

        await Booking.findByIdAndUpdate(
          { _id: booking._id },
          { reviewServed: true },
          { new: true }
        );

        return {
          status: 200,
          response: res,
        };
      }

      return {
        status: 404,
        message: "no.booking.found",
        response: null,
      };
    } catch (error) {
      console.log("ERROR ", error);
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  };

  getCancellationDays = async () => {
    // let policy = await BookingPolicy.findOne({}).sort("-days").exec();
    let policy = await CancelPolicy.find({}).limit(1);

    if (policy && policy.length > 0) {
      const {
        cutOffDays,
        resetTimeToMidnight,
        freeHoursInsideCutoff,
        freeHoursOutsideCutoff,
      } = policy[0];
      return {
        status: 200,
        cancellationPolicy: {
          cutOffDays,
          resetTimeToMidnight,
          freeHoursInsideCutoff,
          freeHoursOutsideCutoff,
        },
      };
    } else
      return {
        status: 400,
        policy: null,
      };
  };

  calculateCancellationCharges = async ({ id }) => {
    let booking = await Booking.findOne({
      _id: id,
    });

    if (!booking)
      return {
        status: 400,
        message: "booking.not.found",
      };

    let cancelPolicy = await CancelPolicy.find({}).limit(1);
    if (!cancelPolicy && cancelPolicy.length === 0)
      return {
        status: 400,
        message: "no.cancellation.policy.exist",
      };
    const days = dateDifference(booking.checkIn, new Date().toISOString());

    // Default free
    let response = {
      status: 200,
      message: "free.cancellation.applied",
      days,
      totalBookingCost: booking.cost.totalBookingCost,
      roomCost: booking.cost.roomCost,
      deductedAmount: 0,
      refundedAmount: booking.cost.totalBookingCost,
    };

    let cutOffDate = new Date(booking.checkIn);

    let diffInHours =
      Math.abs(new Date(new Date()) - new Date(booking.createdAt)) / 36e5;

    if (cancelPolicy[0]["resetTimeToMidnight"]) cutOffDate.setHours(0, 0, 0, 0);
    cutOffDate.setDate(cutOffDate.getDate() - cancelPolicy[0]["cutOffDays"]); //cutOffDate is now 2 days in the past

    // Case 1 - Current time is less than CutOff time
    if (moment(new Date()) < moment(cutOffDate)) {
      return response;
    }

    // Case 2 - When hours are greater than FreeHoursInsideCutoff
    else if (
      diffInHours >= cancelPolicy[0]["freeHoursInsideCutoff"] &&
      Math.round(new Date(booking.createdAt) - cutOffDate) / 36e5 >
        cancelPolicy[0]["freeHoursInsideCutoff"]
    ) {
      // Overlapping case under discussion && (Math.round(new Date(booking.createdAt) - cutOffDate) / 36e5 < cancelPolicy[0]["freeHoursInsideCutoff"])
      response["deductedAmount"] = booking.propertyPrice;
      response["refundedAmount"] =
        booking.cost.totalBookingCost - booking.propertyPrice;
      response["message"] = "one.night.amount.deducted";
      return response;
    } else {
      return response;
    }

    // let deductedPercentage = 0;

    // const days = dateDifference(booking.checkIn, new Date().toISOString());

    // let policy = await BookingPolicy.findOne({ days: { $gte: days } })
    //   .sort({ days: 1 })
    //   .exec();

    // if (policy) deductedPercentage = policy.deductionPercentage;

    // let deductionAmount = booking.cost.roomCost * (deductedPercentage / 100);
    // let refundedAmount = booking.cost.totalBookingCost - deductionAmount;

    // return {
    //   status: 200,
    //   message: "booking.found",
    //   days,
    //   totalBookingCost: booking.cost.totalBookingCost,
    //   roomCost: booking.cost.roomCost,
    //   deductedAmount: deductionAmount,
    //   deductedPercentage: deductedPercentage,
    //   refundedAmount,
    // };
  };

  onCancelBooking = async ({ id }, { by, reason, byCustomer }) => {
    let bkng = await Booking.findOne({ _id: id });

    let cancel = {
      by,
      reason,
      byCustomer,
      date: new Date().toISOString(),
    };

    let cancelStats = await this.calculateCancellationCharges({ id });
    if (!cancelStats || cancelStats.status !== 200)
      return {
        status: 400,
        message: "booking.not.available",
      };

    cancel["deductedAmount"] = cancelStats.deductedAmount;
    cancel["refundedAmount"] = cancelStats.refundedAmount;
    // cancel["deductedPercentage"] = cancelStats.deductedPercentage; // need to be commented and add cancel at

    // if (booking.user.name !== by && reason) cancel["reason"] = reason;

    let update = await Booking.findOneAndUpdate(
      {
        _id: id,
      },
      {
        status: "CANCELLED",
        cancel,
      },
      { new: true }
    );

    if (byCustomer)
      await EmailService.sendEmail({
        obj: {
          action: "BOOKING_CANCEL_BY_USER",
          data: {
            to: bkng.user.email,
            orderId: bkng._id,
          },
        },
        language: bkng.user && bkng.user.language ? bkng.user.language : "en",
      });
    else
      await EmailService.sendEmail({
        obj: {
          action: "BOOKING_CANCEL_BY_ADMIN",
          data: {
            to: bkng.user.email,
            orderId: bkng._id,
          },
        },
        language: bkng.user && bkng.user.language ? bkng.user.language : "en",
      });

    return {
      status: 200,
      message: "booking.cancelled",
      update,
    };
  };

  getTopRatingBookingProperties = async ({ days = 1, limit = 1 }) => {
    try {
      let date = new Date();
      date.setDate(date.getDate() - days);

      let bookings = await Booking.aggregate([
        {
          $match: {
            createdAt: { $gte: date },
          },
        },
        {
          $group: {
            _id: "$propertyId",
            count: { $sum: 1 },
          },
        },
        { $sort: { count: -1 } },
        { $limit: limit },
      ]);

      console.log("BOOKING PROPERTIES ", bookings);

      return {
        status: 200,
        bookings,
      };
    } catch (error) {
      console.log("ERROR ", error);
      return Promise.reject({
        status: 500,
        message: "server.error",
        error,
      });
    }
  };
}

module.exports = new BookingService();
