const axios = require("../../utils/axios");

class EmailService {
  async sendEmail({ obj, language = "en" }) {
    try {
      let email = await axios.post(
        `${process.env.NOTIFICATION_URL}/notification/custom-email`,
        JSON.stringify(obj),
        {
          method: "POST",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            language,
          },
        }
      );

      const { data } = email;

      if (data && data.status === 200) return true;
      else return false;
    } catch (error) {
      return false;
    }
  }

  async createOrderEmail(order, to = []) {
    try {
      let obj = {
        action: "ORDER_CREATED",
        data: [
          {
            to: to,
            emailData: {
              order: order,
            },
          },
        ],
      };

      let response = await this.sendEmail({ obj });
      return response;
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }
}

module.exports = new EmailService();
