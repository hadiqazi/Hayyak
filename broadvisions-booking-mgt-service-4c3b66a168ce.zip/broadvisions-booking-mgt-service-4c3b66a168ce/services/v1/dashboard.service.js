const Booking = require("../../models").Booking;
const axios = require("../../utils/axios");
const BookingService = require("../v1/booking.service");
const JWT = require('../jwt.service')

class DashboardService {
  fetchPropertyAvgRating = async (date) => {
    try {
      const token = await JWT.createOwnJWT();
      let avgRating = await axios.get(
        `${process.env.PROPERTY_URL}/property/rating/avg?date=${date}`,
        {
          method: "GET",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (avgRating && avgRating.status === 200) {
        const { data } = avgRating;
        return data;
      }
      return null;
    } catch (error) {
      console.log("err ", error);
      return null;
    }
  };

  getDashboardStats = async ({ date = "WEEK" }, { language }) => {
    try {
      let dateFilter = new Date();
      let saleFilter = {
        $dateToString: {
          format: "%Y-%m-%d",
          date: "$createdAt",
        },
      };

      if (date === "WEEK") dateFilter.setDate(dateFilter.getDate() - 7);
      else if (date === "MONTH") dateFilter.setDate(dateFilter.getDate() - 30);
      else if (date === "YEAR") {
        dateFilter.setDate(dateFilter.getDate() - 365);
        saleFilter = {
          $month: "$createdAt",
        };
      }

      let stats = {
        ratingAvg: 0,
      };
      let bookstats = {
        active: 0,
        cancelled: 0,
        completed: 0,
        total: 0,
      };
      let bookcountstats = {
        active: 0,
        checkedIn: 0,
        checkedOut: 0,
        cancelled: 0,
      };

      // Fetching Booking Count Stats
      let bookingCountStats = await Booking.aggregate([
        {
          $facet: {
            cancelled: [
              {
                $match: {
                  status: "CANCELLED",
                  createdAt: { $gte: new Date(dateFilter) },
                },
              },
              { $count: "cancelled" },
            ],
            active: [
              {
                $match: {
                  status: "ACTIVE",
                  createdAt: { $gte: new Date(dateFilter) },
                },
              },
              { $count: "active" },
            ],
            completed: [
              {
                $match: {
                  status: "COMPLETED",
                  createdAt: { $gte: new Date(dateFilter) },
                },
              },
              { $count: "completed" },
            ],
            checkedIn: [
              {
                $match: {
                  checkIn: { $lte: new Date() },
                  createdAt: { $gte: new Date(dateFilter) },
                },
              },
              { $count: "checkedIn" },
            ],
            checkedOut: [
              {
                $match: {
                  checkOut: { $gte: new Date() },
                  createdAt: { $gte: new Date(dateFilter) },
                },
              },
              { $count: "checkedOut" },
            ],
          },
        },
        {
          $project: {
            cancelled: { $arrayElemAt: ["$cancelled.cancelled", 0] },
            active: { $arrayElemAt: ["$active.active", 0] },
            completed: { $arrayElemAt: ["$completed.completed", 0] },
            checkedIn: { $arrayElemAt: ["$checkedIn.checkedIn", 0] },
            checkedOut: { $arrayElemAt: ["$checkedOut.checkedOut", 0] },
          },
        },
      ]);

      if (bookingCountStats && bookingCountStats.length > 0) {
        let obj = bookingCountStats[0];

        if (obj.hasOwnProperty("cancelled")) {
          bookstats["cancelled"] = obj.cancelled;
          bookcountstats["cancelled"] = obj.cancelled;
          bookstats.total = bookstats.total + obj.cancelled;
        }

        if (obj.hasOwnProperty("active")) {
          bookstats["active"] = obj.active;
          bookcountstats["active"] = obj.active;
          bookstats.total = bookstats.total + obj.active;
        }

        if (obj.hasOwnProperty("completed")) {
          bookstats["completed"] = obj.completed;
          bookstats.total = bookstats.total + obj.completed;
        }

        if (obj.hasOwnProperty("checkedIn")) {
          bookcountstats["checkedIn"] = obj.checkedIn;
        }

        if (obj.hasOwnProperty("checkedOut")) {
          bookcountstats["checkedOut"] = obj.checkedOut;
        }
      }

      stats["bookingCountStats"] = bookcountstats;
      stats["bookingStatusStats"] = bookstats;

      // Fetching Properties Average Rating
      let avg = await this.fetchPropertyAvgRating(dateFilter);
      if (avg) stats["ratingAvg"] = avg.avg;

      // Fetching Sales Data
      let sales = await Booking.aggregate([
        { $match: { createdAt: { $gte: new Date(dateFilter) } } },
        {
          $group: {
            _id: saleFilter,
            // _id: {
            //   $dateToString: {
            //     format: "%Y-%m-%d",
            //     date: "$createdAt",
            //   },
            // },
            // _id: {
            //   $month: "$createdAt",
            // },
            value: { $sum: "$cost.totalBookingCost" },
          },
        },
        {
          $project: {
            key: "$_id",
            value: 1,
            _id: 0,
          },
        },
      ]);

      stats["salesGraphData"] = sales;

      // Fetching Booking Status Stats
      // let bookingStats = await Booking.aggregate([
      //   {
      //     $group: { _id: { status: "$status" }, count: { $sum: 1 } },
      //   },
      // ]);

      // if (bookingStats && bookingStats.length > 0) {
      //   let total = 0;
      //   bookingStats.forEach((stat) => {
      //     total = total + stat.count;
      //     if (stat._id.status === "ACTIVE") bookstats["active"] = stat.count;
      //     if (stat._id.status === "CANCELLED")
      //       bookstats["cancelled"] = stat.count;
      //     if (stat._id.status === "COMPLETED")
      //       bookstats["completed"] = stat.count;
      //   });
      //   bookstats["total"] = total;
      //   stats["bookingStatusStats"] = bookstats;
      // }

      // Fetching Latest 3 Bookings
      let recentBookings = await Booking.find({
        createdAt: { $gte: new Date(dateFilter) },
      })
        .sort({ createdAt: -1 })
        .limit(3)
        .select("bookingId cost.totalBookingCost user.name propertyId");

      // Merging Property Name, Cover Image and Building Name with Bookings
      let data = null;
      let updatedBooking = [];
      if (recentBookings) {
        let propertyIds = [];
        recentBookings.forEach((booking) => {
          propertyIds.push(booking.propertyId);
        });

        let uniqueIds = [...new Set(propertyIds)];
        data = await BookingService.getMultipleProperties({
          ids: uniqueIds,
          language,
          attributes: ["_id", "name", "coverImage", "building"],
        });

        if (data && data.length > 0) {
          recentBookings.map((book) => {
            data.forEach((prop) => {
              if (book.propertyId === prop._id) {
                updatedBooking.push({
                  ...book.toObject(),
                  property: {
                    ...prop,
                    building: {
                      name: prop.building.name,
                    },
                  },
                });
              }
            });
          });
        }
      }

      if (recentBookings) stats["recentBookings"] = updatedBooking;

      return {
        status: 200,
        stats,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  };
}

module.exports = new DashboardService();
