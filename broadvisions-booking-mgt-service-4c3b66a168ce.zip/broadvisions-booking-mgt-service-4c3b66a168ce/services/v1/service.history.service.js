const ServiceHistory = require("../../models").ServiceHistory;
const Booking = require("../../models").Booking;

class HistoryService {
  getAll = async () => {
    let histories = await ServiceHistory.find({});
    return {
      status: 200,
      histories,
    };
  };

  //TODO: ADD METHOD TO GET SERVICE HISTORY FOR SPECIFIC BOOKING ID AND FETCH SERVICE NAME FROM PROPERTY MGT SERVICE

  create = async ({ bookingId, service, isAdded }) => {
    let history = await ServiceHistory.create({
      bookingId,
      service,
      isAdded,
    });

    if (history) {
      await Booking.findOneAndUpdate(
        { _id: bookingId },
        { $push: { serviceHistory: history._id } }
      );
    }

    return {
      status: 200,
      history,
    };
  };
}

module.exports = new HistoryService();
