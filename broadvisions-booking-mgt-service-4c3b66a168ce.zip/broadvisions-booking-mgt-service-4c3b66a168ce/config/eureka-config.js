class EurekaConfig {

    get eurekaURL() {
        return process.env.EUREKA_URL;
    };

}

module.exports = new EurekaConfig();