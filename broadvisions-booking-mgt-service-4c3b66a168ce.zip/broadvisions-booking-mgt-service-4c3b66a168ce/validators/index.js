const BookingValidator = require("./booking-validator");
const DashboardValidator = require("./dashboard.validator");

module.exports = {
  BookingValidator,
  DashboardValidator,
};
