const Joi = require("joi");

class BookingValidator {
  create() {
    return Joi.object({
      propertyId: Joi.string().required(),
      checkIn: Joi.date(),
      checkOut: Joi.string(),
      rooms: Joi.number().required(),
      guest: Joi.object({
        name: Joi.string().required(),
        email: Joi.string()
          .email({ tlds: { allow: false } })
          .required(),
        phone: Joi.string().required(),
        dob: Joi.string(),
        country: Joi.string().required(),
      }).required(),
      vas: Joi.array().items(
        Joi.object().keys({
          id: Joi.string(),
          dates: Joi.array().items(Joi.date().iso().required()),
        })
      ),
    });
  }

  remove() {
    return Joi.object({
      id: Joi.string().required(),
    });
  }

  filter() {
    return Joi.object({
      bookingId: Joi.string(),
      status: Joi.string().valid(
        "ACTIVE",
        "CANCELLED",
        "COMPLETED",
        "UPCOMING",
        "CURRENT"
      ),
      page: Joi.number(),
      isDeleted: Joi.boolean(),
      sortOrder: Joi.string().valid("ASC", "DESC"),
      sortColumn: Joi.string(),
    });
  }

  propertyFilter() {
    return Joi.object({
      noOfRooms: Joi.number().required(),
      checkIn: Joi.string().required(),
      checkOut: Joi.string().required(),
      properties: Joi.array().required(),
    });
  }

  addService() {
    return Joi.object({
      bookingId: Joi.string().required(),
      service: Joi.object({
        id: Joi.string().required(),
        price: Joi.number().required(),
        quantity: Joi.number().required(),
        name: Joi.object({
          en: Joi.string().required(),
          ar: Joi.string().required(),
        }).required(),
      }).required(),
    });
  }

  lookup() {
    return Joi.object({
      userId: Joi.string().required(),
    });
  }

  cancel() {
    return Joi.object({
      id: Joi.string().required(),
      reason: Joi.string(),
    });
  }

  calculateCancel() {
    return Joi.object({
      id: Joi.string().required(),
    });
  }

  topBookings() {
    return Joi.object({
      days: Joi.number().required(),
      limit: Joi.number().required(),
    });
  }
}

module.exports = new BookingValidator();
