const Joi = require("joi");

class DashboardValidator {
  stats() {
    return Joi.object({
      date: Joi.string().valid("WEEK", "MONTH", "YEAR").required(),
    });
  }
}

module.exports = new DashboardValidator();
