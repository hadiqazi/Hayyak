const BOOKING_SCHEDULER = require("./booking.scheduler");

module.exports = {
  ...BOOKING_SCHEDULER,
};
