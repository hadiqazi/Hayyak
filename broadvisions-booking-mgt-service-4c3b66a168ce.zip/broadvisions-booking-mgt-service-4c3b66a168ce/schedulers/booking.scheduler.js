const CronJob = require("cron").CronJob;
const Booking = require("../models").Booking;
const EmailService = require("../services/v1/email.service");

// "0 */59 * * * *"

const bookingStatusAccept = new CronJob("0 */59 * * * *", async () => {
  try {
    console.log("Starting booking status CrobJob ", new Date());
    let ids = await Booking.find({
      checkOut: { $lte: new Date().toISOString() },
      status: "ACTIVE",
    }).select("_id user");

    console.log("IDS ", ids);

    await Booking.updateMany(
      { checkOut: { $lte: new Date().toISOString() }, status: "ACTIVE" },
      { $set: { status: "COMPLETED" } }
    );

    if (ids && ids.length > 0) {
      EmailService.sendEmail({
        obj: {
          action: "BOOKING_COMPLETED",
          data: {
            bookingIds: ids,
          },
        },
        language: "en",
      });
    }

    console.log("Ending booking status CrobJob ", new Date());
  } catch (error) {
    console.log("ERROR IN BOOKING STATUS CRON JOB ", error);
  }
});

module.exports = {
  bookingStatusAccept,
};
