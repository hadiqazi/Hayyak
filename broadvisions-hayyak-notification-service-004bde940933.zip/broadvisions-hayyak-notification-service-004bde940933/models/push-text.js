const mongoose = require("mongoose");

const pushTextSchema = new mongoose.Schema(
  {
    uuid: { type: String },
    name: { type: String },
    text: { type: String },
    title: { type: String },
    action: { type: String },
  },
  {
    timestamps: true,
    strict: true,
  }
);

module.exports = mongoose.model("PushText", pushTextSchema);
