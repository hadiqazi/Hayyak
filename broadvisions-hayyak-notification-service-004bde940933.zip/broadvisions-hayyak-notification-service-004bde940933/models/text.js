const mongoose = require("mongoose");

const textSchema = new mongoose.Schema(
  {
    uuid: { type: String },
    name: { type: String },
    eventText: { type: String },
    eventTrigger: { type: String },
    notificationText: { type: String },
    notificationType: { type: Number },
    templateName: { type: Number },
  },
  {
    timestamps: true,
    strict: true,
  }
);

module.exports = mongoose.model("Text", textSchema);
