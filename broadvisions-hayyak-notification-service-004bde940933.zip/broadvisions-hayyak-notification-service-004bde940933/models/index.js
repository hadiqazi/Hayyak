const Text = require("./text");
const PushText = require("./push-text");
const EmailTemplate = require("./email-template");

module.exports = {
  Text,
  PushText,
  EmailTemplate,
};
