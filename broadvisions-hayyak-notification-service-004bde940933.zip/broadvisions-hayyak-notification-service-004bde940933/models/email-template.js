const mongoose = require("mongoose");

const emailTemplateSchema = new mongoose.Schema(
  {
    uuid: { type: String },
    name: { type: String },
    action: { type: String },
    subject: { type: String },
    from: { type: String },
    template: { type: String },
  },
  {
    timestamps: true,
    strict: true,
  }
);

module.exports = mongoose.model("EmailTemplate", emailTemplateSchema);
