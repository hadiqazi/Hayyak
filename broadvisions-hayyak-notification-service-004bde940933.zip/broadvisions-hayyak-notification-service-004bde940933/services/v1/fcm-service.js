const { __ } = require("i18n");
const _ = require("lodash");
const axios = require("../../utils/axios");

class FcmService {
  async sendNotification(data) {
    try {
      let axiosOptions = {
        headers: {
          Authorization: `key=${process.env.FCM_SERVER_KEY}`,
        },
      };

      for (let i = 0; i < data.to.length; i++) {
        let fcmURL = "https://fcm.googleapis.com/fcm/send";

        let notificationData = {
          ...data.notification,
          to: data.to[i],
        };

        let fcmResult = await axios.post(
          fcmURL,
          notificationData,
          axiosOptions
        );
        console.log(`Notification Result:`);
        console.log(fcmResult.data);
      }

      return {
        status: 200,
        message: "Notification sent successfully.",
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }
}

module.exports = new FcmService();
