const client = require("twilio")(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);
const { __ } = require("i18n");
const _ = require("lodash");

class TwilioService {
  async prepareSendingMessages(body) {
    try {
      let msgResult = await this.sendMessage(
        "+923337831508",
        "Welcome to Twilio SMS."
      );
    } catch (error) {
      console.log(error);
    }
  }

  async sendMessage(to, message) {
    try {
      let messageResult = await client.messages.create({
        body: message,
        from: process.env.TWILIO_NUMBER,
        to,
      });

      console.log(messageResult);
      return {
        status: 200,
        messageCode: __("sms.sent"),
        message: message,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        messageCode: "server.error",
        error,
      });
    }
  }
}

module.exports = new TwilioService();
