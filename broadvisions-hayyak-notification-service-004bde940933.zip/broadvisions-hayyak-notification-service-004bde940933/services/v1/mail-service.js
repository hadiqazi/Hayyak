const nodemailer = require("nodemailer");
const inlineBase64 = require("nodemailer-plugin-inline-base64");
const fs = require("fs");
const path = require("path");
const _ = require("lodash");
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: +process.env.SMTP_PORT,
  secure: "true" === false, // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

class MailService {
  async parseEmailsData(emailData) {
    //parse and loop for the emails that are to be sent
    try {
      let data = emailData.data;
      for (let j = 0; j < data.length; j++) {
        let singleData = data[j];
        for (let i = 0; i < singleData.to.length; i++) {
          let html = "";
          if (_.isEqual("User-Password.html", singleData.template)) {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../templates/${singleData.template}`),
              "utf8"
            );
            html = html.replace("##EMAIL##", singleData.data.email);
            html = html.replace("##WORKSPACE##", singleData.data.workspace);
            html = html.replace("##PASSWORD##", singleData.data.password);
          } else if (
            _.isEqual("welcome_email_english.html", singleData.template)
          ) {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../templates/${singleData.template}`),
              "utf8"
            );
            html = html.replace("##NAME##", singleData.data.name);
            html = html.replace("##EMAIL##", singleData.data.email);
            html = html.replace("##WORKSPACE##", singleData.data.workspace);
            html = html.replace("##PASSWORD##", singleData.data.password);
          } else if (_.isEqual("Reset-Password.html", singleData.template)) {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../templates/${singleData.template}`),
              "utf8"
            );
            html = html.replace("##PASSWORD##", singleData.data.password);
          } else if (
            _.isEqual("forgot_password_english.html", singleData.template)
          ) {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../templates/${singleData.template}`),
              "utf8"
            );
            html = html.replace("##PASSWORD##", singleData.data.password);
            html = html.replace("##NAME##", singleData.data.name);
          } else if (_.isEqual("Email-Template.html", singleData.template)) {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../templates/${singleData.template}`),
              "utf8"
            );
            html = html.replace("##VERIFICATION_LINK##", singleData.data.link);
          } else if (
            _.isEqual("publish_course_english.html", singleData.template)
          ) {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../templates/${singleData.template}`),
              "utf8"
            );
            html = html.replace("##NAME##", singleData.data.user_name);
            html = html.replace(
              "##CampaignName##",
              singleData.data.campaignContent.campaign.campaignName
            );
            html = html.replace(
              "##Description##",
              singleData.data.campaignContent.campaign.campaignDescription
            );
          } else if (_.isEqual("campaign-publish.html", singleData.template)) {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../templates/${singleData.template}`),
              "utf8"
            );
            html = html.replace("##name##", singleData.data.user_name);
            html = html.replace(
              "##campaignName##",
              singleData.data.campaignContent.campaign.campaignName
            );
            html = html.replace(
              "##campaignName2##",
              singleData.data.campaignContent.campaign.campaignName
            );
            html = html.replace(
              "##Description##",
              singleData.data.campaignContent.campaign.campaignDescription
            );
            html = html.replace("##startDate##", singleData.data.startDate);
            html = html.replace(
              "##endDate##",
              singleData.data.endDate === null
                ? "Forever"
                : singleData.data.endDate
            );

            let themesAndCategoriesContentLinks =
              singleData.data.campaignContent.campaign.themes;

            let list = ``;
            list += ` <ul class="list-style outer-list">`;
            for (let theme of themesAndCategoriesContentLinks) {
              list += ` <li> ${theme.themeName}`;
              list += ` <ul class="list-style">`;
              for (let category of theme.categories) {
                list += ` <li> ${category.categoryName}`;
                list += ` <ul class="list-style">`;
                let links = category.categoryContentLink;
                for (let link of links) {
                  list += ` <li>`;
                  list += ` <a href="${link.split(";")[0]}"> ${
                    link.split(";")[1] === undefined
                      ? "Default"
                      : link.split(";")[1]
                  } </a>`;
                  list += ` </li>`;
                }
                list += ` </ul>`;
                list += ` </li>`;
              }
              list += ` </ul>`;
              list += ` </li>`;
            }
            list += ` </ul>`;

            html = html.replace("##listing##", list);
          }

          this.sendEmail(
            singleData.to[i],
            singleData.from,
            singleData.subject,
            html
          );
        }
      }

      return {
        status: 200,
        message: "Emails have been queued for sending.",
      };
    } catch (error) {
      console.log(error);

      return Promise.reject({
        status: 400,
        message: "Error parsing email data format.",
        error,
      });
    }
  }

  async sendEmailCustomTemplate(
    emailData,
    templateName,
    action,
    subject,
    from,
    orgName
  ) {
    //parse and loop for the emails that are to be sent
    try {
      let data = emailData;
      for (let j = 0; j < data.length; j++) {
        let singleData = data[j];
        for (let i = 0; i < singleData.to.length; i++) {
          let message = "";
          let html = "";
          html = fs.readFileSync(
            path.join(__dirname, "/", `../../templates/${templateName}`),
            "utf8"
          );

          if (action == "INVOICE") {
            let itemsHTML = "";
            for (let singleItem of singleData.data.order.orderItems) {
              let singleItemHTML = `<tr class="item last"><td>${singleItem.name}</td><td>${singleItem.price}</td></tr> <br>`;

              itemsHTML += singleItemHTML;
            }
            html = html.replace("##ITEMS_LIST##", itemsHTML);
          }
          if (action == "FORGOT_PASSWORD") {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../../templates/${templateName}`),
              "utf8"
            );
            html = html.replace("##PASSWORD##", singleData.data.password);
            html = html.replace("##NAME##", singleData.data.name);
          } else if (action == "WELCOME") {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../templates/${templateName}`),
              "utf8"
            );
            html = html.replace("##NAME##", singleData.data.name);
            html = html.replace("##EMAIL##", singleData.data.email);
            html = html.replace("##WORKSPACE##", singleData.data.workspace);
            html = html.replace("##PASSWORD##", singleData.data.password);
          } else if (action == "COURSE_ASSIGN") {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../templates/${templateName}`),
              "utf8"
            );
            html = html.replace("##NAME##", singleData.data.user_name);
            html = html.replace(
              "##CAMPAIGNNAME##",
              singleData.data.campaignContent.campaign.campaignName
            );
            html = html.replace(
              "##DESCRIPTION##",
              singleData.data.campaignContent.campaign.campaignDescription
            );
            html = html.replace(
              "##COMPLETIONRULES##",
              singleData.data.campaignContent.campaign.completion
            );
            html = html.replace(
              "##TIMELIMIT##",
              singleData.data.campaignContent.campaign.timeLimit
            );
          } else if (action === "ORDER_CREATED") {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../../templates/${templateName}`),
              "utf8"
            );

            let {
              _id,
              address,
              paymentId,
              createdAt,
              email,
              orderPrice,
              paymentMode,
              userId,
              orderItems,
              orderStatus,
            } = singleData.emailData.order;

            html = html.replace("##ORDER_ID##", _id);
            html = html.replace("##CREATED_AT##", createdAt);
            html = html.replace("##EMAIL##", email);
            html = html.replace("##ADDRESS##", address);
            // html = html.replace("##USER_NAME##", userId);
            html = html.replace("##EMAIL##", email);
            html = html.replace("##PAYMENT_METHOD##", paymentMode);
            html = html.replace("##PAYMENT_ID##", paymentId);
            html = html.replace("##PAYMENT_MODE##", paymentMode);
            html = html.replace("##GRAND_TOTAL##", orderPrice);
            html = html.replace("##STATUS##", orderStatus);

            let itemsHTML = "";
            orderItems.forEach((singleItem) => {
              const {
                product: { name, saleActive, salePrice, regularPrice },
              } = singleItem;
              console.log("NAME ", name);
              let singleItemHTML = `<tr class="item last"><td>${name}</td><td>${
                saleActive ? salePrice : regularPrice
              }</td></tr> <br>`;

              itemsHTML += singleItemHTML;
            });

            html = html.replace("##ITEMS_LIST##", itemsHTML);
            message = "Feedy Order Success";
          } else if (action === "WELCOME_FEEDY") {
            html = fs.readFileSync(
              path.join(__dirname, "/", `../../templates/${templateName}`),
              "utf8"
            );

            let { verificationlink } = singleData.emailData;
            html = html.replace("##ACTION_URL##", verificationlink);
            message = "Feedy Welcome";
          }

          this.sendEmail(singleData.to[i], from, message, html)
            .then(() => {
              console.log("Email Sent Successfully.");
            })
            .catch((error) => {
              console.error(error);
            });
        }
      }

      return {
        status: 200,
        message: "Emails have been queued for sending.",
      };
    } catch (error) {
      return Promise.reject({
        status: 400,
        message: "Error parsing email data format.",
        error,
      });
    }
  }

  sendEmail(to, from, subject, html) {
    return new Promise((resolve, reject) => {
      // setup email data with unicode symbols
      let mailOptions = {
        from, // sender address
        to, // list of receivers
        subject, // Subject line
        html,
      };

      transporter.use("compile", inlineBase64());
      // send mail with defined transport object
      transporter.sendMail(mailOptions, (error) => {
        if (error) {
          console.error(error);
          reject({ _message: "Unable to send Email OTP", status: 500, error });
        } else {
          resolve();
        }
      });
    });
  }
}
module.exports = new MailService();
