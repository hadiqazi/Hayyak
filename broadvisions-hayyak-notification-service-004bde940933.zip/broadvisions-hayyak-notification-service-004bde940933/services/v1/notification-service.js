const _ = require("lodash");

const FcmService = require("./fcm-service");
const MailService = require("./mail-service");
const { PushText, EmailTemplate } = require("../../models");

class NotificationService {
  async getNotificationTextForEventTrigger(data) {
    try {
      let notificationPushTextResult = await PushText.findOne({
        where: {
          action: data.action,
        },
      });

      if (_.isNull(notificationPushTextResult)) {
        let result = {
          status: 404,
          message: "Notification Push Text Not Found!",
        };
        return result;
      }

      return {
        status: 200,
        message: "Notification Push Text Found!",
        notificationPushTextResult: notificationPushTextResult,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "Error occurred while sending the call",
        error,
      });
    }
  }

  async getNotificationEmailTemplateForAction(action) {
    try {
      let notificationEmailResult = await EmailTemplate.findOne({
        action: action,
      });

      if (_.isNull(notificationEmailResult)) {
        let result = {
          status: 404,
          message: "Notification Email Template Not Found!",
        };
        return result;
      }

      return {
        status: 200,
        message: "Notification Email Template Found!",
        notificationEmailResult: notificationEmailResult,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "Error occurred while sending the call",
        error,
      });
    }
  }

  async sendCustomPush(data) {
    try {
      let notificationData = await this.getNotificationTextForEventTrigger(
        data
      );

      let pushText = notificationData.notificationPushTextResult.text;
      let pushTitle = notificationData.notificationPushTextResult.title;

      let notification = data.notification;
      notification.notification.title = pushTitle;
      notification.notification.body = pushText;

      notification.notification.title = notification.notification.title.replace(
        "##ORGNAME##",
        data.orgName
      );

      console.log(data.notification);

      let fcmData = {
        to: data.to,
        notification,
      };

      FcmService.sendNotification(fcmData);

      return {
        status: 200,
        message: "Notification Prepared!",
        notification,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "Error occurred while sending the call",
        error,
      });
    }
  }

  async sendCustomEmails({ action, data }) {
    try {
      let notificationData = await this.getNotificationEmailTemplateForAction(
        action
      );

      let templateName = notificationData.notificationEmailResult.template;
      let from = notificationData.notificationEmailResult.from;
      let subject = notificationData.notificationEmailResult.subject;

      MailService.sendEmailCustomTemplate(
        data,
        templateName,
        action,
        subject,
        from,
        ""
      );

      return {
        status: 200,
        message: "Emails Prepared!",
        notificationEmail: notificationData.notificationEmailResult,
      };
    } catch (error) {
      return Promise.reject({
        status: 500,
        message: "Error occurred while sending the call",
        error,
      });
    }
  }
}
module.exports = new NotificationService();
