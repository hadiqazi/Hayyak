module.exports = {
  mongodb:
    process.env.MONGO_CONNECTION_STRING ||
    "mongodb+srv://feedy-dev:lKCyolfkbsBPCjuZ@dev.qlnud.mongodb.net/feedy-dev?retryWrites=true&w=majority",
};
