const { Router } = require("express");
const router = Router();
const { handleRouteError } = require("../../../utils/common-utils");
const {
  NotificationService,
  MailService,
  FcmService,
} = require("../../../services/v1");

router.get("/", async (req, res) => {
  res.status(200).send({
    message: "Welcome to the beginning of nothingness.",
  });
});

router.post("/trigger-notification", async (req, resp) => {
  try {
    NotificationService.getNotificationTextForEventTrigger(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/custom-push", async (req, resp) => {
  try {
    NotificationService.sendCustomPush(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/custom-email", async (req, resp) => {
  try {
    NotificationService.sendCustomEmails(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/send-email", async (req, resp) => {
  try {
    MailService.parseEmailsData(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

router.post("/send-notification", async (req, resp) => {
  try {
    FcmService.sendNotification(req.body)
      .then((result) => {
        resp.status(result.status).send(result);
      })
      .catch(handleRouteError(resp));
  } catch (error) {
    handleRouteError(resp)({
      status: 403,
      message: __("mandatory.fields"),
      error,
    });
  }
});

module.exports = router;
