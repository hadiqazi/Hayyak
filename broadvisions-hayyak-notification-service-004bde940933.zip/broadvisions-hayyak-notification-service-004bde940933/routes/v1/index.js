const { Router } = require("express");

// const orderRoutes = require("./order-routes");
const notificationRoutes = require('./notification-routes')

const setup = (app) => {
  const router = Router();

  // router.use("/order", orderRoutes);
  router.use('/notification', notificationRoutes)

  // this should be the last line
  app.use("/v1", router);
};

module.exports = setup;
