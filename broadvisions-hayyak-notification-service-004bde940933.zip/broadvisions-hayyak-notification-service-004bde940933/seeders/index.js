const fs = require("fs");
const exec = require("child_process").exec;

const async = require("async"); // npm install async

const scriptsFolder = "./seeders/"; // add your scripts to folder named scripts

const files = fs.readdirSync(scriptsFolder); // reading files from folders
const funcs = [];
files.forEach(function (file) {
  if (file !== "index.js")
    funcs.push(exec.bind(null, `node ${scriptsFolder}${file}`)); // execute node command
});

// to run your scipts in parallel use
async.parallel(funcs, () => {
  console.log("Seeders Generated");
});
