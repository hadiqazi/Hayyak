const seeder = require("mongoose-seed");
const uuid = require("uuid");
const { mongodb } = require("../config/keys");
const db = mongodb;

const document = [
  {
    uuid: uuid(),
    name: "Course Assigned",
    text: "Lycka till!",
    title: "##ORGNAME## - Du har blivit tilldelad en ny kurs.",
    action: "COURSE_ASSIGN",
  },
  {
    uuid: uuid(),
    name: "Challenge Request",
    text: "Lycka till!",
    title: "##ORGNAME## - Du har blivit utmanad av en vän i kunskap!",
    action: "CHALLENGE_REQUEST",
  },
];

const getSeedingData = async () => {
  try {
    return [
      {
        model: "PushText",
        documents: document,
      },
    ];
  } catch (err) {
    console.log("Error while seeding ", err);
    return [];
  }
};

seeder.connect(db, function () {
  seeder.loadModels(["models/push-text.js"]);
  seeder.clearModels(["PushText"], async () => {
    seeder.populateModels(await getSeedingData(), function () {
      seeder.disconnect();
    });
  });
});
