const seeder = require("mongoose-seed");
const uuid = require("uuid");
const { mongodb } = require("../config/keys");
const db = mongodb;

const document = [
  {
    uuid: uuid(),
    name: "Forgot Password",
    action: "FORGOT_PASSWORD",
    subject: "##ORGNAME## - Här kommer ditt nya lösenord!",
    from: "no-reply@weareiapps.com",
    template: "general/swedish/forgot_password.html",
  },
  {
    uuid: uuid(),
    name: "New User",
    action: "WELCOME",
    subject: "##ORGNAME## - Välkommen till din nya lärplattform!",
    from: "no-reply@weareiapps.com",
    template: "general/swedish/welcome.html",
  },
  {
    uuid: uuid(),
    name: "Course Assign",
    action: "COURSE_ASSIGN",
    subject: "##ORGNAME## - Du har blivit tilldelad en ny kurs!",
    from: "no-reply@weareiapps.com",
    template: "general/swedish/course_assign.html",
  },
];

const getSeedingData = async () => {
  try {
    return [
      {
        model: "EmailTemplate",
        documents: document,
      },
    ];
  } catch (err) {
    console.log("Error while seeding ", err);
    return [];
  }
};

seeder.connect(db, function () {
  seeder.loadModels(["models/email-template.js"]);
  seeder.clearModels(["EmailTemplate"], async () => {
    seeder.populateModels(await getSeedingData(), function () {
      seeder.disconnect();
    });
  });
});
