const _axios = require('axios');
const _ = require('lodash');
const pickRandom = require('pick-random');
const isPortReachable = require('is-port-reachable');

const fetchHost = async (serviceName) => {
  console.time('fetchHost');

  const getPort = (instance) => {
    return instance.securePort['@enabled'] === 'true' ? instance.securePort['$'] : instance.port['$'];
  };

  const instances = eurekaClient.getInstancesByAppId(serviceName.toUpperCase());



  // Filter based on what is UP
  const activeInstances = [];
  if (!_.isEmpty(instances)) {
    for (let index = 0; index < instances.length; index++) {
      const instance = instances[index];
      const __port = getPort(instance);
      console.log('Port', __port);
      console.time("CheckingPort");
      const reachable = await isPortReachable(__port, { host: instance.hostName });
      console.timeEnd("CheckingPort");

      if (reachable) {
        activeInstances.push(instance);
      }
    }
  }

  console.timeEnd('fetchHost');


  if (_.isEmpty(activeInstances)) {
    throw new Error(`No active instances of service ${serviceName} found`);
  }

  const availableUrls = activeInstances.map(instance => {
    const protocol = instance.securePort['@enabled'] === 'true' ? 'https' : 'http';
    const { hostName } = instance;
    const port = protocol === 'https' ? instance.securePort['$'] : instance.port['$'];

    return `${protocol}://${hostName}:${port}`;
  });

  console.log('Available Urls for service ', serviceName, availableUrls);

  const pickedUrl = pickRandom(availableUrls, { count: 1 })[0];

  console.log('Picked Url for service ', serviceName, pickedUrl);


  return pickedUrl;
};

const getUrl = async (host) => {
  if (host.startsWith('http')) {
    return host;
  }

  let urlParts = host.split('/');
  let fetchedHost = await fetchHost(urlParts.shift());
  const finalUrl = fetchedHost + '/' + urlParts.join('/');

  console.log('finalUrl', finalUrl);

  return finalUrl;
};

const prepareAxios = {
  get: async (url, options) => {
    let _url = await getUrl(url);
    return _axios.get(_url, options);
  },
  delete: async (url, options) => {
    let _url = await getUrl(url);
    return _axios.delete(_url, options);
  },
  post: async (url, body, options) => {
    let _url = await getUrl(url);
    return _axios.post(_url, body, options);
  },
  put: async (url, body, options) => {
    let _url = await getUrl(url);
    return _axios.put(_url, body, options);
  }
};

module.exports = prepareAxios;