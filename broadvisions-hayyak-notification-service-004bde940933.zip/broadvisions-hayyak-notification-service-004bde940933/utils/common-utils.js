const _ = require('lodash');

const GENERAL_ERROR_CODE = "server.error";
const BAD_REQ_ERROR_CODE = "bad.request";

const handleRouteError = (resp) => {
    return (error) => {
        logErrorDetails(error);

        if (isBadRequestError(error)) {
            sendBadRequestResponse(error, resp);
        } else {
            sendGeneralErrorResponse(resp);
        }
    };
};

const logErrorDetails = (error) => {
    console.error(error);
};

const isBadRequestError = (error) => {
    return !_.isEmpty(error) && _.isFinite(error.status) && error.status >= 400 && error.status < 500;
};

const sendBadRequestResponse = (error, resp) => {
    const messageCode = _.isEmpty(error.messageCode) ? BAD_REQ_ERROR_CODE : error.messageCode;
    // resp.status(error.status).send({status: error.status, message: resp.__(messageCode), error});
    resp.status(error.status).send({status: error.status, message: 'BAD_REQUEST', error});
};

const sendGeneralErrorResponse = (resp) => {
    // resp.status(500).send({status: 500, message: resp.__(GENERAL_ERROR_CODE)});
    resp.status(500).send({status: 500, message: 'GENERAL_ERROR'});
};

module.exports = {
    handleRouteError
};