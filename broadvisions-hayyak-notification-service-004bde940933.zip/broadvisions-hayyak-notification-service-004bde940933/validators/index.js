const NotificationValidator = require("./notification.validator");

module.exports = {
  NotificationValidator,
};
