const Joi = require("joi");

class OrderValidator {
  create() {
    return Joi.object({
      userId: Joi.number().required(),
      address: Joi.string().required(),
      paymentMode: Joi.string().required(),
      orderType: Joi.string().required(),
      storeId: Joi.number().required(),
      // originalPrice: Joi.number().required(),
      // orderPrice: Joi.number().required(),
      // discount: Joi.number().required(),
      // vat: Joi.number().required(),
      // invoicePrice: Joi.number().required(),
      // paymentId: Joi.number().required(),
      // chargedPrice: Joi.number().required(),
      // orderStatus: Joi.string().required(),
      // products: Joi.array().required(),
      // quantity: Joi.number().required(),
      // replacementCriteria: Joi.number().required(),
    });
  }

  orderStatus() {
    return Joi.object({
      status: Joi.string().required(),
      id: Joi.string().required(),
    });
  }

  find() {
    return Joi.object({
      cases: Joi.string().required(),
      storeId: Joi.number(),
      orderId: Joi.string(),
      userId: Joi.number(),
    });
  }

  update() {
    return Joi.object({
      id: Joi.string().required(),
      chargedPrice: Joi.number(),
      paymentId: Joi.string(),
      paymentMode: Joi.string(),
      orderType: Joi.string(),
      address: Joi.string(),
      invoicePrice: Joi.number(),
      vat: Joi.number(),
      code: Joi.string(),
      discount: Joi.number(),
      orderPrice: Joi.number(),
      originalPrice: Joi.number(),
    });
  }
}

module.exports = new OrderValidator();
