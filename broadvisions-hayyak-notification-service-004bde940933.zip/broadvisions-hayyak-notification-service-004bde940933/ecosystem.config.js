module.exports = {
    apps: [{
        name: 'feedy-notification-service',
        script: 'app.js',
        // Options reference: https://pm2.io/doc/en/runtime/reference/ecosystem-file/
        args: 'one two',
        instances: 1,
        autorestart: true,
        watch: false,
        max_memory_restart: '1G',
        env: {
            APP_NAME:"feedy-notification-service",
            PORT: 8006,
            NODE_ENV: "development",
            EUREKA_URL:"http://localhost:8761/eureka",
            PRIVATE_KEY_PATH:'/etc/keys/feedy_dev.key',
            PUBLIC_KEY_PATH:'/etc/keys/feedy_dev_public.key',
            BASE_URL:'http://localhost:8080/',
            MONGO_CONNECTION_STRING:"mongodb+srv://feedy-dev:lKCyolfkbsBPCjuZ@dev.qlnud.mongodb.net/feedy-dev?retryWrites=true&w=majority",
            FCM_SERVER_KEY:'AAAAhoRltRg:APA91bE5P9YbWuTSuTB_ZqHDdA-5InU5MXgahnByoa7_M2pG9_ZuheSKUIz7XKAc85Uhn1WTCOvoSdOHPRpzo87NVhCfggAecgdIF4rwOViOBwKiuyMiaJb02_0HHOToOWGIlToGJZRC',
            TWILIO_ACCOUNT_SID:'ACab4bd8daaab424091ac19f4b75e759b6',
            TWILIO_AUTH_TOKEN:'d16f9fe26a24547816ac5530e54204c6',
            TWILIO_NUMBER:"+12563636682",
            SMTP_HOST:'mailcluster.loopia.se',
            SMTP_PORT:587,
            SMTP_USER:'noreply@weareiapps.com',
            SMTP_PASS:'Iapps@2019'
        },
        env_development: {
            APP_NAME:"feedy-notification-service",
            PORT: 8006,
            NODE_ENV: "development",
            EUREKA_URL:"http://localhost:8761/eureka",
            PRIVATE_KEY_PATH:'/etc/keys/feedy_dev.key',
            PUBLIC_KEY_PATH:'/etc/keys/feedy_dev_public.key',
            BASE_URL:'http://localhost:8080/',
            MONGO_CONNECTION_STRING:"mongodb+srv://feedy-dev:lKCyolfkbsBPCjuZ@dev.qlnud.mongodb.net/feedy-dev?retryWrites=true&w=majority",
            FCM_SERVER_KEY:'AAAAhoRltRg:APA91bE5P9YbWuTSuTB_ZqHDdA-5InU5MXgahnByoa7_M2pG9_ZuheSKUIz7XKAc85Uhn1WTCOvoSdOHPRpzo87NVhCfggAecgdIF4rwOViOBwKiuyMiaJb02_0HHOToOWGIlToGJZRC',
            TWILIO_ACCOUNT_SID:'ACab4bd8daaab424091ac19f4b75e759b6',
            TWILIO_AUTH_TOKEN:'d16f9fe26a24547816ac5530e54204c6',
            TWILIO_NUMBER:"+12563636682",
            SMTP_HOST:'mailcluster.loopia.se',
            SMTP_PORT:587,
            SMTP_USER:'noreply@weareiapps.com',
            SMTP_PASS:'Iapps@2019'
        },
        env_staging: {
            APP_NAME:"boilerplate-user-service",
            NODE_ENV: "development",
            PORT: 8000,
            EUREKA_URL:"http://localhost:8761/eureka",
            PRIVATE_KEY_PATH:'/etc/keys/feedy_dev.key',
            PUBLIC_KEY_PATH:'/etc/keys/feedy_dev_public.key'
        },
        env_production: {
            APP_NAME:"boilerplate-user-service",
            NODE_ENV: "development",
            PORT: 8000,
            EUREKA_URL:"http://localhost:8761/eureka",
            PRIVATE_KEY_PATH:'/etc/keys/feedy_dev.key',
            PUBLIC_KEY_PATH:'/etc/keys/feedy_dev_public.key'
        }
    }],
    deploy: {
    }
}