package sa.com.hayyak.android

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
