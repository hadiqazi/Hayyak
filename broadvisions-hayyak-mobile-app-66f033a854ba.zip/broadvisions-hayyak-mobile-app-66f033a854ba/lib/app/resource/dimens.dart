/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'dart:io';

import 'package:flutter/material.dart';

class Dimens {
  final screenPadding = EdgeInsets.symmetric(horizontal: 20, vertical: 16);
  final screenFormPadding = 24.0;
  final screenListPadding = 8.0;

  final formFieldsMargin = 8.0;
  final bottomBarMargin = Platform.isIOS ? 96.0 : 80.0;
  final roundedCornerSize = 11.0;
  final appBarEndMargin = 8.0;

  final buttonHeight = 56.0;
  final minButtonWidth = 104.0;
  final smallButtonWidth = 56.0;
  final overlayTopMargin = Platform.isIOS ? 48.0 : 32.0;

  final socialIconSize = 48.0;
  final roundThumbnailSize = 80.0;
}
