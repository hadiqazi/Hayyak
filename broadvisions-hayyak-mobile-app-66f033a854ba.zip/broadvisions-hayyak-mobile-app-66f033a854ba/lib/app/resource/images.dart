/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 04/11/2021
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';
import 'package:hayyak/view/utils/utils.dart';

class Images {
  static const _imagePath = 'assets/images/';

  // ===== DEFAULTS ===== //
  final defaultPlaceholder = '${_imagePath}loader_image.gif';
  final imageLoader = '${_imagePath}loader_image.gif';

  // ===== GENERICS ===== //
  final emptyData = '${_imagePath}data_empty.svg';
  final errorInData = '${_imagePath}data_error.svg';

  // ========== //
  String authDecoration(BuildContext context) =>
      _getLocalizedResource(context, 'auth_decoration', 'svg');

  final splashLogo = '${_imagePath}splash_logo.gif';
  final loader = '${_imagePath}loader.gif';
  final facebook = '${_imagePath}social_facebook.svg';
  final google = '${_imagePath}social_google.svg';
  final apple = '${_imagePath}social_apple.svg';
  final homeLogo = '${_imagePath}home_logo.svg';

  final city = '${_imagePath}cities/';
  final starFull = '${_imagePath}star_full.svg';
  final starHalf = '${_imagePath}star_half.svg';
  final starEmpty = '${_imagePath}star_empty.svg';

  final profilePic = '${_imagePath}default_dp.png';
  final emptyBookings = '${_imagePath}no_bookings.svg';
  final cancelBooking = '${_imagePath}cancel_booking.svg';
  final bookingComplete = '${_imagePath}booking_complete.svg';

  // ============================== //

  String _getLocalizedResource(BuildContext context, String name, String extension) {
    String language = Utils.getCurrentLanguage(context);
    return '$_imagePath${name}_$language.$extension';
  }
}
