/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 04/11/2021
            Project: flutter_foundation
 */

import 'package:hayyak/app/resource/dimens.dart';
import 'package:hayyak/app/resource/images.dart';

class Assets {
  Assets._();

  static var image = Images();
  static var dimens = Dimens();
}
