/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

enum ScreenState {
  /// No action performed yet
  DEFAULT,

  /// Screen is in loading state
  LOADING,

  /// Action completed with success
  SUCCESS,

  /// Action completed with error
  ERROR
}
