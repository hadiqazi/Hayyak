/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'dart:collection';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class Cache {
  Cache._();

  static HashMap<String, dynamic> _data = HashMap();

  static void clear() {
    _data.clear();
  }

  static void put(String key, dynamic value, {bool persist = false}) async {
    assert(value != null);

    // Store value in cache
    _data[key] = value;

    // Save value in preferences if memoryOnly is false
    if (persist) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      if (value is bool)
        prefs.setBool(key, value);
      else if (value is int)
        prefs.setInt(key, value);
      else if (value is double)
        prefs.setDouble(key, value);
      else if (value is String)
        prefs.setString(key, value);
      else
        prefs.setObject(key, value);
    }
  }

  static Future<dynamic> get(String key) async {
    // Get value from cache
    dynamic value = _data[key];

    if (value == null) {
      // If value is not found in cache, get it from preferences
      SharedPreferences prefs = await SharedPreferences.getInstance();
      try {
        value = prefs.get(key);
      } catch (e) {
        value = await prefs.getObject(key);
      }
    }
    return value;
  }

  static void remove(String key) async {
    // Remove value from cache
    _data.remove(key);

    // Remove value from preferences
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove(key);
  }
}

extension DataHandling on SharedPreferences {
  /// Store an object in preferences
  void setObject(String key, Object object) async {
    String json = jsonEncode(object);
    setString(key, json);
  }

  /// Retrieve an object from preferences
  Future<dynamic> getObject(String key) async {
    String? json = getString(key);

    if (json == null) return null;

    return jsonDecode(json);
  }
}
