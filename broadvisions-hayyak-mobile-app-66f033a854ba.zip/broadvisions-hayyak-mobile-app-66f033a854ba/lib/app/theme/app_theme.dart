/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';

import '/app/theme/light/light_theme.dart';

class AppTheme {
  AppTheme._();

  static const fontFamily = 'ReadexPro';

  // ========== WIDGET THEMES ========== //
  static final buttonTheme = ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      primary: LightTheme.colorScheme.primary,
      onPrimary: LightTheme.colorScheme.onPrimary,
    ),
  );

  static final chipTheme = ChipThemeData(
    shape: StadiumBorder(
      side: BorderSide(color: LightTheme.borderColor),
    ),
    backgroundColor: LightTheme.colorScheme.surface,
    selectedColor: LightTheme.colorScheme.primary,
    labelStyle: textTheme.caption?.copyWith(color: Colors.black),
    pressElevation: 2,
    showCheckmark: false,
  );

  // ========== TEXT THEME ========== //

  static const textTheme = TextTheme(
    headline1: TextStyle(
      fontFamily: fontFamily,
      fontSize: 97,
      fontWeight: FontWeight.w300,
      letterSpacing: -1.5,
    ),
    headline2: TextStyle(
      fontFamily: fontFamily,
      fontSize: 61,
      fontWeight: FontWeight.w300,
      letterSpacing: -0.5,
    ),
    headline3: TextStyle(
      fontFamily: fontFamily,
      fontSize: 48,
      fontWeight: FontWeight.w400,
    ),
    headline4: TextStyle(
      fontFamily: fontFamily,
      fontSize: 34,
      fontWeight: FontWeight.w600,
      letterSpacing: 0.25,
    ),
    headline5: TextStyle(
      fontFamily: fontFamily,
      fontSize: 24,
      fontWeight: FontWeight.w400,
    ),
    headline6: TextStyle(
      fontFamily: fontFamily,
      fontSize: 20,
      fontWeight: FontWeight.w600,
      letterSpacing: 0.15,
    ),
    subtitle1: TextStyle(
      fontFamily: fontFamily,
      fontSize: 16,
      fontWeight: FontWeight.w400,
      letterSpacing: 0.15,
    ),
    subtitle2: TextStyle(
      fontFamily: fontFamily,
      fontSize: 14,
      fontWeight: FontWeight.w500,
      letterSpacing: 0.1,
    ),
    bodyText1: TextStyle(
      fontFamily: fontFamily,
      fontSize: 16,
      fontWeight: FontWeight.w400,
      letterSpacing: 0.5,
    ),
    bodyText2: TextStyle(
      fontFamily: fontFamily,
      fontSize: 14,
      fontWeight: FontWeight.w400,
      letterSpacing: 0.25,
    ),
    button: TextStyle(
      fontFamily: fontFamily,
      fontSize: 14,
      fontWeight: FontWeight.w500,
      letterSpacing: 1.15,
    ),
    caption: TextStyle(
      fontFamily: fontFamily,
      fontSize: 11,
      fontWeight: FontWeight.w400,
      letterSpacing: 0.4,
    ),
    overline: TextStyle(
      fontFamily: fontFamily,
      fontSize: 10,
      fontWeight: FontWeight.w400,
      letterSpacing: 0.25,
    ),
  );
}
