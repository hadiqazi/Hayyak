/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '/app/theme/app_colors.dart';
import '/app/theme/app_theme.dart';
import '/app/theme/light/light_theme.dart';

class LightThemeData {
  LightThemeData._();

  static final ThemeData get = ThemeData(
    // Color scheme
    colorScheme: LightTheme.colorScheme,
    scaffoldBackgroundColor: LightTheme.screenBackground,

    // Theme colors
    primaryColor: LightTheme.colorScheme.primary,
    errorColor: LightTheme.colorScheme.error,
    backgroundColor: LightTheme.colorScheme.background,

    // Colors & Themes
    cardColor: LightTheme.colorScheme.background,
    dividerTheme: DividerThemeData(
      color: AppColors.divider,
      thickness: 1,
    ),
    hintColor: LightTheme.textFieldHint,
    unselectedWidgetColor: Color(0xFFD6D6D6),

    // Font family
    fontFamily: AppTheme.fontFamily,

    // Appbar theme
    appBarTheme: AppBarTheme(
      color: LightTheme.actionBar,
      systemOverlayStyle: SystemUiOverlayStyle.dark,
      foregroundColor: LightTheme.onActionBar,
      elevation: 0,
      centerTitle: true,
    ),

    // Text theme
    textTheme: AppTheme.textTheme.copyWith(
      headline4: AppTheme.textTheme.headline4?.copyWith(color: LightTheme.textSecondary),
      headline5: AppTheme.textTheme.headline5?.copyWith(color: LightTheme.textSecondary),
      caption: AppTheme.textTheme.caption?.copyWith(color: Color(0xFFA6A6A6)),
    ),

    // Widget themes
    elevatedButtonTheme: AppTheme.buttonTheme,
    chipTheme: AppTheme.chipTheme,

    // Density
    visualDensity: VisualDensity.adaptivePlatformDensity,
  );
}
