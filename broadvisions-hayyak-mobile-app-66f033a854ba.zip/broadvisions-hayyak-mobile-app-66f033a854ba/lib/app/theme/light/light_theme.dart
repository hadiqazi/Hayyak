/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';

import '/app/theme/app_colors.dart';

class LightTheme {
  LightTheme._();

  static const ColorScheme colorScheme = ColorScheme.light(
    // Primary
    primary: AppColors.red,
    onPrimary: Colors.white,
    // Secondary
    secondary: AppColors.blue,
    onSecondary: Colors.white,
    // Surface & Background
    surface: Colors.white,
    onSurface: Colors.black,
    background: Colors.white,
    onBackground: Colors.black,
    // Error
    error: AppColors.error,
    onError: Colors.white,
  );

  // Text
  static const textPrimary = Color(0xFF000000);
  static const textSecondary = Color(0xFF212121);
  static const textTertiary = Color(0xFF7A7A7A);
  static const textFieldHint = Color(0xFFBCBCBC);

  // Action bar
  static const actionBar = Colors.white;
  static const onActionBar = Colors.black;

  // Buttons
  static final primaryButton = colorScheme.primary;
  static final secondaryButton = colorScheme.secondary;

  // Generics
  static final screenBackground = colorScheme.background;
  static const deleteButton = Colors.red;

  static const listEmptyDataTitle = Color(0xFFECAD4E);
  static const listErrorInDataTitle = Color(0xFF5676A0);

  // SnackBars
  static final errorSnackBar = colorScheme.error;
  static final onErrorSnackBar = colorScheme.onError;
  static const successSnackBar = AppColors.success;
  static const onSuccessSnackBar = Colors.white;

  // Others
  static const ratingColor = Color(0xFFFFC20E);
  static const borderColor = Color(0xFFE9E9E9);
}
