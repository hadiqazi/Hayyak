/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color red = Color(0xFFE44057);        //500
  static const Color darkerRed = Color(0xFFAC002E);  //700
  static const Color lighterRed = Color(0xFFFF7583); //200

  static const Color blue = Color(0xFF205B7D);        //500
  static const Color darkerBlue = Color(0xFF003251);  //700
  static const Color lighterBlue = Color(0xFF5488AC); //200

  static const divider = Color(0xFFF4F4F4);

  static const success = Color(0xFF29B57A);
  static const warning = Color(0xFFEF9D21);
  static const error = Color(0xFFFA4949);
}
