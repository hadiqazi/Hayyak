/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 17/11/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class LocationHelper {
  static Future<bool> determineReadyStatus(BuildContext context) async {
    bool serviceEnabled;
    LocationPermission permission;

    // Check if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      // Location services are not enabled
      debugPrint('Location services are disabled.');
      return false;
    }

    // Check location permissions
    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      // Permission is denied. This can happen when user previously denied permission or
      // the app is run for the first time.
      // Show permission dialog to request permission.
      permission = await Geolocator.requestPermission();

      // Permission is still denied
      if (permission == LocationPermission.denied) {
        debugPrint('Location permissions are denied');
        return false;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever
      debugPrint('Location permissions are permanently denied, we cannot request permissions.');
      return false;
    }

    // Every thing is ready, so return true.
    return true;
  }
}
