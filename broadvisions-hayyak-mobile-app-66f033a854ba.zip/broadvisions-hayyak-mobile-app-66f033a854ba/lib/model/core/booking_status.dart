/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 28/12/2021
            Project: hayyak-mobile-app
 */

class BookingStatus {
  final String _value;

  String get value => _value;

  const BookingStatus._create(this._value);

  static BookingStatus? tryParse(String value) {
    switch (value) {
      case 'ACTIVE':
        return BookingStatus.ACTIVE;
      case 'COMPLETED':
        return BookingStatus.COMPLETED;
      case 'CANCELLED':
        return BookingStatus.CANCELLED;
      default:
        return null;
    }
  }

  static const ACTIVE = const BookingStatus._create('ACTIVE');
  static const COMPLETED = const BookingStatus._create('COMPLETED');
  static const CANCELLED = const BookingStatus._create('CANCELLED');

  toString() => _value;
}
