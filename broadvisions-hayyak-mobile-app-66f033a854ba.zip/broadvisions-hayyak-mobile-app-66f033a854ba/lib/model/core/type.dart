/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

class Type {
  String id;
  String name;

  Type(this.id, this.name);

  Type.fromJson(Map<String, dynamic> json)
      : id = json['_id'],
        name = json['name'];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
      };

  @override
  bool operator ==(Object other) => other is Type && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
