/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 29/12/2021
            Project: hayyak-mobile-app
 */

class Pagination {
  int pageNumber;
  int totalItems;
  int pageSize;

  Pagination(this.pageNumber, this.totalItems, this.pageSize);

  Pagination.fromJson(Map<String, dynamic> json)
      : pageNumber = json['page'] ?? 1,
        totalItems = json['total'],
        pageSize = json['size'];
}
