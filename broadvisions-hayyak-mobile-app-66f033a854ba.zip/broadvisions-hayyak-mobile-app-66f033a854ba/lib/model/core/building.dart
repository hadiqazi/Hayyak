/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

class Building {
  String id;
  String name;
  String checkInTime;
  String checkOutTime;

  Building(this.id, this.name, this.checkInTime, this.checkOutTime);

  Building.fromJson(Map<String, dynamic> json)
      : id = json['_id'],
        name = json['name'],
        checkInTime = json['checkInTime'],
        checkOutTime = json['checkOutTime'];
}
