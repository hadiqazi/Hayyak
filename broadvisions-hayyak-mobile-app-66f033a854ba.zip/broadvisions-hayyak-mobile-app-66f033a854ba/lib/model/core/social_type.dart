/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 23/02/2022
            Project: hayyak-mobile-app
 */

enum SocialType {
  GOOGLE,
  FACEBOOK,
  APPLE,
  EMAIL,
}

extension HttpMethodExtension on SocialType {
  String get value {
    switch (this) {
      case SocialType.GOOGLE:
        return 'GOOGLE';
      case SocialType.FACEBOOK:
        return 'FACEBOOK';
      case SocialType.APPLE:
        return 'APPLE';
      case SocialType.EMAIL:
        return 'EMAIL';
    }
  }
}

class SocialTypeParser {
  SocialTypeParser._();

  static SocialType? tryParse(String value) {
    SocialType? parsed;

    SocialType.values.forEach((type) {
      if (type.value == value) parsed = type;
    });
    return parsed;
  }
}
