/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 30/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/building.dart';
import 'package:hayyak/model/core/image_data.dart';
import 'package:hayyak/model/core/property.dart';

class BookingProperty {
  String id;
  String name;
  String coverImageUrl;

  // Following attributes are for details
  String? propertyType;
  String? bedType;
  Building? building;
  int guestCount = 0;
  double rating = 0;

  BookingProperty(this.id, this.name, this.coverImageUrl);

  BookingProperty._createFrom(Map<String, dynamic> json)
      : id = json['_id'],
        name = json['name'],
        coverImageUrl = json['coverImage'];

  factory BookingProperty.fromJson(Map<String, dynamic> json) {
    BookingProperty property = BookingProperty._createFrom(json);

    if (json['propertyType'] != null) property.propertyType = json['propertyType']['name'];
    if (json['bedType'] != null) property.bedType = json['bedType']['name'];
    if (json['building'] != null) property.building = Building.fromJson(json['building']);
    if (json['guestCount'] != null)
      property.guestCount = int.tryParse(json["guestCount"].toString()) ?? 0;
    if (json['average'] != null)
      property.rating = double.tryParse(json["average"]['overall'].toString()) ?? 0;

    return property;
  }

  Property toProperty(double pricePerNight) {
    return Property(
      id,
      name,
      propertyType ?? '',
      bedType ?? '',
      building!,
      pricePerNight,
      rating,
      guestCount,
      ImageData('', coverImageUrl),
      List.filled(5, 0),
    );
  }
}
