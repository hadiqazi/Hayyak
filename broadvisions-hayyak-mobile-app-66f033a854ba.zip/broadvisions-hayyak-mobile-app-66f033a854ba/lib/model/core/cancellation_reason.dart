/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/01/2022
            Project: hayyak-mobile-app
 */

class CancellationReason {
  String value;
  String text;

  CancellationReason(this.value, this.text);
}
