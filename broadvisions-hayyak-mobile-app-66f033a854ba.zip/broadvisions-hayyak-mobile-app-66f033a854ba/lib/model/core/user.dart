/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 10/11/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/social_type.dart';
import 'package:hayyak/view/utils/utils.dart';

class User {
  String id;
  String firstName;
  String? lastName;
  String email;
  String phone;
  DateTime? dateOfBirth;
  String? country;
  String? profilePicUrl;
  String? language;
  SocialType? accountType;
  bool isVerified;

  User.fromJson(Map<String, dynamic> json)
      : id = json['_id'],
        firstName = json['firstName'],
        lastName = json['lastName'],
        email = json['email'],
        phone = json['phone'],
        dateOfBirth = DateTime.tryParse(json['dateOfBirth'] ?? ''),
        country = json['country'],
        profilePicUrl = json['profileImage'],
        language = json['language'],
        isVerified = json['isVerified'] ?? false,
        accountType = SocialTypeParser.tryParse(json['loginType']);

  Map<String, dynamic> toJson() => {
        '_id': id,
        'firstName': firstName,
        'lastName': lastName,
        'email': email,
        'phone': phone,
        'dateOfBirth': dateOfBirth == null ? null : Utils.formatDateForNetwork(dateOfBirth!),
        'country': country,
        'profileImage': profilePicUrl,
        'language': language,
        'isVerified': isVerified,
      };

  String getFullName() {
    return (this.firstName + ' ' + (this.lastName ?? '')).trim();
  }
}
