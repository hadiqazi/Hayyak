/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 11/02/2022
            Project: hayyak-mobile-app
 */

class Rating {
  String id;
  int starRating;
  String? review;
  DateTime? postedOn;
  String? reviewerName;
  String? reviewerImageUrl;
  String? propertyName;
  String? propertyImageUrl;

  Rating._createFrom(Map<String, dynamic> json)
      : id = json['_id'],
        starRating = json['rate'],
        review = json['review']?['comment'],
        postedOn = DateTime.tryParse(json['updatedAt'] ?? '');

  factory Rating.fromJson(Map<String, dynamic> json) {
    Rating rating = Rating._createFrom(json);

    if (json['property'] != null && json['property'] is Map) {
      rating.propertyName = json['property']['name'];
      rating.propertyImageUrl = json['property']['coverImage']?['imageUrl'];
    }
    if (json['user'] != null && json['user'] is Map) {
      rating.reviewerName = json['user']['firstName'];
      rating.reviewerImageUrl = json['user']['profileImage'];
    }

    return rating;
  }
}
