/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

class ImageData {
  String id;
  String url;

  ImageData(this.id, this.url);

  ImageData.fromJson(Map<String, dynamic> json)
      : id = json['uuid'],
        url = json['imageUrl'];
}
