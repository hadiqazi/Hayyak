/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 23/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/social_type.dart';

class SocialSignUpInfo {
  SocialType type;
  String token;
  String? name;
  String? email;
  String? profilePicUrl;

  SocialSignUpInfo({
    required this.type,
    required this.token,
    this.name,
    this.email,
    this.profilePicUrl,
  });
}
