/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 28/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/booking_cost.dart';
import 'package:hayyak/model/core/booking_property.dart';
import 'package:hayyak/model/core/guest.dart';
import 'package:hayyak/model/core/room.dart';
import 'package:hayyak/model/core/vas_booked.dart';

class Booking {
  String uuid;
  int? bookingId;
  DateTime checkInDate;
  DateTime checkOutDate;
  BookingProperty? property;
  double pricePerNight;
  late List<Room> rooms;
  Guest guest;
  BookingCost costs;
  String status;
  DateTime? bookedAt;

  // Following attributes are for details
  List<BookedVAS>? services;

  Booking._createFrom(Map<String, dynamic> json)
      : uuid = json['_id'],
        bookingId = json['bookingId'],
        checkInDate = DateTime.parse(json['checkIn']),
        checkOutDate = DateTime.parse(json['checkOut']),
        pricePerNight = double.tryParse(json["propertyPrice"].toString()) ?? 0,
        guest = Guest.fromJson(json['guest']),
        costs = BookingCost.fromJson(json['cost']),
        status = json['status'],
        bookedAt = DateTime.tryParse(json['createdAt']);

  factory Booking.fromJson(Map<String, dynamic> json) {
    var roomJson = json['rooms'] as List;
    List<Room> roomList = roomJson.map((e) => Room.fromJson(e)).toList();

    List<BookedVAS>? serviceList;
    if (json['services'] != null) {
      var serviceJson = json['services'] as List;
      serviceList = serviceJson.map((e) => BookedVAS.fromJson(e)).toList();
    }

    Booking booking = Booking._createFrom(json);
    booking.rooms = roomList;
    booking.services = serviceList;

    if (json['property'] != null) {
      booking.property = BookingProperty.fromJson(json['property']);
    } else if (json['propertyId'] != null) {
      booking.property = BookingProperty.fromJson(json['propertyId']);
    }

    return booking;
  }
}
