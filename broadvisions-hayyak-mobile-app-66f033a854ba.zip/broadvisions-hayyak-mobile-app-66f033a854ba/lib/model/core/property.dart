/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/amenity.dart';
import 'package:hayyak/model/core/building.dart';
import 'package:hayyak/model/core/image_data.dart';
import 'package:hayyak/model/core/value_added_service.dart';

class Property {
  String id;
  String name;
  String? description;
  String propertyType;
  String bedType;
  Building building;
  double pricePerNight;
  double rating;
  int guestCount;
  ImageData coverImage;
  List<ImageData>? images;
  List<Amenity>? amenities;
  List<ValueAddedService>? services;
  late List<double> ratingDistribution;
  late int ratingCount;
  int reviewCount;

  Property(this.id, this.name, this.propertyType, this.bedType, this.building, this.pricePerNight,
      this.rating, this.guestCount, this.coverImage, this.ratingDistribution,
      {this.description,
      this.images,
      this.amenities,
      this.services,
      this.ratingCount = 0,
      this.reviewCount = 0});

  Property._createFrom(Map<String, dynamic> json)
      : id = json['_id'],
        name = json['name'],
        description = json['description'],
        propertyType = json['propertyType']['name'],
        bedType = json['bedType']['name'],
        pricePerNight = double.tryParse(json["price"].toString()) ?? 0,
        rating = double.tryParse(json["average"]['overall'].toString()) ?? 0,
        building = Building.fromJson(json['building']),
        guestCount = int.tryParse(json["guestCount"].toString()) ?? 0,
        coverImage = ImageData.fromJson(json['coverImage']),
        reviewCount = int.tryParse(json["reviewCount"].toString()) ?? 0 {
    //
    final List<double> ratings = [];
    final ratingJson = json["average"];
    ratings.add(double.tryParse(ratingJson['one_star'].toString()) ?? 0);
    ratings.add(double.tryParse(ratingJson['two_star'].toString()) ?? 0);
    ratings.add(double.tryParse(ratingJson['three_star'].toString()) ?? 0);
    ratings.add(double.tryParse(ratingJson['four_star'].toString()) ?? 0);
    ratings.add(double.tryParse(ratingJson['five_star'].toString()) ?? 0);

    ratingCount = ratings.reduce((value, element) => value + element).round();
    ratingDistribution = ratings;
  }

  factory Property.fromJson(Map<String, dynamic> json) {
    var imageJson = json['images'] as List;
    List<ImageData> imageList = imageJson.map((e) => ImageData.fromJson(e)).toList();
    var amenityJson = json['amenities'] as List;
    List<Amenity> amenityList = amenityJson.map((e) => Amenity.fromJson(e)).toList();
    var serviceJson = json['valueAddedServices'] as List;
    List<ValueAddedService> serviceList =
        serviceJson.map((e) => ValueAddedService.fromJson(e)).toList();

    Property property = Property._createFrom(json);
    property.images = imageList;
    property.amenities = amenityList;
    property.services = serviceList;

    return property;
  }
}
