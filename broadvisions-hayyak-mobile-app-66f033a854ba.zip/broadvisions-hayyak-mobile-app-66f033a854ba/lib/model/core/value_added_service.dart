/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/image_data.dart';

class ValueAddedService {
  String id;
  String name;
  String? description;
  double price;
  ImageData? image;

  // Internal
  bool isSelected = false;
  List<DateTime>? selectionDates;

  ValueAddedService(this.id, this.name, this.description, this.price, this.image);

  ValueAddedService.fromJson(Map<String, dynamic> json)
      : id = json['_id'],
        name = json['name'],
        description = json['description'],
        price = double.tryParse(json["price"].toString()) ?? 0,
        image = json['image'] == null ? null : ImageData.fromJson(json['image']);

  factory ValueAddedService.clone(ValueAddedService service) {
    return ValueAddedService(
        service.id, service.name, service.description, service.price, service.image);
  }
}
