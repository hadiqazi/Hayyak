/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'dart:typed_data';

class FileToUpload {
  String fileName;
  Uint8List fileData;

  FileToUpload(this.fileName, this.fileData);
}
