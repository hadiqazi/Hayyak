/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 27/01/2022
            Project: hayyak-mobile-app
 */

class CancellationPolicy {
  int cutOffDays;
  bool resetTimeToMidnight;
  int freeHoursInsideCutoff;
  int freeHoursOutsideCutoff;

  CancellationPolicy.fromJson(Map<String, dynamic> json)
      : cutOffDays = int.tryParse(json["cutOffDays"].toString()) ?? 0,
        resetTimeToMidnight = json['resetTimeToMidnight'],
        freeHoursInsideCutoff = int.tryParse(json["freeHoursInsideCutoff"].toString()) ?? 0,
        freeHoursOutsideCutoff = int.tryParse(json["freeHoursOutsideCutoff"].toString()) ?? 0;
}
