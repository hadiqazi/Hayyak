/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 30/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/value_added_service.dart';

class BookedVAS {
  ValueAddedService vas;
  late List<DateTime> dates;
  double totalCost;

  BookedVAS(this.vas, this.dates, this.totalCost);

  BookedVAS._createFrom(Map<String, dynamic> json)
      : vas = ValueAddedService.fromJson(json['service']),
        totalCost = double.tryParse(json["total"].toString()) ?? 0;

  factory BookedVAS.fromJson(Map<String, dynamic> json) {
    var dateJson = json['dates'] as List;
    List<DateTime> dateList = dateJson.map((e) => DateTime.parse(e)).toList();

    BookedVAS bookedService = BookedVAS._createFrom(json);
    bookedService.dates = dateList;

    return bookedService;
  }
}
