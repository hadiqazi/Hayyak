/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 17/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/booking.dart';

class BookingToRate {
  String id;
  DateTime checkInDate;
  DateTime checkOutDate;
  String propertyId;
  String propertyName;
  String propertyImage;

  BookingToRate._({
    required this.id,
    required this.checkInDate,
    required this.checkOutDate,
    required this.propertyId,
    required this.propertyName,
    required this.propertyImage,
  });

  BookingToRate.fromJson(Map<String, dynamic> json)
      : id = json['bookingId'],
        checkInDate = DateTime.parse(json['checkIn']),
        checkOutDate = DateTime.parse(json['checkOut']),
        propertyId = json['propertyId'],
        propertyName = json['propertyName'],
        propertyImage = json['propertyCoverImage']['imageUrl'];

  factory BookingToRate.fromBooking(Booking booking) {
    return BookingToRate._(
      id: booking.uuid,
      checkInDate: booking.checkInDate,
      checkOutDate: booking.checkOutDate,
      propertyId: booking.property!.id,
      propertyName: booking.property!.name,
      propertyImage: booking.property!.coverImageUrl,
    );
  }
}
