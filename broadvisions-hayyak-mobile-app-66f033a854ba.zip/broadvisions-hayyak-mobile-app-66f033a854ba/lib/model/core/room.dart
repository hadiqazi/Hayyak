/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 16/12/2021
            Project: hayyak-mobile-app
 */

class Room {
  String id;
  String number;

  Room(this.id, this.number);

  Room.fromJson(Map<String, dynamic> json)
      : id = json['_id'],
        number = json['number'];
}
