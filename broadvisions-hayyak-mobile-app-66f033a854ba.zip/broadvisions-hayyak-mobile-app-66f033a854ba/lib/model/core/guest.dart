/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 29/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/view/utils/utils.dart';

class Guest {
  String name;
  String email;
  String phone;
  DateTime? dateOfBirth;
  String? country;
  String? image;

  Guest({
    required this.name,
    required this.email,
    required this.phone,
    required this.dateOfBirth,
    required this.country,
  });

  Guest.fromJson(Map<String, dynamic> json)
      : name = json['name'],
        email = json['email'],
        phone = json['phone'],
        dateOfBirth = DateTime.tryParse(json['dob'] ?? ''),
        country = json['country'],
        image = json['image'];

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'phone': phone,
        'dob': Utils.formatDateForNetwork(dateOfBirth!),
        'country': country,
      };
}
