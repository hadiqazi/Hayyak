/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/type.dart';

class Amenity {
  String id;
  String name;
  Type amenityType;

  Amenity(this.id, this.name, this.amenityType);

  Amenity.fromJson(Map<String, dynamic> json)
      : id = json['_id'],
        name = json['name'],
        amenityType = Type.fromJson(json['amenityType']);
}
