/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 30/12/2021
            Project: hayyak-mobile-app
 */

class BookingCost {
  double room;
  double services;
  double total;

  BookingCost.fromJson(Map<String, dynamic> json)
      : room = double.tryParse(json["roomCost"].toString()) ?? 0,
        services = double.tryParse(json["servicesCost"].toString()) ?? 0,
        total = double.tryParse(json["totalBookingCost"].toString()) ?? 0;
}
