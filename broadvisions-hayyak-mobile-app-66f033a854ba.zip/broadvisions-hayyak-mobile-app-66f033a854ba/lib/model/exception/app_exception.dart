/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

class AppException implements Exception {
  int? errorCode;
  String? message;
  String? localizedMessage;
  Exception? exception;
  Map<String, dynamic>? payload;

  AppException(this.errorCode, this.message);

  AppException.exception(this.exception);

  AppException.errorCode(this.errorCode);

  AppException.message(this.message);

  @override
  String toString() {
    String? msg;
    if (exception != null) {
      msg = exception.toString();
    } else {
      msg = message;
    }

    if (msg == null) msg = '';
    if (errorCode != null) msg = '$errorCode: ' + msg;
    return msg;
  }
}
