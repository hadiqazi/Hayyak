/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/02/2022
            Project: hayyak-mobile-app
 */

class UpdateRatingRequest {
  String ratingId;
  int rating;
  String review;

  UpdateRatingRequest({required this.ratingId, required this.rating, required this.review});

  Map<String, dynamic> toJson() => {
        'rating': rating,
        'review': review,
      };
}
