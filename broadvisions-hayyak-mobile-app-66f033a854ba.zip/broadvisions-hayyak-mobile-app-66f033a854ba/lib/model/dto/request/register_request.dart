/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 10/11/2021
            Project: hayyak-mobile-app
 */

class RegisterRequest {
  String name;
  String email;
  String phone;
  String password;
  String emailOTP;
  String phoneOTP;
  String language;

  RegisterRequest(this.name, this.email, this.phone, this.password, this.emailOTP, this.phoneOTP,
      this.language);

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'phone': phone,
        'password': password,
        'emailOTP': emailOTP,
        'phoneOTP': phoneOTP,
        'language': language,
      };
}
