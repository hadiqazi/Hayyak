/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 24/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/social_type.dart';

class SocialSignupRequest {
  SocialType type;
  String token;
  String name;
  String phone;
  String email;
  String emailOTP;
  String phoneOTP;
  String language;

  SocialSignupRequest(this.type, this.token, this.name, this.phone, this.email, this.emailOTP,
      this.phoneOTP, this.language);

  Map<String, dynamic> toJson() => {
        'type': type.value,
        'token': token,
        'name': name,
        'phone': phone,
        'emailOTP': emailOTP,
        'phoneOTP': phoneOTP,
        'language': language,
      };
}
