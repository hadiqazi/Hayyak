/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/view/utils/utils.dart';

class SearchPropertiesRequest {
  double latitude;
  double longitude;
  DateTime checkInDate;
  DateTime checkOutDate;
  int roomCount;
  String? bedTypeId;
  String? roomTypeId;

  int? guestCount;
  int? minPrice;
  int? maxPrice;
  int? rating;
  List<String>? amenities;
  List<String>? services;

  SearchPropertiesRequest({
    required this.latitude,
    required this.longitude,
    required this.checkInDate,
    required this.checkOutDate,
    required this.roomCount,
    this.bedTypeId,
    this.roomTypeId,
    this.guestCount,
    this.minPrice,
    this.maxPrice,
    this.rating,
    this.amenities,
    this.services,
  });

  Map<String, dynamic> toJson() => {
        'coordinates': {
          'lat': latitude,
          'lng': longitude,
        },
        'checkIn': Utils.formatDateForNetwork(checkInDate),
        'checkOut': Utils.formatDateForNetwork(checkOutDate),
        "noOfRooms": roomCount,
        'bedType': bedTypeId,
        'roomType': roomTypeId,
        'noOfGuests': guestCount,
        'minPrice': minPrice,
        'maxPrice': maxPrice,
        'rating': rating,
        'amenities': amenities,
        'vas': services,
      }..removeWhere((key, value) => value == null);
}
