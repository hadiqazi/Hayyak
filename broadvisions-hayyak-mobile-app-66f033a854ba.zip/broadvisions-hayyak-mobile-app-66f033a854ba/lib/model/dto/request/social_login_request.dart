/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 24/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/social_type.dart';

class SocialLoginRequest {
  SocialType type;
  String token;

  SocialLoginRequest(this.type, this.token);

  Map<String, dynamic> toJson() => {
        'type': type.value,
        'token': token,
      };
}
