/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 28/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/booking_status.dart';

class GetBookingsRequest {
  BookingStatus status;
  int pageNum;

  GetBookingsRequest(this.status, this.pageNum);

  Map<String, dynamic> toJson() => {
        'status': status.value,
      };
}
