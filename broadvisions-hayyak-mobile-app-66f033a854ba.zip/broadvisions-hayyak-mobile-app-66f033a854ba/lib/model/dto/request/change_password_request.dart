/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 08/02/2022
            Project: hayyak-mobile-app
 */

class ChangePasswordRequest {
  String currentPassword;
  String newPassword;

  ChangePasswordRequest(this.currentPassword, this.newPassword);

  Map<String, dynamic> toJson() => {
        'oldPassword': currentPassword,
        'newPassword': newPassword,
      };
}
