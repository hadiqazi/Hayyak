/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 10/11/2021
            Project: hayyak-mobile-app
 */

class GetOTPRequest {
  String email;
  String phone;

  GetOTPRequest(this.email, this.phone);

  Map<String, dynamic> toJson() => {
        'email': email,
        'phone': phone,
      };
}
