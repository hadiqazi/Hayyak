/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

class LoginRequest {
  String email;
  String password;

  LoginRequest(this.email, this.password);

  Map<String, dynamic> toJson() => {
        'email': email,
        'password': password,
      };
}
