/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 09/02/2022
            Project: hayyak-mobile-app
 */

class ResetPasswordRequest {
  String email;

  ResetPasswordRequest(this.email);

  Map<String, dynamic> toJson() => {
        'email': email,
      };
}
