/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 30/12/2021
            Project: hayyak-mobile-app
 */

class GetBookingDetailsRequest {
  String bookingId;

  GetBookingDetailsRequest(this.bookingId);
}
