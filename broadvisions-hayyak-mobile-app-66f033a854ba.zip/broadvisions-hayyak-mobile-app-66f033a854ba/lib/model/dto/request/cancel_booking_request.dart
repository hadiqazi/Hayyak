/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/01/2022
            Project: hayyak-mobile-app
 */

class CancelBookingRequest {
  String bookingId;
  String reason;

  CancelBookingRequest(this.bookingId, this.reason);

  Map<String, dynamic> toJson() => {
        'reason': reason,
      };
}
