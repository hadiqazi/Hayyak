/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import '/model/core/file_to_upload.dart';

class UploadFilesRequest {
  String parameterName;
  List<FileToUpload> dataFiles;

  UploadFilesRequest(this.dataFiles, {this.parameterName = 'image'});
}
