/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 11/02/2022
            Project: hayyak-mobile-app
 */

class RatePropertyRequest {
  int rating;
  String review;
  String bookingId;
  String propertyId;

  RatePropertyRequest({
    required this.rating,
    required this.review,
    required this.bookingId,
    required this.propertyId,
  });

  Map<String, dynamic> toJson() => {
        'rating': rating,
        'comment': review,
        'bookingId': bookingId,
        'propertyId': propertyId,
      };
}
