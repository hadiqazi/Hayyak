/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/guest.dart';
import 'package:hayyak/model/core/value_added_service.dart';
import 'package:hayyak/view/utils/utils.dart';

class MakeBookingRequest {
  String propertyId;
  DateTime checkInDate;
  DateTime checkOutDate;
  int roomCount;
  int nightCount;
  Guest? guestInfo;
  List<ServiceDTO>? services;

  MakeBookingRequest({
    required this.propertyId,
    required this.checkInDate,
    required this.checkOutDate,
    required this.roomCount,
    required this.nightCount,
    this.guestInfo,
  });

  Map<String, dynamic> toJson() => {
        'propertyId': propertyId,
        'checkIn': Utils.formatDateForNetwork(checkInDate),
        'checkOut': Utils.formatDateForNetwork(checkOutDate),
        'rooms': roomCount,
        'guest': guestInfo?.toJson(),
        'vas': services?.map((service) => service.toJson()).toList(growable: false)
      };
}

class ServiceDTO {
  ValueAddedService serviceInfo;
  String serviceId;
  List<String> selectedDates;

  ServiceDTO(this.serviceId, this.selectedDates, this.serviceInfo);

  Map<String, dynamic> toJson() => {
        'id': serviceId,
        'dates': selectedDates,
      };
}

extension BookingRequestExt on MakeBookingRequest {
  double calculateServicesCost() {
    if (this.services == null) return 0;

    final servicesCost = this.services?.fold(
        0.0,
        (previousValue, service) =>
            ((previousValue ?? 0) as double) +
            (service.serviceInfo.price * service.selectedDates.length));

    return servicesCost ?? 0;
  }
}
