/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/file_to_upload.dart';
import 'package:hayyak/view/utils/utils.dart';

class UpdateProfileRequest {
  String userId;
  String? name;
  DateTime? dateOfBirth;
  String? country;
  String? language;
  FileToUpload? image;
  final imageParamName = 'profileImage';

  UpdateProfileRequest({required this.userId, this.name, this.dateOfBirth, this.country});

  Map<String, dynamic> toJson() => {
        'name': name,
        'dateOfBirth': dateOfBirth == null ? null : Utils.formatDateForNetwork(dateOfBirth!),
        'country': country,
        'language': language,
      }..removeWhere((key, value) => value == null);
}
