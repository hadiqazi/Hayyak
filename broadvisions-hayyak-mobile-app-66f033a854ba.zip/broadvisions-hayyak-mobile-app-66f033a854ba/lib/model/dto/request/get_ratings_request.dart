/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 14/02/2022
            Project: hayyak-mobile-app
 */

class GetRatingsRequest {
  String? bookingId;
  String? propertyId;
  int pageNum;

  GetRatingsRequest({required this.pageNum, this.bookingId, this.propertyId});

  Map<String, dynamic> toJson() => {
        'bookingId': bookingId,
        'propertyId': propertyId,
      }..removeWhere((key, value) => value == null);
}
