/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 16/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/dto/response/base_response.dart';
import 'package:hayyak/model/dto/response/booking_dto.dart';

class MakeBookingResponse extends BaseResponse {
  BookingDTO booking;

  MakeBookingResponse.fromJson(Map<String, dynamic> json)
      : booking = BookingDTO.fromJson(json['booking']),
        super.fromJson(json);
}
