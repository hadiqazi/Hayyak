/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 16/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/value_added_service.dart';
import 'package:hayyak/model/dto/response/base_response.dart';

class GetServicesResponse extends BaseResponse {
  late List<ValueAddedService> valueAddedServices;

  GetServicesResponse._createWith(json) : super.fromJson(json);

  factory GetServicesResponse.fromJson(Map<String, dynamic> json) {
    var serviceJson = json['valueAddedServices'] as List;
    List<ValueAddedService> services =
        serviceJson.map((e) => ValueAddedService.fromJson(e)).toList();

    GetServicesResponse response = GetServicesResponse._createWith(json);
    response.valueAddedServices = services;

    return response;
  }
}
