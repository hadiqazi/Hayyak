/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 11/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/rating.dart';
import 'package:hayyak/model/dto/response/base_response.dart';

class RatePropertyResponse extends BaseResponse {
  Rating rating;

  RatePropertyResponse.fromJson(json)
      : rating = Rating.fromJson(json['rating']),
        super.fromJson(json);
}
