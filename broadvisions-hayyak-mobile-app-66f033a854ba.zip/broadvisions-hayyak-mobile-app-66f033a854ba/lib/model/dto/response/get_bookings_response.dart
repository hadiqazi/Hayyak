/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 28/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/booking.dart';
import 'package:hayyak/model/core/pagination.dart';
import 'package:hayyak/model/dto/response/base_response.dart';

class GetBookingsResponse extends BaseResponse {
  late List<Booking> bookings;
  Pagination pagination;

  GetBookingsResponse._createWith(json)
      : pagination = Pagination.fromJson(json['pagination']),
        super.fromJson(json);

  factory GetBookingsResponse.fromJson(Map<String, dynamic> json) {
    var bookingsJson = json['booking'] as List;
    List<Booking> bookings = bookingsJson.map((e) => Booking.fromJson(e)).toList();

    GetBookingsResponse response = GetBookingsResponse._createWith(json);
    response.bookings = bookings;

    return response;
  }
}
