/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/guest.dart';
import 'package:hayyak/model/core/room.dart';

class BookingDTO {
  String id;
  DateTime checkInDate;
  DateTime checkOutDate;
  List<Room> rooms;
  Guest guest;
  String status;

  BookingDTO.fromJson(Map<String, dynamic> json)
      : id = json['_id'],
        checkInDate = DateTime.parse(json['checkIn']),
        checkOutDate = DateTime.parse(json['checkOut']),
        guest = Guest.fromJson(json['guest']),
        rooms = (json['rooms'] as List).map((e) => Room.fromJson(e)).toList(),
        status = json['status'];
}
