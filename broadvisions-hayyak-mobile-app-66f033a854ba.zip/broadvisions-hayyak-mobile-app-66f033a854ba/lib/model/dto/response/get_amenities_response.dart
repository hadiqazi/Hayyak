/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 09/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/amenity.dart';
import 'package:hayyak/model/dto/response/base_response.dart';

class GetAmenitiesResponse extends BaseResponse {
  late List<Amenity> amenities;

  GetAmenitiesResponse._createWith(json) : super.fromJson(json);

  factory GetAmenitiesResponse.fromJson(Map<String, dynamic> json) {
    var amenityJson = json['amenities'] as List;
    List<Amenity> amenities = amenityJson.map((e) => Amenity.fromJson(e)).toList();

    GetAmenitiesResponse response = GetAmenitiesResponse._createWith(json);
    response.amenities = amenities;

    return response;
  }
}
