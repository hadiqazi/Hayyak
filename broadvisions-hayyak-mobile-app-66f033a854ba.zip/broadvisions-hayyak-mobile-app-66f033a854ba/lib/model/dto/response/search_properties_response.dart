/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/pagination.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/model/dto/response/base_response.dart';

class SearchPropertiesResponse extends BaseResponse {
  late List<Property>? properties;
  Pagination pagination;

  SearchPropertiesResponse._createWith(json)
      : pagination = Pagination.fromJson(json['pagination']),
        super.fromJson(json);

  factory SearchPropertiesResponse.fromJson(Map<String, dynamic> json) {
    var jsonList = json['properties'] as List;
    List<Property> propertyList = jsonList.map((e) => Property.fromJson(e)).toList();

    SearchPropertiesResponse response = SearchPropertiesResponse._createWith(json);
    response.properties = propertyList;

    return response;
  }
}
