/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/booking_to_rate.dart';
import 'package:hayyak/model/core/cancellation_policy.dart';
import 'package:hayyak/model/core/type.dart';
import 'package:hayyak/view/utils/constants.dart';

import '/model/dto/response/base_response.dart';

class LookupResponse extends BaseResponse {
  late List<Type> amenityTypes;
  late List<Type> bedTypes;
  late List<Type> roomTypes;
  CancellationPolicy cancellationPolicy;
  BookingToRate? bookingToRate;

  LookupResponse._createWith(json)
      : cancellationPolicy = CancellationPolicy.fromJson(json['cancellationPolicy']),
        super.fromJson(json);

  factory LookupResponse.fromJson(Map<String, dynamic> json) {
    var amenityJson = json['amenityTypes'] as List;
    List<Type> amenityTypes = amenityJson.map((e) => Type.fromJson(e)).toList();
    var bedJson = json['bedTypes'] as List;
    List<Type> bedTypes = bedJson.map((e) => Type.fromJson(e)).toList();
    var propertyJson = json['propertyTypes'] as List;
    List<Type> propertyTypes = propertyJson.map((e) => Type.fromJson(e)).toList();

    LookupResponse response = LookupResponse._createWith(json);
    response.amenityTypes = amenityTypes;
    response.bedTypes = bedTypes;
    response.roomTypes = propertyTypes;

    if (json['bookingToBeReviewed'] != null) {
      response.bookingToRate = BookingToRate.fromJson(json['bookingToBeReviewed']);
    }
    return response;
  }

  Map<String, dynamic> toJson() => {
        Constants.amenityTypes: amenityTypes,
        Constants.bedTypes: bedTypes,
        Constants.roomTypes: roomTypes,
      };
}
