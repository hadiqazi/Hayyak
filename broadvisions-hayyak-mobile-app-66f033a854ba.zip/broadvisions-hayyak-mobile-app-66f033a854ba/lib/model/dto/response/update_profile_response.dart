/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/user.dart';

import '/model/dto/response/base_response.dart';

class UpdateProfileResponse extends BaseResponse {
  User user;

  UpdateProfileResponse.fromJson(Map<String, dynamic> json)
      : user = User.fromJson(json['user']),
        super.fromJson(json);
}
