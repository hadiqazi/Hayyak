/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/01/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/dto/response/base_response.dart';

class CancellationCostResponse extends BaseResponse {
  double deductionAmount;
  double refundAmount;

  CancellationCostResponse.fromJson(json)
      : deductionAmount = double.tryParse(json["deductedAmount"].toString()) ?? 0,
        refundAmount = double.tryParse(json["refundedAmount"].toString()) ?? 0,
        super.fromJson(json);
}
