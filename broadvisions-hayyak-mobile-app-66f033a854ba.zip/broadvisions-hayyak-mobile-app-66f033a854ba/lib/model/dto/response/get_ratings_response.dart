/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 14/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/pagination.dart';
import 'package:hayyak/model/core/rating.dart';
import 'package:hayyak/model/dto/response/base_response.dart';

class GetRatingsResponse extends BaseResponse {
  late List<Rating> ratings;
  Pagination pagination;

  GetRatingsResponse._createWith(json)
      : pagination = Pagination.fromJson(json['pagination']),
        super.fromJson(json);

  factory GetRatingsResponse.fromJson(Map<String, dynamic> json) {
    var ratingJson = json['ratings'] as List;
    List<Rating> ratings = ratingJson.map((e) => Rating.fromJson(e)).toList();

    GetRatingsResponse response = GetRatingsResponse._createWith(json);
    response.ratings = ratings;

    return response;
  }
}
