/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

class BaseResponse {
  int statusCode;
  String message;

  BaseResponse(this.statusCode, this.message);

  BaseResponse.fromJson(Map<String, dynamic> json)
      : statusCode = json['status'],
        message = json['message'] ?? '';
}
