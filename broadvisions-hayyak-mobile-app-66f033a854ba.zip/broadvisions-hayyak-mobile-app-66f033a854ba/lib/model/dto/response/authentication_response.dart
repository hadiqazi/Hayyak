/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:hayyak/model/core/user.dart';

import '/model/dto/response/base_response.dart';

class AuthenticationResponse extends BaseResponse {
  String sessionToken;
  User user;

  AuthenticationResponse.fromJson(Map<String, dynamic> json)
      : sessionToken = json['token'],
        user = User.fromJson(json['user']),
        super.fromJson(json);
}
