/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 30/12/2021
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/booking.dart';
import 'package:hayyak/model/dto/response/base_response.dart';

class GetBookingDetailsResponse extends BaseResponse {
  Booking booking;

  GetBookingDetailsResponse.fromJson(json)
      : booking = Booking.fromJson(json['booking']),
        super.fromJson(json);
}
