/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

class NetworkConfig {
  NetworkConfig._();

  static const SERVER_URL = _ServerUrl.DEVELOPMENT;
  static const CONNECTION_TIMEOUT = 60;

  static const TERMS_URL = _ServerUrl.TERMS_URI;
  static const HELP_URL = _ServerUrl.HELP_URI;
}

/// All backend server URLs used in app
class _ServerUrl {
  _ServerUrl._();

  static const DEVELOPMENT = 'https://hayyak.feedy.se:8081/';
  static const STAGING = 'https://staging.hayyak.com.sa:8080/';

  // TODO: Update URIs below to actual links
  static const TERMS_URI = 'https://www.google.com';
  static const HELP_URI = 'https://www.yahoo.com';
}
