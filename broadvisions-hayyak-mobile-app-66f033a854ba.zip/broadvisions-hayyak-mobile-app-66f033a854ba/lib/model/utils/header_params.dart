/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

class HeaderParams {
  static const String LANGUAGE = "language";
}
