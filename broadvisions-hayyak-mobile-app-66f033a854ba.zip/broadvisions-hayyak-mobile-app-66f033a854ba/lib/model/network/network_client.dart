/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hayyak/model/network/http_method.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';

import '/model/dto/request/upload_file_request.dart';
import '/model/exception/app_exception.dart';
import '/model/network/network_response.dart';
import '/model/network/response_code.dart';
import '/model/network/web_service_header.dart';
import '/model/utils/network_config.dart';

class NetworkClient {
  Future<NetworkResponse> sendGetRequest(String requestUrl, {WebServiceHeader? header}) async {
    //
    http.Response? httpResponse;

    // Add common headers
    final headerMap = await _addCommonHeaderParams(header);

    debugPrint('=============== GET REQUEST ===============');
    debugPrint('REQUEST URL: $requestUrl');
    debugPrint('REQUEST HEADERS: ${header?.headerMap}');

    try {
      httpResponse = await http
          .get(
            Uri.parse(requestUrl),
            headers: headerMap,
          )
          .timeout(Duration(seconds: NetworkConfig.CONNECTION_TIMEOUT));

      debugPrint('RESPONSE DATA: ${httpResponse.body}');

      // Check response code
      if (httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
        // Populate header and body in response
        return NetworkResponse(WebServiceHeader(), httpResponse.body);
        //
      } else {
        // Handle request failure
        throw _getRequestFailureException(httpResponse);
      }
    } on TimeoutException catch (e) {
      throw getTimeoutException(e);
    } on SocketException catch (e) {
      throw getTimeoutException(e);
    } catch (e) {
      if (e is AppException) throw e;
      final ex = AppException.exception(e as Exception);
      ex.errorCode = httpResponse?.statusCode;
      throw ex;
    }
  }

  Future<NetworkResponse> sendRequest(HttpMethod httpMethod, String requestUrl, String requestData,
      {WebServiceHeader? header}) async {
    //
    http.Response? httpResponse;

    // Add common headers
    final headerMap = await _addCommonHeaderParams(header);

    debugPrint('=============== ${httpMethod.value} REQUEST ===============');
    debugPrint('REQUEST URL: $requestUrl');
    debugPrint('REQUEST HEADERS: ${header?.headerMap}');
    debugPrint('REQUEST BODY: $requestData');

    try {
      if (httpMethod == HttpMethod.POST) {
        httpResponse = await http
            .post(
              Uri.parse(requestUrl),
              headers: headerMap,
              body: requestData,
            )
            .timeout(Duration(seconds: NetworkConfig.CONNECTION_TIMEOUT));
        //
      } else if (httpMethod == HttpMethod.PATCH) {
        httpResponse = await http
            .patch(
              Uri.parse(requestUrl),
              headers: headerMap,
              body: requestData,
            )
            .timeout(Duration(seconds: NetworkConfig.CONNECTION_TIMEOUT));
        //
      } else if (httpMethod == HttpMethod.PUT) {
        httpResponse = await http
            .put(
              Uri.parse(requestUrl),
              headers: headerMap,
              body: requestData,
            )
            .timeout(Duration(seconds: NetworkConfig.CONNECTION_TIMEOUT));
        //
      } else {
        throw AppException.message('Invalid HTTP method provided');
      }

      debugPrint('RESPONSE DATA: ${httpResponse.body}');

      // Check response code
      if (httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
        // Populate header and body in response
        return NetworkResponse(WebServiceHeader(), httpResponse.body);
        //
      } else {
        // Handle request failure
        throw _getRequestFailureException(httpResponse);
      }
    } on TimeoutException catch (e) {
      throw getTimeoutException(e);
    } on SocketException catch (e) {
      throw getTimeoutException(e);
    } catch (e) {
      if (e is AppException) throw e;
      final ex = AppException.exception(e as Exception);
      ex.errorCode = httpResponse?.statusCode;
      throw ex;
    }
  }

  Future<NetworkResponse> sendMultipartRequest(HttpMethod httpMethod, String requestUrl,
      Map<String, dynamic> requestData, UploadFilesRequest filesRequest,
      {WebServiceHeader? header}) async {
    //
    debugPrint('=============== MULTIPART POST REQUEST ===============');
    debugPrint('REQUEST URL: $requestUrl');
    debugPrint('REQUEST HEADERS: ${header?.headerMap}');
    debugPrint('REQUEST BODY: $requestData');
    debugPrint('FILES COUNT: ${filesRequest.dataFiles.length}');

    http.MultipartRequest httpRequest =
        http.MultipartRequest(httpMethod.value, Uri.parse(requestUrl));
    http.Response? httpResponse;

    // Add common headers
    final headerMap = await _addCommonHeaderParams(header);
    httpRequest.headers.addAll(headerMap);

    try {
      // Add all request params as multipart fields
      requestData.forEach((key, value) {
        if (value != null) {
          httpRequest.fields[key] = value.toString();
        }
      });

      // Add all request files as multipart files
      for (var fileToUpload in filesRequest.dataFiles) {
        final fileName = fileToUpload.fileName;
        final mediaType = await _getMediaType(fileName);

        http.MultipartFile mpf = http.MultipartFile.fromBytes(
          filesRequest.parameterName,
          fileToUpload.fileData,
          filename: fileName,
          contentType: mediaType,
        );
        httpRequest.files.add(mpf);
      }

      final response = await httpRequest.send();
      httpResponse = await http.Response.fromStream(response);

      debugPrint('RESPONSE DATA: ${httpResponse.body}');

      // Check response code
      if (httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
        // Populate header and body in response
        return NetworkResponse(WebServiceHeader(), httpResponse.body);
        //
      } else {
        // Handle request failure
        throw _getRequestFailureException(httpResponse);
      }
    } on TimeoutException catch (e) {
      throw getTimeoutException(e);
    } on SocketException catch (e) {
      throw getTimeoutException(e);
    } catch (e) {
      if (e is AppException) throw e;
      final ex = AppException.exception(e as Exception);
      ex.errorCode = httpResponse?.statusCode;
      throw ex;
    }
  }

  Future<NetworkResponse> sendDeleteRequest(String requestUrl, {WebServiceHeader? header}) async {
    //
    http.Response? httpResponse;

    // Add common headers
    final headerMap = await _addCommonHeaderParams(header);

    debugPrint('=============== DELETE REQUEST ===============');
    debugPrint('REQUEST URL: $requestUrl');
    debugPrint('REQUEST HEADERS: ${header?.headerMap}');

    try {
      httpResponse = await http
          .delete(
            Uri.parse(requestUrl),
            headers: headerMap,
          )
          .timeout(Duration(seconds: NetworkConfig.CONNECTION_TIMEOUT));

      debugPrint('RESPONSE DATA: ${httpResponse.body}');

      // Check response code
      if (httpResponse.statusCode >= 200 && httpResponse.statusCode < 300) {
        // Populate header and body in response
        return NetworkResponse(WebServiceHeader(), httpResponse.body);
        //
      } else {
        // Handle request failure
        throw _getRequestFailureException(httpResponse);
      }
    } on TimeoutException catch (e) {
      throw getTimeoutException(e);
    } on SocketException catch (e) {
      throw getTimeoutException(e);
    } catch (e) {
      if (e is AppException) throw e;
      final ex = AppException.exception(e as Exception);
      ex.errorCode = httpResponse?.statusCode;
      throw ex;
    }
  }

  // =============== PRIVATE METHODS =============== //

  Future<HashMap<String, String>> _addCommonHeaderParams(WebServiceHeader? webHeader,
      {bool? isMultiPart}) async {
    //
    final headers = HashMap<String, String>();
    if (webHeader != null) headers.addAll(webHeader.headerMap);

    if (isMultiPart != null && isMultiPart) {
      headers['Content-Type'] = 'multipart/form-data';
    } else {
      headers['Content-Type'] = 'application/json; charset=UTF-8';
    }

    return headers;
  }

  AppException _getRequestFailureException(http.Response httpResponse) {
    // Try parsing the error response
    try {
      final json = jsonDecode(httpResponse.body) as Map<String, dynamic>;
      final error = AppException(json['status'], json['message']);

      // If there's any useful data in response, set it as error's payload sans status and message
      json.remove('status');
      json.remove('message');
      error.payload = json;

      return error;
      //
    } catch (parsingError) {
      // Throw an error
      return AppException.errorCode(httpResponse.statusCode);
    }
  }

  Future<MediaType> _getMediaType(String filePath) async {
    final fileName = filePath.split('/').last;
    final extension = fileName.split('.').last.toLowerCase();

    if (extension == 'jpg' || extension == 'jpeg') {
      return MediaType('image', 'jpeg');
    } else if (extension == 'png') {
      return MediaType('image', 'png');
    } else {
      return MediaType('text', 'plain');
    }
  }

  AppException getTimeoutException(Exception e) {
    final appEx = AppException.exception(e);
    appEx.errorCode = ResponseCode.REQUEST_TIMEOUT;
    return appEx;
  }
}
