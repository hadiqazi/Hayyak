/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'dart:collection';
import 'dart:io';

import '/model/utils/header_params.dart';

class WebServiceHeader {
  var _headerMap = HashMap<String, String>();

  // ========== Class Methods ========== //
  HashMap<String, String> get headerMap {
    return _headerMap;
  }

  String? getProperty(String key) {
    return this.headerMap[key];
  }

  void setProperty(String key, String value) {
    this.headerMap[key] = value;
  }

  // ========== Utility Getters & Setters ========== //

  void setSessionId(String? sessionId) {
    if (sessionId != null) this.headerMap[HttpHeaders.authorizationHeader] = sessionId;
  }

  void setLanguage(String? language) {
    if (language != null) this.headerMap[HeaderParams.LANGUAGE] = language;
  }
}
