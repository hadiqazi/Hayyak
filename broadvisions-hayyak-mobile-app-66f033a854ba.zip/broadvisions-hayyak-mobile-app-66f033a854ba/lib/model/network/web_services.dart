/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import '/model/utils/network_config.dart';

class WebServices {
  WebServices._();

  // ========== AUTH ========== //
  static const LOOKUP = NetworkConfig.SERVER_URL + 'hayyak-user-service/v1/user/lookup';
  static const REQUEST_OTP = NetworkConfig.SERVER_URL + 'hayyak-user-service/v1/otp/request';
  static const REGISTER = NetworkConfig.SERVER_URL + 'hayyak-user-service/v1/auth/signup-user';
  static const LOGIN = NetworkConfig.SERVER_URL + 'hayyak-user-service/v1/auth/login-user';
  static const SOCIAL_LOGIN =
      NetworkConfig.SERVER_URL + 'hayyak-user-service/v1/auth/social-signin';
  static const SOCIAL_SIGNUP =
      NetworkConfig.SERVER_URL + 'hayyak-user-service/v1/auth/social-signup';

  // ========== PROPERTIES ========== //
  static const SEARCH_PROPERTIES =
      NetworkConfig.SERVER_URL + 'hayyak-property-service/v1/property/filter?page=##';
  static const GET_SERVICES =
      NetworkConfig.SERVER_URL + 'hayyak-property-service/v1/value-added-service';
  static const GET_AMENITIES = NetworkConfig.SERVER_URL + 'hayyak-property-service/v1/amenity';
  static const GET_RATINGS =
      NetworkConfig.SERVER_URL + 'hayyak-property-service/v1/rating/filter-customer?page=##';
  static const RATE_PROPERTY = NetworkConfig.SERVER_URL + 'hayyak-property-service/v1/rating';
  static const UPDATE_RATING = NetworkConfig.SERVER_URL + 'hayyak-property-service/v1/rating/##';

  // ========== BOOKING ========== //
  static const MAKE_BOOKING = NetworkConfig.SERVER_URL + 'hayyak-booking-service/v1/booking';
  static const LIST_BOOKINGS =
      NetworkConfig.SERVER_URL + 'hayyak-booking-service/v1/booking/filter?page=##';
  static const GET_BOOKING_DETAILS =
      NetworkConfig.SERVER_URL + 'hayyak-booking-service/v1/booking/detail?id=##';
  static const GET_BOOKING_CANCEL_COST =
      NetworkConfig.SERVER_URL + 'hayyak-booking-service/v1/booking/calculate-cancel?id=##';
  static const CANCEL_BOOKING =
      NetworkConfig.SERVER_URL + 'hayyak-booking-service/v1/booking/cancel?id=##';

  // ========== USER ========== //
  static const UPDATE_PROFILE = NetworkConfig.SERVER_URL + 'hayyak-user-service/v1/user/##';
  static const UPDATE_PASSWORD =
      NetworkConfig.SERVER_URL + 'hayyak-user-service/v1/user/reset-password';
  static const RESET_PASSWORD =
      NetworkConfig.SERVER_URL + 'hayyak-user-service/v1/user/update-password-user';
}
