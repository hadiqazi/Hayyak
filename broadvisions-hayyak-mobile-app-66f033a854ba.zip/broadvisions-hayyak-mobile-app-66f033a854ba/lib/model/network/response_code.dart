/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

class ResponseCode {
  ResponseCode._();

  // ===== SUCCESS CODE ===== //

  static const SUCCESS = 200;

  // ===== HTTP STATUS CODES ===== //

  static const HTTP_BAD_REQUEST = 400;
  static const HTTP_UNAUTHORIZED = 401;
  static const HTTP_NOT_FOUND = 404;
  static const CONFLICT = 409;
  static const HTTP_SERVER_ERRORS_START = 500;
  static const HTTP_SERVER_ERRORS_END = 599;
  static const HTTP_INVALID_RESPONSE = 501;

  // ===== CUSTOM CODES ===== //

  static const REQUEST_TIMEOUT = 601;
  static const INVALID_OTP = 'OTPS.not.verified';
  static const SOCIAL_LOGIN_ERROR = -2002;
  static const SOCIAL_USER_CONFLICT = 999;
}
