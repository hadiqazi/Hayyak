/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import '/model/network/web_service_header.dart';

class NetworkResponse {
  WebServiceHeader header;
  String body;

  NetworkResponse(this.header, this.body);
}
