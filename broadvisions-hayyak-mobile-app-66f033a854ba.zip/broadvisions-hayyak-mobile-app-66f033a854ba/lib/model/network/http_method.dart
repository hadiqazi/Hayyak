/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/02/2022
            Project: hayyak-mobile-app
 */

enum HttpMethod {
  POST,
  PUT,
  PATCH,
  GET,
  DELETE,
}

extension HttpMethodExtension on HttpMethod {
  String get value {
    switch (this) {
      case HttpMethod.POST:
        return 'POST';
      case HttpMethod.PUT:
        return 'PUT';
      case HttpMethod.PATCH:
        return 'PATCH';
      case HttpMethod.GET:
        return 'GET';
      case HttpMethod.DELETE:
        return 'DELETE';
    }
  }
}
