/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/view/screen/splash/splash_screen.dart';

import '/app/theme/light/light_theme_data.dart';
import '/view/utils/constants.dart';

void main() {
  // Disable logs for release mode
  if (kReleaseMode) {
    debugPrint = (String? message, {int? wrapWidth}) {};
  }

  // Customize status bar and icons
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));

  // Use Hybrid Composition to render the GoogleMap widget on Android
  if (defaultTargetPlatform == TargetPlatform.android) {
    AndroidGoogleMapsFlutter.useAndroidViewSurface = true;
  }

  // Run the app
  runApp(HayyakApp());
}

class HayyakApp extends StatefulWidget {
  const HayyakApp({Key? key}) : super(key: key);

  @override
  _HayyakAppState createState() => _HayyakAppState();

  static _HayyakAppState? of(BuildContext context) =>
      context.findAncestorStateOfType<_HayyakAppState>();
}

class _HayyakAppState extends State<HayyakApp> {
  Locale? _locale;

  void setLocale(Locale value) {
    setState(() {
      _locale = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hayyak',
      debugShowCheckedModeBanner: false,

      // Theme
      theme: LightThemeData.get,

      // List all of the app's supported locales here
      supportedLocales: Constants.SUPPORTED_LANGUAGES.map((language) => Locale(language)).toList(),
      locale: _locale,

      // These delegates make sure that the localization data for the proper language is loaded
      localizationsDelegates: [
        // A class which loads the translations from JSON files
        I18n.getDelegate(),
        // Built-in localization of basic text for Material widgets
        GlobalMaterialLocalizations.delegate,
        // Built-in localization of basic text for Cupertino widgets
        GlobalCupertinoLocalizations.delegate,
        // Built-in localization for text direction LTR/RTL
        GlobalWidgetsLocalizations.delegate,
      ],
      // Returns a locale which will be used by the app
      localeResolutionCallback: (locale, supportedLocales) {
        // If system locale is null, return the default supported locale
        if (locale == null) return supportedLocales.first;

        // Check if the current device locale is supported
        for (var supportedLocale in supportedLocales) {
          if (supportedLocale.languageCode == locale.languageCode) {
            // && supportedLocale.countryCode == locale.countryCode) {
            return supportedLocale;
          }
        }
        // If the locale of the device is not supported, use the first one from the list.
        return supportedLocales.first;
      },

      home: SplashScreen(),
    );
  }
}
