/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';

class Constants {
  Constants._();

  static const SUPPORTED_LANGUAGES = ['en', 'ar'];
  static const DEFAULT_LANGUAGE = "en";

  static const sessionToken = 'session_token';
  static const loggedInUser = 'logged_in_user';
  static const loggedInUserJson = 'logged_in_user_json';
  static const lookupData = 'lookup_data';
  static const amenityTypes = 'lookup_data';
  static const bedTypes = 'bed_types';
  static const roomTypes = 'room_types';
  static const propertySearchRequest = 'property_search_request';

  static final emailRegex =
      RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
  static final phoneRegex = RegExp(r"(^(?:[+0]9)?[0-9]{10,12}$)");

  static final lookupRetriesCount = 3;
  static final roomSelectorThreshold = 10;
  static final guestSelectorThreshold = 8;
  static final maxPriceRangeInFilter = 1000.0;
}

class ApiKeys {
  ApiKeys._();

  static const googlePlaces = 'AIzaSyBqZM4qPFVD7P1POdcoaJ2k4OMEV-K7miE';
}

class Currency {
  static const longFormat = "#,##0.00";
  static const shortFormat = "#,##0";
  static const appearsAfterText = true;
  static const hasSpace = true;

  static getSymbol(BuildContext context) {
    return I18n.values(context)!.currency;
  }
}
