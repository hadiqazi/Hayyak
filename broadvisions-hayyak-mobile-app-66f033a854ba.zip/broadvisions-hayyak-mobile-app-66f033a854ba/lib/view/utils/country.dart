/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';

class Country {
  String code;
  String name;

  Country(this.code, this.name);

  @override
  bool operator ==(Object other) => other is Country && other.code == code;

  @override
  int get hashCode => code.hashCode;

  static List<Country> getAll(BuildContext context) {
    final i18n = I18n.values(context)!;

    final List<Country> countries = [];
    countries.add(Country('sau', i18n.country_sau));

    return countries;
  }

  static Country? tryParse(BuildContext context, String countryCode) {
    // Get all supported countries
    final countries = getAll(context);
    // Find the given country code in available countries
    Country? country;
    try {
      country = countries.singleWhere((country) => country.code == countryCode);
    } catch (e) {}

    // Clone the object so changing it won't affect available countries list
    Country? cloned;
    if (country != null) {
      cloned = Country(country.code, country.name);
    }
    return cloned;
  }
}
