/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 08/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';

class Language {
  String code;
  String name;

  Language(this.code, this.name);

  @override
  bool operator ==(Object other) => other is Language && other.code == code;

  @override
  int get hashCode => code.hashCode;

  static List<Language> getAll(BuildContext context) {
    final i18n = I18n.values(context)!;

    final List<Language> languages = [];
    languages.add(Language('en', i18n.language_en));
    languages.add(Language('ar', i18n.language_ar));

    return languages;
  }

  static Language? tryParse(BuildContext context, String languageCode) {
    // Get all supported languages
    final languages = getAll(context);
    // Find the given language code in available languages
    Language? language;
    try {
      language = languages.singleWhere((language) => language.code == languageCode);
    } catch (e) {}

    // Clone the object so changing it won't affect available languages list
    Language? cloned;
    if (language != null) {
      cloned = Language(language.code, language.name);
    }
    return cloned;
  }
}