/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 08/11/2021
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';

class ListDataHelper {
  ListDataHelper._();

  /// Creates appropriate widgets against different states of FutureBuilder
  static Widget prepareFutureBuilder(
      {required AsyncSnapshot snapshot,
      required Widget success,
      required BuildContext context,
      String? loadingText}) {
    // Set loading data
    final loadingTextVal = loadingText ?? I18n.values(context)!.loader_data;

    if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
      // Display data
      return success;
    } else if (snapshot.connectionState == ConnectionState.waiting) {
      // Show loading view
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            HayyakProgressIndicator(),
            SizedBox(height: 16),
            Text(loadingTextVal, style: TextStyle(fontSize: 16))
          ],
        ),
      );
    } else if (snapshot.hasError) {
      return displayError(context, snapshot.error);
    } else {
      // Not sure why would this happen. Show an error message.
      return displayUnknownError(context);
    }
  }

  /// Display a view when there's no data
  static Widget displayEmptyDataMsg(
    BuildContext context,
    String message, {
    String? title,
    String? image,
  }) {
    return _showDataMessage(
      context,
      image ?? Assets.image.emptyData,
      title ?? I18n.values(context)!.data_empty_title,
      message,
      LightTheme.listEmptyDataTitle,
    );
  }

  /// When not sure why error occurred, show this error view.
  static Widget displayUnknownError(BuildContext context) {
    return _showDataMessage(
        context,
        Assets.image.errorInData,
        I18n.values(context)!.data_error_title,
        I18n.values(context)!.data_error_msg,
        LightTheme.listErrorInDataTitle);
  }

  /// Display the error view
  static Widget displayError(BuildContext context, Object? error) {
    var displayMsg;
    if (error is AppException) {
      displayMsg = error.message;
    } else if (error is String) {
      displayMsg = error;
    }
    if (displayMsg == null) {
      displayMsg = I18n.values(context)!.data_error_unknown_msg;
    }

    // Show error
    return _showDataMessage(
      context,
      Assets.image.errorInData,
      I18n.values(context)!.data_error_title,
      displayMsg,
      LightTheme.listErrorInDataTitle,
    );
  }

  /// Displays the formatted message
  static Widget _showDataMessage(
      BuildContext context, String icon, String title, String message, Color titleColor) {
    //
    final textTheme = Theme.of(context).textTheme;

    return Container(
      padding: EdgeInsets.all(32),
      color: Theme.of(context).colorScheme.background,
      child: Center(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          // Imagery
          SvgPicture.asset(icon, width: 200),
          SizedBox(height: 32),
          // Title
          /*Text(title,
              style: textTheme.headline6?.copyWith(fontWeight: FontWeight.bold, color: titleColor)),
          SizedBox(height: 10),*/
          // Message
          Text(
            message,
            textAlign: TextAlign.center,
            style: textTheme.bodyText1?.copyWith(color: LightTheme.textTertiary),
          ),
          SizedBox(height: 50),
        ],
      )),
    );
  }
}
