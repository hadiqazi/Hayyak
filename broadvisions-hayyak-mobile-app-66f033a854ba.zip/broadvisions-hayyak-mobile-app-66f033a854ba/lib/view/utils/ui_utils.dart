/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/progress_dialog.dart';
import 'package:intl/intl.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:timeago/timeago.dart' as timeago;

import '/app/theme/light/light_theme.dart';

class UiUtils {
  UiUtils._();

  /// Navigate to another screen
  @optionalTypeArgs
  static Future<T?> navigateTo<T extends Object?>({
    required BuildContext context,
    required Widget child,
    bool endCurrent = false,
  }) {
    if (endCurrent)
      return Navigator.of(context).pushReplacement(CupertinoPageRoute(builder: (_) => child));
    else
      return Navigator.of(context).push(CupertinoPageRoute(builder: (_) => child));
  }

  static void navigateAndClearPrevious({
    required BuildContext context,
    required Widget child,
  }) {
    Navigator.of(context)
        .pushAndRemoveUntil(CupertinoPageRoute(builder: (_) => child), (route) => false);
  }

  static Future<T?> showOverlay<T extends Object>(
      {required BuildContext context, required Widget child}) {
    return showCupertinoModalPopup(context: context, builder: (context) => child);
  }

  /// Navigate back
  @optionalTypeArgs
  static void navigateBack<T extends Object?>(BuildContext context, [T? result]) {
    Navigator.of(context).pop(result);
  }

  /// Creates a progress dialog
  static dynamic createProgressDialog(BuildContext context, String message, {cancelable = true}) {
    return ProgressDialog(context, message, cancelable);
  }

  /// Displays success message
  static void displaySuccess(BuildContext context, String message) {
    final snackBar = SnackBar(
        content: Text(
          message,
          style: TextStyle(color: LightTheme.onSuccessSnackBar),
        ),
        backgroundColor: LightTheme.successSnackBar);
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  /// Displays error message
  static void displayError(BuildContext context, String message) {
    final snackBar = SnackBar(
        content: Text(
          message,
          style: TextStyle(color: LightTheme.onErrorSnackBar),
        ),
        backgroundColor: LightTheme.errorSnackBar);
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  /// Displays error message from the exception
  static void displayException(BuildContext context, dynamic exception) {
    String? message;

    if (exception is AppException) {
      message = exception.localizedMessage != null
          ? exception.localizedMessage
          : exception.message != null
              ? exception.message
              : '';
    } else {
      message = (exception as TypeError).toString();
    }

    debugPrint('LOCALIZED EXCEPTION MSG: $message');
    displayError(context, message!);
  }

  /// Displays success message
  static void displayInformation(BuildContext context, String message) {
    final colorScheme = Theme.of(context).colorScheme;
    final snackBar = SnackBar(
        content: Text(
          message,
          style: TextStyle(color: colorScheme.onSecondary),
        ),
        backgroundColor: colorScheme.secondary);
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  /// Loads an image from network
  static Widget getNetworkImage(
      {required String imageUrl, String? placeholder, double? width, double? height, BoxFit? fit}) {
    // Set default placeholder
    if (placeholder == null) placeholder = Assets.image.defaultPlaceholder;

    return CachedNetworkImage(
      placeholder: (context, _) => Image.asset(placeholder!),
      fit: fit,
      width: width,
      height: height,
      imageUrl: imageUrl,
    );
  }

  /// Formats the number/rating to a single precision decimal
  static String formatRating(double rating) {
    return rating.toStringAsFixed(1);
  }

  /// Formats the price with currency
  static String formatPrice(BuildContext context, double price, {bool useShortFormat = false}) {
    final format = useShortFormat ? Currency.shortFormat : Currency.longFormat;
    final currencyFormat = new NumberFormat(format, Utils.getCurrentLanguage(context));
    final amount = currencyFormat.format(price);
    final space = Currency.hasSpace ? ' ' : '';
    String symbol = Currency.getSymbol(context);
    String formatted;

    if (Currency.appearsAfterText) {
      formatted = amount + space + symbol;
    } else {
      formatted = symbol + space + amount;
    }
    return formatted;
  }

  /// Formats the provided DateTime to date string
  static String formatDate(BuildContext context, DateTime date) {
    final locale = Utils.getCurrentLanguage(context);
    final format = locale == 'en' ? 'MMM dd, yyyy' : 'dd MMM yyyy';

    return DateFormat(format, locale).format(date.toLocal());
  }

  /// Formats the provided DateTime to date & time string
  static String formatDateTime(BuildContext context, DateTime date) {
    final locale = Utils.getCurrentLanguage(context);
    final format = locale == 'en' ? 'MMM dd, yyyy |' : 'dd MMM yyyy |';

    return DateFormat(format, locale).add_jm().format(date.toLocal());
  }

  /// Formats the provided DateTime to time past format
  static String formatDateAsTimePast(BuildContext context, DateTime date) {
    timeago.setLocaleMessages('ar', timeago.ArMessages());
    return timeago.format(date, locale: Utils.getCurrentLanguage(context));
  }

  /// Formats the provided DateTime to date & time string
  static Future<String> formatPhone(String phone) async {
    try {
      PhoneNumber number = await PhoneNumber.getRegionInfoFromPhoneNumber(phone);
      final num = number.phoneNumber?.substring((number.dialCode?.length ?? 0) + 1);
      return '+${number.dialCode} ${num?.substring(0, 3)} ${num?.substring(3)}';
    } catch (e) {
      return phone;
    }
  }
}
