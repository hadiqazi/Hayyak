/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/02/2022
            Project: hayyak-mobile-app
 */

import 'dart:io';

class ImageFile {
  String name;
  File file;

  ImageFile(this.name, this.file);
}
