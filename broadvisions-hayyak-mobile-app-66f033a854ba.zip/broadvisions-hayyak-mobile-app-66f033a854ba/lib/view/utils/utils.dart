/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/model/core/cancellation_reason.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '/model/exception/app_exception.dart';
import '/model/network/response_code.dart';

class Utils {
  Utils._();

  /// Checks for null or empty string
  static bool isNullOrEmpty(dynamic obj) {
    return obj == null || ((obj is String || obj is List || obj is Map) && obj.isEmpty);
  }

  /// Processes the passed exception and adds appropriate localized message
  /// against provided error code
  static AppException processException(AppException ex, BuildContext context) {
    //
    switch (ex.errorCode) {
      case ResponseCode.HTTP_BAD_REQUEST:
        ex.localizedMessage = I18n.values(context)?.http_bad_request;
        break;
      case ResponseCode.HTTP_UNAUTHORIZED:
        ex.localizedMessage = I18n.values(context)?.http_unauthorized;
        break;
      case ResponseCode.HTTP_NOT_FOUND:
        ex.localizedMessage = I18n.values(context)?.http_not_found;
        break;
      case ResponseCode.HTTP_INVALID_RESPONSE:
        ex.localizedMessage = I18n.values(context)?.http_invalid_response;
        break;
      case ResponseCode.REQUEST_TIMEOUT:
        ex.localizedMessage = I18n.values(context)?.request_timed_out;
        break;
      default:
        final code = ex.errorCode;
        if (code != null &&
            code >= ResponseCode.HTTP_SERVER_ERRORS_START &&
            code <= ResponseCode.HTTP_SERVER_ERRORS_END)
          ex.localizedMessage = I18n.values(context)?.http_5xx(code.toString());
        //
        else if (Utils.isNullOrEmpty(ex.message)) {
          String codeVal = code?.toString() ?? '';
          ex.localizedMessage = I18n.values(context)?.unknown_error(codeVal);
        }
    }
    return ex;
  }

  static String getCurrentLanguage(BuildContext context) {
    return Localizations.localeOf(context).languageCode;
  }

  static bool isRtlMode(BuildContext context) {
    return Directionality.of(context) == TextDirection.rtl;
  }

  static String formatDateForNetwork(DateTime dateTime) {
    return dateTime.toIso8601String();
  }

  static List<CancellationReason> getCancellationReasons(BuildContext context) {
    final i18n = I18n.values(context)!;

    return [
      CancellationReason("changed dates or destination", i18n.cancellation_reason_1),
      CancellationReason("personal or called off", i18n.cancellation_reason_2),
      CancellationReason("change of individuals", i18n.cancellation_reason_3),
      CancellationReason("found alternative", i18n.cancellation_reason_4),
      CancellationReason("other", i18n.cancellation_reason_5),
    ];
  }

  /// Store token and user details in cache and storage
  static saveUserLoginInfo(String sessionToken, User user, [bool skipOverwrite = false]) async {
    Cache.put(Constants.sessionToken, sessionToken, persist: !skipOverwrite);
    saveProfileInfo(user, skipOverwrite);
  }

  /// Store user details in cache and storage
  static saveProfileInfo(User user, [bool skipOverwrite = false]) async {
    Cache.put(Constants.loggedInUser, user);

    if (!skipOverwrite) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString(Constants.loggedInUserJson, jsonEncode(user.toJson()));
    }
  }

  /// Remove token and user details from cache and storage
  static clearUserLoginInfo() async {
    Cache.remove(Constants.sessionToken);
    Cache.remove(Constants.loggedInUser);

    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove(Constants.loggedInUserJson);
  }

  // Return whether a password is strong or not
  static bool isPasswordStrong(int strength) {
    return strength >= 3;
  }
}
