/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 16/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/model/core/booking.dart';
import 'package:hayyak/model/core/booking_status.dart';
import 'package:hayyak/model/core/cancellation_policy.dart';
import 'package:hayyak/model/core/value_added_service.dart';
import 'package:hayyak/model/dto/request/make_booking_request.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/dialog_box.dart';
import 'package:hayyak/view/widget/service_date_selection_screen.dart';

class BookingUtils {
  BookingUtils._();

  /// Opens up a range picker view to select date range
  static void chooseDateRange({
    required BuildContext context,
    required DateTimeRange? initialDateRange,
    ValueChanged<DateTimeRange>? onRangeSelected,
  }) async {
    //
    DateTimeRange? range = await showDateRangePicker(
        context: context,
        firstDate: DateTime.now().add(Duration(days: 1)),
        lastDate: DateTime.now().add(Duration(days: 30 * 6)),
        initialDateRange: initialDateRange,
        saveText: I18n.values(context)!.action_select.toUpperCase(),
        builder: (BuildContext context, Widget? child) {
          return Theme(
            data: Theme.of(context).copyWith(
              appBarTheme: AppBarTheme(
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            child: Padding(
              padding: EdgeInsets.only(top: Assets.dimens.overlayTopMargin),
              child: Container(
                  clipBehavior: Clip.hardEdge,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(20),
                      topRight: const Radius.circular(20),
                    ),
                  ),
                  child: child),
            ),
          );
        });
    print('picked = $range');

    if (range != null && onRangeSelected != null) {
      onRangeSelected(range);
    }
  }

  static Future<void> chooseMultipleDates({
    required BuildContext context,
    required ValueAddedService service,
    required MakeBookingRequest bookingRequest,
    ValueChanged<List<DateTime>?>? onSelection,
  }) async {
    Object? dates = await UiUtils.showOverlay(
        context: context,
        child: ServiceDateSelectionScreen(
          service: service,
          bookingRequest: bookingRequest,
        ));

    if (onSelection != null) onSelection(dates as List<DateTime>?);
  }

  /// Cancels the booking process after confirmation from user and taker user back to details screen
  static void cancelBookingProcess(BuildContext context, int numberOfPops) {
    final i18n = I18n.values(context)!;

    DialogBox(context).show(
      title: i18n.cancel_booking_process_title,
      message: i18n.cancel_booking_process_msg,
      mainButton: i18n.txt_yes,
      onMainButtonClick: () {
        for (int i = 0; i < numberOfPops; i++) {
          UiUtils.navigateBack(context);
        }
      },
      secondButton: i18n.txt_no,
    );
  }

  /// Returns a the date or time until when the user can cancel a booking free of cost
  static String calculateFreeCancellationDate(BuildContext context, DateTime checkInDate,
      String checkInTime, CancellationPolicy cancellationPolicy) {
    //
    // Calculate cut-off time
    final date = checkInDate.subtract(Duration(days: cancellationPolicy.cutOffDays));
    DateTime cutOffTime;

    if (cancellationPolicy.resetTimeToMidnight) {
      // Reset time to midnight
      cutOffTime = DateTime(date.year, date.month, date.day, 0, 0, 0);
    } else {
      // Combine check-in time in check-in date
      cutOffTime = combineDateAndTime(date, checkInTime);
    }

    // Get current time
    final currentTime = DateTime.now();
    final String cancellationTime;

    // Add freeHoursInsideCutoff in current time to handle scenario where user is trying to cancel
    // a booking at 23:15pm. The cutoff time is still 45m away but we must give user minimum
    // freeHoursInsideCutoff time for cancellation instead of just 45m or less.
    if (currentTime
        .add(Duration(hours: cancellationPolicy.freeHoursInsideCutoff))
        .isAfter(cutOffTime)) {
      // Immediate booking, since current time has already past cut-off time
      cancellationTime =
          I18n.values(context)!.cancellation_hours(cancellationPolicy.freeHoursInsideCutoff);
    } else {
      // Booking in future
      cancellationTime = I18n.values(context)!.cancellation_time(
          UiUtils.formatDateTime(context, cutOffTime.subtract(Duration(minutes: 1))));

      /* // Below logic will be used when we only give limited time to user for free cancellation.
         // For remaining span in between, the deduction will be calculated by server and doesn't
         // need to be shown/handled here.

      DateTime cancellationUntil =
          currentTime.add(Duration(hours: cancellationPolicy.freeHoursOutsideCutoff));
      if (cancellationUntil.isAfter(cutOffTime)) {
        // Too less time until cutoff, set cutoff time as cancellation time
        cancellationTime = I18n.values(context)!.cancellation_time(
            UiUtils.formatDateTime(context, cutOffTime.subtract(Duration(minutes: 1))));
      } else {
        // Set the cancellation duration
        cancellationTime =
            I18n.values(context)!.cancellation_hours(cancellationPolicy.freeHoursOutsideCutoff);
      }*/
    }

    return cancellationTime;
  }

  /// Uses the provided date object and time string to create a DateTime object having values
  /// of both
  static DateTime combineDateAndTime(DateTime date, String time) {
    final timeTokens = time.split(':');
    final hours = timeTokens.length > 0 ? int.tryParse(timeTokens[0]) ?? 0 : 0;
    final minutes = timeTokens.length > 1 ? int.tryParse(timeTokens[1]) ?? 0 : 0;

    return DateTime(
      date.year,
      date.month,
      date.day,
      hours,
      minutes,
    );
  }

  static bool canBookingBeCancelled(Booking booking) {
    final checkInTime = BookingUtils.combineDateAndTime(
        booking.checkInDate, booking.property?.building?.checkInTime ?? '');
    return booking.status == BookingStatus.ACTIVE.value && DateTime.now().isBefore(checkInTime);
  }
}
