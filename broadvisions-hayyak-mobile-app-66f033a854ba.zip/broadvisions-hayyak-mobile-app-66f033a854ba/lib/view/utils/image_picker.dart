/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 04/02/2022
            Project: hayyak-mobile-app
 */

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/view/utils/image_file.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';

class CroppedImagePicker {
  final BuildContext context;

  CroppedImagePicker(this.context);

  Future<ImageFile?> pickImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 512,
      maxHeight: 512,
      imageQuality: 100,
    );

    if (pickedFile != null) {
      return _cropImage(pickedFile);
    } else {
      return null;
    }
  }

  Future<ImageFile?> _cropImage(XFile imageFile) async {
    final theme = Theme.of(context);
    final i18n = I18n.values(context)!;

    File? croppedFile = await ImageCropper().cropImage(
      sourcePath: imageFile.path,
      aspectRatioPresets: [
        CropAspectRatioPreset.square,
        CropAspectRatioPreset.ratio3x2,
        CropAspectRatioPreset.original,
        CropAspectRatioPreset.ratio4x3,
        CropAspectRatioPreset.ratio16x9,
      ],
      androidUiSettings: AndroidUiSettings(
        toolbarTitle: i18n.crop_screen_title,
        toolbarColor: theme.appBarTheme.backgroundColor,
        toolbarWidgetColor: theme.appBarTheme.foregroundColor,
        activeControlsWidgetColor: theme.primaryColor,
        initAspectRatio: CropAspectRatioPreset.original,
        lockAspectRatio: false,
      ),
      iosUiSettings: IOSUiSettings(
        title: i18n.crop_screen_title,
      ),
    );

    if (croppedFile == null)
      return null;
    else
      return ImageFile(imageFile.name, croppedFile);
  }
}
