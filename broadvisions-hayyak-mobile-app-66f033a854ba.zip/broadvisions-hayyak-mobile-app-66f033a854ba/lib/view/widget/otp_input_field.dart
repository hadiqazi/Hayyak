/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 11/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class OTPInputField extends StatelessWidget {
  final StreamController<ErrorAnimationType>? errorController;
  final TextEditingController textController;
  final TextInputType keyboardType;

  const OTPInputField({
    required this.textController,
    required this.errorController,
    required this.keyboardType,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return PinCodeTextField(
      appContext: context,
      pastedTextStyle: TextStyle(
        color: theme.primaryColor,
        fontWeight: FontWeight.bold,
      ),
      length: 4,
      pinTheme: PinTheme(
        shape: PinCodeFieldShape.underline,
        fieldWidth: 65,
        fieldHeight: 60,
        borderWidth: 1,
        borderRadius: BorderRadius.circular(5),
        // Field which do not contain value
        inactiveFillColor: theme.colorScheme.surface,
        inactiveColor: Colors.black,
        // Active field
        selectedFillColor: theme.colorScheme.surface,
        selectedColor: theme.primaryColor,
        // Field which do not contain value
        activeFillColor: theme.colorScheme.surface,
        activeColor: Colors.black,
        // Fields with error
        errorBorderColor: theme.errorColor,
      ),
      enableActiveFill: true,
      obscureText: false,
      // obscuringCharacter: '*',
      cursorColor: Colors.black,
      blinkWhenObscuring: true,
      animationType: AnimationType.fade,
      /*validator: (v) {
        if (v!.length < 3) {
          return "I'm from validator";
        } else {
          return null;
        }
      },*/
      controller: textController,
      animationDuration: Duration(milliseconds: 300),
      errorAnimationController: errorController,
      keyboardType: keyboardType,
      /*boxShadows: [
        BoxShadow(
          offset: Offset(0, 1),
          color: Colors.black12,
          blurRadius: 10,
        )
      ],*/
      /*onCompleted: (v) {
        print("Completed");
      },*/
      onChanged: (value) {
        // print(value);
      },
      beforeTextPaste: (text) {
        //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
        //but you can show anything you want here, like your pop up saying wrong paste format or etc
        return true;
      },
    );
  }
}
