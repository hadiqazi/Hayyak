/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 08/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/back_button.dart';

class AppBarBackButton extends StatelessWidget {
  const AppBarBackButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomBackButton(
      padding: 0,
      iconSize: 16,
      onPressed: () {
        UiUtils.navigateBack(context);
      },
    );
  }
}
