/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 20/01/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';

class HayyakProgressIndicator extends ProgressIndicator {
  final double? width;

  const HayyakProgressIndicator({this.width, Key? key}) : super(key: key);

  @override
  _HayyakProgressIndicatorState createState() => _HayyakProgressIndicatorState();
}

class _HayyakProgressIndicatorState extends State<HayyakProgressIndicator> {
  //
  @override
  Widget build(BuildContext context) {
    return Image.asset(Assets.image.loader, width: widget.width ?? 60);
  }
}
