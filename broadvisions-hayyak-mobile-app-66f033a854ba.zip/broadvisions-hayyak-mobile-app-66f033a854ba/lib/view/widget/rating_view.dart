/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 13/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hayyak/app/resource/assets.dart';

class RatingView extends StatelessWidget {
  final double initialRating;
  final double starSize;
  final int? minRating;
  final ValueChanged<double>? onRatingChanged;

  const RatingView({
    required this.initialRating,
    this.starSize = 14,
    this.minRating,
    this.onRatingChanged,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isReadOnlyMode = onRatingChanged == null;

    return RatingBar(
      initialRating: initialRating,
      direction: Axis.horizontal,
      allowHalfRating: isReadOnlyMode,
      minRating: (minRating ?? 0).toDouble(),
      itemCount: 5,
      ratingWidget: RatingWidget(
        empty: _getStar(0),
        half: _getStar(1),
        full: _getStar(2),
      ),
      ignoreGestures: isReadOnlyMode,
      itemSize: starSize,
      itemPadding: EdgeInsets.symmetric(horizontal: isReadOnlyMode ? 1 : 4),
      glow: false,
      onRatingUpdate: (rating) {
        if (!isReadOnlyMode && onRatingChanged != null) onRatingChanged!(rating);
      },
    );
  }

  Widget _getStar(int type) {
    final asset;
    if (type == 0)
      asset = Assets.image.starEmpty;
    else if (type == 1)
      asset = Assets.image.starHalf;
    else
      asset = Assets.image.starFull;

    return SvgPicture.asset(asset);
  }
}
