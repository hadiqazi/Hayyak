/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 17/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/view/widget/tertiary_button.dart';

class DialogBox {
  BuildContext context;

  DialogBox(this.context);

  void show({
    required String? title,
    required String? message,
    String? mainButton,
    Function? onMainButtonClick,
    bool isNegativeAction = false,
    String? secondButton,
    Function? onSecondButtonClick,
    bool isDismissible = true,
  }) {
    //                     //
    var bodyText = message != null ? Text(message) : null;

    showCustom(
      title: title,
      contents: bodyText,
      mainButton: mainButton,
      onMainButtonClick: onMainButtonClick,
      isNegativeAction: isNegativeAction,
      secondButton: secondButton,
      onSecondButtonClick: onSecondButtonClick,
      isDismissible: isDismissible,
    );
  }

  void showCustom({
    required String? title,
    required Widget? contents,
    String? mainButton,
    Function? onMainButtonClick,
    bool isNegativeAction = false,
    String? secondButton,
    Function? onSecondButtonClick,
    bool autoCloseDialog = true,
    bool? isDismissible,
  }) {
    //                     //
    assert(!(mainButton == null && secondButton != null),
        'Negative button makes sense only if action/positive button text is provided.');

    var titleText;
    if (title != null) titleText = Text(title);
    final mainButtonText = mainButton == null ? I18n.values(context)!.txt_ok : mainButton;

    if (Platform.isIOS) {
      _showCupertinoDialog(titleText, contents, mainButtonText, onMainButtonClick, isNegativeAction,
          secondButton, onSecondButtonClick, isDismissible!,
          autoCloseDialog: autoCloseDialog);
    } else {
      _showMaterialDialog(titleText, contents, mainButtonText, onMainButtonClick, isNegativeAction,
          secondButton, onSecondButtonClick, isDismissible!,
          autoCloseDialog: autoCloseDialog);
    }
  }

  void _showMaterialDialog(
      Text? titleText,
      Widget? contents,
      String mainButton,
      Function? onMainButtonClick,
      bool isNegativeAction,
      String? secondButton,
      Function? onSecondButtonClick,
      bool isDismissible,
      {bool autoCloseDialog = true}) {
    //                     //
    var mainButtonText = Text(mainButton);

    // Show dialog
    showDialog(
      context: context,
      barrierDismissible: isDismissible,
      builder: (BuildContext context) {
        return AlertDialog(
          title: titleText,
          content: contents,
          actions: <Widget>[
            // Negative button
            if (secondButton != null)
              TertiaryButton(
                child: Text(
                  secondButton,
                  // style: buttonTextStyle,
                ),
                onPressed: () {
                  Navigator.of(context).pop();

                  if (onSecondButtonClick != null) {
                    onSecondButtonClick();
                  }
                },
              ),
            // Action/Positive button
            TertiaryButton(
              child: mainButtonText,
              onPressed: () {
                if (autoCloseDialog) {
                  Navigator.of(context).pop();
                }
                if (onMainButtonClick != null) {
                  onMainButtonClick();
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _showCupertinoDialog(
      Text? titleText,
      Widget? contents,
      String mainButton,
      Function? onMainButtonClick,
      bool isNegativeAction,
      String? secondButton,
      Function? onSecondButtonClick,
      bool isDismissible,
      {bool autoCloseDialog = true}) {
    //
    showDialog(
      context: context,
      barrierDismissible: isDismissible,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
          title: titleText,
          content: contents,
          actions: <Widget>[
            // Negative button
            if (secondButton != null)
              CupertinoDialogAction(
                  isDefaultAction: false,
                  child: Text(secondButton),
                  onPressed: () {
                    Navigator.of(context).pop();

                    if (onSecondButtonClick != null) {
                      onSecondButtonClick();
                    }
                  }),
            // Action/Positive button
            CupertinoDialogAction(
              isDefaultAction: true,
              isDestructiveAction: isNegativeAction,
              child: Text(mainButton),
              onPressed: () {
                if (autoCloseDialog) {
                  Navigator.of(context).pop();
                }
                if (onMainButtonClick != null) {
                  onMainButtonClick();
                }
              },
            ),
          ],
        );
      },
    );
  }
}
