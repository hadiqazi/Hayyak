/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';

class FloatingBottomNavbarItem {
  final String? title;
  final IconData? icon;
  final Widget? customWidget;

  FloatingBottomNavbarItem({
    this.icon,
    this.title,
    this.customWidget,
  }) : assert(icon != null || customWidget != null);
}
