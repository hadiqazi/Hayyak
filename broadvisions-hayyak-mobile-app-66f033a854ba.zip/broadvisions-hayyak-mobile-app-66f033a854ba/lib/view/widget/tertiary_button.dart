/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 08/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';

class TertiaryButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final Widget child;
  final bool uppercase;
  final ButtonStyle? style;

  const TertiaryButton({
    required this.child,
    required this.onPressed,
    this.uppercase = true,
    this.style,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Make text uppercase
    var newChild = child;
    if (child is Text && uppercase) {
      Text text = child as Text;

      var style = text.style ?? TextStyle();
      style = style.copyWith(letterSpacing: 1);

      newChild = Text(text.data!.toUpperCase(), style: style);
    }

    // Stylize and build button
    return TextButton(
      onPressed: onPressed,
      child: newChild,
      style: style,
    );
  }
}
