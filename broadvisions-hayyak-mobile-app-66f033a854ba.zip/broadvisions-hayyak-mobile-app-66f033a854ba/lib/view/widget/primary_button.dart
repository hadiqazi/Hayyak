/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';

class PrimaryButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final Widget child;
  final bool uppercase;
  final bool maxWide;
  final double? width;
  final Color? backgroundColor;

  const PrimaryButton({
    required this.child,
    required this.onPressed,
    this.uppercase = true,
    this.maxWide = false,
    this.width,
    this.backgroundColor,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Make text uppercase
    var newChild = child;
    if (child is Text && uppercase) {
      Text text = child as Text;
      newChild = Text(text.data!.toUpperCase(), style: text.style);
    }

    // Stylize and build button
    return ElevatedButton(
      onPressed: onPressed,
      child: newChild,
      style: ElevatedButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(Assets.dimens.roundedCornerSize),
        ),
        elevation: 0,
        minimumSize: Size(
          maxWide ? double.maxFinite : width ?? Assets.dimens.minButtonWidth,
          Assets.dimens.buttonHeight,
        ),
        primary: backgroundColor,
      ),
    );
  }
}
