/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 09/11/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';

class FormContainer extends StatelessWidget {
  final Widget child;
  final bool handleFullPageScroll;

  const FormContainer({required this.child, this.handleFullPageScroll = false, Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: handleFullPageScroll
          ?
          // Create a custom scroll view so children can be placed apart vertically
          CustomScrollView(
              slivers: [
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: this.child,
                ),
              ],
            )
          // Otherwise, show the child as is
          : this.child,
      behavior: HitTestBehavior.translucent,
      onTap: () {
        FocusScope.of(context).unfocus();
      },
    );
  }
}
