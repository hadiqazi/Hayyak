/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 04/11/2021
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';

class ProgressDialog {
  BuildContext context;
  String message;
  bool cancelable;

  ProgressDialog(this.context, this.message, this.cancelable);

  void show() {
    showDialog(
      context: context,
      builder: (_) => WillPopScope(
        child: AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Assets.dimens.roundedCornerSize),
          ),
          content: Row(
            children: [
              HayyakProgressIndicator(),
              SizedBox(width: 16),
              Flexible(child: Text(message, style: Theme.of(context).textTheme.subtitle1)),
            ],
          ),
        ),
        onWillPop: () async => cancelable,
      ),
    );
  }

  void dismiss() {
    Navigator.of(context, rootNavigator: true).pop();
  }
}
