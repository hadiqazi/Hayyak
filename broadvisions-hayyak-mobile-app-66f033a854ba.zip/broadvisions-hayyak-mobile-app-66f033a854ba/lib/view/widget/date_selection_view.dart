/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 14/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:intl/intl.dart';

class DateSelectionCard extends StatelessWidget {
  final String label;
  final String text;
  final VoidCallback? onPressed;

  const DateSelectionCard({
    required this.label,
    required this.text,
    this.onPressed,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(color: Color(0x09000000), blurRadius: 14),
          ],
        ),
        child: Card(
          elevation: 0,
          clipBehavior: Clip.hardEdge,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Assets.dimens.roundedCornerSize),
          ),
          child: InkWell(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: IntrinsicHeight(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Flexible(
                      child: Icon(Icons.calendar_today),
                    ),
                    Flexible(
                      child: SizedBox(width: 25, child: Center(child: VerticalDivider())),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(label, style: Theme.of(context).textTheme.caption),
                        SizedBox(height: 4),
                        Text(text),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            onTap: onPressed,
          ),
        ),
      ),
    );
  }

  static String formatDate(DateTime? date) {
    if (date == null)
      return '';
    else
      return DateFormat('dd/MM/yy').format(date);
  }
}
