/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 16/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/view/widget/tertiary_button.dart';

class AppBarAction extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;

  const AppBarAction({required this.text, required this.onPressed, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TertiaryButton(
      child: Text(text),
      uppercase: false,
      style: TextButton.styleFrom(textStyle: Theme.of(context).textTheme.subtitle1),
      onPressed: onPressed,
    );
  }
}
