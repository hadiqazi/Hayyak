/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 08/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';

class SecondaryButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final Widget child;
  final bool uppercase;
  final bool maxWide;
  final double? width;
  final bool greyVariant;
  final double? height;

  const SecondaryButton({
    required this.child,
    required this.onPressed,
    this.uppercase = true,
    this.maxWide = false,
    this.width,
    this.greyVariant = false,
    this.height,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Make text uppercase
    var newChild = child;
    if (child is Text && uppercase) {
      Text text = child as Text;
      newChild = Text(text.data!.toUpperCase(), style: text.style);
    }

    final primaryColor = Theme.of(context).primaryColor;
    final textColor = greyVariant ? Colors.black : primaryColor;
    final borderColor = greyVariant ? Color(0xFFD3D3D3) : primaryColor;

    // Stylize and build button
    return OutlinedButton(
      onPressed: onPressed,
      child: newChild,
      style: OutlinedButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(Assets.dimens.roundedCornerSize),
        ),
        primary: textColor,
        side: BorderSide(color: borderColor),
        elevation: 0,
        minimumSize: Size(
          maxWide ? double.maxFinite : width ?? Assets.dimens.minButtonWidth,
          height ?? Assets.dimens.buttonHeight,
        ),
      ),
    );
  }
}
