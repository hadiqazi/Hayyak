/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 17/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/model/core/value_added_service.dart';
import 'package:hayyak/model/dto/request/make_booking_request.dart';
import 'package:hayyak/view/utils/booking_utils.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/app_bar_action.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:syncfusion_flutter_core/theme.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

class ServiceDateSelectionScreen extends StatefulWidget {
  final ValueAddedService service;
  final MakeBookingRequest bookingRequest;

  const ServiceDateSelectionScreen({
    required this.service,
    required this.bookingRequest,
    Key? key,
  }) : super(key: key);

  @override
  _ServiceDateSelectionScreenState createState() => _ServiceDateSelectionScreenState();
}

class _ServiceDateSelectionScreenState extends State<ServiceDateSelectionScreen> {
  DateRangePickerController _datePickerController = DateRangePickerController();

  @override
  initState() {
    _datePickerController.selectedDates = widget.service.selectionDates;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = Theme.of(context).textTheme;
    final i18n = I18n.values(context)!;

    return Padding(
      padding: EdgeInsets.only(top: Assets.dimens.overlayTopMargin),
      child: Container(
        clipBehavior: Clip.hardEdge,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
          ),
        ),
        child: Scaffold(
          backgroundColor: Colors.black54,
          appBar: AppBar(
            leading: AppBarBackButton(),
            title: Text(i18n.service_dates_title),
            actions: [
              AppBarAction(
                text: i18n.txt_cancel,
                onPressed: () => BookingUtils.cancelBookingProcess(context, 3),
              ),
              SizedBox(width: Assets.dimens.appBarEndMargin),
            ],
          ),
          body: SafeArea(
            child: Container(
              color: theme.colorScheme.surface,
              padding: Assets.dimens.screenPadding,
              child: Column(
                children: [
                  Expanded(
                    child: SfDateRangePickerTheme(
                      data: SfDateRangePickerThemeData(
                        headerTextStyle: textTheme.headline6,
                        viewHeaderTextStyle: textTheme.button?.copyWith(color: Color(0x66212121)),
                        todayHighlightColor: Color(0x66212121),
                        activeDatesTextStyle: textTheme.bodyText2,
                        selectionTextStyle:
                            textTheme.bodyText2?.copyWith(color: theme.colorScheme.onPrimary),
                        disabledDatesTextStyle:
                            textTheme.bodyText2?.copyWith(color: Color(0x1A212121)),
                        leadingDatesTextStyle:
                            textTheme.bodyText2?.copyWith(color: Color(0x1A212121)),
                        selectionColor: theme.primaryColor,
                      ),
                      child: SfDateRangePicker(
                        controller: _datePickerController,
                        selectionMode: DateRangePickerSelectionMode.multiple,
                        minDate: widget.bookingRequest.checkInDate,
                        maxDate: widget.bookingRequest.checkOutDate,
                        showNavigationArrow: true,
                        enablePastDates: false,
                        toggleDaySelection: false,
                        headerHeight: 80,
                      ),
                    ),
                  ),
                  SizedBox(height: 64),
                  PrimaryButton(
                    child: Text(i18n.service_dates_action),
                    maxWide: true,
                    onPressed: () {
                      UiUtils.navigateBack(context, _datePickerController.selectedDates);
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
