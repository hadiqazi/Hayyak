/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 08/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';

class DropDownField<T> extends StatelessWidget {
  final String label;
  final Widget? hint;
  final List<DropdownMenuItem<T>>? items;
  final T? initialValue;
  final ValueChanged<T?>? onChanged;

  const DropDownField({
    required this.label,
    required this.items,
    this.hint,
    this.initialValue,
    this.onChanged,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Text(label,
            style: Theme.of(context).textTheme.caption?.copyWith(color: LightTheme.textPrimary)),
        Padding(
          padding: EdgeInsets.only(top: 8),
          child: DropdownButtonFormField<T>(
            hint: hint,
            items: items,
            value: initialValue,
            onChanged: onChanged,
            icon: Padding(
              padding: EdgeInsetsDirectional.only(end: 16),
              child: Icon(HayyakIcons.dropdown),
            ),
            iconSize: 8,
          ),
        ),
      ],
    );
  }
}
