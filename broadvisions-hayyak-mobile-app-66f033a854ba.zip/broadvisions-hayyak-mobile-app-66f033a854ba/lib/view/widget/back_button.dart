/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 06/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';

class CustomBackButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final double iconSize;
  final double padding;
  final Color color;

  const CustomBackButton({
    this.onPressed,
    this.padding = 8,
    this.iconSize = 20,
    this.color = Colors.black,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: I18n.values(context)!.txt_back,
      child: Padding(
        padding: EdgeInsetsDirectional.only(start: padding, top: padding),
        child: IconButton(
          icon: Icon(
            Utils.isRtlMode(context)
                ? HayyakIcons.navigate_back_rtl
                : HayyakIcons.navigate_back_ltr,
            size: iconSize,
            color: color,
          ),
          onPressed: onPressed != null
              ? onPressed
              : () {
                  UiUtils.navigateBack(context);
                },
        ),
      ),
    );
  }
}
