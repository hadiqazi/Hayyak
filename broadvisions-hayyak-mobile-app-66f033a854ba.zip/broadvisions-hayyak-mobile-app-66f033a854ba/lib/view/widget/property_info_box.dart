/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';

class PropertyInfoBox extends StatelessWidget {
  final Property property;

  const PropertyInfoBox(this.property, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    return // Property info box
        Container(
      decoration: BoxDecoration(
        border: Border.all(color: LightTheme.borderColor),
        borderRadius: BorderRadius.all(Radius.circular(24)),
      ),
      padding: EdgeInsets.all(8),
      child: Row(
        children: [
          // Image
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: UiUtils.getNetworkImage(
              imageUrl: property.coverImage.url,
              fit: BoxFit.cover,
              width: 84,
              height: 84,
            ),
          ),
          // Space
          SizedBox(width: 16),
          // Property info
          Flexible(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Rating
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Icon(HayyakIcons.rating, color: LightTheme.ratingColor, size: 13),
                    SizedBox(width: 4),
                    Text(
                      UiUtils.formatRating(property.rating),
                      style: textTheme.caption?.copyWith(color: Color(0xFF6C6C6C)),
                    ),
                  ],
                ),
                SizedBox(height: 4),
                // Property name
                Text(
                  property.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: textTheme.bodyText2?.copyWith(color: LightTheme.textSecondary),
                ),
                SizedBox(height: 8),
                // Price
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      UiUtils.formatPrice(context, property.pricePerNight),
                      style: textTheme.bodyText2?.copyWith(color: Theme.of(context).primaryColor),
                    ),
                    SizedBox(width: 2),
                    Text(i18n.per_night, style: textTheme.caption),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
