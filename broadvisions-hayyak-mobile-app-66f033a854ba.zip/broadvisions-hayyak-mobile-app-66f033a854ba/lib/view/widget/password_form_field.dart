/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 02/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';

class PasswordFormField extends StatefulWidget {
  final InputDecoration? decoration;
  final TextEditingController? controller;
  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;
  final FormFieldValidator<String>? validator;
  final bool? showStrength;
  final ValueChanged<int>? onStrengthChanged;

  const PasswordFormField({
    this.decoration,
    this.keyboardType,
    this.textInputAction,
    this.controller,
    this.validator,
    this.showStrength,
    this.onStrengthChanged,
    Key? key,
  }) : super(key: key);

  @override
  _PasswordFormFieldState createState() => _PasswordFormFieldState();
}

class _PasswordFormFieldState extends State<PasswordFormField> {
  bool obscureText = true;
  int strength = 0;

  // All below fields are for strength
  final unfilledColor = Color(0xFFC4C4C4);
  late final List<Color> strengthColors;
  List<String>? strengthNames;
  late List<Color> colors;
  String name = '';

  @override
  void initState() {
    strengthColors = [
      Colors.red,
      Colors.orange,
      Colors.amber,
      Colors.lightGreen,
      Colors.green,
    ];
    colors = List.filled(5, unfilledColor, growable: false);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (true == widget.showStrength) {
      return _buildStrengthField();
    } else {
      return _buildSimple();
    }
  }

  Widget _buildSimple() {
    final passwordDecoration = _getDecoration();

    return TextFormField(
      decoration: passwordDecoration,
      keyboardType: widget.keyboardType,
      textInputAction: widget.textInputAction,
      controller: widget.controller,
      validator: widget.validator,
      obscureText: obscureText,
    );
  }

  InputDecoration _getDecoration() {
    InputDecoration decoration = widget.decoration ?? InputDecoration();

    return decoration.copyWith(
      suffixIcon: IconButton(
        splashRadius: 24,
        icon: Icon(obscureText ? Icons.visibility_off : Icons.visibility),
        onPressed: () {
          setState(() {
            obscureText = !obscureText;
          });
        },
      ),
    );
  }

  Widget _buildStrengthField() {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;
    final passwordDecoration = _getDecoration();

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Password field
        TextFormField(
          decoration: passwordDecoration,
          keyboardType: widget.keyboardType,
          textInputAction: widget.textInputAction,
          controller: widget.controller,
          validator: widget.validator,
          obscureText: obscureText,
          onChanged: (value) => _checkPassword(value),
        ),
        SizedBox(height: 20),

        // Strength heading and name
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              i18n.password_strength,
              style: textTheme.caption?.copyWith(color: LightTheme.textPrimary),
            ),
            if (strength > 0)
              Text(
                name,
                style: textTheme.caption?.copyWith(color: strengthColors[strength - 1]),
              ),
          ],
        ),
        SizedBox(height: 12),

        // Strength meter
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _getProgressSlice(colors[0]),
            _getSpacer(),
            _getProgressSlice(colors[1]),
            _getSpacer(),
            _getProgressSlice(colors[2]),
            _getSpacer(),
            _getProgressSlice(colors[3]),
            _getSpacer(),
            _getProgressSlice(colors[4]),
          ],
        ),
        SizedBox(height: 16),

        // Good-password info
        Text(i18n.good_password_info, style: textTheme.caption),
      ],
    );
  }

  void _checkPassword(String value) {
    // Initialize array of strength names
    final i18n = I18n.values(context)!;
    if (strengthNames == null) {
      strengthNames = [
        i18n.strength_1,
        i18n.strength_2,
        i18n.strength_3,
        i18n.strength_4,
        i18n.strength_5,
      ];
    }

    // Calculate strength of password
    strength = _measureStrength(value);

    // Set all colors based on calculated strength
    colors = List.filled(5, unfilledColor, growable: false);
    for (int i = 0; i < strength; i++) {
      colors[i] = strengthColors[strength - 1];
    }

    // Set strength name
    final strengthIndex = strength > 1 ? strength - 1 : 0;
    name = strengthNames![strengthIndex];

    setState(() {});

    // Trigger callback
    if (widget.onStrengthChanged != null) {
      widget.onStrengthChanged!(strength);
    }
  }

  int _measureStrength(String input) {
    // Strength is checked on 5 parameters:
    //    1- Password length
    //    2- Contains a small letter
    //    3- Contains a capital letter
    //    4- Contains a number
    //    5- Contains a special character

    int strength = 0;

    if (input.isEmpty) {
      return strength;
    }

    if (input.length >= 6) strength++;
    if (RegExp(r".*[a-z].*").hasMatch(input)) strength++;
    if (RegExp(r".*[A-Z].*").hasMatch(input)) strength++;
    if (RegExp(r".*\d.*").hasMatch(input)) strength++;
    if (RegExp(r".*?[!@#$%&*~].*").hasMatch(input)) strength++;

    return strength;
  }

  Widget _getProgressSlice(Color color) {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          color: color,
        ),
        height: 6,
      ),
    );
  }

  Widget _getSpacer() {
    return SizedBox(width: 8);
  }
}
