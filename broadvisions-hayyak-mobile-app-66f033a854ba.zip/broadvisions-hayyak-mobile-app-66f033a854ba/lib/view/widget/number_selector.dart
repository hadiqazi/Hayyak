/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 16/11/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';

class NumberSelector extends StatefulWidget {
  final int initialValue;
  final int minValue;
  final int? maxValue;
  final TextEditingController? controller;
  final ValueChanged<int>? onChanged;

  NumberSelector({
    this.initialValue = 1,
    this.minValue = 1,
    this.maxValue,
    this.controller,
    this.onChanged,
    Key? key,
  }) : super(key: key) {
    if (controller != null) controller?.text = initialValue.toString();
  }

  @override
  _NumberSelectorState createState() => _NumberSelectorState();
}

class _NumberSelectorState extends State<NumberSelector> {
  late int value;

  @override
  void initState() {
    if (widget.initialValue < widget.minValue)
      value = widget.minValue;
    else
      value = widget.initialValue;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Color(0xFFF4F4F4),
        borderRadius: BorderRadius.circular(Assets.dimens.roundedCornerSize),
      ),
      child: Row(
        children: [
          _getButton('‒', true),
          SizedBox(
            width: 40,
            child: Align(
              alignment: Alignment.center,
              child: Text('$value'),
            ),
          ),
          _getButton('+', false),
        ],
      ),
    );
  }

  void _updateValue(bool negative) {
    setState(() {
      if (negative) {
        if (value > widget.minValue) value--;
      } else {
        if (widget.maxValue == null || value < widget.maxValue!) value++;
      }
      if (widget.controller != null) {
        widget.controller?.text = value.toString();
      }
      if (widget.onChanged != null) {
        widget.onChanged!(value);
      }
    });
  }

  Widget _getButton(String text, bool negative) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        primary: Colors.white,
        onPrimary: Colors.black,
        padding: EdgeInsets.all(8),
        minimumSize: Size(40, 40),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(Assets.dimens.roundedCornerSize),
        ),
      ),
      child: Text(text),
      onPressed: () {
        _updateValue(negative);
      },
    );
  }
}
