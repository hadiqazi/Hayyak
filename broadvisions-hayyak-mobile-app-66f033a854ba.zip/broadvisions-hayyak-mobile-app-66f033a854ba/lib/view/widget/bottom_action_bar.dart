/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 14/12/2021
            Project: hayyak-mobile-app
 */

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class BottomActionBar extends StatelessWidget {
  final Widget? info;
  final String? action;
  final VoidCallback? onPressed;

  const BottomActionBar({
    this.info,
    this.action,
    this.onPressed,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final padding = EdgeInsets.only(left: 20, right: 20, top: 16, bottom: Platform.isIOS ? 0 : 16);

    return Align(
      alignment: AlignmentDirectional.bottomCenter,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
          color: Colors.white,
          boxShadow: [BoxShadow(offset: Offset(0, -6), blurRadius: 34, color: Color(0x14000000))],
        ),
        padding: padding,
        child: SafeArea(
          top: false,
          left: false,
          right: false,
          bottom: Platform.isIOS,
          child: Row(
            children: [
              if (info != null) info!,
              Spacer(),
              if (action != null)
                PrimaryButton(
                  child: Text('  $action  '),
                  onPressed: onPressed,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
