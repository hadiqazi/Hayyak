/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/02/2022
            Project: hayyak-mobile-app
 */

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/view/utils/ui_utils.dart';

class Avatar extends StatelessWidget {
  final String? url;
  final File? image;
  final double size;

  Avatar({this.url, this.image, this.size = 24, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipOval(
      child: image != null
          ? Image.file(
              image!,
              width: size,
              height: size,
              fit: BoxFit.cover,
            )
          : url != null && url!.isNotEmpty
              ? UiUtils.getNetworkImage(
                  imageUrl: url!,
                  fit: BoxFit.cover,
                  width: size,
                  height: size,
                )
              : Image.asset(
                  Assets.image.profilePic,
                  width: size,
                  height: size,
                ),
    );
  }
}
