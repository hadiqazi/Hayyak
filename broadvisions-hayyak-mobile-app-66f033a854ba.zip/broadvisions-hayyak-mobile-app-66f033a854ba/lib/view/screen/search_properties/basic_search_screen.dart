/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/11/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_place/google_place.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/model/core/type.dart';
import 'package:hayyak/model/dto/request/search_properties_request.dart';
import 'package:hayyak/model/dto/response/lookup_response.dart';
import 'package:hayyak/view/screen/common/location_selection_screen.dart';
import 'package:hayyak/view/screen/property_list/property_listing_screen.dart';
import 'package:hayyak/view/utils/booking_utils.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/date_selection_view.dart';
import 'package:hayyak/view/widget/dropdown_field.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/number_selector.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:hayyak/view/widget/secondary_button.dart';

class BasicSearchScreen extends StatelessWidget {
  const BasicSearchScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(I18n.values(context)!.search_title),
      ),
      body: SafeArea(
        child: FormContainer(
          handleFullPageScroll: true,
          child: FutureBuilder(
            future: Cache.get(Constants.lookupData),
            builder: (_, snapshot) {
              if (snapshot.connectionState == ConnectionState.done && snapshot.data != null)
                return _BasicSearchForm(snapshot.data as LookupResponse);
              else
                return Center(child: HayyakProgressIndicator());
            },
          ),
        ),
      ),
    );
  }
}

class _BasicSearchForm extends StatefulWidget {
  final LookupResponse lookupData;

  const _BasicSearchForm(this.lookupData, {Key? key}) : super(key: key);

  @override
  _BasicSearchFormState createState() => _BasicSearchFormState();
}

class _BasicSearchFormState extends State<_BasicSearchForm> {
  final _formKey = GlobalKey<FormState>();
  final _addressController = TextEditingController();
  final _roomCountController = TextEditingController();

  late List<Type> bedTypes;
  late List<Type> roomTypes;
  late GooglePlace googlePlace;

  LatLng? selectedLocation;
  DateTimeRange? selectedDates;
  Type? selectedBedType;
  Type? selectedRoomType;
  int roomCount = 1;
  bool showLocationError = false;
  bool showDateError = false;

  @override
  void initState() {
    bedTypes = widget.lookupData.bedTypes;
    roomTypes = widget.lookupData.roomTypes;
    googlePlace = GooglePlace(ApiKeys.googlePlaces);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final errorStyle =
        Theme.of(context).textTheme.caption?.copyWith(color: Theme.of(context).errorColor);

    return Form(
      key: _formKey,
      child: Container(
        padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Location selection
            Row(
              children: [
                Expanded(
                  child: TypeAheadField(
                    keepSuggestionsOnLoading: false,
                    hideOnEmpty: true,
                    textFieldConfiguration: TextFieldConfiguration(
                      decoration: InputDecoration(labelText: i18n.search_location_hint),
                      autofocus: false,
                      controller: _addressController,
                    ),
                    suggestionsCallback: (pattern) async {
                      if (pattern.isEmpty) {
                        return <AutocompletePrediction>[];
                      } else {
                        await Future.delayed(Duration(milliseconds: 500));
                        debugPrint('Google Places - Searching for pattern: $pattern');

                        final result = await _autoCompleteSearch(pattern);
                        return result ?? <AutocompletePrediction>[];
                      }
                    },
                    itemBuilder: (context, AutocompletePrediction suggestion) {
                      return ListTile(
                        leading: Icon(Icons.location_on),
                        title: Text(suggestion.description ?? ''),
                        // subtitle: Text(suggestion.structuredFormatting?.mainText ?? ''),
                      );
                    },
                    onSuggestionSelected: (AutocompletePrediction suggestion) =>
                        _onLocationSelected(suggestion),
                  ),
                ),
                SizedBox(width: 16),
                SecondaryButton(
                    child: Icon(HayyakIcons.map),
                    width: Assets.dimens.smallButtonWidth,
                    onPressed: () async {
                      // Navigate user
                      final location = await UiUtils.navigateTo<LatLng>(
                          context: context,
                          child: LocationSelectionScreen(initialSelection: selectedLocation));

                      // Process result
                      if (location != null) {
                        selectedLocation = location;
                        _addressController.text = location.toString();

                        setState(() {
                          showLocationError = false;
                        });
                      }
                    }),
              ],
            ),
            if (showLocationError) SizedBox(height: 8),
            if (showLocationError) Text(i18n.error_empty_location, style: errorStyle),

            // Check-in check-out dates
            SizedBox(height: Assets.dimens.formFieldsMargin * 2.5),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                DateSelectionCard(
                  label: i18n.check_in,
                  text: DateSelectionCard.formatDate(selectedDates?.start),
                  onPressed: () {
                    _openDateRangePicker();
                  },
                ),
                SizedBox(width: 8),
                DateSelectionCard(
                  label: i18n.check_out,
                  text: DateSelectionCard.formatDate(selectedDates?.end),
                  onPressed: () {
                    _openDateRangePicker();
                  },
                ),
              ],
            ),
            if (showDateError) SizedBox(height: 8),
            if (showDateError) Text(i18n.error_empty_dates, style: errorStyle),

            // Rooms
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(i18n.search_num_of_rooms),
                NumberSelector(
                  initialValue: roomCount,
                  maxValue: Constants.roomSelectorThreshold,
                  controller: _roomCountController,
                  onChanged: (value) {
                    roomCount = value;
                  },
                ),
              ],
            ),

            // Bed type
            SizedBox(height: Assets.dimens.formFieldsMargin * 4),
            DropDownField(
              label: i18n.label_bed_type,
              hint: Text(i18n.hint_bed_type),
              items: bedTypes.map((Type bedType) {
                return DropdownMenuItem<Type>(value: bedType, child: Text(bedType.name));
              }).toList(),
              onChanged: (Type? bedType) {
                selectedBedType = bedType;
              },
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),

            // Room type
            DropDownField(
              label: i18n.label_room_type,
              hint: Text(i18n.hint_room_type),
              items: roomTypes.map((Type propertyType) {
                return DropdownMenuItem<Type>(value: propertyType, child: Text(propertyType.name));
              }).toList(),
              onChanged: (Type? propertyType) {
                selectedRoomType = propertyType;
              },
            ),
            //
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),
            Spacer(),
            //
            PrimaryButton(
              child: Text(i18n.search_submit),
              maxWide: true,
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  FocusScope.of(context).unfocus();
                  // Perform search
                  _validateForm();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  void _validateForm() {
    showLocationError = selectedLocation == null;
    showDateError = selectedDates == null;

    if (showLocationError || showDateError)
      setState(() {});
    else
      _performSearch();
  }

  void _performSearch() {
    final latLng = selectedLocation == null ? LatLng(0, 0) : selectedLocation!;
    final request = SearchPropertiesRequest(
      latitude: latLng.latitude,
      longitude: latLng.longitude,
      checkInDate: selectedDates!.start,
      checkOutDate: selectedDates!.end,
      roomCount: roomCount,
      bedTypeId: selectedBedType?.id,
      roomTypeId: selectedRoomType?.id,
    );

    UiUtils.navigateTo(context: context, child: PropertyListingScreen(request), endCurrent: true);
  }

  Future<List<AutocompletePrediction>?> _autoCompleteSearch(String value) async {
    try {
      AutocompleteResponse? result = await googlePlace.autocomplete.get(value);

      debugPrint('=== RESULT ===');
      debugPrint(result?.status);

      if (result != null && result.predictions != null && mounted) {
        debugPrint('${result.predictions?.length} places found.');
        return result.predictions;
      }
    } catch (e) {
      debugPrint(e.toString());
    }
    return null;
  }

  void _onLocationSelected(AutocompletePrediction selection) async {
    // Set the text in text field
    _addressController.text = selection.description ?? '';
    debugPrint('selection.placeId = ${selection.placeId}');

    // Get coordinates of selected location
    if (selection.placeId == null) {
      selectedLocation = null;
      return;
    }
    DetailsResponse? details = await googlePlace.details.get(selection.placeId!);
    debugPrint('Place details object? returned.');

    if (details != null && details.result != null) {
      final location = details.result?.geometry?.location;
      if (location != null) {
        selectedLocation = LatLng(location.lat ?? 0, location.lng ?? 0);
        setState(() {
          showLocationError = false;
        });

        debugPrint(
            'selection.placeId = ${selectedLocation?.latitude}, ${selectedLocation?.longitude}');
        return;
      }
    }
    selectedLocation = null;
  }

  void _openDateRangePicker() async {
    BookingUtils.chooseDateRange(
      context: context,
      initialDateRange: selectedDates,
      onRangeSelected: (range) {
        setState(() {
          selectedDates = range;
          showDateError = false;
        });
      },
    );
  }

  @override
  void dispose() {
    _addressController.dispose();
    _roomCountController.dispose();
    super.dispose();
  }
}
