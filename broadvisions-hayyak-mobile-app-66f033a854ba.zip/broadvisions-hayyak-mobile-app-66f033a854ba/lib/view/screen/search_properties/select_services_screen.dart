/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 10/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/property_service.dart';
import 'package:hayyak/model/core/value_added_service.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class SelectServicesScreen extends StatelessWidget {
  final List<String> selectedServices;

  const SelectServicesScreen(this.selectedServices, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(I18n.values(context)!.title_services),
      ),
      body: SafeArea(
        child: Padding(
          padding: Assets.dimens.screenPadding,
          child: FutureBuilder(
            future: _loadData(context),
            builder: (_, snapshot) {
              if (snapshot.connectionState == ConnectionState.done && snapshot.data != null)
                return _ServicesList(
                  services: snapshot.data as List<ValueAddedService>,
                  initialSelection: selectedServices,
                );
              else
                return Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      HayyakProgressIndicator(),
                      SizedBox(height: 16),
                      Text(I18n.values(context)!.loader_services),
                    ],
                  ),
                );
            },
          ),
        ),
      ),
    );
  }

  Future<List<ValueAddedService>> _loadData(BuildContext context) async {
    // Get services data
    try {
      final response = await PropertyService(context).getValueAddedServices();
      return response.valueAddedServices;
    } on AppException catch (e) {
      // Display error
      UiUtils.displayException(context, e);
      throw e;
    }
  }
}

class _ServicesList extends StatefulWidget {
  final List<ValueAddedService> services;
  final List<String> initialSelection;

  const _ServicesList({required this.services, required this.initialSelection, Key? key})
      : super(key: key);

  @override
  _ServicesListState createState() => _ServicesListState();
}

class _ServicesListState extends State<_ServicesList> {
  late List<String> selectedServices;

  @override
  void initState() {
    selectedServices = widget.initialSelection;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = Theme.of(context).textTheme;
    final thumbnailSize = 56.0;

    return Column(
      children: [
        // Amenities
        Expanded(
          child: ListView.separated(
            itemCount: widget.services.length,
            itemBuilder: (_, index) {
              final service = widget.services[index];
              final isSelected = selectedServices.contains(service.id);

              return InkWell(
                child: Row(
                  children: [
                    // Checkbox
                    Checkbox(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      activeColor: theme.primaryColor,
                      value: isSelected,
                      onChanged: (value) {
                        setState(() {
                          _handleChecked(service, value ?? false);
                        });
                      },
                    ),
                    SizedBox(width: 8),

                    // Thumbnail
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: service.image != null
                          ? UiUtils.getNetworkImage(
                              imageUrl: service.image!.url,
                              fit: BoxFit.cover,
                              width: thumbnailSize,
                              height: thumbnailSize,
                            )
                          : Container(width: thumbnailSize, height: thumbnailSize),
                    ),
                    SizedBox(width: 16),

                    // Info
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(service.name, style: textTheme.subtitle2),
                          if (service.description != null) SizedBox(height: 8),
                          if (service.description != null)
                            Text(
                              service.name,
                              style: textTheme.caption?.copyWith(color: LightTheme.textTertiary),
                            ),
                        ],
                      ),
                    ),
                    SizedBox(width: 8),

                    // Price
                    Text(UiUtils.formatPrice(context, service.price)),
                  ],
                ),
                onTap: () {
                  setState(() {
                    _handleChecked(service, !isSelected);
                  });
                },
              );
            },
            separatorBuilder: (_, index) {
              return Divider();
            },
          ),
        ),

        // Margin
        SizedBox(height: Assets.dimens.formFieldsMargin * 3),

        // Submit button
        PrimaryButton(
          child: Text(I18n.values(context)!.action_select),
          maxWide: true,
          onPressed: () {
            UiUtils.navigateBack(context, selectedServices);
          },
        ),
      ],
    );
  }

  void _handleChecked(ValueAddedService service, bool value) {
    setState(() {
      if (value) {
        selectedServices.add(service.id);
      } else {
        selectedServices.removeWhere((String id) {
          return id == service.id;
        });
      }
    });
  }
}
