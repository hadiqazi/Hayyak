/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 09/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_place/google_place.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/model/core/type.dart';
import 'package:hayyak/model/dto/request/search_properties_request.dart';
import 'package:hayyak/model/dto/response/lookup_response.dart';
import 'package:hayyak/view/screen/common/location_selection_screen.dart';
import 'package:hayyak/view/screen/search_properties/select_amenities_screen.dart';
import 'package:hayyak/view/screen/search_properties/select_services_screen.dart';
import 'package:hayyak/view/utils/booking_utils.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/date_selection_view.dart';
import 'package:hayyak/view/widget/dropdown_field.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/number_selector.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:hayyak/view/widget/rating_view.dart';
import 'package:hayyak/view/widget/secondary_button.dart';

class AdvancedSearchScreen extends StatelessWidget {
  final SearchPropertiesRequest request;

  const AdvancedSearchScreen(this.request, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(I18n.values(context)!.adv_search_title),
      ),
      body: SafeArea(
        child: FormContainer(
          handleFullPageScroll: true,
          child: FutureBuilder(
            future: Cache.get(Constants.lookupData),
            builder: (_, snapshot) {
              if (snapshot.connectionState == ConnectionState.done && snapshot.data != null)
                return _AdvancedSearchForm(
                  lookupData: snapshot.data as LookupResponse,
                  currentFilter: request,
                );
              else
                return Center(child: HayyakProgressIndicator());
            },
          ),
        ),
      ),
    );
  }
}

class _AdvancedSearchForm extends StatefulWidget {
  final LookupResponse lookupData;
  final SearchPropertiesRequest currentFilter;

  const _AdvancedSearchForm({required this.lookupData, required this.currentFilter, Key? key})
      : super(key: key);

  @override
  _AdvancedSearchFormState createState() => _AdvancedSearchFormState();
}

class _AdvancedSearchFormState extends State<_AdvancedSearchForm> {
  final _formKey = GlobalKey<FormState>();
  final _addressController = TextEditingController();
  final _roomCountController = TextEditingController();
  final _guestCountController = TextEditingController();

  late List<Type> bedTypes = widget.lookupData.bedTypes;
  late List<Type> roomTypes = widget.lookupData.roomTypes;
  late GooglePlace googlePlace = GooglePlace(ApiKeys.googlePlaces);

  LatLng? selectedLocation;
  DateTimeRange? selectedDates;
  Type? selectedBedType;
  Type? selectedRoomType;
  late int roomCount;
  late int guestCount;
  bool showLocationError = false;
  bool showDateError = false;
  late RangeValues priceRange;
  late double rating;
  late List<String> selectedAmenities;
  late List<String> selectedServices;

  @override
  void initState() {
    // Populate fields from current filter
    selectedLocation = LatLng(widget.currentFilter.latitude, widget.currentFilter.longitude);
    _addressController.text = selectedLocation.toString();
    selectedDates = DateTimeRange(
        start: widget.currentFilter.checkInDate, end: widget.currentFilter.checkOutDate);
    try {
      selectedBedType =
          bedTypes.firstWhere((element) => element.id == widget.currentFilter.bedTypeId);
    } catch (e) {}
    try {
      selectedRoomType =
          roomTypes.firstWhere((element) => element.id == widget.currentFilter.roomTypeId);
    } catch (e) {}
    roomCount = widget.currentFilter.roomCount;
    guestCount = widget.currentFilter.guestCount ?? 1;
    if (widget.currentFilter.minPrice != null && widget.currentFilter.maxPrice != null) {
      priceRange = RangeValues(
          widget.currentFilter.minPrice!.toDouble(), widget.currentFilter.maxPrice!.toDouble());
    } else {
      priceRange = RangeValues(0, Constants.maxPriceRangeInFilter);
    }
    rating = (widget.currentFilter.rating ?? 0).toDouble();
    selectedAmenities = widget.currentFilter.amenities ?? [];
    selectedServices = widget.currentFilter.services ?? [];

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final errorStyle =
        Theme.of(context).textTheme.caption?.copyWith(color: Theme.of(context).errorColor);

    return Form(
      key: _formKey,
      child: Container(
        padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Location selection
            Row(
              children: [
                Expanded(
                  child: TypeAheadField(
                    keepSuggestionsOnLoading: false,
                    hideOnEmpty: true,
                    textFieldConfiguration: TextFieldConfiguration(
                      decoration: InputDecoration(labelText: i18n.search_location_hint),
                      autofocus: false,
                      controller: _addressController,
                    ),
                    suggestionsCallback: (pattern) async {
                      if (pattern.isEmpty) {
                        return <AutocompletePrediction>[];
                      } else {
                        await Future.delayed(Duration(milliseconds: 500));
                        debugPrint('Google Places - Searching for pattern: $pattern');

                        final result = await _autoCompleteSearch(pattern);
                        return result ?? <AutocompletePrediction>[];
                      }
                    },
                    itemBuilder: (context, AutocompletePrediction suggestion) {
                      return ListTile(
                        leading: Icon(Icons.location_on),
                        title: Text(suggestion.description ?? ''),
                      );
                    },
                    onSuggestionSelected: (AutocompletePrediction suggestion) =>
                        _onLocationSelected(suggestion),
                  ),
                ),
                SizedBox(width: 16),
                SecondaryButton(
                    child: Icon(HayyakIcons.map),
                    width: Assets.dimens.smallButtonWidth,
                    onPressed: () async {
                      // Navigate user
                      final location = await UiUtils.navigateTo<LatLng>(
                          context: context,
                          child: LocationSelectionScreen(initialSelection: selectedLocation));

                      // Process result
                      if (location != null) {
                        selectedLocation = location;
                        _addressController.text = location.toString();

                        setState(() {
                          showLocationError = false;
                        });
                      }
                    }),
              ],
            ),
            if (showLocationError) SizedBox(height: 8),
            if (showLocationError) Text(i18n.error_empty_location, style: errorStyle),

            // Check-in check-out dates
            SizedBox(height: Assets.dimens.formFieldsMargin * 2.5),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                DateSelectionCard(
                  label: i18n.check_in,
                  text: DateSelectionCard.formatDate(selectedDates?.start),
                  onPressed: () {
                    _openDateRangePicker();
                  },
                ),
                SizedBox(width: 8),
                DateSelectionCard(
                  label: i18n.check_out,
                  text: DateSelectionCard.formatDate(selectedDates?.end),
                  onPressed: () {
                    _openDateRangePicker();
                  },
                ),
              ],
            ),
            if (showDateError) SizedBox(height: 8),
            if (showDateError) Text(i18n.error_empty_dates, style: errorStyle),

            // Rooms
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(i18n.search_num_of_rooms),
                NumberSelector(
                  initialValue: roomCount,
                  maxValue: Constants.roomSelectorThreshold,
                  controller: _roomCountController,
                  onChanged: (value) {
                    roomCount = value;
                  },
                ),
              ],
            ),

            // Guests
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(i18n.label_num_of_guests),
                NumberSelector(
                  initialValue: guestCount,
                  maxValue: Constants.guestSelectorThreshold,
                  controller: _guestCountController,
                  onChanged: (value) {
                    guestCount = value;
                  },
                ),
              ],
            ),

            // Bed type
            SizedBox(height: Assets.dimens.formFieldsMargin * 4),
            DropDownField(
              initialValue: selectedBedType,
              label: i18n.label_bed_type,
              hint: Text(i18n.hint_bed_type),
              items: bedTypes.map((Type bedType) {
                return DropdownMenuItem<Type>(value: bedType, child: Text(bedType.name));
              }).toList(),
              onChanged: (Type? bedType) {
                selectedBedType = bedType;
              },
            ),

            // Room type
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),
            DropDownField(
              initialValue: selectedRoomType,
              label: i18n.label_room_type,
              hint: Text(i18n.hint_room_type),
              items: roomTypes.map((Type propertyType) {
                return DropdownMenuItem<Type>(value: propertyType, child: Text(propertyType.name));
              }).toList(),
              onChanged: (Type? propertyType) {
                selectedRoomType = propertyType;
              },
            ),

            // Amenities
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),
            _createOptionRow(i18n.amenities, selectedAmenities.length, () async {
              // Navigate to amenities selection screen
              final amenities = await UiUtils.navigateTo(
                  context: context,
                  child: SelectAmenitiesScreen(selectedAmenities)) as List<String>;
              // Update amenities with selection
              setState(() {
                selectedAmenities = amenities;
              });
            }),

            // Services
            _createOptionRow(i18n.extra_services, selectedServices.length, () async {
              // Navigate to amenities selection screen
              final services = await UiUtils.navigateTo(
                  context: context, child: SelectServicesScreen(selectedServices)) as List<String>;
              // Update amenities with selection
              setState(() {
                selectedServices = services;
              });
            }),

            // Divider
            SizedBox(height: Assets.dimens.formFieldsMargin),
            Divider(),

            // Price Range
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),
            Row(
              children: [
                Text(i18n.label_price_range),
                Spacer(),
                Text(UiUtils.formatPrice(context, priceRange.start.roundToDouble(),
                        useShortFormat: true) +
                    ' - ' +
                    UiUtils.formatPrice(context, priceRange.end.roundToDouble(),
                        useShortFormat: true)),
              ],
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin / 2),
            RangeSlider(
              values: priceRange,
              max: Constants.maxPriceRangeInFilter,
              onChanged: (RangeValues values) {
                setState(() {
                  priceRange = values;
                });
              },
            ),

            // Divider
            SizedBox(height: Assets.dimens.formFieldsMargin),
            Divider(),

            // Rating
            SizedBox(height: Assets.dimens.formFieldsMargin),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(i18n.label_rating),
                RatingView(
                  initialRating: rating,
                  starSize: 26,
                  onRatingChanged: (double value) {
                    rating = value;
                  },
                ),
              ],
            ),

            // Submit button
            SizedBox(height: Assets.dimens.formFieldsMargin * 5),
            PrimaryButton(
              child: Text(i18n.adv_search_submit),
              maxWide: true,
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  FocusScope.of(context).unfocus();
                  // Perform search
                  _validateForm();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _createOptionRow(String title, int count, VoidCallback onTap) {
    final textTheme = Theme.of(context).textTheme;
    final color = Theme.of(context).primaryColor;

    return InkWell(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: Assets.dimens.formFieldsMargin * 2),
        child: Row(
          children: [
            Text(title, style: textTheme.bodyText1),
            Spacer(),
            //
            if (count > 0)
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Color(0xFFFCECEE),
                ),
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: Text(
                  I18n.values(context)!.label_selected_count(count),
                  style: textTheme.caption?.copyWith(color: color),
                ),
              ),
            if (count > 0) SizedBox(width: 8),
            //
            Icon(Icons.chevron_right),
          ],
        ),
      ),
      onTap: onTap,
    );
  }

  void _validateForm() {
    showLocationError = selectedLocation == null;
    showDateError = selectedDates == null;

    if (showLocationError || showDateError)
      setState(() {});
    else
      _prepareRequestAndReturn();
  }

  void _prepareRequestAndReturn() {
    final latLng = selectedLocation == null ? LatLng(0, 0) : selectedLocation!;
    final request = SearchPropertiesRequest(
      latitude: latLng.latitude,
      longitude: latLng.longitude,
      checkInDate: selectedDates!.start,
      checkOutDate: selectedDates!.end,
      roomCount: roomCount,
      guestCount: guestCount,
      bedTypeId: selectedBedType?.id,
      roomTypeId: selectedRoomType?.id,
      minPrice: priceRange.start.round(),
      maxPrice: priceRange.end.round(),
      rating: rating.toInt(),
      amenities: selectedAmenities.length == 0 ? null : selectedAmenities,
      services: selectedServices.length == 0 ? null : selectedServices,
    );

    UiUtils.navigateBack(context, request);
  }

  Future<List<AutocompletePrediction>?> _autoCompleteSearch(String value) async {
    try {
      AutocompleteResponse? result = await googlePlace.autocomplete.get(value);

      debugPrint('=== RESULT ===');
      debugPrint(result?.status);

      if (result != null && result.predictions != null && mounted) {
        debugPrint('${result.predictions?.length} places found.');
        return result.predictions;
      }
    } catch (e) {
      debugPrint(e.toString());
    }
    return null;
  }

  void _onLocationSelected(AutocompletePrediction selection) async {
    // Set the text in text field
    _addressController.text = selection.description ?? '';
    debugPrint('selection.placeId = ${selection.placeId}');

    // Get coordinates of selected location
    if (selection.placeId == null) {
      selectedLocation = null;
      return;
    }
    DetailsResponse? details = await googlePlace.details.get(selection.placeId!);
    debugPrint('Place details object? returned.');

    if (details != null && details.result != null) {
      final location = details.result?.geometry?.location;
      if (location != null) {
        selectedLocation = LatLng(location.lat ?? 0, location.lng ?? 0);
        setState(() {
          showLocationError = false;
        });

        debugPrint(
            'selection.placeId = ${selectedLocation?.latitude}, ${selectedLocation?.longitude}');
        return;
      }
    }
    selectedLocation = null;
  }

  void _openDateRangePicker() async {
    BookingUtils.chooseDateRange(
      context: context,
      initialDateRange: selectedDates,
      onRangeSelected: (range) {
        setState(() {
          selectedDates = range;
          showDateError = false;
        });
      },
    );
  }

  @override
  void dispose() {
    _addressController.dispose();
    _roomCountController.dispose();
    _guestCountController.dispose();
    super.dispose();
  }
}
