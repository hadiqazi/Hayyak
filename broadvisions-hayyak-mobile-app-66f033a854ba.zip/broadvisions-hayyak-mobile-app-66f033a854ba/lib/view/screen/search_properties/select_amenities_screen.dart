/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 09/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/property_service.dart';
import 'package:hayyak/model/core/amenity.dart';
import 'package:hayyak/model/core/type.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class SelectAmenitiesScreen extends StatelessWidget {
  final List<String> selectedAmenities;

  const SelectAmenitiesScreen(this.selectedAmenities, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(I18n.values(context)!.title_amenities),
      ),
      body: SafeArea(
        child: Padding(
          padding: Assets.dimens.screenPadding,
          child: FutureBuilder(
            future: _loadData(context),
            builder: (_, snapshot) {
              if (snapshot.connectionState == ConnectionState.done && snapshot.data != null)
                return _AmenitiesList(
                  amenitiesMap: snapshot.data as Map<Type, List<Amenity>>,
                  initialSelection: selectedAmenities,
                );
              else
                return Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      HayyakProgressIndicator(),
                      SizedBox(height: 16),
                      Text(I18n.values(context)!.loader_amenities),
                    ],
                  ),
                );
            },
          ),
        ),
      ),
    );
  }

  Future<Map<Type, List<Amenity>>> _loadData(BuildContext context) async {
    // Get amenities data
    try {
      final response = await PropertyService(context).getAmenities();

      // Group amenities by amenity types
      final amenityMap = Map<Type, List<Amenity>>();
      response.amenities.forEach((amenity) {
        amenityMap.putIfAbsent(amenity.amenityType, () => []);

        final amenities = amenityMap[amenity.amenityType]!;
        amenities.add(amenity);
        amenityMap[amenity.amenityType] = amenities;
      });

      // Return response
      return amenityMap;
    } on AppException catch (e) {
      // Display error
      UiUtils.displayException(context, e);
      throw e;
    }
  }
}

class _AmenitiesList extends StatefulWidget {
  final Map<Type, List<Amenity>> amenitiesMap;
  final List<String> initialSelection;

  const _AmenitiesList({required this.amenitiesMap, required this.initialSelection, Key? key})
      : super(key: key);

  @override
  _AmenitiesListState createState() => _AmenitiesListState();
}

class _AmenitiesListState extends State<_AmenitiesList> {
  late List<String> selectedAmenities;

  @override
  void initState() {
    selectedAmenities = widget.initialSelection;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = Theme.of(context).textTheme;

    // Create widgets for amenity groups and amenities
    final List<Widget> amenityGroups = [];
    widget.amenitiesMap.forEach((type, value) {
      // Margin
      amenityGroups.add(
        SizedBox(height: amenityGroups.length == 0 ? 12 : 24),
      );

      // Type name
      amenityGroups.add(
        Text(type.name, style: textTheme.headline6),
      );

      // Margin
      amenityGroups.add(
        SizedBox(height: 16),
      );

      // Amenities
      final List<Widget> amenities = [];
      value.forEach((amenity) {
        final isSelected = selectedAmenities.contains(amenity.id);

        amenities.add(
          FilterChip(
            label: Text(amenity.name),
            selected: isSelected,
            shape: StadiumBorder(
                side: BorderSide(
              color: isSelected ? theme.primaryColor : LightTheme.borderColor,
            )),
            labelStyle: textTheme.caption?.copyWith(
                color: isSelected ? theme.colorScheme.onPrimary : LightTheme.textTertiary),
            onSelected: (bool value) {
              setState(() {
                if (value) {
                  selectedAmenities.add(amenity.id);
                } else {
                  selectedAmenities.removeWhere((String id) {
                    return id == amenity.id;
                  });
                }
              }); // setState
            },
          ),
        );
      });

      // Add amenities to wrap
      amenityGroups.add(
        Wrap(
          spacing: 8,
          children: amenities,
        ),
      );
    });

    return Column(
      children: [
        // Amenities
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: amenityGroups,
            ),
          ),
        ),

        // Margin
        SizedBox(height: Assets.dimens.formFieldsMargin * 3),

        // Submit button
        PrimaryButton(
          child: Text(I18n.values(context)!.action_select),
          maxWide: true,
          onPressed: () {
            UiUtils.navigateBack(context, selectedAmenities);
          },
        ),
      ],
    );
  }
}
