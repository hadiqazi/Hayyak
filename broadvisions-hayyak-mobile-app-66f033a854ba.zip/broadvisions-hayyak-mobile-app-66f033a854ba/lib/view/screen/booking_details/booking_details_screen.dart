/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 30/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/app_colors.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/booking_service.dart';
import 'package:hayyak/controller/service/property_service.dart';
import 'package:hayyak/model/core/booking.dart';
import 'package:hayyak/model/core/booking_status.dart';
import 'package:hayyak/model/core/booking_to_rate.dart';
import 'package:hayyak/model/core/rating.dart';
import 'package:hayyak/model/core/vas_booked.dart';
import 'package:hayyak/model/dto/request/get_booking_details_request.dart';
import 'package:hayyak/model/dto/request/get_ratings_request.dart';
import 'package:hayyak/model/dto/response/get_booking_details_response.dart';
import 'package:hayyak/view/screen/booking_cancel/cancel_booking_screen.dart';
import 'package:hayyak/view/screen/booking_details/booking_service_view.dart';
import 'package:hayyak/view/screen/rating/post_rating_screen.dart';
import 'package:hayyak/view/utils/booking_utils.dart';
import 'package:hayyak/view/utils/list_data_helper.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/app_bar_action.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/date_selection_view.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:hayyak/view/widget/property_info_box.dart';
import 'package:hayyak/view/widget/rating_view.dart';

class BookingDetails extends StatelessWidget {
  final Booking bookingBrief;
  final VoidCallback? onBookingCancelled;

  const BookingDetails(
    this.bookingBrief, {
    this.onBookingCancelled,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(i18n.booking_details_title),
        actions: [
          // Show cancel action only for active booking
          if (BookingUtils.canBookingBeCancelled(bookingBrief))
            AppBarAction(
              text: i18n.booking_action_cancel,
              onPressed: () {
                // Navigate to booking cancellation screen
                UiUtils.showOverlay(
                  context: context,
                  child: CancelBookingScreen(
                    bookingBrief,
                    onBookingCancelled: onBookingCancelled,
                    comingFromDetails: true,
                  ),
                );
              },
            ),
          SizedBox(width: Assets.dimens.appBarEndMargin),
        ],
      ),
      body: SafeArea(
        child: FutureBuilder(
          future: _getBookingDetails(context),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
              final data = snapshot.data as List<dynamic>;
              return ListDataHelper.prepareFutureBuilder(
                context: context,
                snapshot: snapshot,
                loadingText: I18n.values(context)!.booking_details_loader,
                success: snapshot.data == null
                    ? Container()
                    : _DetailsView(booking: data[0].booking, guestPhone: data[1]),
              );
            } else
              return Center(child: HayyakProgressIndicator());
          },
        ),
      ),
    );
  }

  Future<List<dynamic>> _getBookingDetails(BuildContext context) async {
    // Fetch booking details from server
    final GetBookingDetailsResponse response = await BookingService(context)
        .getBookingDetails(GetBookingDetailsRequest(bookingBrief.uuid));

    final String formattedPhone = await UiUtils.formatPhone(response.booking.guest.phone);

    return [response, formattedPhone];
  }
}

class _DetailsView extends StatefulWidget {
  final Booking booking;
  final String guestPhone;

  const _DetailsView({required this.booking, required this.guestPhone, Key? key}) : super(key: key);

  @override
  _DetailsViewState createState() => _DetailsViewState();
}

class _DetailsViewState extends State<_DetailsView> {
  late final Booking booking;
  late final String guestPhone;
  Rating? rating;

  @override
  void initState() {
    this.booking = widget.booking;
    this.guestPhone = widget.guestPhone;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;
    final i18n = I18n.values(context)!;

    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: Assets.dimens.screenFormPadding,
          vertical: 12,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Booking ID
            Text('#${booking.bookingId}',
                style: textTheme.caption?.copyWith(color: theme.primaryColor)),
            SizedBox(height: 4),

            // Heading & Status
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(i18n.booking_details_heading, style: textTheme.headline6),
                _getStatusTag(context, booking.status),
              ],
            ),
            SizedBox(height: 4),

            // Booking date
            Text(
              booking.bookedAt != null ? UiUtils.formatDateTime(context, booking.bookedAt!) : '-',
              style: textTheme.overline?.copyWith(color: Color(0xFFBCBCBC)),
            ),
            SizedBox(height: 16),

            // Property Info
            PropertyInfoBox(booking.property!.toProperty(booking.pricePerNight)),
            SizedBox(height: 8),

            // Booking dates
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                DateSelectionCard(
                  label: i18n.check_in,
                  text: DateSelectionCard.formatDate(booking.checkInDate),
                ),
                SizedBox(width: 8),
                DateSelectionCard(
                  label: i18n.check_out,
                  text: DateSelectionCard.formatDate(booking.checkOutDate),
                ),
              ],
            ),
            SizedBox(height: 8),

            // Check-in time
            ..._createInfoRow(
                context, i18n.label_check_in_time, booking.property!.building!.checkInTime),
            // Check-out time
            ..._createInfoRow(
                context, i18n.label_check_out_time, booking.property!.building!.checkOutTime),
            // Guests allowed
            ..._createInfoRow(context, i18n.label_guests, booking.property!.guestCount.toString()),
            // Number of rooms
            ..._createInfoRow(context, i18n.label_room_count, booking.rooms.length.toString()),
            SizedBox(height: 8),

            //Guest info heading
            Text(i18n.heading_guest_info, style: textTheme.headline6),
            SizedBox(height: 8),
            // Guest name
            ..._createInfoRow(context, i18n.label_name, booking.guest.name),
            // Guest email
            ..._createInfoRow(context, i18n.label_email, booking.guest.email),
            // Guest phone
            ..._createInfoRow(context, i18n.label_phone, guestPhone),
            SizedBox(height: 8),

            // Room charges
            Text(i18n.room_charges, style: textTheme.headline6),
            SizedBox(height: 8),
            ..._createPricingRow(
              context: context,
              label: i18n.price_per_night,
              price: booking.pricePerNight,
              count: booking.checkOutDate.difference(booking.checkInDate).inDays,
              totalPrice: booking.costs.room,
              totalLabel: i18n.room_count(booking.rooms.length),
            ),
            SizedBox(height: 8),

            // Value Added Services
            Text(i18n.extra_services, style: textTheme.headline6),
            SizedBox(height: 16),
            ..._displayServices(context, booking.services),
            SizedBox(height: 8),

            // Total
            Divider(),
            ..._createInfoRow(
                context, i18n.total, UiUtils.formatPrice(context, booking.costs.total),
                finalRow: true),
            SizedBox(height: 16),

            // Review (Show only when booking is completed)
            if (BookingStatus.tryParse(booking.status) == BookingStatus.COMPLETED)
              FutureBuilder(
                future: _loadRating(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.done) {
                    return _displayReview(snapshot.data as Rating?);
                  } else {
                    return Align(
                      alignment: Alignment.center,
                      child: Column(
                        children: [
                          HayyakProgressIndicator(),
                          SizedBox(height: 8),
                          Text(i18n.loader_review, style: textTheme.caption),
                          SizedBox(height: 16),
                        ],
                      ),
                    );
                  }
                },
              ),
            if (BookingStatus.tryParse(booking.status) == BookingStatus.COMPLETED)
              SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _getStatusTag(BuildContext context, String status) {
    final bookingStatus = BookingStatus.tryParse(status);
    final i18n = I18n.values(context)!;

    Color backgroundColor = Color(0xFFD7D7D7);
    Color textColor = Colors.black;
    String statusText = status;

    switch (bookingStatus) {
      case BookingStatus.ACTIVE:
        backgroundColor = AppColors.warning.withOpacity(0.1);
        textColor = AppColors.warning;
        statusText = i18n.booking_status_active;
        break;
      case BookingStatus.COMPLETED:
        backgroundColor = AppColors.success.withOpacity(0.1);
        textColor = AppColors.success;
        statusText = i18n.booking_status_completed;
        break;
      case BookingStatus.CANCELLED:
        backgroundColor = AppColors.error.withOpacity(0.1);
        textColor = AppColors.error;
        statusText = i18n.booking_status_cancelled;
        break;
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: backgroundColor,
      ),
      padding: EdgeInsets.symmetric(vertical: 6, horizontal: 24),
      child: Text(
        statusText.toUpperCase(),
        style: Theme.of(context).textTheme.overline?.copyWith(color: textColor),
      ),
    );
  }

  List<Widget> _createInfoRow(BuildContext context, String label, String text,
      {bool finalRow = false}) {
    //
    final List<Widget> widgets = [];
    widgets.add(SizedBox(height: 8));

    final textTheme = Theme.of(context).textTheme;
    final labelStyle = finalRow
        ? textTheme.subtitle1
        : textTheme.bodyText2?.copyWith(color: Colors.black.withOpacity(0.6));
    final valueStyle = finalRow ? textTheme.subtitle1 : textTheme.bodyText2;

    widgets.add(Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: labelStyle),
        Text(text, style: valueStyle),
      ],
    ));
    widgets.add(SizedBox(height: 8));
    if (!finalRow) widgets.add(Divider());

    return widgets;
  }

  List<Widget> _createPricingRow(
      {required BuildContext context,
      required String label,
      required double price,
      required int count,
      required double totalPrice,
      String? totalLabel}) {
    //
    final List<Widget> widgets = [];
    widgets.add(SizedBox(height: 8));
    final subscriptStyle = Theme.of(context).textTheme.caption?.copyWith(color: Color(0xFFB3B3B3));

    widgets.add(Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Left side
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label),
            SizedBox(height: 4),
            Row(
              // (Using Row instead of Text to avoid text scrambling in Arabic)
              children: [
                Text(UiUtils.formatPrice(context, price), style: subscriptStyle),
                Text(' x ', style: subscriptStyle),
                Text('$count', style: subscriptStyle),
              ],
            ),
          ],
        ),
        // Right side
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(UiUtils.formatPrice(context, totalPrice)),
            if (totalLabel != null) SizedBox(height: 4),
            if (totalLabel != null) Text(totalLabel, style: subscriptStyle),
          ],
        ),
      ],
    ));

    widgets.add(SizedBox(height: 8));
    widgets.add(Divider());

    return widgets;
  }

  List<Widget> _displayServices(BuildContext context, List<BookedVAS>? services) {
    final List<Widget> widgets = [];

    services?.forEach((service) {
      widgets.add(BookingServiceView(service));
    });

    if (widgets.isEmpty) {
      widgets.add(Text(
        I18n.values(context)!.no_services_purchased,
        style: Theme.of(context).textTheme.caption,
      ));
    }

    return widgets;
  }

  Future<Rating?> _loadRating() async {
    if (rating != null) return rating;

    // Create request
    final request = GetRatingsRequest(pageNum: 1, bookingId: booking.uuid);

    // Fetch rating
    try {
      final response = await PropertyService(context).getRatings(request);
      if (response.ratings.length > 0) {
        rating = response.ratings[0];
      }
      //
    } catch (e) {}

    return rating;
  }

  Widget _displayReview(Rating? rating) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    if (rating == null) {
      return PrimaryButton(
        child: Text(i18n.action_add_review),
        maxWide: true,
        backgroundColor: Color(0xFFFFC20E),
        onPressed: () => _showViewToRate(rating),
      );
    } else {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Heading
          Text(i18n.your_rating, style: textTheme.headline6),
          SizedBox(height: 8),

          // Rating
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RatingView(initialRating: rating.starRating.toDouble()),
                  SizedBox(height: 4),
                  Text(
                    rating.postedOn == null
                        ? '-'
                        : UiUtils.formatDateAsTimePast(context, rating.postedOn!),
                    style: textTheme.caption,
                  ),
                ],
              ),
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0x1A205B7D),
                ),
                child: IconButton(
                  splashRadius: 24,
                  icon: Icon(HayyakIcons.edit, size: 20),
                  color: Color(0xFF205B7D),
                  onPressed: () => _showViewToRate(rating),
                ),
              ),
            ],
          ),

          // Review
          if (rating.review != null) SizedBox(height: 8),
          if (rating.review != null && rating.review!.isNotEmpty)
            Text(
              '"${rating.review!}"',
              style: textTheme.bodyText2?.copyWith(color: LightTheme.textTertiary),
            ),
        ],
      );
    }
  }

  void _showViewToRate(Rating? rating) async {
    final updatedRating = await UiUtils.navigateTo(
      context: context,
      child: PostRatingScreen(
        booking: BookingToRate.fromBooking(booking),
        rating: rating,
      ),
    );
    if (updatedRating != null)
      setState(() {
        this.rating = updatedRating as Rating;
      });
  }
}
