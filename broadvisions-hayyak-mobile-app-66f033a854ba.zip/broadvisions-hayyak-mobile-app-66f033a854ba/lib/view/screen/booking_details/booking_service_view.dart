/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 31/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/vas_booked.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';
import 'package:hayyak/view/widget/tertiary_button.dart';
import 'package:intl/intl.dart';

class BookingServiceView extends StatefulWidget {
  final BookedVAS bookedService;

  BookingServiceView(this.bookedService, {Key? key}) : super(key: key) {
    debugPrint('BookingServiceView called.');
  }

  @override
  _BookingServiceViewState createState() => _BookingServiceViewState();
}

class _BookingServiceViewState extends State<BookingServiceView> {
  bool isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 8),
        Row(
          children: [
            // Image
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: UiUtils.getNetworkImage(
                imageUrl: widget.bookedService.vas.image?.url ?? '',
                fit: BoxFit.cover,
                width: 56,
                height: 56,
              ),
            ),
            SizedBox(width: 16),

            // Service info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.bookedService.vas.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.subtitle2,
                  ),
                  SizedBox(height: 2),
                  Text(
                    widget.bookedService.vas.description ?? '',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.bodyText2?.copyWith(color: LightTheme.textTertiary),
                  ),
                ],
              ),
            ),
            SizedBox(width: 8),

            // Service price
            Text(UiUtils.formatPrice(context, widget.bookedService.totalCost)),
          ],
        ),

        // Collapsible button
        Padding(
          padding: EdgeInsetsDirectional.only(start: 64),
          child: TertiaryButton(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(HayyakIcons.calendar, color: Theme.of(context).primaryColor, size: 12),
                SizedBox(width: 8),
                Text(
                  I18n.values(context)!.action_view_dates,
                  style: textTheme.caption?.copyWith(color: Theme.of(context).primaryColor),
                ),
                SizedBox(width: 2),
                Icon(isExpanded ? HayyakIcons.angle_up : HayyakIcons.angle_down, size: 16),
              ],
            ),
            onPressed: () => setState(() {
              isExpanded = !isExpanded;
            }),
          ),
        ),

        // Booked dates for service
        if (isExpanded)
          Padding(
            padding: EdgeInsets.only(bottom: 16),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: widget.bookedService.dates
                    .map((date) => _createDateView(date))
                    .toList(growable: false),
              ),
            ),
          ),
      ],
    );
  }

  Widget _createDateView(DateTime date) {
    final monthFormat = DateFormat("MMM");

    return Padding(
      padding: EdgeInsetsDirectional.only(end: 8),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: LightTheme.borderColor),
        ),
        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
        child: Column(
          children: [
            Text(
              monthFormat.format(date),
              style: Theme.of(context).textTheme.caption?.copyWith(color: Color(0xFFBCBCBC)),
            ),
            SizedBox(height: 2),
            Text(date.day.toString()),
          ],
        ),
      ),
    );
  }
}
