/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 09/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/main.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/view/screen/login/login_screen.dart';
import 'package:hayyak/view/screen/main/main_screen.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    Future.delayed(Duration(milliseconds: 2200), () async {
      // Check if user is already logged in
      bool isUserLoggedIn = await _isUserLoggedIn(context);
      final target = isUserLoggedIn ? MainScreen() : LoginScreen();

      // Navigate to target screen
      UiUtils.navigateTo(context: context, endCurrent: true, child: target);
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: FractionallySizedBox(
            widthFactor: 0.75,
            child: Image.asset(Assets.image.splashLogo),
          ),
        ),
      ),
    );
  }

  Future<bool> _isUserLoggedIn(BuildContext context) async {
    // Get token and user details from preferences
    SharedPreferences prefs = await SharedPreferences.getInstance();

    String? token = prefs.getString(Constants.sessionToken);
    if (token == null) return false;

    String? userJson = prefs.getString(Constants.loggedInUserJson);
    if (userJson == null) return false;

    try {
      final user = User.fromJson(jsonDecode(userJson));

      // Save token and user details
      Utils.saveUserLoginInfo(token, user, true);

      // Update app language based on user's language preference
      if (user.language != null) HayyakApp.of(context)?.setLocale(Locale(user.language!));

      return true;
    } catch (e) {
      return false;
    }
  }
}
