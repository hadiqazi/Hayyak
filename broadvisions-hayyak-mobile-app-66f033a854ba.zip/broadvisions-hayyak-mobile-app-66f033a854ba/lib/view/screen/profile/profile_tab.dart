/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 20/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/app_colors.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/authentication_service.dart';
import 'package:hayyak/controller/service/property_service.dart';
import 'package:hayyak/model/core/social_type.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/model/utils/network_config.dart';
import 'package:hayyak/view/screen/common/external_url_screen.dart';
import 'package:hayyak/view/screen/login/login_screen.dart';
import 'package:hayyak/view/screen/profile/change_password/change_password_screen.dart';
import 'package:hayyak/view/screen/profile/edit_profile/edit_profile_screen.dart';
import 'package:hayyak/view/screen/profile/update_language/update_language_screen.dart';
import 'package:hayyak/view/screen/reviews/reviews_screen.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/avatar.dart';
import 'package:hayyak/view/widget/dialog_box.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';
import 'package:hayyak/view/widget/tertiary_button.dart';

class ProfileTab extends StatefulWidget {
  const ProfileTab({Key? key}) : super(key: key);

  @override
  _ProfileTabState createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> with AutomaticKeepAliveClientMixin<ProfileTab> {
  //
  final horizontalPadding = Assets.dimens.screenPadding.left;

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final i18n = I18n.values(context)!;

    return Padding(
      padding: Assets.dimens.screenPadding.copyWith(left: 0, right: 0),
      child: Column(
        children: [
          // Header
          Padding(
            padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(i18n.profile_title, style: Theme.of(context).textTheme.headline5),
                TertiaryButton(child: Text(i18n.action_logout), onPressed: _logout)
              ],
            ),
          ),
          SizedBox(height: 16),

          Expanded(
            child: SingleChildScrollView(
              child: FutureBuilder(
                future: Cache.get(Constants.loggedInUser),
                builder: (context, snapshot) {
                  if (snapshot.data != null)
                    return _buildView(snapshot.data as User);
                  else
                    return Container();
                },
              ),
            ),
          ),

          // Margin for bottom nav bar
          SizedBox(height: Assets.dimens.bottomBarMargin),
        ],
      ),
    );
  }

  Widget _buildView(User user) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;
    final dpSize = 100.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 16),
        // Top section
        Align(
          alignment: Alignment.center,
          child: Column(
            children: [
              // Profile picture
              FutureBuilder(
                future: Cache.get(Constants.loggedInUser),
                builder: (_, snapshot) {
                  final user = snapshot.data;
                  String? url;

                  if (snapshot.connectionState == ConnectionState.done &&
                      user != null &&
                      (user as User).profilePicUrl != null) {
                    url = user.profilePicUrl!;
                  }
                  return Avatar(url: url, size: dpSize);
                },
              ),
              SizedBox(height: 24),

              // Name
              Text(user.getFullName(), style: textTheme.bodyText1),
              SizedBox(height: 8),

              // Email
              Text(user.email, style: textTheme.caption),
              SizedBox(height: 4),

              // Phone
              Text(user.phone, style: textTheme.caption),
              SizedBox(height: 32),

              // Profile
              ..._createOption(
                icon: HayyakIcons.profile,
                label: i18n.menu_profile,
                onPressed: () async {
                  final updatedUser =
                      await UiUtils.navigateTo(context: context, child: EditProfileScreen(user));

                  // Update state if user has changed from edit screen
                  if (updatedUser != null) {
                    setState(() {});
                  }
                },
              ),

              // My reviews
              ..._createOption(
                icon: HayyakIcons.reviews,
                label: i18n.menu_reviews,
                onPressed: () {
                  UiUtils.navigateTo(context: context, child: ReviewsScreen());
                },
              ),

              // Show change-password only when user is logged in through email/password
              if (user.accountType == SocialType.EMAIL)
                // Change password
                ..._createOption(
                  icon: HayyakIcons.security,
                  label: i18n.menu_password,
                  onPressed: () {
                    UiUtils.navigateTo(context: context, child: ChangePasswordScreen(user));
                  },
                ),

              // Help and support
              ..._createOption(
                icon: HayyakIcons.support,
                label: i18n.menu_support,
                onPressed: () {
                  UiUtils.navigateTo(
                    context: context,
                    child: ExternalUrlScreen(
                      url: NetworkConfig.HELP_URL,
                      title: i18n.title_help,
                    ),
                  );
                },
              ),

              // Identity verification
              /*..._createOption(
                icon: HayyakIcons.identity,
                label: i18n.menu_identity,
                tag: user.isVerified ? null : i18n.status_unverified,
                onPressed: () {},
              ),*/

              // Language
              ..._createOption(
                icon: HayyakIcons.language,
                label: i18n.menu_language,
                onPressed: () async {
                  final result =
                      await UiUtils.navigateTo(context: context, child: UpdateLanguageScreen(user));
                  if (result != null) {
                    // Load lookup data again in updated language
                    Future.delayed(Duration(milliseconds: 500), () {
                      PropertyService(context).fetchLookupData();
                    });
                  }
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  List<Widget> _createOption({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    String? tag,
  }) {
    final List<Widget> widgets = [];

    widgets.add(
      InkWell(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: horizontalPadding, vertical: 16),
          child: Row(
            children: [
              Icon(icon, size: 20, color: LightTheme.textTertiary),
              SizedBox(width: 16),
              //
              Text(label),
              SizedBox(width: 16),
              //
              if (tag != null) Spacer(),
              if (tag != null)
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    color: AppColors.error.withOpacity(0.1),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 6, horizontal: 16),
                  child: Text(
                    tag,
                    style: Theme.of(context).textTheme.overline?.copyWith(color: AppColors.error),
                  ),
                )
            ],
          ),
        ),
        onTap: onPressed,
      ),
    );
    widgets.add(Divider());

    return widgets;
  }

  void _logout() async {
    final i18n = I18n.values(context)!;

    DialogBox(context).show(
      title: null,
      message: i18n.logout_confirmation,
      mainButton: i18n.logout_action,
      onMainButtonClick: () {
        // Logout user
        AuthenticationService(context).logout();

        // Navigate to login screen
        UiUtils.navigateTo(context: context, child: LoginScreen(), endCurrent: true);
      },
      secondButton: i18n.txt_cancel,
    );
  }
}
