/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 04/02/2022
            Project: hayyak-mobile-app
 */

import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/service/user_service.dart';
import 'package:hayyak/model/core/file_to_upload.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/model/dto/request/update_profile_request.dart';
import 'package:hayyak/view/utils/country.dart';
import 'package:hayyak/view/utils/image_file.dart';
import 'package:hayyak/view/utils/image_picker.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/avatar.dart';
import 'package:hayyak/view/widget/dropdown_field.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class EditProfileScreen extends StatelessWidget {
  final User user;

  const EditProfileScreen(this.user, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(I18n.values(context)!.edit_profile_title),
      ),
      body: SafeArea(
        // Using FutureBuilder since I18n doesn't work in initState()
        child: FutureBuilder(
          future: _loadCountries(context),
          builder: (_, snapshot) {
            if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
              final data = snapshot.data as List<dynamic>;
              return _EditProfileForm(
                user: user,
                countries: data[0],
                userCountry: data[1],
              );
            } else
              return Center(child: HayyakProgressIndicator());
          },
        ),
      ),
    );
  }

  Future<List> _loadCountries(BuildContext context) async {
    return [
      Country.getAll(context),
      Country.tryParse(context, user.country ?? ''),
    ];
  }
}

class _EditProfileForm extends StatefulWidget {
  final User user;
  final List<Country> countries;
  final Country? userCountry;

  const _EditProfileForm({
    required this.user,
    required this.countries,
    required this.userCountry,
    Key? key,
  }) : super(key: key);

  @override
  _EditProfileFormState createState() => _EditProfileFormState();
}

class _EditProfileFormState extends State<_EditProfileForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _dobController = TextEditingController();

  Country? _selectedCountry;
  DateTime? _selectedDOB;
  ImageFile? _selectedImage;
  String? _pickImageError;

  @override
  void initState() {
    _nameController.text = (widget.user.firstName + ' ' + (widget.user.lastName ?? '')).trim();
    _emailController.text = widget.user.email;
    _phoneController.text = widget.user.phone;
    _selectedCountry = widget.userCountry;

    if (widget.user.dateOfBirth != null) {
      // formatDate() method cannot be called in initState()
      Future.delayed(Duration.zero, () {
        _dobController.text = UiUtils.formatDate(context, widget.user.dateOfBirth!);
        _selectedDOB = widget.user.dateOfBirth;
      });
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final theme = Theme.of(context);
    final profilePicSize = 100.0;

    EdgeInsets screenPadding = EdgeInsets.all(Assets.dimens.screenFormPadding);
    if (Platform.isIOS) screenPadding = screenPadding.copyWith(bottom: 0);

    return FormContainer(
      handleFullPageScroll: true,
      child: Padding(
        padding: screenPadding,
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Profile picture view
              Stack(
                children: [
                  // Display picture
                  Avatar(
                    image: _selectedImage?.file,
                    url: widget.user.profilePicUrl,
                    size: profilePicSize,
                  ),
                  // Change DP button
                  Container(
                    width: profilePicSize,
                    height: profilePicSize,
                    child: Align(
                      alignment: AlignmentDirectional(1.3, 1.3),
                      child: GestureDetector(
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(32),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  offset: Offset(0, 2),
                                  blurRadius: 24,
                                  color: Color(0x29000000),
                                ),
                              ]),
                          padding: EdgeInsets.all(12),
                          child: Icon(Icons.camera_alt_outlined, color: theme.primaryColor),
                        ),
                        onTap: _selectImage,
                      ),
                    ),
                  ),
                ],
              ),

              // Image picking error
              if (_pickImageError != null) SizedBox(height: Assets.dimens.formFieldsMargin),
              if (_pickImageError != null)
                Text(
                  _pickImageError!,
                  style: theme.textTheme.caption?.copyWith(color: theme.errorColor),
                ),

              // DP margin
              SizedBox(height: Assets.dimens.formFieldsMargin * 2),

              // === Form fields start from here === //

              TextFormField(
                decoration: InputDecoration(labelText: i18n.hint_name),
                keyboardType: TextInputType.name,
                textInputAction: TextInputAction.done,
                controller: _nameController,
                validator: (value) {
                  if (value!.trim().isEmpty)
                    return i18n.error_name_empty;
                  else
                    return null;
                },
              ),
              SizedBox(height: Assets.dimens.formFieldsMargin),

              TextFormField(
                decoration: InputDecoration(labelText: i18n.hint_email),
                keyboardType: TextInputType.emailAddress,
                enabled: false,
                textInputAction: TextInputAction.done,
                controller: _emailController,
              ),
              SizedBox(height: Assets.dimens.formFieldsMargin),

              TextFormField(
                decoration: InputDecoration(labelText: i18n.hint_phone),
                keyboardType: TextInputType.phone,
                enabled: false,
                textInputAction: TextInputAction.done,
                controller: _phoneController,
              ),
              SizedBox(height: Assets.dimens.formFieldsMargin),

              InkWell(
                child: IgnorePointer(
                  child: TextFormField(
                    decoration: InputDecoration(labelText: i18n.hint_date_of_birth),
                    textInputAction: TextInputAction.done,
                    controller: _dobController,
                    validator: (value) {
                      if (value!.trim().isEmpty)
                        return i18n.error_dob_empty;
                      else
                        return null;
                    },
                    onTap: () {
                      FocusScope.of(context).unfocus();
                      _selectDOB();
                    },
                  ),
                ),
                onTap: _selectDOB,
              ),
              SizedBox(height: Assets.dimens.formFieldsMargin * 2),

              DropDownField<Country>(
                label: i18n.label_country,
                initialValue: _selectedCountry,
                items: widget.countries.map((Country country) {
                  return DropdownMenuItem<Country>(value: country, child: Text(country.name));
                }).toList(),
                onChanged: (Country? country) {
                  _selectedCountry = country as Country;
                },
              ),

              // Margin
              SizedBox(height: Assets.dimens.formFieldsMargin * 5),
              Spacer(),

              // Submit button
              PrimaryButton(
                child: Text(i18n.action_update_profile),
                maxWide: true,
                onPressed: () {
                  if (_formKey.currentState!.validate() && _pickImageError == null) {
                    FocusScope.of(context).unfocus();
                    // Update user profile
                    _updateProfile();
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _selectDOB() async {
    final lastDate = DateTime.now().subtract(Duration(days: 18 * 365));

    final selectedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDOB ?? lastDate,
      firstDate: DateTime.now().subtract(Duration(days: 100 * 365)),
      lastDate: lastDate,
    );

    if (selectedDate != null) {
      setState(() {
        _selectedDOB = selectedDate;
        _dobController.text = UiUtils.formatDate(context, selectedDate);
        debugPrint('_dobController.text = ${_dobController.text}');
      });
    }
  }

  void _selectImage() async {
    try {
      final pickedImage = await CroppedImagePicker(context).pickImage();
      if (pickedImage != null) {
        setState(() {
          _selectedImage = pickedImage;
          _pickImageError = null;
        });
      }
      //
    } catch (e) {
      setState(() {
        _pickImageError = e.toString();
      });
    }
  }

  void _updateProfile() async {
    final i18n = I18n.values(context)!;
    final progress =
        UiUtils.createProgressDialog(context, i18n.loader_update_profile, cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create request
    final request = UpdateProfileRequest(
      userId: widget.user.id,
      name: _nameController.text.trim(),
      dateOfBirth: _selectedDOB,
      country: _selectedCountry?.code,
    );

    // Get byte data from image asset and convert to upload format
    if (_selectedImage != null) {
      Uint8List byteData = await _selectedImage!.file.readAsBytes();
      request.image = FileToUpload(_selectedImage!.name, byteData);
    }

    // Update profile
    await UserService(context) //
        .updateProfile(request) //
        .then((response) => {
              // Hide progress dialog
              progress.dismiss(),

              // Update user object in cache
              Utils.saveProfileInfo(response.user),

              // Show success message and navigate back
              UiUtils.displaySuccess(context, i18n.update_profile_success_msg),
              UiUtils.navigateBack(context, response.user),
            })
        .catchError((err) => {
              // Hide progress dialog
              progress.dismiss(),

              // Display error
              UiUtils.displayException(context, err),
            });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _dobController.dispose();
    super.dispose();
  }
}
