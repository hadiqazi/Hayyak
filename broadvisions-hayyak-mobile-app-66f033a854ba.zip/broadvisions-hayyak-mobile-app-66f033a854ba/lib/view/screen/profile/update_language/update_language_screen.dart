/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 08/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/app_colors.dart';
import 'package:hayyak/controller/service/user_service.dart';
import 'package:hayyak/main.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/model/dto/request/update_profile_request.dart';
import 'package:hayyak/view/utils/language.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';

class UpdateLanguageScreen extends StatelessWidget {
  final User user;

  const UpdateLanguageScreen(this.user, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(I18n.values(context)!.language_title),
      ),
      body: SafeArea(
        // Using FutureBuilder since I18n doesn't work in initState()
        child: FutureBuilder(
          future: _loadLanguages(context),
          builder: (_, snapshot) {
            if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
              final data = snapshot.data as List<dynamic>;
              return _UpdateLanguageForm(
                user: user,
                languages: data[0],
                userLanguage: data[1],
              );
            } else
              return Center(child: HayyakProgressIndicator());
          },
        ),
      ),
    );
  }

  Future<List> _loadLanguages(BuildContext context) async {
    final languages = Language.getAll(context);
    return [
      languages,
      Language.tryParse(context, user.language ?? '') ?? languages[0],
    ];
  }
}

class _UpdateLanguageForm extends StatefulWidget {
  final User user;
  final List<Language> languages;
  final Language userLanguage;

  const _UpdateLanguageForm({
    required this.user,
    required this.languages,
    required this.userLanguage,
    Key? key,
  }) : super(key: key);

  @override
  _UpdateLanguageFormState createState() => _UpdateLanguageFormState();
}

class _UpdateLanguageFormState extends State<_UpdateLanguageForm> {
  @override
  Widget build(BuildContext context) {
    final languages = Language.getAll(context);

    return Padding(
      padding: Assets.dimens.screenPadding,
      child: ListView.separated(
        itemCount: languages.length,
        itemBuilder: (context, index) {
          final language = languages[index];

          return InkWell(
            child: ListTile(
              title: Text(language.name),
              trailing: language.code == widget.userLanguage.code
                  ? Icon(Icons.check, color: AppColors.success)
                  : null,
            ),
            onTap: () => _updateLanguage(language),
          );
        },
        separatorBuilder: (context, _) {
          return Divider();
        },
      ),
    );
  }

  void _updateLanguage(Language language) async {
    final i18n = I18n.values(context)!;
    final progress =
        UiUtils.createProgressDialog(context, i18n.loader_update_language, cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create request
    final request = UpdateProfileRequest(userId: widget.user.id)..language = language.code;

    // Update profile
    await UserService(context)
        .updateProfile(request)
        .then((response) => {
              // Hide progress dialog
              progress.dismiss(),

              // Update user object in cache
              Utils.saveProfileInfo(response.user),

              // Update language
              HayyakApp.of(context)?.setLocale(Locale(language.code)),

              // Navigate back
              UiUtils.navigateBack(context, response.user),
            })
        .catchError((err) => {
              // Hide progress dialog
              progress.dismiss(),

              // Display error
              UiUtils.displayException(context, err),
            });
  }
}
