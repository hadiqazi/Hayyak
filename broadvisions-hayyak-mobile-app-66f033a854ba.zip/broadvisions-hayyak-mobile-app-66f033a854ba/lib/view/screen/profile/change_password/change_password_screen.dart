/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 08/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/service/user_service.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/model/dto/request/change_password_request.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/password_form_field.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class ChangePasswordScreen extends StatefulWidget {
  final User user;

  const ChangePasswordScreen(this.user, {Key? key}) : super(key: key);

  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final _formKey = GlobalKey<FormState>();
  final _currentPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  int passwordStrength = 0;

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(I18n.values(context)!.title_change_password),
      ),
      body: SafeArea(
        child: FormContainer(
          handleFullPageScroll: true,
          child: Form(
            key: _formKey,
            child: Padding(
              padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Current password
                  PasswordFormField(
                    decoration: InputDecoration(labelText: i18n.hint_current_password),
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.next,
                    controller: _currentPasswordController,
                    validator: (value) {
                      if (value!.isEmpty)
                        return i18n.error_password_empty;
                      else
                        return null;
                    },
                  ),
                  SizedBox(height: Assets.dimens.formFieldsMargin),

                  // New password
                  PasswordFormField(
                    decoration: InputDecoration(labelText: i18n.hint_new_password),
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.next,
                    controller: _newPasswordController,
                    showStrength: true,
                    onStrengthChanged: (value) {
                      passwordStrength = value;
                    },
                    validator: (value) {
                      if (value!.isEmpty)
                        return i18n.error_password_empty;
                      else if (!Utils.isPasswordStrong(passwordStrength))
                        return i18n.error_password_invalid;
                      else
                        return null;
                    },
                  ),
                  SizedBox(height: Assets.dimens.formFieldsMargin),

                  // Confirm new password
                  PasswordFormField(
                    decoration: InputDecoration(labelText: i18n.hint_confirm_new_password),
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    controller: _confirmPasswordController,
                    validator: (value) {
                      if (value! != _newPasswordController.text)
                        return i18n.register_error_password_mismatch;
                      else
                        return null;
                    },
                  ),
                  SizedBox(height: Assets.dimens.formFieldsMargin * 5),
                  Spacer(),
                  PrimaryButton(
                    child: Text(i18n.action_change_password),
                    maxWide: true,
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        FocusScope.of(context).unfocus();
                        // Update password
                        _updatePassword();
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _updatePassword() async {
    final progress = UiUtils.createProgressDialog(
        context, I18n.values(context)!.loader_change_password,
        cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create request
    final request = ChangePasswordRequest(
      _currentPasswordController.text,
      _newPasswordController.text,
    );

    // Send OTPs to user
    await UserService(context)
        .updatePassword(request)
        .then((response) => {
              // Hide progress dialog
              progress.dismiss(),

              // Clear all text field
              _currentPasswordController.text = '',
              _newPasswordController.text = '',
              _confirmPasswordController.text = '',

              // Show success message
              UiUtils.displaySuccess(context, I18n.values(context)!.success_change_password),
              //
            })
        .catchError((err) => {
              // Hide progress dialog
              progress.dismiss(),

              // Display error
              UiUtils.displayException(context, err),
            });
  }

  @override
  void dispose() {
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }
}
