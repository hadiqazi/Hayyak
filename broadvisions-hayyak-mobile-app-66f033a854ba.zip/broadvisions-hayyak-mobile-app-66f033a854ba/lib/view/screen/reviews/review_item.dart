/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/rating.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/avatar.dart';
import 'package:hayyak/view/widget/rating_view.dart';

class ReviewItem extends StatelessWidget {
  final Rating rating;
  final bool showingUserReview;

  const ReviewItem({required this.rating, this.showingUserReview = false, Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // final theme = Theme.of(context);
    final textTheme = Theme.of(context).textTheme;
    final name, imageUrl;
    if (showingUserReview) {
      name = rating.propertyName;
      imageUrl = rating.propertyImageUrl;
    } else {
      name = rating.reviewerName;
      imageUrl = rating.reviewerImageUrl;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 16),
        // Header
        Row(
          children: [
            Avatar(url: imageUrl, size: 42),
            SizedBox(width: 16),

            // Name & rating
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name ?? '', style: textTheme.subtitle1),
                SizedBox(height: 4),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    RatingView(initialRating: rating.starRating.toDouble(), starSize: 16),
                    SizedBox(width: 8),
                    Text(
                      rating.postedOn == null
                          ? '-'
                          : UiUtils.formatDateAsTimePast(context, rating.postedOn!),
                      style: textTheme.caption,
                    ),
                  ],
                ),
              ],
            )
          ],
        ),
        SizedBox(height: 16),

        // Review
        Text(
          '"${rating.review}"',
          style: textTheme.bodyText2?.copyWith(color: LightTheme.textTertiary),
        ),
        SizedBox(height: 16),
      ],
    );
  }
}
