/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/02/2022
            Project: hayyak-mobile-app
 */

import 'package:async/async.dart';
import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/screen_state.dart';
import 'package:hayyak/controller/service/property_service.dart';
import 'package:hayyak/model/core/pagination.dart';
import 'package:hayyak/model/core/rating.dart';
import 'package:hayyak/model/dto/request/get_ratings_request.dart';
import 'package:hayyak/model/dto/response/get_ratings_response.dart';
import 'package:hayyak/view/screen/reviews/review_item.dart';
import 'package:hayyak/view/utils/list_data_helper.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';

class ReviewsScreen extends StatefulWidget {
  final String? propertyId;

  const ReviewsScreen({this.propertyId, Key? key}) : super(key: key);

  @override
  _ReviewsScreenState createState() => _ReviewsScreenState();
}

class _ReviewsScreenState extends State<ReviewsScreen> {
  late String screenTitle;
  late String loader;

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    if (widget.propertyId == null) {
      // Load messages for my/user reviews
      screenTitle = i18n.title_my_reviews;
      loader = i18n.loader_my_reviews;
    } else {
      // Load messages for property reviews
      screenTitle = i18n.title_reviews;
      loader = i18n.loader_reviews;
    }

    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(screenTitle),
      ),
      body: SafeArea(
        child: RefreshIndicator(
          child: FutureBuilder(
            future: _loadInitialData(context),
            builder: (context, AsyncSnapshot<GetRatingsResponse> snapshot) {
              return ListDataHelper.prepareFutureBuilder(
                context: context,
                snapshot: snapshot,
                loadingText: loader,
                success: snapshot.data == null
                    ? Container()
                    : _ItemsList(
                        response: snapshot.data!,
                        propertyId: widget.propertyId,
                      ),
              );
            },
          ),
          onRefresh: () => _loadInitialData(context),
        ),
      ),
    );
  }

  Future<GetRatingsResponse> _loadInitialData(BuildContext context) async {
    return _fetchRatingsData(context, page: 1, propertyId: widget.propertyId);
  }
}

Future<GetRatingsResponse> _fetchRatingsData(context,
    {required int page, required String? propertyId}) async {
  // Fetch ratings data from server
  final request = GetRatingsRequest(pageNum: page, propertyId: propertyId);
  return await PropertyService(context).getRatings(request);
}

class _ItemsList extends StatefulWidget {
  final GetRatingsResponse response;
  final String? propertyId;

  const _ItemsList({required this.response, required this.propertyId, Key? key}) : super(key: key);

  @override
  _ItemsListState createState() => _ItemsListState();
}

class _ItemsListState extends State<_ItemsList> {
  late List<Rating> ratings;
  late int currentPage, maxPages;
  ScreenState screenState = ScreenState.DEFAULT;
  final ScrollController scrollController = new ScrollController();
  CancelableOperation? loadOperation;

  @override
  void initState() {
    ratings = widget.response.ratings;
    // Set pagination
    _resetPagination(widget.response.pagination);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (ratings.isEmpty) {
      final i18n = I18n.values(context)!;
      final emptyMsg =
          widget.propertyId == null ? i18n.msg_empty_my_reviews : i18n.msg_empty_reviews;
      return ListDataHelper.displayEmptyDataMsg(context, emptyMsg);
    }

    return NotificationListener(
      onNotification: onNotification,
      child: ListView.separated(
        itemCount: ratings.length + 1,
        controller: scrollController,
        padding: Assets.dimens.screenPadding.copyWith(top: 0),
        physics: AlwaysScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          if (index == ratings.length) {
            // Show loading view
            if (screenState == ScreenState.LOADING)
              return Center(
                child: HayyakProgressIndicator(),
              );
            else
              return Container();
          } else {
            // Show list item
            return ReviewItem(
              rating: ratings[index],
              showingUserReview: widget.propertyId == null,
            );
          }
        },
        separatorBuilder: (context, index) {
          return Divider();
        },
      ),
    );
  }

  /// Called when list is scrolled to bottom
  bool onNotification(ScrollNotification notification) {
    if (!(notification is ScrollUpdateNotification)) return false;

    if (scrollController.position.maxScrollExtent > scrollController.offset &&
        scrollController.position.maxScrollExtent - scrollController.offset <= 50) {
      if (screenState != ScreenState.LOADING) {
        setState(() {
          screenState = ScreenState.LOADING;
        });

        loadOperation = CancelableOperation.fromFuture(_loadMoreData().then((value) => {
              screenState = ScreenState.SUCCESS,
              setState(() => {ratings.addAll(value)})
            }));
        return true;
      }
    }
    return false;
  }

  // Get next page of data
  Future<List<Rating>> _loadMoreData() async {
    final nextPage = ++currentPage;
    // Return if max page size is reached
    if (nextPage > maxPages) return [];

    try {
      GetRatingsResponse response = await _fetchRatingsData(
        context,
        page: nextPage,
        propertyId: widget.propertyId,
      );

      currentPage = nextPage;
      return response.ratings;
    } catch (e) {
      print(e);
      return [];
    }
  }

  void _resetPagination(Pagination pagination) {
    maxPages = (pagination.totalItems / pagination.pageSize).ceil();
    currentPage = 1;
  }
}
