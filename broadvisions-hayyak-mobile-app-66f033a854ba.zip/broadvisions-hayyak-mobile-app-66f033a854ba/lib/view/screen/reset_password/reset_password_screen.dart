/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 11/11/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/user_service.dart';
import 'package:hayyak/model/dto/request/reset_password_request.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/back_button.dart';
import 'package:hayyak/view/widget/dialog_box.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class ResetPasswordScreen extends StatelessWidget {
  const ResetPasswordScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            FormContainer(
              child: _ResetPasswordForm(),
              handleFullPageScroll: true,
            ),
            CustomBackButton(),
          ],
        ),
      ),
    );
  }
}

class _ResetPasswordForm extends StatefulWidget {
  const _ResetPasswordForm({Key? key}) : super(key: key);

  @override
  _ResetPasswordFormState createState() => _ResetPasswordFormState();
}

class _ResetPasswordFormState extends State<_ResetPasswordForm> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Form(
      key: _formKey,
      child: Container(
        padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 56),
            // Heading
            Text(
              i18n.reset_pwd_title,
              style: Theme.of(context).textTheme.headline4,
            ),
            SizedBox(height: 16),
            Text(i18n.reset_pwd_sub_title,
                style: Theme.of(context)
                    .textTheme
                    .bodyText2
                    ?.copyWith(color: LightTheme.textTertiary)),

            // Form fields below
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),
            TextFormField(
              decoration: InputDecoration(labelText: i18n.hint_email),
              keyboardType: TextInputType.emailAddress,
              textInputAction: TextInputAction.next,
              controller: _emailController,
              validator: (value) {
                if (value!.trim().isEmpty)
                  return i18n.error_email_empty;
                else if (!Constants.emailRegex.hasMatch(value))
                  return i18n.error_email_invalid;
                else
                  return null;
              },
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin * 4),
            PrimaryButton(
              child: Text(i18n.reset_pwd_submit),
              maxWide: true,
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  FocusScope.of(context).unfocus();
                  // Reset password
                  _sendResetInfo();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  void _sendResetInfo() async {
    final i18n = I18n.values(context)!;
    final progress =
        UiUtils.createProgressDialog(context, i18n.reset_pwd_loader, cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create request
    final request = ResetPasswordRequest(
      _emailController.text.trim(),
    );

    // Send reset link
    await UserService(context)
        .resetPassword(request)
        .then((response) => {
              // Hide progress dialog
              progress.dismiss(),

              // Display success message
              DialogBox(context).show(
                  title: i18n.reset_pwd_title,
                  message: i18n.reset_pwd_success,
                  onMainButtonClick: () {
                    UiUtils.navigateBack(context);
                  }),
            })
        .catchError(
            (err) => {
                  // Hide progress dialog
                  progress.dismiss(),

                  // Display error
                  debugPrint('${err.message}'),
                  UiUtils.displayException(context, err)
                },
            test: (err) => err is AppException);
  }

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }
}
