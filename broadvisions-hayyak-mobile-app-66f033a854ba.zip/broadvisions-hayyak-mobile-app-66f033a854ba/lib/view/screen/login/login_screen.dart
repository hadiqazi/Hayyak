/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 09/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/authentication_service.dart';
import 'package:hayyak/controller/service/social_auth_service.dart';
import 'package:hayyak/main.dart';
import 'package:hayyak/model/core/social_signup_info.dart';
import 'package:hayyak/model/core/social_type.dart';
import 'package:hayyak/model/dto/request/login_request.dart';
import 'package:hayyak/model/dto/request/social_login_request.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/model/network/response_code.dart';
import 'package:hayyak/view/screen/main/main_screen.dart';
import 'package:hayyak/view/screen/register/register_screen.dart';
import 'package:hayyak/view/screen/register/social_signup_screen.dart';
import 'package:hayyak/view/screen/reset_password/reset_password_screen.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/dialog_box.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/password_form_field.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:hayyak/view/widget/tertiary_button.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: FormContainer(
          child: _LoginForm(),
          handleFullPageScroll: true,
        ),
      ),
    );
  }
}

class _LoginForm extends StatefulWidget {
  const _LoginForm({Key? key}) : super(key: key);

  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<_LoginForm> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void initState() {
    if (kDebugMode) {
      _emailController.text = 'umair@ebv.net';
      _passwordController.text = 'Uma!r123';
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Heading
          SizedBox(height: 24),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Padding(
                  padding: EdgeInsetsDirectional.only(
                    start: Assets.dimens.screenFormPadding,
                    end: 16,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        i18n.login_title,
                        style: Theme.of(context).textTheme.headline4,
                      ),
                      SizedBox(height: 16),
                      Text(
                        i18n.login_sub_title,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText2
                            ?.copyWith(color: LightTheme.textTertiary),
                      ),
                    ],
                  ),
                ),
              ),
              SvgPicture.asset(Assets.image.authDecoration(context)),
            ],
          ),
          SizedBox(height: Assets.dimens.screenFormPadding),
          // Form fields below
          Padding(
            padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
            child: Column(
              children: [
                TextFormField(
                  decoration: InputDecoration(labelText: i18n.hint_email),
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  controller: _emailController,
                  validator: (value) {
                    if (value!.trim().isEmpty)
                      return i18n.error_email_empty;
                    else if (!Constants.emailRegex.hasMatch(value))
                      return i18n.error_email_invalid;
                    else
                      return null;
                  },
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin),
                PasswordFormField(
                  decoration: InputDecoration(labelText: i18n.hint_password),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.done,
                  controller: _passwordController,
                  validator: (value) {
                    if (value!.trim().isEmpty)
                      return i18n.error_password_empty;
                    else
                      return null;
                  },
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin),
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: TertiaryButton(
                    child: Text(i18n.login_action_reset_pwd),
                    style: TextButton.styleFrom(primary: LightTheme.textPrimary),
                    onPressed: () {
                      UiUtils.navigateTo(context: context, child: ResetPasswordScreen());
                    },
                  ),
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin),
                PrimaryButton(
                  child: Text(i18n.login_submit),
                  maxWide: true,
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      FocusScope.of(context).unfocus();
                      // Login user
                      _loginUser();
                    }
                  },
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin * 3),

                // Social login heading
                Text(i18n.login_social_label),
                SizedBox(height: Assets.dimens.formFieldsMargin * 2),
                // Social login buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: SvgPicture.asset(Assets.image.google),
                      padding: EdgeInsets.zero,
                      iconSize: Assets.dimens.socialIconSize,
                      splashRadius: Assets.dimens.socialIconSize / 2,
                      onPressed: () => _loginWithSocial(SocialType.GOOGLE),
                    ),
                    SizedBox(width: 8),
                    IconButton(
                      icon: SvgPicture.asset(Assets.image.facebook),
                      padding: EdgeInsets.zero,
                      iconSize: Assets.dimens.socialIconSize,
                      splashRadius: Assets.dimens.socialIconSize / 2,
                      onPressed: () => _loginWithSocial(SocialType.FACEBOOK),
                    ),
                    if (Platform.isIOS) SizedBox(width: 8),
                    if (Platform.isIOS)
                      IconButton(
                        icon: SvgPicture.asset(Assets.image.apple),
                        padding: EdgeInsets.zero,
                        iconSize: Assets.dimens.socialIconSize,
                        splashRadius: Assets.dimens.socialIconSize / 2,
                        onPressed: () => _loginWithSocial(SocialType.APPLE),
                      ),
                  ],
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin * 3),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(i18n.login_register_label),
                    TertiaryButton(
                      child: Text(i18n.login_action_register),
                      onPressed: () {
                        // Navigate to register screen
                        UiUtils.navigateTo(context: context, child: RegisterScreen());
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _loginUser() async {
    final progress = UiUtils.createProgressDialog(context, I18n.values(context)!.login_loader,
        cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create request
    final request = LoginRequest(
      _emailController.text.trim(),
      _passwordController.text,
    );

    // Login user
    await AuthenticationService(context)
        .login(request)
        .then((response) => {
              // Hide progress dialog
              progress.dismiss(),

              // Update app language based on user's language preference
              if (response.user.language != null &&
                  response.user.language != Utils.getCurrentLanguage(context))
                HayyakApp.of(context)?.setLocale(Locale(response.user.language!)),

              UiUtils.navigateAndClearPrevious(context: context, child: MainScreen()),
            })
        .catchError((err) => {
              // Hide progress dialog
              progress.dismiss(),

              // Display error
              UiUtils.displayException(context, err)
            });
  }

  void _loginWithSocial(SocialType socialType) async {
    final progress = UiUtils.createProgressDialog(
        context, I18n.values(context)!.loader_social_login,
        cancelable: false);

    // Show progress dialog
    await progress.show();

    final service = SocialAuthService(context);
    late SocialSignUpInfo signUpInfo;

    try {
      if (socialType == SocialType.FACEBOOK) {
        signUpInfo = await service.loginWithFacebook();
        //
      } else if (socialType == SocialType.GOOGLE) {
        signUpInfo = await service.loginWithGoogle();
        //
      } else if (socialType == SocialType.APPLE) {
        signUpInfo = await service.loginWithApple();
        //
      } else {
        progress.dismiss();
        return;
      }

      // Social login complete. Login this user on Hayyak server
      final response = await AuthenticationService(context)
          .socialLogin(SocialLoginRequest(socialType, signUpInfo.token));

      // Hide progress dialog
      progress.dismiss();

      // Update app language based on user's language preference
      if (response.user.language != null &&
          response.user.language != Utils.getCurrentLanguage(context))
        HayyakApp.of(context)?.setLocale(Locale(response.user.language!));

      UiUtils.navigateAndClearPrevious(context: context, child: MainScreen());
      //
    } catch (err) {
      // Hide progress dialog
      progress.dismiss();

      if (err is AppException && err.errorCode == ResponseCode.HTTP_NOT_FOUND) {
        // User doesn't exist in Hayyak system. Take user to complete-profile screen

        if (socialType == SocialType.APPLE) {
          // Additional steps for Apple login
          if (signUpInfo.name == null || signUpInfo.email == null) {
            // User sign-in is not the first and hence Apple has not provided required information.
            // Inform user on how to fix this, and end the login flow.
            final i18n = I18n.values(context)!;
            DialogBox(context).show(
              title: i18n.apple_login_error_title,
              message: i18n.apple_login_error_msg,
            );
            return;
            //
          } else {
            // Set refreshToken instead of initial token in SignUp request
            signUpInfo.token = err.payload?['refreshToken'];
          }
        }

        UiUtils.navigateTo(context: context, child: SocialSignupScreen(signUpInfo));
        return;
      }

      if (err is AppException && err.errorCode == ResponseCode.SOCIAL_USER_CONFLICT) {
        // Logout of the account to avoid further issues
        if (socialType == SocialType.FACEBOOK) {
          service.logoutFromFacebook();
          //
        } else if (socialType == SocialType.GOOGLE) {
          service.logoutFromGoogle();
          //
        } else if (socialType == SocialType.APPLE) {
          service.logoutFromApple();
        }
      }

      // Display error
      UiUtils.displayException(context, err);
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
