/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 10/12/2021
            Project: hayyak-mobile-app
 */

import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/amenity.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/model/dto/response/lookup_response.dart';
import 'package:hayyak/view/screen/common/image_viewer.dart';
import 'package:hayyak/view/screen/make_booking/make_booking_screen.dart';
import 'package:hayyak/view/screen/reviews/reviews_screen.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/back_button.dart';
import 'package:hayyak/view/widget/bottom_action_bar.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';
import 'package:hayyak/view/widget/rating_view.dart';
import 'package:hayyak/view/widget/tertiary_button.dart';

class PropertyDetailScreen extends StatelessWidget {
  final Property property;

  const PropertyDetailScreen(this.property, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: Cache.get(Constants.lookupData),
      builder: (context, AsyncSnapshot<dynamic> snapshot) {
        if (snapshot.connectionState == ConnectionState.done &&
            snapshot.hasData &&
            snapshot.data is LookupResponse) {
          return _detailsView(context, snapshot.data as LookupResponse);
        } else {
          return Container();
        }
      },
    );
  }

  Widget _detailsView(BuildContext context, LookupResponse lookupData) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      body: SafeArea(
        top: false,
        bottom: false,
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                children: [
                  // Cover image
                  AspectRatio(
                    aspectRatio: 0.97,
                    child: ClipRRect(
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                      child: UiUtils.getNetworkImage(
                        imageUrl: property.coverImage.url,
                        fit: BoxFit.cover,
                        width: double.maxFinite,
                      ),
                    ),
                  ),

                  // Padded container
                  Container(
                    padding: Assets.dimens.screenPadding,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 12),

                        // Rating
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Icon(HayyakIcons.rating, color: LightTheme.ratingColor, size: 17),
                            SizedBox(width: 4),
                            Text(UiUtils.formatRating(property.rating)),
                          ],
                        ),
                        SizedBox(height: 4),

                        // Name
                        Text(property.name, style: textTheme.headline5),
                        SizedBox(height: 16),

                        // Tags
                        Wrap(
                          spacing: 8,
                          children: [
                            _getTag(context, property.propertyType),
                            _getTag(context, property.bedType),
                          ],
                        ),
                        SizedBox(height: 24),

                        // Description
                        Text(i18n.description, style: textTheme.headline5),
                        SizedBox(height: 8),
                        Text(property.description ?? '',
                            style: textTheme.bodyText2?.copyWith(color: LightTheme.textTertiary)),
                        SizedBox(height: 24),

                        // Highlights
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            _getHighlight(context, i18n.check_in, property.building.checkInTime),
                            SizedBox(width: 12),
                            _getHighlight(context, i18n.check_out, property.building.checkOutTime),
                            SizedBox(width: 12),
                            _getHighlight(context, i18n.guests, property.guestCount.toString()),
                          ],
                        ),
                        SizedBox(height: 24),

                        // Gallery
                        Text(i18n.gallery, style: textTheme.headline5),
                        SizedBox(height: 16),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: _getGalleryView(context),
                        ),
                        SizedBox(height: 24),

                        // Amenities
                        Text(i18n.amenities, style: textTheme.headline5),
                        // SizedBox(height: 16),
                        _getAmenitiesView(context, lookupData),
                        SizedBox(height: 24),

                        // Rating
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(i18n.reviews, style: textTheme.headline5),
                            TertiaryButton(
                              child: Text(i18n.action_all_reviews(property.reviewCount)),
                              onPressed: () => UiUtils.navigateTo(
                                context: context,
                                child: ReviewsScreen(propertyId: property.id),
                              ),
                            ),
                          ],
                        ),
                        _getRatingView(context, i18n),
                        SizedBox(height: 32),

                        // Reviews
                        // Text(i18n.recent_reviews, style: textTheme.headline5),
                        // SizedBox(height: 16),
                        // ..._displayReviews(),

                        // Padding at bottom to make space for booking bar
                        SizedBox(height: Assets.dimens.bottomBarMargin),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Back Button
            Align(
              alignment: AlignmentDirectional.topStart,
              child: Padding(
                padding: EdgeInsetsDirectional.only(start: 8, top: 32),
                child: Container(
                  padding: EdgeInsetsDirectional.only(end: 12, bottom: 2),
                  decoration: BoxDecoration(
                    color: Color(0x33000000),
                    shape: BoxShape.circle,
                  ),
                  child: CustomBackButton(padding: 2, iconSize: 16, color: Colors.white),
                ),
              ),
            ),
            // Booking view
            BottomActionBar(
              info: Row(
                children: [
                  Text(
                    UiUtils.formatPrice(context, property.pricePerNight),
                    style: textTheme.headline5,
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Text(
                      i18n.per_night,
                      style: textTheme.caption?.copyWith(color: LightTheme.textPrimary),
                    ),
                  ),
                ],
              ),
              action: i18n.action_book,
              onPressed: () {
                UiUtils.navigateTo(context: context, child: MakeBookingScreen(property));
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _getTag(BuildContext context, String text) {
    final theme = Theme.of(context);
    return Container(
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: theme.primaryColor,
      ),
      child: Text(
        text,
        style: theme.textTheme.caption?.copyWith(color: theme.colorScheme.onPrimary),
      ),
    );
  }

  Widget _getHighlight(BuildContext context, String label, String text) {
    final textTheme = Theme.of(context).textTheme;
    final colorScheme = Theme.of(context).colorScheme;

    return Expanded(
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: Color(0x1AC4C4C4),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: textTheme.caption?.copyWith(color: colorScheme.secondary),
            ),
            SizedBox(height: 4),
            Text(
              text,
              style: textTheme.bodyText2?.copyWith(color: LightTheme.textPrimary),
              textAlign: TextAlign.center,
            )
          ],
        ),
      ),
    );
  }

  Widget _getGalleryView(BuildContext context) {
    List<Widget> widgets = [];

    if (property.images != null) {
      for (int i = 0; i < property.images!.length; i++) {
        final image = property.images![i];

        widgets.add(
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              children: [
                UiUtils.getNetworkImage(
                  imageUrl: image.url,
                  width: 80,
                  height: 80,
                  fit: BoxFit.cover,
                ),
                Positioned.fill(
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        UiUtils.showOverlay(
                            context: context,
                            child: ImageViewer(images: property.images!, initialIndex: i));
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        );

        // Add space, if required
        if (i < property.images!.length - 1) {
          widgets.add(SizedBox(width: 8));
        }
      }
    }

    return Row(
      children: widgets,
    );
  }

  Widget _getAmenitiesView(BuildContext context, LookupResponse lookupData) {
    final amenities = HashMap<String, List<Amenity>>();

    property.amenities?.forEach((amenity) {
      final type = amenity.amenityType;
      final data = amenities[type.name];
      if (data == null) {
        amenities[type.name] = [amenity];
      } else {
        amenities[type.name] = data..add(amenity);
      }
    });

    List<Widget> widgets = [];
    final textTheme = Theme.of(context).textTheme;

    amenities.forEach((typeName, amenities) {
      widgets.add(SizedBox(height: 20));
      widgets.add(Text(
        typeName,
        style: textTheme.bodyText1?.copyWith(fontWeight: FontWeight.w500),
      ));
      widgets.add(SizedBox(height: 12));
      widgets.add(_getAmenityTags(context, amenities, textTheme));
    });

    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: widgets,
      ),
    );
  }

  Widget _getAmenityTags(BuildContext context, List<Amenity> amenities, TextTheme textTheme) {
    List<Widget> widgets = [];
    for (int i = 0; i < amenities.length; i++) {
      widgets.add(
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(23),
              border: Border.all(color: LightTheme.borderColor)),
          child: Text(
            amenities[i].name,
            style: textTheme.caption?.copyWith(color: LightTheme.textTertiary),
          ),
        ),
      );
    }

    return Wrap(
      spacing: 8,
      runSpacing: 10,
      children: widgets,
    );
  }

  Widget _getRatingView(BuildContext context, dynamic i18n) {
    final textTheme = Theme.of(context).textTheme;
    final ratings = property.ratingDistribution;
    final ratingsTotal = ratings.reduce((value, element) => value + element);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Big rating view
        Row(
          children: [
            Text(
              UiUtils.formatRating(property.rating),
              style: textTheme.headline6?.copyWith(fontSize: 48),
            ),
            SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  i18n.label_total_ratings(property.ratingCount),
                  style: textTheme.bodyText2?.copyWith(color: LightTheme.textTertiary),
                ),
                SizedBox(height: Utils.isRtlMode(context) ? 4 : 2),
                RatingView(initialRating: property.rating, starSize: 18),
              ],
            ),
          ],
        ),
        // Star-wise rating
        ..._createBar(context, ratings[4], ratingsTotal, i18n.distributed_rating_label(5)),
        ..._createBar(context, ratings[3], ratingsTotal, i18n.distributed_rating_label(4)),
        ..._createBar(context, ratings[2], ratingsTotal, i18n.distributed_rating_label(3)),
        ..._createBar(context, ratings[1], ratingsTotal, i18n.distributed_rating_label(2)),
        ..._createBar(context, ratings[0], ratingsTotal, i18n.distributed_rating_label(1)),
      ],
    );
  }

  List<Widget> _createBar(BuildContext context, double value, double totalValue, String label) {
    final double percentage = totalValue == 0 ? 0 : value / totalValue;

    final bar = Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: Stack(
            children: [
              Container(
                height: 14,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: LightTheme.borderColor,
                ),
              ),
              FractionallySizedBox(
                widthFactor: percentage,
                child: Container(
                  height: 14,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: Theme.of(context).primaryColor,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 16),
        Text(
          label,
          style: Theme.of(context)
              .textTheme
              .caption
              ?.copyWith(color: LightTheme.textTertiary, fontSize: 12),
        ),
      ],
    );

    return [SizedBox(height: 16), bar];
  }
}
