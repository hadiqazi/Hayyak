/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 14/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/cancellation_policy.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/model/dto/request/make_booking_request.dart';
import 'package:hayyak/model/dto/request/search_properties_request.dart';
import 'package:hayyak/model/dto/response/lookup_response.dart';
import 'package:hayyak/view/screen/make_booking/add_services_screen.dart';
import 'package:hayyak/view/utils/booking_utils.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/app_bar_action.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/bottom_action_bar.dart';
import 'package:hayyak/view/widget/date_selection_view.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/number_selector.dart';
import 'package:hayyak/view/widget/property_info_box.dart';

class MakeBookingScreen extends StatelessWidget {
  final Property property;

  const MakeBookingScreen(this.property, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(i18n.booking_title),
        actions: [
          AppBarAction(
            text: i18n.txt_cancel,
            onPressed: () => BookingUtils.cancelBookingProcess(context, 1),
          ),
          SizedBox(width: Assets.dimens.appBarEndMargin),
        ],
      ),
      body: FutureBuilder(
        future: _loadFromCache(),
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
            final data = snapshot.data! as List;
            return _BookingForm(
              request: data[0],
              property: property,
              cancellationPolicy: data[1],
            );
          } else
            return Center(child: HayyakProgressIndicator());
        },
      ),
    );
  }

  Future<List> _loadFromCache() async {
    List data = [];
    data.add(await Cache.get(Constants.propertySearchRequest));

    final lookupData = await Cache.get(Constants.lookupData);
    data.add((lookupData  as LookupResponse).cancellationPolicy);

    return data;
  }
}

class _BookingForm extends StatefulWidget {
  final SearchPropertiesRequest request;
  final Property property;
  final CancellationPolicy cancellationPolicy;

  _BookingForm({
    required this.request,
    required this.property,
    required this.cancellationPolicy,
    Key? key,
  }) : super(key: key);

  @override
  _BookingFormState createState() => _BookingFormState();
}

class _BookingFormState extends State<_BookingForm> {
  late final Property property;

  late DateTimeRange selectedDates;
  late int nightsCount;
  late int roomCount;
  late double totalPrice;
  final _roomCountController = TextEditingController();
  String cancellationTime = '';

  @override
  void initState() {
    property = widget.property;
    selectedDates = DateTimeRange(
      start: widget.request.checkInDate,
      end: widget.request.checkOutDate,
    );
    roomCount = widget.request.roomCount;

    _calculateNightCount();
    _calculateTotalPrice();
    Future.delayed(Duration(milliseconds: 100), () {
      setState(() {
        _calculateCancellationDate();
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final i18n = I18n.values(context)!;

    return Stack(
      children: [
        FormContainer(
          child: Padding(
            padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Property info box
                PropertyInfoBox(property),
                SizedBox(height: 20),

                // Booking dates
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    DateSelectionCard(
                      label: i18n.check_in,
                      text: DateSelectionCard.formatDate(selectedDates.start),
                      onPressed: () {
                        _openDateRangePicker();
                      },
                    ),
                    SizedBox(width: 8),
                    DateSelectionCard(
                      label: i18n.check_out,
                      text: DateSelectionCard.formatDate(selectedDates.end),
                      onPressed: () {
                        _openDateRangePicker();
                      },
                    ),
                  ],
                ),
                SizedBox(height: 16),

                // Check-in time
                ..._createInfoRow(i18n.label_check_in_time, property.building.checkInTime),
                // Check-out time
                ..._createInfoRow(i18n.label_check_out_time, property.building.checkOutTime),
                // Guests allowed
                ..._createInfoRow(i18n.label_guests, property.guestCount.toString()),

                // Number of rooms
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(i18n.search_num_of_rooms),
                    NumberSelector(
                      initialValue: roomCount,
                      maxValue: Constants.roomSelectorThreshold,
                      controller: _roomCountController,
                      onChanged: (value) {
                        setState(() {
                          roomCount = int.parse(_roomCountController.text);
                          _calculateTotalPrice();
                        });
                      },
                    ),
                  ],
                ),
                Spacer(),

                // Free cancellation notice
                Text(i18n.free_cancellation_title, style: textTheme.bodyText2),
                Text(
                  cancellationTime,
                  style: textTheme.bodyText2?.copyWith(color: Theme.of(context).primaryColor),
                ),
                SizedBox(height: 8),
                Text(
                  i18n.free_cancellation_msg,
                  style: textTheme.overline?.copyWith(color: LightTheme.textTertiary),
                ),

                // Padding at bottom to make space for booking bar
                SizedBox(height: Assets.dimens.bottomBarMargin),
              ],
            ),
          ),
          handleFullPageScroll: true,
        ),

        // Bottom bar
        BottomActionBar(
          info: IntrinsicHeight(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  UiUtils.formatPrice(context, totalPrice),
                  style: textTheme.headline6,
                ),
                SizedBox(height: 4),
                Text(
                  i18n.label_nights_count(nightsCount),
                  style: textTheme.caption?.copyWith(color: LightTheme.textTertiary),
                ),
              ],
            ),
          ),
          action: i18n.txt_next,
          onPressed: continueToNextStep,
        ),
      ],
    );
  }

  void _calculateNightCount() {
    this.nightsCount = selectedDates.end.difference(selectedDates.start).inDays;
  }

  void _openDateRangePicker() {
    BookingUtils.chooseDateRange(
      context: context,
      initialDateRange: selectedDates,
      onRangeSelected: (range) {
        setState(() {
          selectedDates = range;
          _calculateNightCount();
          _calculateTotalPrice();
          _calculateCancellationDate();
        });
      },
    );
  }

  void _calculateTotalPrice() {
    this.totalPrice = property.pricePerNight * nightsCount * roomCount;
  }

  void _calculateCancellationDate() {
    cancellationTime = BookingUtils.calculateFreeCancellationDate(
      context,
      selectedDates.start,
      property.building.checkInTime,
      widget.cancellationPolicy,
    );
  }

  List<Widget> _createInfoRow(String label, String text) {
    final List<Widget> widgets = [];
    widgets.add(SizedBox(height: 8));
    widgets.add(Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label),
        Text(text),
      ],
    ));
    widgets.add(SizedBox(height: 8));
    widgets.add(Divider());

    return widgets;
  }

  void continueToNextStep() {
    // Create booking request
    final request = MakeBookingRequest(
      propertyId: property.id,
      checkInDate: selectedDates.start,
      checkOutDate: selectedDates.end,
      roomCount: roomCount,
      nightCount: this.nightsCount,
    );

    // Navigate to service selection screen
    UiUtils.navigateTo(
      context: context,
      child: AddServicesScreen(property: property, bookingRequest: request),
    );
  }

  @override
  void dispose() {
    _roomCountController.dispose();
    super.dispose();
  }
}
