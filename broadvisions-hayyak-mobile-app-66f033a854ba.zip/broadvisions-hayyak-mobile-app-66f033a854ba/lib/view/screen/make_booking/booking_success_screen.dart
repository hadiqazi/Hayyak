/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/app_colors.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/model/dto/response/booking_dto.dart';
import 'package:hayyak/view/screen/main/main_screen.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:hayyak/view/widget/rating_view.dart';
import 'package:hayyak/view/widget/secondary_button.dart';

class BookingSuccessScreen extends StatelessWidget {
  final Property property;
  final BookingDTO booking;

  const BookingSuccessScreen({
    required this.booking,
    required this.property,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(I18n.values(context)!.booking_invoice_title),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(
            left: Assets.dimens.screenFormPadding,
            right: Assets.dimens.screenFormPadding,
            bottom: Assets.dimens.screenFormPadding,
            top: Assets.dimens.screenFormPadding / 2,
          ),
          child: _createView(context),
        ),
      ),
    );
  }

  Widget _createView(BuildContext context) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    return Column(
      children: [
        // Property cover image
        Container(
          width: Assets.dimens.roundThumbnailSize,
          height: Assets.dimens.roundThumbnailSize,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            image: DecorationImage(
              fit: BoxFit.cover,
              image: NetworkImage(property.coverImage.url),
            ),
          ),
        ),
        SizedBox(height: 16),

        // Name
        Text(property.name, style: textTheme.subtitle1),
        SizedBox(height: 8),

        // Rating
        RatingView(initialRating: property.rating, starSize: 16),
        SizedBox(height: 4),
        Text(
          UiUtils.formatRating(property.rating) + '/' + UiUtils.formatRating(5),
          style: textTheme.caption?.copyWith(color: LightTheme.textTertiary),
        ),
        SizedBox(height: 16),

        // Success message
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check, color: AppColors.success),
            SizedBox(width: 4),
            Text(
              i18n.booking_success_msg,
              style: textTheme.caption?.copyWith(color: AppColors.success),
            ),
          ],
        ),
        SizedBox(height: 32),

        // Booking details
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: Text(i18n.booking_details, style: textTheme.subtitle1),
        ),
        SizedBox(height: 16),

        // Booking date
        ..._createInfoRow(
            i18n.label_booking_date,
            UiUtils.formatDate(context, booking.checkInDate) +
                ' - ' +
                UiUtils.formatDate(context, booking.checkOutDate)),
        // Check-in time
        ..._createInfoRow(i18n.label_check_in_time, property.building.checkInTime),
        // Check-out time
        ..._createInfoRow(i18n.label_check_out_time, property.building.checkOutTime),
        // Guests allowed
        ..._createInfoRow(i18n.label_guests, property.guestCount.toString()),
        // Number of rooms
        ..._createInfoRow(i18n.label_room_count, booking.rooms.length.toString()),
        SizedBox(height: 32),

        // Buttons
        PrimaryButton(
          child: Text(i18n.action_go_to_bookings),
          maxWide: true,
          onPressed: () => _navigateToStart(context, true),
        ),
        SizedBox(height: 8),
        SecondaryButton(
          child: Text(i18n.action_go_to_home),
          maxWide: true,
          onPressed: () => _navigateToStart(context, false),
        ),
      ],
    );
  }

  List<Widget> _createInfoRow(String label, String text) {
    final List<Widget> widgets = [];
    widgets.add(SizedBox(height: 8));
    widgets.add(Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label),
        Text(text),
      ],
    ));
    widgets.add(SizedBox(height: 8));
    widgets.add(Divider());

    return widgets;
  }

  void _navigateToStart(BuildContext context, bool bookingsTab) {
    UiUtils.navigateTo(
      context: context,
      endCurrent: true,
      child: MainScreen(
        initialTab: bookingsTab ? MainScreenTab.BOOKINGS : MainScreenTab.HOME,
        skipLookupFetching: true,
      ),
    );
  }
}
