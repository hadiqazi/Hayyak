/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 14/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/guest.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/model/dto/request/make_booking_request.dart';
import 'package:hayyak/view/screen/make_booking/booking_invoice_screen.dart';
import 'package:hayyak/view/utils/booking_utils.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/country.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/app_bar_action.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/bottom_action_bar.dart';
import 'package:hayyak/view/widget/dropdown_field.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';

class GuestInfoScreen extends StatelessWidget {
  final Property property;
  final MakeBookingRequest bookingRequest;

  const GuestInfoScreen({
    required this.property,
    required this.bookingRequest,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(i18n.guest_info_title),
        actions: [
          AppBarAction(
            text: i18n.txt_cancel,
            onPressed: () => BookingUtils.cancelBookingProcess(context, 3),
          ),
          SizedBox(width: Assets.dimens.appBarEndMargin),
        ],
      ),
      body: FutureBuilder(
        future: _loadData(context),
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
            final data = snapshot.data as List<dynamic>;
            return _GuestInfoForm(
              bookingRequest: bookingRequest,
              property: property,
              user: data[0],
              initialPhoneNumber: data[1],
              countries: data[2],
              userCountry: data[3],
            );
          } else
            return Center(child: HayyakProgressIndicator());
        },
      ),
    );
  }

  Future<List<dynamic>> _loadData(BuildContext context) async {
    final user = await Cache.get(Constants.loggedInUser) as User;

    // Parse phone number
    PhoneNumber number;
    try {
      number = await PhoneNumber.getRegionInfoFromPhoneNumber(user.phone);
    } catch (e) {
      number = PhoneNumber(isoCode: 'SA', phoneNumber: user.phone);
    }

    return [
      user,
      number,
      Country.getAll(context),
      Country.tryParse(context, user.country ?? ''),
    ];
  }
}

class _GuestInfoForm extends StatefulWidget {
  final MakeBookingRequest bookingRequest;
  final Property property;
  final User user;
  final PhoneNumber initialPhoneNumber;
  final List<Country> countries;
  final Country? userCountry;

  const _GuestInfoForm({
    required this.bookingRequest,
    required this.property,
    required this.user,
    required this.initialPhoneNumber,
    required this.countries,
    required this.userCountry,
    Key? key,
  }) : super(key: key);

  @override
  _GuestInfoFormState createState() => _GuestInfoFormState();
}

class _GuestInfoFormState extends State<_GuestInfoForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _dobController = TextEditingController();

  late String phoneNumber;
  Country? selectedCountry;
  DateTime? selectedDOB;

  @override
  void initState() {
    _nameController.text = (widget.user.firstName + ' ' + (widget.user.lastName ?? '')).trim();
    _emailController.text = widget.user.email;
    phoneNumber = widget.user.phone;
    selectedCountry = widget.userCountry;

    if (widget.user.dateOfBirth != null) {
      // formatDate() method cannot be called in initState()
      Future.delayed(Duration.zero, () {
        _dobController.text = UiUtils.formatDate(context, widget.user.dateOfBirth!);
        selectedDOB = widget.user.dateOfBirth;
      });
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;
    // Calculate total cost
    final roomCost = widget.property.pricePerNight *
        widget.bookingRequest.nightCount *
        widget.bookingRequest.roomCount;
    final servicesCost = widget.bookingRequest.calculateServicesCost();
    final totalCost = roomCost + servicesCost;

    return Stack(
      children: [
        // Form
        FormContainer(
          child: Padding(
            padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Heading
                  Text(i18n.guest_info_sub_title, style: textTheme.headline6),
                  SizedBox(height: Assets.dimens.formFieldsMargin),

                  // Form fields below
                  TextFormField(
                    decoration: InputDecoration(labelText: i18n.hint_name),
                    keyboardType: TextInputType.name,
                    textInputAction: TextInputAction.next,
                    controller: _nameController,
                    validator: (value) {
                      if (value!.trim().isEmpty)
                        return i18n.error_name_empty;
                      else
                        return null;
                    },
                  ),
                  SizedBox(height: Assets.dimens.formFieldsMargin),

                  TextFormField(
                    decoration: InputDecoration(labelText: i18n.hint_email),
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    controller: _emailController,
                    validator: (value) {
                      if (value!.trim().isEmpty)
                        return i18n.error_email_empty;
                      else if (!Constants.emailRegex.hasMatch(value))
                        return i18n.error_email_invalid;
                      else
                        return null;
                    },
                  ),
                  SizedBox(height: Assets.dimens.formFieldsMargin),

                  InternationalPhoneNumberInput(
                    inputDecoration: InputDecoration(labelText: i18n.hint_phone),
                    textAlign: Utils.isRtlMode(context) ? TextAlign.end : TextAlign.start,
                    keyboardType: TextInputType.phone,
                    keyboardAction: TextInputAction.next,
                    initialValue: widget.initialPhoneNumber,
                    locale: Utils.getCurrentLanguage(context),
                    errorMessage: i18n.error_phone_invalid,
                    searchBoxDecoration: InputDecoration(labelText: i18n.hint_country_code_search),
                    selectorConfig: SelectorConfig(
                      useEmoji: true,
                      setSelectorButtonAsPrefixIcon: true,
                      selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                    ),
                    onInputChanged: (PhoneNumber phone) {
                      phoneNumber = phone.toString();
                    },
                  ),
                  SizedBox(height: Assets.dimens.formFieldsMargin),

                  InkWell(
                    child: IgnorePointer(
                      child: TextFormField(
                        decoration: InputDecoration(labelText: i18n.hint_date_of_birth),
                        textInputAction: TextInputAction.done,
                        controller: _dobController,
                        validator: (value) {
                          if (value!.trim().isEmpty)
                            return i18n.error_dob_empty;
                          else
                            return null;
                        },
                        onTap: () {
                          FocusScope.of(context).unfocus();
                          _selectDOB();
                        },
                      ),
                    ),
                    onTap: _selectDOB,
                  ),
                  SizedBox(height: Assets.dimens.formFieldsMargin * 2),

                  DropDownField<Country>(
                    label: i18n.label_country,
                    initialValue: selectedCountry,
                    items: widget.countries.map((Country country) {
                      return DropdownMenuItem<Country>(value: country, child: Text(country.name));
                    }).toList(),
                    onChanged: (Country? country) {
                      selectedCountry = country as Country;
                    },
                  ),

                  // Padding at bottom to make space for booking bar
                  SizedBox(height: Assets.dimens.bottomBarMargin),
                ],
              ),
            ),
          ),
          handleFullPageScroll: true,
        ),

        // Bottom bar
        BottomActionBar(
          info: IntrinsicHeight(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  UiUtils.formatPrice(context, totalCost),
                  style: textTheme.headline6,
                ),
                SizedBox(height: 4),
                Text(
                  i18n.label_nights_count(widget.bookingRequest.nightCount),
                  style: textTheme.caption?.copyWith(color: LightTheme.textTertiary),
                ),
              ],
            ),
          ),
          action: i18n.txt_next,
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              FocusScope.of(context).unfocus();
              // Move to next step
              continueToNextStep();
            }
          },
        ),
      ],
    );
  }

  void _selectDOB() async {
    final lastDate = DateTime.now().subtract(Duration(days: 18 * 365));

    final selectedDate = await showDatePicker(
      context: context,
      initialDate: selectedDOB ?? lastDate,
      firstDate: DateTime.now().subtract(Duration(days: 100 * 365)),
      lastDate: lastDate,
    );

    if (selectedDate != null) {
      setState(() {
        selectedDOB = selectedDate;
        _dobController.text = UiUtils.formatDate(context, selectedDate);
        debugPrint('_dobController.text = ${_dobController.text}');
      });
    }
  }

  void continueToNextStep() async {
    // Gather guest info
    final guestInfo = Guest(
      name: _nameController.text,
      email: _emailController.text,
      phone: phoneNumber,
      dateOfBirth: selectedDOB!,
      country: selectedCountry?.code,
    );

    // Update the request
    widget.bookingRequest.guestInfo = guestInfo;

    // Navigate to service selection screen
    UiUtils.navigateTo(
      context: context,
      child: BookingInvoiceScreen(property: widget.property, bookingRequest: widget.bookingRequest),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _dobController.dispose();
    super.dispose();
  }
}
