/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/booking_service.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/model/dto/request/make_booking_request.dart';
import 'package:hayyak/model/dto/response/lookup_response.dart';
import 'package:hayyak/model/utils/network_config.dart';
import 'package:hayyak/view/screen/common/external_url_screen.dart';
import 'package:hayyak/view/screen/make_booking/booking_success_screen.dart';
import 'package:hayyak/view/utils/booking_utils.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/app_bar_action.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/bottom_action_bar.dart';
import 'package:hayyak/view/widget/date_selection_view.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/property_info_box.dart';

class BookingInvoiceScreen extends StatelessWidget {
  final Property property;
  final MakeBookingRequest bookingRequest;

  const BookingInvoiceScreen({
    required this.property,
    required this.bookingRequest,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(i18n.booking_invoice_title),
        actions: [
          AppBarAction(
            text: i18n.txt_cancel,
            onPressed: () => BookingUtils.cancelBookingProcess(context, 4),
          ),
          SizedBox(width: Assets.dimens.appBarEndMargin),
        ],
      ),
      body: FutureBuilder(
        future: Cache.get(Constants.lookupData),
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.done && snapshot.data != null)
            return _InvoiceView(
              property: property,
              bookingRequest: bookingRequest,
              lookupData: snapshot.data as LookupResponse,
            );
          else
            return Center(child: HayyakProgressIndicator());
        },
      ),
    );
  }
}

class _InvoiceView extends StatelessWidget {
  final Property property;
  final MakeBookingRequest bookingRequest;
  final LookupResponse lookupData;

  const _InvoiceView({
    required this.property,
    required this.bookingRequest,
    required this.lookupData,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    // Calculate prices
    final roomCost = property.pricePerNight * bookingRequest.roomCount * bookingRequest.nightCount;
    final servicesCost = bookingRequest.calculateServicesCost();
    final totalCost = roomCost + servicesCost;

    return Stack(
      children: [
        // Main Content
        SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Property info box
                PropertyInfoBox(property),
                SizedBox(height: 20),

                // Booking dates
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    DateSelectionCard(
                      label: i18n.check_in,
                      text: DateSelectionCard.formatDate(bookingRequest.checkInDate),
                    ),
                    SizedBox(width: 8),
                    DateSelectionCard(
                      label: i18n.check_out,
                      text: DateSelectionCard.formatDate(bookingRequest.checkOutDate),
                    ),
                  ],
                ),
                SizedBox(height: 16),

                // Check-in time
                ..._createInfoRow(i18n.label_check_in_time, property.building.checkInTime),
                // Check-out time
                ..._createInfoRow(i18n.label_check_out_time, property.building.checkOutTime),
                // Guests allowed
                ..._createInfoRow(i18n.label_guests, property.guestCount.toString()),
                // Number of rooms
                ..._createInfoRow(i18n.label_room_count, bookingRequest.roomCount.toString()),
                SizedBox(height: 16),

                // Room Charges
                Text(i18n.room_charges, style: textTheme.headline6),
                SizedBox(height: 8),
                ..._createPricingRow(
                  context: context,
                  label: i18n.price_per_night,
                  price: property.pricePerNight,
                  count: bookingRequest.nightCount,
                  totalPrice: roomCost,
                  totalLabel: i18n.room_count(bookingRequest.roomCount),
                ),
                SizedBox(height: 16),

                // Value Added Services
                Text(i18n.extra_services, style: textTheme.headline6),
                SizedBox(height: 8),
                ..._getServicesView(context),
                SizedBox(height: 16),

                // Total
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(i18n.total, style: textTheme.subtitle1),
                    Text(UiUtils.formatPrice(context, totalCost), style: textTheme.subtitle1),
                  ],
                ),
                SizedBox(height: 8),
                Text(
                  i18n.bill_info,
                  style: textTheme.caption?.copyWith(color: LightTheme.textTertiary),
                ),
                SizedBox(height: 24),

                // Disclaimer
                Text(
                  i18n.disclaimer_heading,
                  style: textTheme.subtitle2?.copyWith(color: Theme.of(context).primaryColor),
                ),
                SizedBox(height: 8),
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: i18n.disclaimer_text + ' ',
                        style: textTheme.caption?.copyWith(color: LightTheme.textPrimary),
                      ),
                      TextSpan(
                        text: i18n.disclaimer_action,
                        style: textTheme.caption?.copyWith(color: Theme.of(context).primaryColor),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () {
                            UiUtils.navigateTo(
                              context: context,
                              child: ExternalUrlScreen(
                                url: NetworkConfig.TERMS_URL,
                                title: i18n.title_terms,
                              ),
                            );
                          },
                      ),
                    ],
                  ),
                ),
                // Padding at bottom to make space for booking bar
                SizedBox(height: Assets.dimens.bottomBarMargin),
              ],
            ),
          ),
        ),

        // Bottom bar
        BottomActionBar(
          info: IntrinsicHeight(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  UiUtils.formatPrice(context, totalCost),
                  style: textTheme.headline6,
                ),
                SizedBox(height: 4),
                Text(
                  i18n.total_payable,
                  style: textTheme.caption?.copyWith(color: LightTheme.textTertiary),
                ),
              ],
            ),
          ),
          action: i18n.action_confirm_booking,
          onPressed: () {
            // Make booking
            _makeBooking(context);
          },
        ),
      ],
    );
  }

  List<Widget> _createInfoRow(String label, String text) {
    final List<Widget> widgets = [];
    widgets.add(SizedBox(height: 8));
    widgets.add(Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label),
        Text(text),
      ],
    ));
    widgets.add(SizedBox(height: 8));
    widgets.add(Divider());

    return widgets;
  }

  List<Widget> _createPricingRow(
      {required BuildContext context,
      required String label,
      required double price,
      required int count,
      required double totalPrice,
      String? totalLabel}) {
    //
    final List<Widget> widgets = [];
    widgets.add(SizedBox(height: 8));
    final subscriptStyle = Theme.of(context).textTheme.caption?.copyWith(color: Color(0xFFB3B3B3));

    widgets.add(Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Left side
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label),
            SizedBox(height: 4),
            Row(
              // (Using Row instead of Text to avoid text scrambling in Arabic)
              children: [
                Text(UiUtils.formatPrice(context, price), style: subscriptStyle),
                Text(' x ', style: subscriptStyle),
                Text('$count', style: subscriptStyle),
              ],
            ),
          ],
        ),
        // Right side
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(UiUtils.formatPrice(context, totalPrice)),
            if (totalLabel != null) SizedBox(height: 4),
            if (totalLabel != null) Text(totalLabel, style: subscriptStyle),
          ],
        ),
      ],
    ));

    widgets.add(SizedBox(height: 8));
    widgets.add(Divider());

    return widgets;
  }

  List<Widget> _getServicesView(BuildContext context) {
    final List<Widget> widgets = [];

    bookingRequest.services?.forEach((service) {
      final serviceInfo = service.serviceInfo;
      widgets.addAll(
        _createPricingRow(
          context: context,
          label: serviceInfo.name,
          price: serviceInfo.price,
          count: service.selectedDates.length,
          totalPrice: serviceInfo.price * service.selectedDates.length,
        ),
      );
    });

    if (widgets.isEmpty) {
      widgets.add(Text(
        I18n.values(context)!.no_services_selected,
        style: Theme.of(context).textTheme.caption,
      ));
    }

    return widgets;
  }

  void _makeBooking(BuildContext context) async {
    final progress = UiUtils.createProgressDialog(context, I18n.values(context)!.loader_booking,
        cancelable: false);

    // Show progress dialog
    await progress.show();

    // Make booking
    await BookingService(context)
        .makeBooking(bookingRequest)
        .then((response) => {
              // Hide progress dialog
              progress.dismiss(),

              UiUtils.navigateAndClearPrevious(
                context: context,
                child: BookingSuccessScreen(booking: response.booking, property: property),
              )
            })
        .catchError((err) => {
              // Hide progress dialog
              progress.dismiss(),

              // Display error
              UiUtils.displayException(context, err)
            });
  }
}
