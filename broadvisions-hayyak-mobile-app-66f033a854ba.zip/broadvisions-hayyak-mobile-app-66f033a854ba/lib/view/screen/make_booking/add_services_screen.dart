/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 16/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/model/core/value_added_service.dart';
import 'package:hayyak/model/dto/request/make_booking_request.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/view/screen/make_booking/guest_info_screen.dart';
import 'package:hayyak/view/utils/booking_utils.dart';
import 'package:hayyak/view/utils/list_data_helper.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/bottom_action_bar.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';
import 'package:hayyak/view/widget/tertiary_button.dart';

class AddServicesScreen extends StatelessWidget {
  final Property property;
  final MakeBookingRequest bookingRequest;

  AddServicesScreen({
    required this.property,
    required this.bookingRequest,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(i18n.add_services_title),
      ),
      body: FutureBuilder(
        future: _loadData(context),
        builder: (context, AsyncSnapshot<List<ValueAddedService>> snapshot) {
          return ListDataHelper.prepareFutureBuilder(
            context: context,
            snapshot: snapshot,
            loadingText: I18n.values(context)!.services_loader,
            success: snapshot.data == null
                ? Container()
                : _ServicesList(
                    services: snapshot.data as List<ValueAddedService>,
                    property: property,
                    bookingRequest: bookingRequest,
                  ),
          );
        },
      ),
    );
  }

  Future<List<ValueAddedService>> _loadData(BuildContext context) async {
    // Get value-added services data
    try {
      /*final response = await PropertyService(context).getValueAddedServices();
      // Return response
      return response.valueAddedServices;*/

      if (property.services == null) return [];
      // Return a copy of properties' services so selection is not copied to main list's objects
      return property.services!.map((service) => ValueAddedService.clone(service)).toList();
      //
    } on AppException catch (e) {
      // Display error
      UiUtils.displayException(context, e);
      throw e;
    }
  }
}

class _ServicesList extends StatefulWidget {
  final List<ValueAddedService> services;
  final Property property;
  final MakeBookingRequest bookingRequest;
  late final roomPrice;

  _ServicesList({
    required this.services,
    required this.property,
    required this.bookingRequest,
    Key? key,
  }) : super(key: key) {
    // Calculate room price
    this.roomPrice = property.pricePerNight * bookingRequest.nightCount * bookingRequest.roomCount;
  }

  @override
  _ServicesListState createState() => _ServicesListState();
}

class _ServicesListState extends State<_ServicesList> {
  double totalPrice = 0;

  @override
  void initState() {
    _calculateTotalPrice();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    return Stack(
      children: [
        // Services list
        Padding(
          padding: EdgeInsets.only(bottom: Assets.dimens.bottomBarMargin),
          child: ListView.separated(
            padding: EdgeInsetsDirectional.only(start: 12, end: 24, top: 16, bottom: 16),
            itemCount: widget.services.length,
            itemBuilder: (BuildContext context, int index) {
              return _ServiceItem(
                service: widget.services[index],
                bookingRequest: widget.bookingRequest,
                onValueChanged: _calculateTotalPrice,
              );
            },
            separatorBuilder: (BuildContext context, int index) {
              return Divider();
            },
          ),
        ),

        // Bottom bar
        BottomActionBar(
          info: IntrinsicHeight(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  UiUtils.formatPrice(context, totalPrice),
                  style: textTheme.headline6,
                ),
                SizedBox(height: 4),
                Text(
                  i18n.label_nights_count(widget.bookingRequest.nightCount),
                  style: textTheme.caption?.copyWith(color: LightTheme.textTertiary),
                ),
              ],
            ),
          ),
          action: i18n.txt_next,
          onPressed: () => _continueToNextStep(),
        ),
      ],
    );
  }

  void _calculateTotalPrice() {
    totalPrice = widget.services.fold<double>(
        widget.roomPrice,
        (sum, service) =>
            sum +
            (service.isSelected && service.selectionDates != null
                ? service.price * service.selectionDates!.length
                : 0));
    setState(() {});
  }

  void _continueToNextStep() {
    // Put selected services in booking request
    List<ServiceDTO> services = [];
    for (var service in widget.services) {
      if (service.isSelected &&
          service.selectionDates != null &&
          service.selectionDates!.length > 0) {
        services.add(
          ServiceDTO(
              service.id,
              service.selectionDates!
                  .map((date) => Utils.formatDateForNetwork(date))
                  .toList(growable: false),
              service),
        );
      }
    }
    widget.bookingRequest.services = services;

    // Navigate to service selection screen
    UiUtils.navigateTo(
      context: context,
      child: GuestInfoScreen(property: widget.property, bookingRequest: widget.bookingRequest),
    );
  }
}

class _ServiceItem extends StatefulWidget {
  final ValueAddedService service;
  final MakeBookingRequest bookingRequest;
  final VoidCallback onValueChanged;

  const _ServiceItem({
    required this.service,
    required this.bookingRequest,
    required this.onValueChanged,
    Key? key,
  }) : super(key: key);

  @override
  _ServiceItemState createState() => _ServiceItemState(service);
}

class _ServiceItemState extends State<_ServiceItem> {
  final ValueAddedService service;

  _ServiceItemState(this.service);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final theme = Theme.of(context);
    final textTheme = Theme.of(context).textTheme;
    final thumbnailSize = 56.0;

    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            child: Row(
              children: [
                // Checkbox
                Checkbox(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4))),
                  activeColor: theme.primaryColor,
                  value: service.isSelected,
                  onChanged: (value) {
                    setState(() {
                      service.isSelected = value ?? false;
                      _handleChecked();
                    });
                  },
                ),
                SizedBox(width: 8),

                // Thumbnail
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: service.image != null
                      ? UiUtils.getNetworkImage(
                          imageUrl: service.image!.url,
                          fit: BoxFit.cover,
                          width: thumbnailSize,
                          height: thumbnailSize,
                        )
                      : Container(width: thumbnailSize, height: thumbnailSize),
                ),
                SizedBox(width: 16),

                // Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(service.name, style: textTheme.subtitle2),
                      if (service.description != null) SizedBox(height: 8),
                      if (service.description != null)
                        Text(
                          service.name,
                          style: textTheme.caption?.copyWith(color: LightTheme.textTertiary),
                        ),
                    ],
                  ),
                ),
                SizedBox(width: 8),

                // Price
                Text(UiUtils.formatPrice(context, service.price)),
              ],
            ),
            onTap: () {
              setState(() {
                service.isSelected = !service.isSelected;
                _handleChecked();
              });
            },
          ),
          // Date selection
          if (service.isSelected)
            Padding(
              padding: EdgeInsetsDirectional.only(start: 120),
              child: TertiaryButton(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(HayyakIcons.calendar, color: theme.primaryColor, size: 12),
                    SizedBox(width: 8),
                    Text(
                      (service.selectionDates == null || service.selectionDates?.length == 0)
                          ? i18n.action_select_dates
                          : i18n.selected_dates(service.selectionDates!.length),
                      style: textTheme.caption?.copyWith(color: theme.primaryColor),
                    ),
                  ],
                ),
                onPressed: _selectDates,
              ),
            ),
        ],
      ),
    );
  }

  void _handleChecked() {
    if (service.isSelected) {
      // If state is checked, automatically open the date selection
      _selectDates();
    } else {
      // If state if unchecked, clear the selected dates
      service.selectionDates = null;
      widget.onValueChanged();
    }
  }

  void _selectDates() {
    BookingUtils.chooseMultipleDates(
      context: context,
      service: service,
      bookingRequest: widget.bookingRequest,
      onSelection: (dates) => setState(() {
        if (dates != null) {
          service.selectionDates = dates;
          widget.onValueChanged();
        }
      }),
    );
  }
}
