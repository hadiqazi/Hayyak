/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 11/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/service/property_service.dart';
import 'package:hayyak/model/core/booking_to_rate.dart';
import 'package:hayyak/model/core/rating.dart';
import 'package:hayyak/model/dto/request/rate_property_request.dart';
import 'package:hayyak/model/dto/request/update_rating_request.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/avatar.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:hayyak/view/widget/rating_view.dart';

class PostRatingScreen extends StatefulWidget {
  final BookingToRate booking;
  final Rating? rating;

  const PostRatingScreen({required this.booking, this.rating, Key? key}) : super(key: key);

  @override
  _PostRatingScreenState createState() => _PostRatingScreenState();
}

class _PostRatingScreenState extends State<PostRatingScreen> {
  final _reviewController = TextEditingController();
  late double rating;

  @override
  void initState() {
    if (widget.rating != null) {
      rating = widget.rating?.starRating.toDouble() ?? 5;
      _reviewController.text = widget.rating?.review ?? '';
    } else {
      rating = 5;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final isEditMode = widget.rating != null;
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    return Container(
      color: Colors.white70,
      padding: EdgeInsets.only(top: Assets.dimens.overlayTopMargin),
      child: Container(
        clipBehavior: Clip.hardEdge,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
          ),
        ),
        child: Scaffold(
          backgroundColor: Colors.black54,
          appBar: AppBar(
            leading: AppBarBackButton(),
            title: Text(isEditMode ? i18n.edit_review_title : i18n.add_review_title),
          ),
          body: SafeArea(
            bottom: false,
            child: Container(
              color: Theme.of(context).colorScheme.surface,
              width: double.maxFinite,
              height: double.maxFinite,
              child: FormContainer(
                handleFullPageScroll: true,
                child: Padding(
                  padding: Assets.dimens.screenPadding,
                  child: Column(
                    children: [
                      // Property image and name
                      Avatar(url: widget.booking.propertyImage, size: 80),
                      SizedBox(height: 12),
                      Text(widget.booking.propertyName),
                      SizedBox(height: 40),

                      // Heading
                      Text(i18n.review_heading, style: textTheme.headline6),
                      SizedBox(height: 8),

                      // Sub-heading
                      Text(
                        i18n.review_subheading,
                        style: textTheme.bodyText2?.copyWith(color: Color(0xFF909090)),
                      ),
                      SizedBox(height: 24),

                      // Rating
                      RatingView(
                        initialRating: rating,
                        minRating: 1,
                        starSize: 34,
                        onRatingChanged: (value) {
                          rating = value;
                        },
                      ),
                      SizedBox(height: 16),

                      // Review
                      TextFormField(
                        decoration: InputDecoration(labelText: i18n.hint_review),
                        keyboardType: TextInputType.multiline,
                        maxLines: 4,
                        textInputAction: TextInputAction.done,
                        maxLength: 200,
                        controller: _reviewController,
                      ),
                      Spacer(),

                      // Submit button
                      PrimaryButton(
                        child: Text(isEditMode ? i18n.submit_edit_review : i18n.submit_add_review),
                        maxWide: true,
                        onPressed: _postReview,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _postReview() async {
    final progress = UiUtils.createProgressDialog(context, I18n.values(context)!.loader_post_review,
        cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create/update rating
    try {
      final response;

      if (widget.rating == null) {
        // Create request
        final request = RatePropertyRequest(
          rating: rating.toInt(),
          review: _reviewController.text.trim(),
          propertyId: widget.booking.propertyId,
          bookingId: widget.booking.id,
        );

        // Create rating
        response = await PropertyService(context).rateProperty(request);
      } else {
        // Create request
        final request = UpdateRatingRequest(
          ratingId: widget.rating!.id,
          rating: rating.toInt(),
          review: _reviewController.text.trim(),
        );

        // Update rating
        response = await PropertyService(context).updatePropertyRating(request);
      }
      // Hide progress dialog
      progress.dismiss();

      // Navigate back
      UiUtils.navigateBack(context, response.rating);
      //
    } catch (err) {
      // Hide progress dialog
      progress.dismiss();

      // Display error
      UiUtils.displayException(context, err);
    }
  }

  @override
  void dispose() {
    _reviewController.dispose();
    super.dispose();
  }
}
