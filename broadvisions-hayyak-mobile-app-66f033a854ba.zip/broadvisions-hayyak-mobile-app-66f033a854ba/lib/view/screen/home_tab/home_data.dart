/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 09/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';

class HomeData {
  //
  final BuildContext context;
  List<_City> cities = [];

  HomeData(this.context) {
    final i18n = I18n.values(context)!;
    cities.add(_City(
      i18n.city_1,
      Assets.image.city + 'city_1.jpeg',
      0,
      0,
    ));
    cities.add(_City(
      i18n.city_2,
      Assets.image.city + 'city_2.jpeg',
      0,
      0,
    ));
    cities.add(_City(
      i18n.city_3,
      Assets.image.city + 'city_3.jpeg',
      0,
      0,
    ));
    cities.add(_City(
      i18n.city_4,
      Assets.image.city + 'city_4.jpg',
      0,
      0,
    ));
    cities.add(_City(
      i18n.city_5,
      Assets.image.city + 'city_5.jpeg',
      0,
      0,
    ));
    cities.add(_City(
      i18n.city_6,
      Assets.image.city + 'city_6.jpg',
      0,
      0,
    ));
  }

  List<Widget> getCities(ValueChanged clickListener) {
    final List<Widget> widgets = [];
    for (int i = 0; i < cities.length; i++) {
      widgets.add(_getCityWidget(i, clickListener));
      if (i < cities.length - 1) widgets.add(SizedBox(width: 16));
    }
    return widgets;
  }

  Widget _getCityWidget(int index, ValueChanged clickListener) {
    final city = cities[index];

    return GestureDetector(
      child: Column(
        children: [
          Container(
            width: Assets.dimens.roundThumbnailSize,
            height: Assets.dimens.roundThumbnailSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              image: DecorationImage(
                fit: BoxFit.cover,
                image: AssetImage(city.imagePath),
              ),
            ),
          ),
          SizedBox(height: 8),
          Text(city.name, style: Theme.of(context).textTheme.bodyText1),
        ],
      ),
      onTap: () {
        clickListener(index);
      },
    );
  }
}

class _City {
  String name;
  String imagePath;
  double latitude;
  double longitude;

  _City(this.name, this.imagePath, this.latitude, this.longitude);
}
