/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/11/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/view/screen/home_tab/home_data.dart';
import 'package:hayyak/view/screen/search_properties/basic_search_screen.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/avatar.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({Key? key}) : super(key: key);

  @override
  HomeTabState createState() => HomeTabState();
}

class HomeTabState extends State<HomeTab> with AutomaticKeepAliveClientMixin<HomeTab> {
  //
  bool isLookupDataLoaded = false;

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return FutureBuilder(
      future: Cache.get(Constants.loggedInUser),
      builder: (context, snapshot) {
        if (snapshot.data != null)
          return _buildView(snapshot.data as User);
        else
          return Container();
      },
    );
  }

  Widget _buildView(User user) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    return SingleChildScrollView(
      child: Padding(
        padding: Assets.dimens.screenPadding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SvgPicture.asset(Assets.image.homeLogo),
                Avatar(url: user.profilePicUrl, size: 44),
              ],
            ),
            //
            SizedBox(height: 16),
            Stack(
              children: [
                TextFormField(
                  style: TextStyle(color: Colors.grey),
                  keyboardType: TextInputType.none,
                  decoration: InputDecoration(
                    labelText: i18n.home_hint_search,
                    labelStyle: TextStyle(color: Colors.grey),
                  ),
                  readOnly: true,
                ),
                Positioned.fill(
                  child: InkWell(
                    onTap: () {
                      if (isLookupDataLoaded) {
                        FocusScope.of(context).unfocus();
                        UiUtils.navigateTo(context: context, child: BasicSearchScreen());
                      } else {
                        UiUtils.displayInformation(context, i18n.lookup_loading_msg);
                      }
                    },
                  ),
                ),
              ],
            ),
            //
            SizedBox(height: 32),
            Text(i18n.home_cities_heading, style: textTheme.headline6),
            SizedBox(height: 24),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: HomeData(context).getCities((index) {
                  // TODO: Add click event
                  debugPrint('Show properties in city: ${HomeData(context).cities[index].name}');
                }),
              ),
            ),
            //
            Padding(
              padding: EdgeInsets.only(top: 128),
              child: Center(
                child: Text(i18n.temp_popular_msg),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void markDataAsLoaded() {
    setState(() {
      isLookupDataLoaded = true;
    });
  }
}
