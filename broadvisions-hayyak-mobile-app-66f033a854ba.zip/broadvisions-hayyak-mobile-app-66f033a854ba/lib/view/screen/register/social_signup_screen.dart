/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 24/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/authentication_service.dart';
import 'package:hayyak/model/core/social_signup_info.dart';
import 'package:hayyak/model/dto/request/get_otp_request.dart';
import 'package:hayyak/model/dto/request/social_signup_request.dart';
import 'package:hayyak/view/screen/otp_verification/verify_otp_screen.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/avatar.dart';
import 'package:hayyak/view/widget/back_button.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';

class SocialSignupScreen extends StatelessWidget {
  final SocialSignUpInfo socialSignUpInfo;

  const SocialSignupScreen(this.socialSignUpInfo, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            FormContainer(
              child: _SocialSignupForm(socialSignUpInfo),
              handleFullPageScroll: true,
            ),
            CustomBackButton(),
          ],
        ),
      ),
    );
  }
}

class _SocialSignupForm extends StatefulWidget {
  final SocialSignUpInfo socialSignUpInfo;

  const _SocialSignupForm(this.socialSignUpInfo, {Key? key}) : super(key: key);

  @override
  _SocialSignupFormState createState() => _SocialSignupFormState();
}

class _SocialSignupFormState extends State<_SocialSignupForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final initialPhone = PhoneNumber(isoCode: 'SA');
  String phoneNumber = '';
  int passwordStrength = 0;

  @override
  void initState() {
    _nameController.text = widget.socialSignUpInfo.name ?? '';
    _emailController.text = widget.socialSignUpInfo.email ?? '';
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Form(
      key: _formKey,
      child: Container(
        padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 56),
            // Heading
            Text(
              i18n.social_signup_title,
              style: Theme.of(context).textTheme.headline4,
            ),
            SizedBox(height: 16),
            Text(i18n.social_signup_sub_title,
                style: Theme.of(context)
                    .textTheme
                    .bodyText2
                    ?.copyWith(color: LightTheme.textTertiary)),
            SizedBox(height: Assets.dimens.formFieldsMargin * 4),

            // User display pic from social account
            Align(
              alignment: Alignment.center,
              child: Avatar(url: widget.socialSignUpInfo.profilePicUrl, size: 56),
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),

            // Form fields below
            TextFormField(
              decoration: InputDecoration(labelText: i18n.hint_name),
              keyboardType: TextInputType.name,
              textCapitalization: TextCapitalization.words,
              textInputAction: TextInputAction.next,
              controller: _nameController,
              validator: (value) {
                if (value!.trim().isEmpty)
                  return i18n.error_name_empty;
                else
                  return null;
              },
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin),
            //
            TextFormField(
              decoration: InputDecoration(labelText: i18n.hint_email),
              keyboardType: TextInputType.emailAddress,
              textInputAction: TextInputAction.next,
              controller: _emailController,
              enabled: false,
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin),
            //
            InternationalPhoneNumberInput(
              inputDecoration: InputDecoration(labelText: i18n.hint_phone),
              textAlign: Utils.isRtlMode(context) ? TextAlign.end : TextAlign.start,
              keyboardType: TextInputType.phone,
              keyboardAction: TextInputAction.done,
              initialValue: initialPhone,
              locale: Utils.getCurrentLanguage(context),
              errorMessage: i18n.error_phone_invalid,
              searchBoxDecoration: InputDecoration(labelText: i18n.hint_country_code_search),
              selectorConfig: SelectorConfig(
                useEmoji: true,
                setSelectorButtonAsPrefixIcon: true,
                selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
              ),
              onInputChanged: (PhoneNumber phone) {
                phoneNumber = phone.toString();
              },
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin * 5),
            //
            PrimaryButton(
              child: Text(i18n.social_signup_submit),
              maxWide: true,
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  FocusScope.of(context).unfocus();
                  // Verify user contact details
                  _sendVerificationCodes();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  void _sendVerificationCodes() async {
    final progress = UiUtils.createProgressDialog(context, I18n.values(context)!.register_loader,
        cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create request
    final request = GetOTPRequest(
      _emailController.text.trim(),
      phoneNumber,
    );

    // Send OTPs to user
    await AuthenticationService(context) //
        .requestOTP(request) //
        .then((response) {
      // Hide progress dialog
      progress.dismiss();

      final signupRequest = SocialSignupRequest(
        widget.socialSignUpInfo.type,
        widget.socialSignUpInfo.token,
        _nameController.text.trim(),
        phoneNumber,
        _emailController.text,
        '',
        '',
        Utils.getCurrentLanguage(context),
      );

      // Take user to OTP input screen
      UiUtils.navigateTo(
          context: context, child: VerifyOtpScreen(socialSignupRequest: signupRequest));
      //
    }).catchError((err) {
      // Hide progress dialog
      progress.dismiss();

      // Display error
      UiUtils.displayException(context, err);
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    super.dispose();
  }
}
