/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 09/11/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/authentication_service.dart';
import 'package:hayyak/model/dto/request/get_otp_request.dart';
import 'package:hayyak/model/dto/request/register_request.dart';
import 'package:hayyak/view/screen/otp_verification/verify_otp_screen.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/back_button.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/password_form_field.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            FormContainer(
              child: _RegisterForm(),
              handleFullPageScroll: true,
            ),
            CustomBackButton(),
          ],
        ),
      ),
    );
  }
}

class _RegisterForm extends StatefulWidget {
  const _RegisterForm({Key? key}) : super(key: key);

  @override
  _RegisterFormState createState() => _RegisterFormState();
}

class _RegisterFormState extends State<_RegisterForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final initialPhone = PhoneNumber(isoCode: 'SA');
  String phoneNumber = '';
  int passwordStrength = 0;

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;

    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Heading
          SizedBox(height: 24),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Padding(
                  padding: EdgeInsetsDirectional.only(
                    start: Assets.dimens.screenFormPadding,
                    end: 16,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        i18n.register_title,
                        style: Theme.of(context).textTheme.headline4,
                      ),
                      SizedBox(height: 16),
                      Text(
                        i18n.register_sub_title + '\n',
                        style: Theme.of(context)
                            .textTheme
                            .bodyText2
                            ?.copyWith(color: LightTheme.textTertiary),
                      ),
                    ],
                  ),
                ),
              ),
              SvgPicture.asset(Assets.image.authDecoration(context)),
            ],
          ),
          // Form fields below
          Padding(
            padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
            child: Column(
              children: [
                //
                TextFormField(
                  decoration: InputDecoration(labelText: i18n.hint_name),
                  keyboardType: TextInputType.name,
                  textCapitalization: TextCapitalization.words,
                  textInputAction: TextInputAction.next,
                  controller: _nameController,
                  validator: (value) {
                    if (value!.trim().isEmpty)
                      return i18n.error_name_empty;
                    else
                      return null;
                  },
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin),
                //
                TextFormField(
                  decoration: InputDecoration(labelText: i18n.hint_email),
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  controller: _emailController,
                  validator: (value) {
                    if (value!.trim().isEmpty)
                      return i18n.error_email_empty;
                    else if (!Constants.emailRegex.hasMatch(value))
                      return i18n.error_email_invalid;
                    else
                      return null;
                  },
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin),
                //
                InternationalPhoneNumberInput(
                  inputDecoration: InputDecoration(labelText: i18n.hint_phone),
                  textAlign: Utils.isRtlMode(context) ? TextAlign.end : TextAlign.start,
                  keyboardType: TextInputType.phone,
                  keyboardAction: TextInputAction.next,
                  initialValue: initialPhone,
                  locale: Utils.getCurrentLanguage(context),
                  errorMessage: i18n.error_phone_invalid,
                  searchBoxDecoration: InputDecoration(labelText: i18n.hint_country_code_search),
                  selectorConfig: SelectorConfig(
                    useEmoji: true,
                    setSelectorButtonAsPrefixIcon: true,
                    selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                  ),
                  onInputChanged: (PhoneNumber phone) {
                    phoneNumber = phone.toString();
                  },
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin),
                //
                PasswordFormField(
                  decoration: InputDecoration(labelText: i18n.hint_password),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.next,
                  controller: _passwordController,
                  showStrength: true,
                  onStrengthChanged: (value) {
                    passwordStrength = value;
                  },
                  validator: (value) {
                    if (value!.isEmpty)
                      return i18n.error_password_empty;
                    else if (!Utils.isPasswordStrong(passwordStrength))
                      return i18n.error_password_invalid;
                    else
                      return null;
                  },
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin),
                //
                PasswordFormField(
                  decoration: InputDecoration(labelText: i18n.register_hint_confirm_password),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.done,
                  controller: _confirmPasswordController,
                  validator: (value) {
                    if (value! != _passwordController.text)
                      return i18n.register_error_password_mismatch;
                    else
                      return null;
                  },
                ),
                SizedBox(height: Assets.dimens.formFieldsMargin * 5),
                //
                PrimaryButton(
                  child: Text(i18n.register_submit),
                  maxWide: true,
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      FocusScope.of(context).unfocus();
                      // Verify user contact details
                      _sendVerificationCodes();
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _sendVerificationCodes() async {
    final progress = UiUtils.createProgressDialog(context, I18n.values(context)!.register_loader,
        cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create request
    final request = GetOTPRequest(
      _emailController.text.trim(),
      phoneNumber,
    );

    // Send OTPs to user
    await AuthenticationService(context) //
        .requestOTP(request) //
        .then((response) {
      // Hide progress dialog
      progress.dismiss();

      final registerRequest = RegisterRequest(
        _nameController.text.trim(),
        _emailController.text.trim(),
        phoneNumber,
        _passwordController.text,
        '',
        '',
        Utils.getCurrentLanguage(context),
      );

      // Take user to OTP input screen
      UiUtils.navigateTo(
          context: context, child: VerifyOtpScreen(registerRequest: registerRequest));
      //
    }).catchError((err) {
      // Hide progress dialog
      progress.dismiss();

      // Display error
      UiUtils.displayException(context, err);
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }
}
