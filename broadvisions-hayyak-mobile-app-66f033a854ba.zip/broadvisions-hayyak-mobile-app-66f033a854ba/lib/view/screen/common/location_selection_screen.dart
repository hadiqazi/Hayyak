/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 16/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hayyak/app/location_helper.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class LocationSelectionScreen extends StatefulWidget {
  final LatLng? initialSelection;

  const LocationSelectionScreen({this.initialSelection, Key? key}) : super(key: key);

  @override
  _LocationSelectionScreenState createState() => _LocationSelectionScreenState();
}

class _LocationSelectionScreenState extends State<LocationSelectionScreen> {
  LatLng? location;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(I18n.values(context)!.location_title),
      ),
      body: Stack(
        children: [
          FutureBuilder(
            future: Future.delayed(Duration(milliseconds: 250)),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.done)
                return _MapView(
                  initialSelection: widget.initialSelection,
                  onLocationSelected: (latLng) => location = latLng,
                );
              else
                return Container();
            },
          ),
          SafeArea(
            child: Align(
              alignment: AlignmentDirectional.bottomCenter,
              child: Padding(
                padding: EdgeInsets.only(bottom: 16),
                child: PrimaryButton(
                  child: Text(I18n.values(context)!.location_submit),
                  onPressed: () {
                    UiUtils.navigateBack(context, location);
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MapView extends StatefulWidget {
  final LatLng? initialSelection;
  final ValueChanged<LatLng>? onLocationSelected;
  late final _mapStyle;

  _MapView({this.onLocationSelected, this.initialSelection, Key? key}) : super(key: key) {
    rootBundle.loadString('assets/map_style.json').then((string) {
      debugPrint(string);
      _mapStyle = string;
    });
  }

  @override
  _MapViewState createState() => _MapViewState();
}

class _MapViewState extends State<_MapView> {
  Completer<GoogleMapController> controller = Completer();

  late LatLng initialPosition;
  late final CameraPosition initialCameraPosition;
  LatLng? selectedPosition;
  final Set<Marker> _markers = Set();

  @override
  void initState() {
    // Set initial position to previous selection or to a hardcoded position
    final double zoom;
    bool fetchCurrentLocation = false;
    if (widget.initialSelection != null) {
      initialPosition = widget.initialSelection!;
      zoom = 15;
    } else {
      initialPosition = LatLng(24.7009711, 46.6503447); //King Khalid Mosque
      zoom = 12;
      fetchCurrentLocation = true;
    }

    // Move camera (map center) to initial position
    initialCameraPosition = CameraPosition(
      target: initialPosition,
      zoom: zoom,
    );
    // Add marker to initial position
    _addMarker(initialPosition);

    if (fetchCurrentLocation) {
      // Determine user's position only if there's no previous selection
      _determinePosition(context).then((value) {
        if (value != null) {
          _moveToPosition(value);
          _addMarker(LatLng(value.latitude, value.longitude));
        }
      });
    }

    super.initState();
  }

  Future<Position?> _determinePosition(BuildContext context) async {
    bool isReady = await LocationHelper.determineReadyStatus(context);

    if (isReady) {
      return await Geolocator.getCurrentPosition();
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GoogleMap(
          initialCameraPosition: initialCameraPosition,
          myLocationEnabled: true,
          onMapCreated: (GoogleMapController controller) {
            controller.setMapStyle(widget._mapStyle);
            this.controller.complete(controller);
          },
          markers: _markers,
          onCameraMoveStarted: _onCameraMoveStarted,
          onCameraMove: (position) => _onCameraMove(position),
          onCameraIdle: _onCameraIdle,
        ),
      ],
    );
  }

  void _onCameraMoveStarted() {
    setState(() {
      _markers.clear();
    });
  }

  void _onCameraMove(CameraPosition position) async {
    selectedPosition = position.target;
  }

  void _onCameraIdle() async {
    if (selectedPosition == null) return;

    // Add marker
    _addMarker(selectedPosition!);
    // Post value in callback
    if (widget.onLocationSelected != null) {
      widget.onLocationSelected!(selectedPosition!);
    }
  }

  void _addMarker(LatLng location) {
    if (!mounted) return;

    setState(() {
      _markers.add(Marker(
          markerId: MarkerId(location.toString()),
          position: location,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure)));
    });
  }

  Future<void> _moveToPosition(Position position) async {
    final GoogleMapController _controller = await controller.future;
    final CameraPosition cameraPosition = CameraPosition(
        bearing: 0, target: LatLng(position.latitude, position.longitude), tilt: 60, zoom: 18);

    _controller.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
  }
}
