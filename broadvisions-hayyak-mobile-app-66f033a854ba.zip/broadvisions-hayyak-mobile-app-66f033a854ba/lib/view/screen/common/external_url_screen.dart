/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/12/2021
            Project: hayyak-mobile-app
 */

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:webview_flutter/webview_flutter.dart';

class ExternalUrlScreen extends StatelessWidget {
  final String url;
  final String? title;

  ExternalUrlScreen({required this.url, this.title, Key? key}) : super(key: key) {
    if (Platform.isAndroid) WebView.platform = AndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(title ?? ''),
      ),
      body: FutureBuilder(
        future: Future.delayed(Duration(milliseconds: 1000)),
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.done)
            return WebView(initialUrl: url);
          else
            return Center(child: HayyakProgressIndicator());
        },
      ),
    );
  }
}
