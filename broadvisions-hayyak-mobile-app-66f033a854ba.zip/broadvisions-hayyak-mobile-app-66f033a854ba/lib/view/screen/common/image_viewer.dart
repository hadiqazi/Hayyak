/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 13/12/2021
            Project: hayyak-mobile-app
 */

import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:hayyak/model/core/image_data.dart';
import 'package:hayyak/view/widget/back_button.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';

class ImageViewer extends StatelessWidget {
  final List<ImageData> images;
  final int initialIndex;
  final PageController pageController;

  ImageViewer({
    required this.images,
    this.initialIndex = 0,
    Key? key,
  })  : pageController = PageController(initialPage: initialIndex),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black54,
      body: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Stack(
          alignment: Alignment.bottomRight,
          children: <Widget>[
            // Photo Viewer
            PhotoViewGallery.builder(
              scrollPhysics: const BouncingScrollPhysics(),
              builder: _buildItem,
              itemCount: images.length,
              loadingBuilder: (context, _) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              },
              backgroundDecoration: BoxDecoration(color: Colors.transparent),
              pageController: pageController,
            ),

            // Back Button
            Align(
              alignment: AlignmentDirectional.topStart,
              child: Padding(
                padding: EdgeInsetsDirectional.only(start: 8, top: 32),
                child: Container(
                  padding: EdgeInsetsDirectional.only(end: 12, bottom: 2),
                  decoration: BoxDecoration(
                    color: Color(0x33000000),
                    shape: BoxShape.circle,
                  ),
                  child: CustomBackButton(padding: 2, iconSize: 16, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  PhotoViewGalleryPageOptions _buildItem(BuildContext context, int index) {
    return PhotoViewGalleryPageOptions(
      imageProvider: NetworkImage(images[index].url),
      initialScale: PhotoViewComputedScale.contained,
      minScale: PhotoViewComputedScale.contained * (0.5 + index / 10),
      maxScale: PhotoViewComputedScale.covered,
      heroAttributes: PhotoViewHeroAttributes(tag: images[index].id),
    );
  }
}
