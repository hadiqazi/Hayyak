/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 11/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/service/authentication_service.dart';
import 'package:hayyak/model/dto/request/get_otp_request.dart';
import 'package:hayyak/model/dto/request/register_request.dart';
import 'package:hayyak/model/dto/request/social_signup_request.dart';
import 'package:hayyak/view/screen/main/main_screen.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/back_button.dart';
import 'package:hayyak/view/widget/form_container.dart';
import 'package:hayyak/view/widget/otp_input_field.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:hayyak/view/widget/tertiary_button.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class VerifyOtpScreen extends StatelessWidget {
  final RegisterRequest? registerRequest;
  final SocialSignupRequest? socialSignupRequest;

  VerifyOtpScreen({
    this.registerRequest,
    this.socialSignupRequest,
    Key? key,
  }) : super(key: key) {
    assert(registerRequest != null || socialSignupRequest != null,
        'Both request objects cannot be null');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            FormContainer(
              child: _VerifyOtpForm(
                registerRequest: registerRequest,
                socialSignupRequest: socialSignupRequest,
              ),
              handleFullPageScroll: true,
            ),
            CustomBackButton(),
          ],
        ),
      ),
    );
  }
}

class _VerifyOtpForm extends StatefulWidget {
  final RegisterRequest? registerRequest;
  final SocialSignupRequest? socialSignupRequest;

  const _VerifyOtpForm({
    this.registerRequest,
    this.socialSignupRequest,
    Key? key,
  }) : super(key: key);

  @override
  _VerifyOtpFormState createState() => _VerifyOtpFormState();
}

class _VerifyOtpFormState extends State<_VerifyOtpForm> {
  final _formKey = GlobalKey<FormState>();
  final _emailOtpController = TextEditingController();
  final _phoneOtpController = TextEditingController();
  late String email;
  late String phone;
  bool hasErrors = false;
  Timer? _countdownTimer;
  int _remainingTime = 0;

  // ignore: close_sinks
  late StreamController<ErrorAnimationType> _emailErrorController;

  // ignore: close_sinks
  late StreamController<ErrorAnimationType> _phoneErrorController;

  @override
  void initState() {
    if (widget.socialSignupRequest != null) {
      email = widget.socialSignupRequest!.email;
      phone = widget.socialSignupRequest!.phone;
    } else {
      email = widget.registerRequest!.email;
      phone = widget.registerRequest!.phone;
    }
    _emailErrorController = StreamController<ErrorAnimationType>();
    _phoneErrorController = StreamController<ErrorAnimationType>();
    super.initState();

    _startTimer();
  }

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final theme = Theme.of(context);
    final textTheme = Theme.of(context).textTheme;

    return Form(
      key: _formKey,
      child: Container(
        padding: EdgeInsets.all(Assets.dimens.screenFormPadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 56),
            // Heading
            Text(i18n.otp_title, style: textTheme.headline4),
            SizedBox(height: 32),

            // === Form fields below === //

            // Section Heading
            Text(i18n.otp_email_title, style: textTheme.headline5),
            SizedBox(height: Assets.dimens.formFieldsMargin),
            Text(i18n.otp_email_sub_title, style: textTheme.bodyText2),
            Text(email, style: textTheme.bodyText2?.copyWith(color: theme.primaryColor)),
            SizedBox(height: Assets.dimens.formFieldsMargin),
            Align(
              alignment: Alignment.center,
              child: Container(
                width: 300,
                child: OTPInputField(
                  textController: _emailOtpController,
                  errorController: _emailErrorController,
                  keyboardType: TextInputType.number,
                ),
              ),
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin * 4),

            // Section Heading
            Text(i18n.otp_phone_title, style: textTheme.headline5),
            SizedBox(height: Assets.dimens.formFieldsMargin),
            Text(i18n.otp_phone_sub_title, style: textTheme.bodyText2),
            Text(phone, style: textTheme.bodyText2?.copyWith(color: theme.primaryColor)),
            SizedBox(height: Assets.dimens.formFieldsMargin),
            Align(
              alignment: Alignment.center,
              child: Container(
                width: 300,
                child: OTPInputField(
                  textController: _phoneOtpController,
                  errorController: _phoneErrorController,
                  keyboardType: TextInputType.number,
                ),
              ),
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),

            if (hasErrors) SizedBox(height: Assets.dimens.formFieldsMargin * 2),
            if (hasErrors)
              Container(
                width: double.maxFinite,
                child: Text(i18n.otp_error_invalid,
                    style: TextStyle(color: Theme.of(context).errorColor)),
              ),

            SizedBox(height: Assets.dimens.formFieldsMargin * 4),

            PrimaryButton(
              child: Text(i18n.otp_submit),
              maxWide: true,
              onPressed: () {
                hasErrors = false;
                if (_emailOtpController.text.length < 4) {
                  _emailErrorController.add(ErrorAnimationType.shake);
                  hasErrors = true;
                }
                if (_phoneOtpController.text.length < 4) {
                  _phoneErrorController.add(ErrorAnimationType.shake);
                  hasErrors = true;
                }

                if (!hasErrors) {
                  FocusScope.of(context).unfocus();
                  // Verify OTPs and register user
                  _verifyOtpAndRegisterUser();
                } else
                  setState(() {});
              },
            ),
            SizedBox(height: Assets.dimens.formFieldsMargin * 2),

            // Resend code
            SizedBox(
              height: 50,
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Label
                    Text(i18n.otp_resend_label),

                    // Show counter
                    if (_remainingTime > 0) SizedBox(width: 8),
                    if (_remainingTime > 0)
                      SizedBox(
                        width: 50,
                        child: Text('00:${_remainingTime.toString().padLeft(2, '0')}',
                            style: textTheme.bodyText2?.copyWith(color: theme.primaryColor)),
                      ),

                    // Show resend button when counter is over
                    if (_remainingTime == 0)
                      TertiaryButton(
                        child: Text(i18n.otp_action_resend_pwd),
                        onPressed: _sendVerificationCodes,
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _verifyOtpAndRegisterUser() async {
    final progress =
        UiUtils.createProgressDialog(context, I18n.values(context)!.otp_loader, cancelable: false);

    // Show progress dialog
    await progress.show();

    // Send call on server with entered OTPs
    try {
      if (widget.socialSignupRequest != null) {
        // Update social signup request
        widget.socialSignupRequest!.emailOTP = _emailOtpController.text;
        widget.socialSignupRequest!.phoneOTP = _phoneOtpController.text;
        // Register social user
        await AuthenticationService(context).socialSignup(widget.socialSignupRequest!);
        //
      } else {
        // Update register request
        widget.registerRequest!.emailOTP = _emailOtpController.text;
        widget.registerRequest!.phoneOTP = _phoneOtpController.text;
        // Register user
        await AuthenticationService(context).registerUser(widget.registerRequest!);
      }

      // Hide progress dialog
      progress.dismiss();
      // Navigate to home screen
      UiUtils.navigateAndClearPrevious(context: context, child: MainScreen());
      //
    } catch (err) {
      // Hide progress dialog
      progress.dismiss();

      // Display error
      UiUtils.displayException(context, err);
    }
  }

  void _startTimer() {
    _remainingTime = 59;
    setState(() {});

    _countdownTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      _remainingTime--;
      if (_remainingTime >= 0 && timer.isActive) {
        setState(() {});
      } else {
        timer.cancel();
      }
    });
  }

  void _sendVerificationCodes() async {
    final progress = UiUtils.createProgressDialog(context, I18n.values(context)!.resend_otp_loader,
        cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create request
    final request = GetOTPRequest(email, phone);

    // Send OTPs to user
    await AuthenticationService(context) //
        .requestOTP(request) //
        .then((response) {
      // Hide progress dialog
      progress.dismiss();

      // Start the timer again
      _startTimer();
      //
    }).catchError((err) {
      // Hide progress dialog
      progress.dismiss();

      // Display error
      UiUtils.displayException(context, err);
    });
  }

  @override
  void dispose() {
    // _emailOtpController.dispose();
    // _phoneOtpController.dispose();
    _countdownTimer?.cancel();
    super.dispose();
  }
}
