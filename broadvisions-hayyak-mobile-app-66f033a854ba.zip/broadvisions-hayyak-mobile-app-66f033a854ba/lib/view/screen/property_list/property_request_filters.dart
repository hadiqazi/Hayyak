/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 10/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/dto/request/search_properties_request.dart';
import 'package:hayyak/model/dto/response/lookup_response.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';
import 'package:intl/intl.dart';

class PropertyRequestFilters extends StatelessWidget {
  final SearchPropertiesRequest request;

  const PropertyRequestFilters(this.request, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: Cache.get(Constants.lookupData),
      builder: (context, AsyncSnapshot<dynamic> snapshot) {
        if (snapshot.connectionState == ConnectionState.done &&
            snapshot.hasData &&
            snapshot.data is LookupResponse) {
          //
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: _getFilters(context, snapshot.data as LookupResponse),
            ),
          );
        } else {
          return Container();
        }
      },
    );
  }

  List<Widget> _getFilters(BuildContext context, LookupResponse lookupData) {
    final List<Widget> widgets = [];

    // Dates
    DateFormat format = DateFormat("dd MMM", Utils.getCurrentLanguage(context));
    String dates = format.format(request.checkInDate) + ' - ' + format.format(request.checkOutDate);
    widgets.add(_buildFilterView(context, HayyakIcons.filter_date, dates));

    // Bed type
    if (request.bedTypeId != null) {
      final bedType = lookupData.bedTypes.firstWhere((bedType) => bedType.id == request.bedTypeId);
      widgets.add(_space());
      widgets.add(_buildFilterView(context, HayyakIcons.filter_bed, bedType.name));
    }

    // Room type
    if (request.roomTypeId != null) {
      final roomType =
          lookupData.roomTypes.firstWhere((roomType) => roomType.id == request.roomTypeId);
      widgets.add(_space());
      widgets.add(_buildFilterView(context, HayyakIcons.filter_bed, roomType.name));
    }

    return widgets;
  }

  Widget _buildFilterView(BuildContext context, IconData icon, String text) {
    final theme = Theme.of(context);

    return Container(
      padding: EdgeInsets.symmetric(vertical: 12, horizontal: 12),
      decoration: BoxDecoration(
        border: Border.all(
          color: Color(0xFFE2E2E2),
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: theme.primaryColor, size: 15),
          SizedBox(width: 8),
          Text(
            text,
            style: theme.textTheme.bodyText2?.copyWith(
              fontSize: 11,
              color: LightTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _space() {
    return SizedBox(width: 6);
  }
}
