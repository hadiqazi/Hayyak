/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 17/11/2021
            Project: hayyak-mobile-app
 */

import 'package:async/async.dart';
import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/screen_state.dart';
import 'package:hayyak/controller/service/property_service.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/model/dto/request/search_properties_request.dart';
import 'package:hayyak/model/dto/response/search_properties_response.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/view/screen/property_list/property_list_item.dart';
import 'package:hayyak/view/screen/property_list/property_request_filters.dart';
import 'package:hayyak/view/screen/search_properties/advanced_search_screen.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/list_data_helper.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class PropertyListingScreen extends StatefulWidget {
  final SearchPropertiesRequest request;

  const PropertyListingScreen(this.request, {Key? key}) : super(key: key);

  @override
  _PropertyListingScreenState createState() => _PropertyListingScreenState();
}

class _PropertyListingScreenState extends State<PropertyListingScreen> {
  late SearchPropertiesRequest request;

  @override
  void initState() {
    request = widget.request;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBarBackButton(),
        title: Text(I18n.values(context)!.properties_title),
      ),
      body: Container(
        padding: Assets.dimens.screenPadding,
        child: FutureBuilder(
          future: _fetchPropertiesData(context, request, 1),
          builder: (context, AsyncSnapshot<SearchPropertiesResponse> snapshot) {
            return ListDataHelper.prepareFutureBuilder(
              context: context,
              loadingText: I18n.values(context)?.properties_loader,
              snapshot: snapshot,
              success: snapshot.data == null
                  ? Container()
                  : _ItemsList(
                      apiRequest: request,
                      apiResponse: snapshot.data!,
                      onRequestChanged: (value) => onRequestChanged(value)),
            );
          },
        ),
      ),
    );
  }

  void onRequestChanged(SearchPropertiesRequest newRequest) {
    setState(() {
      this.request = newRequest;
    });
  }
}

Future<SearchPropertiesResponse> _fetchPropertiesData(
    BuildContext context, SearchPropertiesRequest request, int page) async {
  // Fetch properties data from server
  try {
    final response = await PropertyService(context).searchProperties(request, page);
    // Update request in cache
    Cache.put(Constants.propertySearchRequest, request);
    // Return response
    return response;
  } on AppException catch (e) {
    // Display error
    UiUtils.displayException(context, e);
    throw e;
  }
}

class _ItemsList extends StatefulWidget {
  final SearchPropertiesRequest apiRequest;
  final SearchPropertiesResponse apiResponse;
  final ValueChanged<SearchPropertiesRequest> onRequestChanged;

  _ItemsList({required this.apiRequest, required this.apiResponse, required this.onRequestChanged});

  @override
  _ItemsListState createState() => _ItemsListState();
}

class _ItemsListState extends State<_ItemsList> {
  late List<Property> properties;
  late int currentPage, maxPages;
  ScreenState screenState = ScreenState.DEFAULT;
  final ScrollController scrollController = ScrollController();
  CancelableOperation? loadOperation;
  late final i18n = I18n.values(context)!;

  @override
  void initState() {
    properties = widget.apiResponse.properties ?? [];
    // Set pagination
    var pagination = widget.apiResponse.pagination;
    maxPages = (pagination.totalItems / pagination.pageSize).ceil();
    currentPage = 1;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return _displayData();
  }

  Widget _displayData() {
    if (properties.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ..._createHeaderView(),
          // Empty data view
          Expanded(
            child: ListDataHelper.displayEmptyDataMsg(context, i18n.properties_empty_msg),
          ),
        ],
      );
    }

    return NotificationListener(
      onNotification: onNotification,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ..._createHeaderView(),
          // Properties List
          Expanded(
            child: GridView.builder(
              itemCount: properties.length,
              controller: scrollController,
              physics: AlwaysScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.53,
                crossAxisSpacing: 16,
              ),
              itemBuilder: (context, index) {
                return PropertyListItem(properties[index]);
              },
            ),
          ),
          if (screenState == ScreenState.LOADING)
            Padding(
              padding: EdgeInsets.all(16),
              child: Center(
                child: HayyakProgressIndicator(),
              ),
            ),
        ],
      ),
    );
  }

  List<Widget> _createHeaderView() {
    final List<Widget> widgets = [];

    widgets.add(
      // Header
      Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  i18n.properties_search_title,
                  style: Theme.of(context).textTheme.headline6,
                ),
                SizedBox(height: Utils.isRtlMode(context) ? 8 : 0),
                Text(
                  i18n.properties_sub_title(properties.length),
                  style: TextStyle(color: Color(0xFF9E9E9E)),
                ),
              ],
            ),
          ),
          PrimaryButton(
            child: Icon(HayyakIcons.filter),
            width: Assets.dimens.smallButtonWidth,
            onPressed: () async {
              final updatedRequest = await UiUtils.navigateTo(
                  context: context, child: AdvancedSearchScreen(widget.apiRequest));
              if (updatedRequest != null) {
                widget.onRequestChanged(updatedRequest as SearchPropertiesRequest);
              }
            },
          ),
        ],
      ),
    );

    widgets.add(SizedBox(height: 16));
    widgets.add(
      // Filter tags
      PropertyRequestFilters(widget.apiRequest),
    );
    widgets.add(SizedBox(height: 16));

    return widgets;
  }

  // Returns whether there's more data to load or not
  bool hasMoreData() {
    return (currentPage + 1) <= maxPages;
  }

  // Get next page of data
  Future<List<Property>> _loadMoreData() async {
    final nextPage = ++currentPage;
    // Return if max page size is reached
    if (nextPage > maxPages) return [];

    try {
      SearchPropertiesResponse response =
          await _fetchPropertiesData(context, widget.apiRequest, nextPage);

      currentPage = nextPage;
      return response.properties ?? [];
    } catch (e) {
      // Display error
      UiUtils.displayException(context, e);
      return [];
    }
  }

  bool onNotification(ScrollNotification notification) {
    if (!(notification is ScrollUpdateNotification)) return false;

    if (scrollController.position.maxScrollExtent > scrollController.offset &&
        scrollController.position.maxScrollExtent - scrollController.offset <= 50) {
      if (screenState != ScreenState.LOADING && hasMoreData()) {
        setState(() {
          screenState = ScreenState.LOADING;
        });

        loadOperation = CancelableOperation.fromFuture(_loadMoreData().then((value) => {
              screenState = ScreenState.SUCCESS,
              setState(() => {
                    properties.addAll(value),
                  }),
            }));
        return true;
      }
    }
    return false;
  }

  @override
  void dispose() {
    scrollController.dispose();
    if (loadOperation != null && !loadOperation!.isCompleted) {
      loadOperation!.cancel();
    }
    super.dispose();
  }
}
