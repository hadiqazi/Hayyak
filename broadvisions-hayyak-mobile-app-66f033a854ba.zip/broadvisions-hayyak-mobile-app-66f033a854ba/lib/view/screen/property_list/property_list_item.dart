/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/property.dart';
import 'package:hayyak/view/screen/property_detail/property_detail_screen.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';

class PropertyListItem extends StatelessWidget {
  final Property property;

  const PropertyListItem(this.property, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return InkWell(
      child: GridTile(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 0.82,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: UiUtils.getNetworkImage(
                  imageUrl: property.coverImage.url,
                  fit: BoxFit.cover,
                  width: double.maxFinite,
                ),
              ),
            ),
            SizedBox(height: 12),
            // Rating
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Icon(HayyakIcons.rating, color: LightTheme.ratingColor, size: 13),
                SizedBox(width: 4),
                Text(
                  UiUtils.formatRating(property.rating),
                  style: textTheme.caption?.copyWith(color: Color(0xFF6C6C6C)),
                ),
              ],
            ),
            SizedBox(height: 4),
            // Name
            Text(
              property.name,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: textTheme.bodyText2?.copyWith(color: LightTheme.textSecondary),
            ),
            SizedBox(height: 8),
            // Price
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  UiUtils.formatPrice(context, property.pricePerNight),
                  style: textTheme.bodyText2?.copyWith(color: Theme.of(context).primaryColor),
                ),
                SizedBox(width: 2),
                Text(I18n.values(context)!.per_night, style: textTheme.caption),
              ],
            ),
          ],
        ),
      ),
      onTap: () {
        UiUtils.navigateTo(context: context, child: PropertyDetailScreen(property));
      },
    );
  }
}
