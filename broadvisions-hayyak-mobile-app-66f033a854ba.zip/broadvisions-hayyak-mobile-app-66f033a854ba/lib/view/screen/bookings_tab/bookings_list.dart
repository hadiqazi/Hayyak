/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 28/12/2021
            Project: hayyak-mobile-app
 */

import 'package:async/async.dart';
import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/screen_state.dart';
import 'package:hayyak/controller/service/booking_service.dart';
import 'package:hayyak/model/core/booking.dart';
import 'package:hayyak/model/core/booking_status.dart';
import 'package:hayyak/model/core/pagination.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/model/dto/request/get_bookings_request.dart';
import 'package:hayyak/model/dto/response/get_bookings_response.dart';
import 'package:hayyak/view/screen/bookings_tab/booking_item.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/list_data_helper.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';

class BookingsList extends StatefulWidget {
  final BookingStatus status;

  const BookingsList(this.status, {Key? key}) : super(key: key);

  @override
  _BookingsListState createState() => _BookingsListState();
}

class _BookingsListState extends State<BookingsList>
    with AutomaticKeepAliveClientMixin<BookingsList> {
  //
  final listKey = new GlobalKey<_ItemsListState>();
  User? user;
  var hasData = false;

  @override
  bool get wantKeepAlive => hasData;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return RefreshIndicator(
      child: FutureBuilder(
        future: _loadInitialData(context),
        builder: (context, AsyncSnapshot<GetBookingsResponse> snapshot) {
          return ListDataHelper.prepareFutureBuilder(
            context: context,
            snapshot: snapshot,
            loadingText: I18n.values(context)!.bookings_loader,
            success: snapshot.data == null
                ? Container()
                : _ItemsList(
                    response: snapshot.data!,
                    status: widget.status,
                    key: listKey,
                  ),
          );
        },
      ),
      onRefresh: () => _loadInitialData(context, updateUi: true),
    );
  }

  Future<GetBookingsResponse> _loadInitialData(BuildContext context,
      {bool updateUi = false}) async {
    //
    if (user == null) this.user = await Cache.get(Constants.loggedInUser);

    GetBookingsResponse response =
        await _fetchBookingsData(context, status: widget.status, page: 1);
    hasData = response.bookings.length > 0;

    if (updateUi) {
      listKey.currentState?.updateListData(response);
    }
    return response;
  }
}

Future<GetBookingsResponse> _fetchBookingsData(context,
    {required BookingStatus status, required int page}) async {
  // Fetch bookings data from server
  return await BookingService(context).getBookings(GetBookingsRequest(status, page));
}

class _ItemsList extends StatefulWidget {
  final GetBookingsResponse response;
  final BookingStatus status;

  const _ItemsList({
    required this.response,
    required this.status,
    Key? key,
  }) : super(key: key);

  @override
  _ItemsListState createState() => _ItemsListState();
}

class _ItemsListState extends State<_ItemsList> {
  late List<Booking> bookings;
  late int currentPage, maxPages;
  ScreenState screenState = ScreenState.DEFAULT;
  final ScrollController scrollController = new ScrollController();
  CancelableOperation? loadOperation;

  @override
  void initState() {
    bookings = widget.response.bookings;
    // Set pagination
    _resetPagination(widget.response.pagination);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (bookings.isEmpty) {
      return ListDataHelper.displayEmptyDataMsg(context, I18n.values(context)!.msg_bookings_empty,
          image: Assets.image.emptyBookings);
    }

    return NotificationListener(
      onNotification: onNotification,
      child: ListView.separated(
        itemCount: bookings.length + 1,
        controller: scrollController,
        physics: AlwaysScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          if (index == bookings.length) {
            // Show loading view
            if (screenState == ScreenState.LOADING)
              return Padding(
                padding: EdgeInsets.all(12),
                child: Center(
                  child: HayyakProgressIndicator(),
                ),
              );
            else
              return Container();
          } else {
            // Show list item
            return BookingItem(
              bookings[index],
              onBookingCancelled: () {
                setState(() {
                  bookings.removeAt(index);
                });
              },
            );
          }
        },
        separatorBuilder: (context, index) {
          return SizedBox(height: 16);
        },
      ),
    );
  }

  /// Called when list is scrolled to bottom
  bool onNotification(ScrollNotification notification) {
    if (!(notification is ScrollUpdateNotification)) return false;

    if (scrollController.position.maxScrollExtent > scrollController.offset &&
        scrollController.position.maxScrollExtent - scrollController.offset <= 50) {
      if (screenState != ScreenState.LOADING) {
        setState(() {
          screenState = ScreenState.LOADING;
        });

        loadOperation = CancelableOperation.fromFuture(_loadMoreData().then((value) => {
              screenState = ScreenState.SUCCESS,
              setState(() => {
                    bookings.addAll(value),
                  }),
            }));
        return true;
      }
    }
    return false;
  }

  // Get next page of data
  Future<List<Booking>> _loadMoreData() async {
    final nextPage = ++currentPage;
    // Return if max page size is reached
    if (nextPage > maxPages) return [];

    try {
      GetBookingsResponse response =
          await _fetchBookingsData(context, page: nextPage, status: widget.status);

      currentPage = nextPage;
      return response.bookings;
    } catch (e) {
      // Display error
      UiUtils.displayException(context, e);
      return [];
    }
  }

  void updateListData(GetBookingsResponse bookingsResponse) {
    setState(() {
      _resetPagination(bookingsResponse.pagination);
      this.bookings = bookingsResponse.bookings;
    });
  }

  void _resetPagination(Pagination pagination) {
    maxPages = (pagination.totalItems / pagination.pageSize).ceil();
    currentPage = 1;
  }
}
