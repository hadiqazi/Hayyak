/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 20/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/model/core/booking_status.dart';
import 'package:hayyak/view/screen/bookings_tab/bookings_list.dart';

class BookingsTab extends StatefulWidget {
  const BookingsTab({Key? key}) : super(key: key);

  @override
  _BookingsTabState createState() => _BookingsTabState();
}

class _BookingsTabState extends State<BookingsTab> with AutomaticKeepAliveClientMixin<BookingsTab> {
  //
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final theme = Theme.of(context);
    final i18n = I18n.values(context)!;

    return Padding(
      padding: Assets.dimens.screenPadding,
      child: DefaultTabController(
        length: 3,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(i18n.my_booking_title, style: theme.textTheme.headline5),
            SizedBox(height: 16),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Color(0xFFF9F9F9),
              ),
              child: TabBar(
                tabs: [
                  Tab(text: i18n.booking_active),
                  Tab(text: i18n.booking_completed),
                  Tab(text: i18n.booking_cancelled),
                ],
                indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(offset: Offset(0, 2), blurRadius: 6, color: Color(0x17000000)),
                    ]),
                indicatorPadding: EdgeInsets.all(4),
                labelColor: theme.primaryColor,
                unselectedLabelColor: Color(0xFFA6A6A6),
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: TabBarView(
                children: [
                  BookingsList(BookingStatus.ACTIVE),
                  BookingsList(BookingStatus.COMPLETED),
                  BookingsList(BookingStatus.CANCELLED),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
