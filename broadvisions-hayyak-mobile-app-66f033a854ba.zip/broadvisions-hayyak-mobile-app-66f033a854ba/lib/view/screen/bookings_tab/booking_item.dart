/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 29/12/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/booking.dart';
import 'package:hayyak/model/core/booking_property.dart';
import 'package:hayyak/view/screen/booking_cancel/cancel_booking_screen.dart';
import 'package:hayyak/view/screen/booking_details/booking_details_screen.dart';
import 'package:hayyak/view/utils/booking_utils.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/date_selection_view.dart';
import 'package:hayyak/view/widget/secondary_button.dart';

class BookingItem extends StatelessWidget {
  final Booking booking;
  final VoidCallback? onBookingCancelled;

  const BookingItem(
    this.booking, {
    this.onBookingCancelled,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;
    final i18n = I18n.values(context)!;
    final nightsCount = booking.checkOutDate.difference(booking.checkInDate).inDays;
    final cancellationAllowed = BookingUtils.canBookingBeCancelled(booking);

    // Fail check
    if (booking.property == null) booking.property = BookingProperty('', '', '');

    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Color(0x0D000000)),
        color: theme.colorScheme.surface,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Property Info
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Image
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: UiUtils.getNetworkImage(
                  imageUrl: booking.property!.coverImageUrl,
                  fit: BoxFit.cover,
                  width: 84,
                  height: 84,
                ),
              ),
              // Space
              SizedBox(width: 16),
              // Property info
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 8),
                    // Property name
                    Text(
                      booking.property!.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: textTheme.bodyText2?.copyWith(color: LightTheme.textSecondary),
                    ),
                    SizedBox(height: 8),
                    // Booking cost
                    Text(
                      UiUtils.formatPrice(context, booking.costs.total),
                      style: textTheme.bodyText2?.copyWith(color: Theme.of(context).primaryColor),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 4),
          Divider(),

          // Booking dates
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              DateSelectionCard(
                label: i18n.check_in,
                text: DateSelectionCard.formatDate(booking.checkInDate),
              ),
              SizedBox(width: 8),
              DateSelectionCard(
                label: i18n.check_out,
                text: DateSelectionCard.formatDate(booking.checkOutDate),
              ),
            ],
          ),
          SizedBox(height: 8),

          // Rooms
          ..._createInfoRow(
              context, i18n.booking_label_rooms, [booking.rooms.length.toString().padLeft(2, '0')]),

          // Price per night
          ..._createInfoRow(context, i18n.price_per_night,
              [UiUtils.formatPrice(context, booking.pricePerNight), ' x ', '$nightsCount']),

          // Services cost
          ..._createInfoRow(
              context, i18n.extra_services, [UiUtils.formatPrice(context, booking.costs.services)]),
          SizedBox(height: 8),

          // Buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Expanded(
                child: SecondaryButton(
                  child: Text(i18n.booking_action_details),
                  greyVariant: true,
                  height: 44,
                  onPressed: () {
                    UiUtils.navigateTo(
                        context: context,
                        child: BookingDetails(
                          booking,
                          onBookingCancelled: onBookingCancelled,
                        ));
                  },
                ),
              ),

              // Show cancel button only when the booking status is active
              if (cancellationAllowed) SizedBox(width: 12),
              if (cancellationAllowed)
                Expanded(
                  child: SecondaryButton(
                    child: Text(i18n.booking_action_cancel),
                    height: 44,
                    onPressed: () {
                      UiUtils.showOverlay(
                        context: context,
                        child: CancelBookingScreen(
                          booking,
                          onBookingCancelled: onBookingCancelled,
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  List<Widget> _createInfoRow(BuildContext context, String label, List<String> values,
      {bool highlight = false}) {
    //
    final List<Widget> widgets = [];
    widgets.add(SizedBox(height: 8));

    var valueStyle = Theme.of(context).textTheme.bodyText2;
    if (!highlight) valueStyle = valueStyle?.copyWith(color: Color(0xFFA6A6A6));

    final valueWidget;
    if (values.length == 1)
      valueWidget = Text(values[0], style: valueStyle);
    else
      valueWidget = Row(
        children: values.map((value) => Text(value, style: valueStyle)).toList(growable: false),
      );

    widgets.add(Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label),
        valueWidget,
      ],
    ));
    widgets.add(SizedBox(height: 8));

    return widgets;
  }
}
