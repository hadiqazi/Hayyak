/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 17/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/model/core/booking_to_rate.dart';
import 'package:hayyak/view/screen/rating/post_rating_screen.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/primary_button.dart';
import 'package:hayyak/view/widget/secondary_button.dart';

class RateBookingView {
  RateBookingView._();

  static void show(BuildContext context, BookingToRate bookingToRate) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    showDialog(
      context: context,
      builder: (context) {
        return Align(
          alignment: Alignment.center,
          child: Material(
            color: Colors.transparent,
            child: Padding(
              padding: EdgeInsets.all(32),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Theme.of(context).colorScheme.background,
                ),
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(height: 16),
                      SvgPicture.asset(Assets.image.bookingComplete),
                      SizedBox(height: 32),
                      //
                      Text(i18n.rate_last_booking_title, style: textTheme.headline6),
                      SizedBox(height: 16),
                      //
                      Text(
                        i18n.rate_last_booking_msg,
                        textAlign: TextAlign.center,
                        style: textTheme.bodyText2?.copyWith(color: LightTheme.textTertiary),
                      ),
                      SizedBox(height: 32),
                      //
                      PrimaryButton(
                        child: Text(i18n.rate_last_booking_action),
                        maxWide: true,
                        onPressed: () {
                          UiUtils.navigateTo(
                            context: context,
                            child: PostRatingScreen(booking: bookingToRate),
                            endCurrent: true,
                          );
                        },
                      ),
                      SizedBox(height: 16),
                      //
                      SecondaryButton(
                        child: Text(i18n.rate_last_booking_cancel),
                        maxWide: true,
                        onPressed: () {
                          UiUtils.navigateBack(context);
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
