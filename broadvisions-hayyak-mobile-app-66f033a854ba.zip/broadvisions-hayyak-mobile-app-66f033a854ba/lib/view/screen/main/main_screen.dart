/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 15/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/service/property_service.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/view/screen/bookings_tab/bookings_tab.dart';
import 'package:hayyak/view/screen/home_tab/home_tab.dart';
import 'package:hayyak/view/screen/main/rate_booking_view.dart';
import 'package:hayyak/view/screen/profile/profile_tab.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/widget/bottomnav/floating_bottom_nav_bar.dart';
import 'package:hayyak/view/widget/bottomnav/floating_bottom_nav_bar_item.dart';
import 'package:hayyak/view/widget/dialog_box.dart';
import 'package:hayyak/view/widget/hayyak_icons.dart';

class MainScreen extends StatefulWidget {
  final MainScreenTab? initialTab;
  final skipLookupFetching;

  const MainScreen({
    this.initialTab,
    this.skipLookupFetching = false,
    Key? key,
  }) : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  late List<Widget> _tabViews;
  late int _currentIndex;
  final _pageController = PageController();
  int lookupRetriesLeft = Constants.lookupRetriesCount;
  final homeTabKey = GlobalKey<HomeTabState>();

  @override
  void initState() {
    super.initState();

    _currentIndex = widget.initialTab?.value ?? 0;

    if (widget.initialTab != null) {
      Future.delayed(Duration(milliseconds: 100), () {
        _pageController.animateToPage(_currentIndex,
            duration: const Duration(milliseconds: 100), curve: Curves.easeInOut);
      });
    }

    _tabViews = <Widget>[
      HomeTab(key: homeTabKey),
      BookingsTab(),
      ProfileTab(),
    ];

    Future.delayed(Duration(milliseconds: 500), () {
      if (!widget.skipLookupFetching) {
        // Load lookup data
        loadLookupData();
      } else {
        // Mark data loaded as app already has lookup data
        homeTabKey.currentState?.markDataAsLoaded();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final margin = EdgeInsets.only(left: 16, right: 16, top: 16, bottom: Platform.isIOS ? 0 : 16);

    return Scaffold(
      extendBody: true,
      body: SafeArea(
        bottom: false,
        child: PageView(
          controller: _pageController,
          onPageChanged: _onTabChanged,
          children: _tabViews,
        ),
      ),
      bottomNavigationBar: FloatingBottomNavBar(
        // Decoration
        margin: margin,
        backgroundColor: colorScheme.surface,
        selectedBackgroundColor: colorScheme.primary,
        selectedItemColor: colorScheme.surface,
        unselectedItemColor: Color(0xFF4D4D4D),
        iconSize: 18,
        padding: EdgeInsets.only(bottom: 12, top: 12),
        // Content
        currentIndex: _currentIndex,
        items: [
          FloatingBottomNavbarItem(icon: HayyakIcons.home),
          FloatingBottomNavbarItem(icon: HayyakIcons.bookings),
          FloatingBottomNavbarItem(icon: HayyakIcons.profile),
        ],
        onTap: (int index) {
          if (_currentIndex == index) return;
          _pageController.animateToPage(index,
              duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
        },
      ),
    );
  }

  void _onTabChanged(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  void loadLookupData() {
    // Update the count
    lookupRetriesLeft--;

    // Load lookup data
    PropertyService(context).fetchLookupData().then((response) {
      homeTabKey.currentState?.markDataAsLoaded();

      // If there's a booking to rate, show rating view
      if (response.bookingToRate != null) {
        Future.delayed(
          Duration(seconds: 2),
          () => RateBookingView.show(context, response.bookingToRate!),
        );
      }

      //
    }).catchError((err) {
      // Retry loading data if retries are remaining
      if (lookupRetriesLeft > 0) {
        loadLookupData();
      } else {
        // Get error message
        final i18n = I18n.values(context)!;
        final String? errorMessage;

        if (err is AppException) {
          errorMessage = err.localizedMessage != null
              ? err.localizedMessage
              : err.message != null
                  ? err.message
                  : '';
        } else {
          errorMessage = (err as TypeError).toString();
        }

        // Show error dialog
        DialogBox(context).show(
          title: null,
          message: errorMessage,
          mainButton: i18n.action_retry,
          onMainButtonClick: loadLookupData,
          secondButton: i18n.action_quit_app,
          onSecondButtonClick: () {
            // Exit the app
            if (Platform.isAndroid)
              SystemChannels.platform.invokeMethod('SystemNavigator.pop');
            else
              exit(0);
          },
          isDismissible: false,
        );
      }
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }
}

enum MainScreenTab {
  HOME,
  BOOKINGS,
  PROFILE,
}

extension _MainScreenTabExt on MainScreenTab {
  int get value {
    switch (this) {
      case MainScreenTab.HOME:
        return 0;
      case MainScreenTab.BOOKINGS:
        return 1;
      case MainScreenTab.PROFILE:
        return 1;
    }
  }
}
