/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/01/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/app_colors.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/controller/service/booking_service.dart';
import 'package:hayyak/model/core/booking.dart';
import 'package:hayyak/model/core/cancellation_reason.dart';
import 'package:hayyak/model/dto/request/cancel_booking_request.dart';
import 'package:hayyak/model/dto/response/get_cancellation_cost_response.dart';
import 'package:hayyak/view/screen/booking_cancel/cancel_booking_success_dialog.dart';
import 'package:hayyak/view/utils/list_data_helper.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/utils/utils.dart';
import 'package:hayyak/view/widget/appbar_back_button.dart';
import 'package:hayyak/view/widget/hayyak_progress_indicator.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class CancelBookingScreen extends StatelessWidget {
  final Booking booking;
  final VoidCallback? onBookingCancelled;
  final bool comingFromDetails;

  const CancelBookingScreen(
    this.booking, {
    this.onBookingCancelled,
    this.comingFromDetails = false,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CancelData(
      cancelCallback: onBookingCancelled,
      comingFromDetails: comingFromDetails,
      child: Padding(
        padding: EdgeInsets.only(top: Assets.dimens.overlayTopMargin),
        child: Container(
          clipBehavior: Clip.hardEdge,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(20),
              topRight: const Radius.circular(20),
            ),
          ),
          child: Scaffold(
            backgroundColor: Colors.black54,
            appBar: AppBar(
              leading: AppBarBackButton(),
              title: Text(I18n.values(context)!.cancel_booking_title),
            ),
            body: SafeArea(
              bottom: false,
              child: Container(
                color: Theme.of(context).colorScheme.surface,
                width: double.maxFinite,
                height: double.maxFinite,
                child: FutureBuilder(
                  future: _getCancellationCost(context),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.done && snapshot.data != null)
                      return _CancellationView(
                        booking: booking,
                        cancellationCost: snapshot.data as CancellationCostResponse,
                      );
                    else if (snapshot.connectionState == ConnectionState.done &&
                        snapshot.error != null) {
                      return ListDataHelper.displayError(context, snapshot.error);
                    } else
                      return Center(child: HayyakProgressIndicator());
                  },
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<CancellationCostResponse> _getCancellationCost(BuildContext context) async {
    // Fetch booking details from server
    return await BookingService(context).getBookingCancellationCost(booking.uuid);
  }
}

class CancelData extends InheritedWidget {
  final VoidCallback? cancelCallback;
  final bool comingFromDetails;

  const CancelData({
    required this.cancelCallback,
    required this.comingFromDetails,
    required Widget child,
    Key? key,
  }) : super(child: child, key: key);

  static CancelData of(BuildContext context) {
    final CancelData? result = context.dependOnInheritedWidgetOfExactType<CancelData>();
    assert(result != null, 'No CancelData found in context');
    return result!;
  }

  @override
  bool updateShouldNotify(covariant InheritedWidget oldWidget) => true;
}

class _CancellationView extends StatelessWidget {
  final Booking booking;
  final CancellationCostResponse cancellationCost;

  const _CancellationView({
    required this.booking,
    required this.cancellationCost,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    return SingleChildScrollView(
      padding: Assets.dimens.screenPadding,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Message
          Text(i18n.cancel_booking_msg, style: textTheme.bodyText1, textAlign: TextAlign.center),
          SizedBox(height: 16),

          // Room charges
          ..._createInfoRow(
              context, i18n.room_charges, UiUtils.formatPrice(context, booking.costs.room)),
          // Extra services
          ..._createInfoRow(
              context, i18n.extra_services, UiUtils.formatPrice(context, booking.costs.services)),
          // Cancellation fee
          ..._createInfoRow(context, i18n.cancellation_fee,
              UiUtils.formatPrice(context, cancellationCost.deductionAmount),
              type: AmountType.NEGATIVE),
          Divider(),

          // Total refund amount
          ..._createInfoRow(context, i18n.total_refund,
              UiUtils.formatPrice(context, cancellationCost.refundAmount),
              type: AmountType.POSITIVE),
          SizedBox(height: 16),

          // Cancellation reason heading
          Text(i18n.cancellation_reason_heading, style: textTheme.headline6),
          SizedBox(height: 8),

          // Cancellation options
          _CancellationReasonView(booking.uuid),
        ],
      ),
    );
  }

  List<Widget> _createInfoRow(BuildContext context, String label, String text,
      {AmountType type = AmountType.DEFAULT, bool finalRow = false}) {
    //
    final List<Widget> widgets = [];
    widgets.add(SizedBox(height: 8));

    final textTheme = Theme.of(context).textTheme;
    final labelStyle = textTheme.bodyText2?.copyWith(
      color: Colors.black.withOpacity(finalRow ? 1 : 0.6),
    );
    final valueColor = type == AmountType.POSITIVE
        ? AppColors.success
        : type == AmountType.NEGATIVE
            ? AppColors.error
            : Colors.black;

    widgets.add(Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: labelStyle),
        Text(text, style: textTheme.bodyText2?.copyWith(color: valueColor)),
      ],
    ));
    widgets.add(SizedBox(height: 8));

    return widgets;
  }
}

class _CancellationReasonView extends StatefulWidget {
  final String bookingId;

  const _CancellationReasonView(this.bookingId, {Key? key}) : super(key: key);

  @override
  _CancellationReasonViewState createState() => _CancellationReasonViewState();
}

class _CancellationReasonViewState extends State<_CancellationReasonView> {
  final _formKey = GlobalKey<FormState>();
  final _reasonController = TextEditingController();
  final otherOptionValue = 'other';

  List<CancellationReason> cancellationReasons = [];
  CancellationReason? selectedReason;

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    if (cancellationReasons.isEmpty) {
      cancellationReasons = Utils.getCancellationReasons(context);
      selectedReason = cancellationReasons[0];
    }

    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Radio options
          ...createCancellationOptions(cancellationReasons),
          //
          if (selectedReason?.value == otherOptionValue)
            TextFormField(
              decoration: InputDecoration(labelText: i18n.hint_issue_detail),
              keyboardType: TextInputType.multiline,
              minLines: 1,
              maxLines: 3,
              controller: _reasonController,
              validator: (value) {
                if (selectedReason?.value == otherOptionValue && value!.trim().isEmpty)
                  return i18n.error_issue_detail_empty;
                else
                  return null;
              },
            ),

          // Margins
          if (selectedReason?.value == otherOptionValue) SizedBox(height: 8),
          SizedBox(height: 16),

          // Button
          PrimaryButton(
            child: Text(i18n.cancel_booking_action),
            maxWide: true,
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                FocusScope.of(context).unfocus();
                // Cancel booking

                final reason = selectedReason?.value == otherOptionValue
                    ? _reasonController.text.trim()
                    : selectedReason?.value;

                if (reason != null) {
                  _cancelBooking(widget.bookingId, reason);
                }
              }
            },
          ),
          SizedBox(height: 16),
        ],
      ),
    );
  }

  List<Widget> createCancellationOptions(List<CancellationReason> cancellationReasons) {
    final List<Widget> widgets = [];
    final theme = Theme.of(context);

    cancellationReasons.forEach((reason) {
      widgets.add(
        RadioListTile<CancellationReason>(
          dense: true,
          contentPadding: EdgeInsets.symmetric(horizontal: 0),
          title: Text(
            reason.text,
            style: theme.textTheme.bodyText2?.copyWith(color: LightTheme.textTertiary),
          ),
          activeColor: theme.primaryColor,
          value: reason,
          groupValue: selectedReason,
          onChanged: (CancellationReason? cReason) {
            setState(() {
              selectedReason = cReason;
            });
          },
        ),
      );
    });

    return widgets;
  }

  void _cancelBooking(String bookingId, String reason) async {
    final progress = UiUtils.createProgressDialog(
        context, I18n.values(context)!.loader_cancel_booking,
        cancelable: false);

    // Show progress dialog
    await progress.show();

    // Create request
    final request = CancelBookingRequest(bookingId, reason);

    // Send OTPs to user
    await BookingService(context) //
        .cancelBooking(request) //
        .then((response) {
      // Hide progress dialog
      progress.dismiss();

      // Retrieve data
      final comingFromDetails = CancelData.of(context).comingFromDetails;
      final cancelCallback = CancelData.of(context).cancelCallback;

      // Hide current (cancel) view
      UiUtils.navigateBack(context);

      // Show success message
      UiUtils.showOverlay(
        context: context,
        child: CancelBookingSuccessDialog(
          cancelCallback: cancelCallback,
          comingFromDetails: comingFromDetails,
        ),
      );
      //
    }).catchError((err) {
      // Hide progress dialog
      progress.dismiss();

      // Display error
      UiUtils.displayException(context, err);
    });
  }

  @override
  void dispose() {
    _reasonController.dispose();
    super.dispose();
  }
}

enum AmountType { POSITIVE, NEGATIVE, DEFAULT }
