/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 21/01/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hayyak/app/resource/assets.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/app/theme/light/light_theme.dart';
import 'package:hayyak/view/utils/ui_utils.dart';
import 'package:hayyak/view/widget/primary_button.dart';

class CancelBookingSuccessDialog extends StatelessWidget {
  final VoidCallback? cancelCallback;
  final bool comingFromDetails;

  const CancelBookingSuccessDialog({
    required this.cancelCallback,
    required this.comingFromDetails,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final i18n = I18n.values(context)!;
    final textTheme = Theme.of(context).textTheme;

    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Padding(
        padding: EdgeInsets.only(top: Assets.dimens.overlayTopMargin),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            bottom: false,
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(20),
                    topRight: const Radius.circular(20),
                  ),
                  color: Theme.of(context).colorScheme.surface,
                ),
                width: double.maxFinite,
                padding: EdgeInsets.only(top: 32, left: 48, right: 48, bottom: 32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset(Assets.image.cancelBooking, width: 80),
                    SizedBox(height: 24),
                    //
                    Text(
                      i18n.cancel_booking_success_title,
                      textAlign: TextAlign.center,
                      style: textTheme.headline6,
                    ),
                    SizedBox(height: 16),
                    //
                    Text(
                      i18n.cancel_booking_success_msg,
                      textAlign: TextAlign.center,
                      style: textTheme.bodyText1?.copyWith(color: LightTheme.textTertiary),
                    ),
                    SizedBox(height: 48),
                    //
                    PrimaryButton(
                      child: Text(i18n.cancel_booking_success_action),
                      onPressed: () {
                        UiUtils.navigateBack(context);
                        if (comingFromDetails) UiUtils.navigateBack(context);

                        // Invoke the callback
                        if (cancelCallback != null) cancelCallback!();
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
