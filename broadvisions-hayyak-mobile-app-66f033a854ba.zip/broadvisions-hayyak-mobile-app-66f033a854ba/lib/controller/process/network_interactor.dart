/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 4/28/21
            Project: flutter_foundation
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/model/network/http_method.dart';
import 'package:hayyak/model/network/web_service_header.dart';
import 'package:hayyak/view/utils/constants.dart';

import '/model/dto/request/upload_file_request.dart';
import '/model/exception/app_exception.dart';
import '/model/network/network_client.dart';
import '/view/utils/utils.dart';

class NetworkInteractor {
  final BuildContext context;

  NetworkInteractor(this.context);

  /// Send a get request on server
  Future sendGetRequest(String url) async {
    try {
      final header = await _getCommonHeader();
      return await NetworkClient().sendGetRequest(url, header: header);
    } on AppException catch (e) {
      debugPrint('*EXCEPTION*: $e');
      throw (Utils.processException(e, context));
    } catch (e) {
      debugPrint('*EXCEPTION*: $e');
      if (e is Exception)
        throw (AppException.exception(e));
      else if (e is Error) throw AppException.message(e.toString());
    }
  }

  /// Sends a 'post' request on server
  Future sendPostRequest(String url, String data) async {
    return _sendRequest(HttpMethod.POST, url, data);
  }

  /// Sends a 'patch' request on server
  Future sendPatchRequest(String url, String data) async {
    return _sendRequest(HttpMethod.PATCH, url, data);
  }

  /// Sends a 'put request on server
  Future sendPutRequest(String url, String data) async {
    return _sendRequest(HttpMethod.PUT, url, data);
  }

  /// Sends request on server with provided http method
  Future _sendRequest(HttpMethod httpMethod, String url, String data) async {
    try {
      final header = await _getCommonHeader();
      return await NetworkClient().sendRequest(httpMethod, url, data, header: header);
    } on AppException catch (e) {
      debugPrint('*EXCEPTION*: $e');
      throw (Utils.processException(e, context));
    } catch (e) {
      debugPrint('*EXCEPTION*: $e');
      if (e is Exception)
        throw (AppException.exception(e));
      else if (e is Error) throw AppException.message(e.toString());
    }
  }

  /// Sends a 'post' request on server containing multipart data
  Future sendMultipartPostRequest(
      String url, Map<String, dynamic> data, UploadFilesRequest files) async {
    return _sendMultipartRequest(HttpMethod.POST, url, data, files);
  }

  /// Sends a 'put' request on server containing multipart data
  Future sendMultipartPutRequest(
      String url, Map<String, dynamic> data, UploadFilesRequest files) async {
    return _sendMultipartRequest(HttpMethod.PUT, url, data, files);
  }

  /// Sends a multipart request on server with provided http method
  Future _sendMultipartRequest(HttpMethod httpMethod, String url, Map<String, dynamic> data,
      UploadFilesRequest files) async {
    try {
      final header = await _getCommonHeader();
      return await NetworkClient()
          .sendMultipartRequest(httpMethod, url, data, files, header: header);
      //
    } on AppException catch (e) {
      debugPrint('*EXCEPTION*: $e');
      throw (Utils.processException(e, context));
    } catch (e) {
      debugPrint('*EXCEPTION*: $e');
      if (e is Exception)
        throw (AppException.exception(e));
      else if (e is Error) throw AppException.message(e.toString());
    }
  }

  /// Sends a 'delete' request on server
  Future sendDeleteRequest(String url) async {
    try {
      final header = await _getCommonHeader();
      return await NetworkClient().sendDeleteRequest(url, header: header);
    } on AppException catch (e) {
      debugPrint('*EXCEPTION*: $e');
      throw (Utils.processException(e, context));
    } catch (e) {
      debugPrint('*EXCEPTION*: $e');
      if (e is Exception)
        throw (AppException.exception(e));
      else if (e is Error) throw AppException.message(e.toString());
    }
  }

  /// Creates a header and puts all the common header fields in it
  Future<WebServiceHeader> _getCommonHeader() async {
    final header = WebServiceHeader();

    final sessionToken = await Cache.get(Constants.sessionToken);
    header.setSessionId(sessionToken);

    String language = Utils.getCurrentLanguage(context);
    header.setLanguage(language);

    return header;
  }
}
