/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 07/02/2022
            Project: hayyak-mobile-app
 */

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/process/network_interactor.dart';
import 'package:hayyak/controller/service/base_service.dart';
import 'package:hayyak/model/core/file_to_upload.dart';
import 'package:hayyak/model/dto/request/change_password_request.dart';
import 'package:hayyak/model/dto/request/reset_password_request.dart';
import 'package:hayyak/model/dto/request/update_profile_request.dart';
import 'package:hayyak/model/dto/request/upload_file_request.dart';
import 'package:hayyak/model/dto/response/base_response.dart';
import 'package:hayyak/model/dto/response/update_profile_response.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/model/network/network_response.dart';
import 'package:hayyak/model/network/response_code.dart';
import 'package:hayyak/model/network/web_services.dart';

class UserService extends BaseService {
  final BuildContext context;

  UserService(this.context);

  Future<UpdateProfileResponse> updateProfile(UpdateProfileRequest request) async {
    // Send request on server
    final String url = WebServices.UPDATE_PROFILE.replaceFirst('##', request.userId);

    final List<FileToUpload> files = [];
    if (request.image != null) files.add(request.image!);
    final fileRequest = UploadFilesRequest(files, parameterName: request.imageParamName);

    NetworkResponse networkResponse = await NetworkInteractor(context)
        .sendMultipartPutRequest(url, request.toJson(), fileRequest);

    // Decode and return the response
    try {
      return UpdateProfileResponse.fromJson(jsonDecode(networkResponse.body));
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<BaseResponse> updatePassword(ChangePasswordRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());
    NetworkResponse networkResponse;
    try {
      networkResponse = await NetworkInteractor(context)
          .sendPostRequest(WebServices.UPDATE_PASSWORD, requestJson);
      //
    } on AppException catch (e) {
      // Update the localized message if provided current-password is invalid
      if (e.errorCode == ResponseCode.HTTP_UNAUTHORIZED) {
        e.localizedMessage = I18n.values(context)!.error_wrong_password;
      }
      throw e;
    }

    // Decode and return the response
    try {
      return BaseResponse.fromJson(jsonDecode(networkResponse.body));
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<BaseResponse> resetPassword(ResetPasswordRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());
    NetworkResponse networkResponse;
    try {
      networkResponse =
          await NetworkInteractor(context).sendPostRequest(WebServices.RESET_PASSWORD, requestJson);
      //
    } on AppException catch (e) {
      // Update the localized message if provided email doesn't exist
      if (e.errorCode == ResponseCode.HTTP_BAD_REQUEST) {
        e.localizedMessage = I18n.values(context)!.reset_pwd_email_error;
      }
      throw e;
    }

    // Decode and return the response
    try {
      return BaseResponse.fromJson(jsonDecode(networkResponse.body));
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }
}
