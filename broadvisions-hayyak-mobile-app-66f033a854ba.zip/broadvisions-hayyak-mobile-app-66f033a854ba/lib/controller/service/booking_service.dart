/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/process/network_interactor.dart';
import 'package:hayyak/controller/service/base_service.dart';
import 'package:hayyak/model/dto/request/cancel_booking_request.dart';
import 'package:hayyak/model/dto/request/get_booking_details_request.dart';
import 'package:hayyak/model/dto/request/get_bookings_request.dart';
import 'package:hayyak/model/dto/request/make_booking_request.dart';
import 'package:hayyak/model/dto/response/base_response.dart';
import 'package:hayyak/model/dto/response/get_booking_details_response.dart';
import 'package:hayyak/model/dto/response/get_bookings_response.dart';
import 'package:hayyak/model/dto/response/get_cancellation_cost_response.dart';
import 'package:hayyak/model/dto/response/make_booking_response.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/model/network/network_response.dart';
import 'package:hayyak/model/network/response_code.dart';
import 'package:hayyak/model/network/web_services.dart';

class BookingService extends BaseService {
  final BuildContext context;

  BookingService(this.context);

  Future<MakeBookingResponse> makeBooking(MakeBookingRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());

    NetworkResponse networkResponse;
    try {
      networkResponse =
          await NetworkInteractor(context).sendPostRequest(WebServices.MAKE_BOOKING, requestJson);
    } on AppException catch (e) {
      if (e.errorCode == ResponseCode.HTTP_NOT_FOUND) {
        e.localizedMessage = I18n.values(context)!.error_rooms_unavailable;
      }
      throw e;
    }

    // Decode and return the response
    try {
      return MakeBookingResponse.fromJson(jsonDecode(networkResponse.body));
      //
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<GetBookingsResponse> getBookings(GetBookingsRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());
    final String url = WebServices.LIST_BOOKINGS.replaceFirst('##', request.pageNum.toString());

    NetworkResponse networkResponse =
        await NetworkInteractor(context).sendPostRequest(url, requestJson);

    // Decode and return the response
    try {
      return GetBookingsResponse.fromJson(jsonDecode(networkResponse.body));
      //
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<GetBookingDetailsResponse> getBookingDetails(GetBookingDetailsRequest request) async {
    // Send request on server
    final String url = WebServices.GET_BOOKING_DETAILS.replaceFirst('##', request.bookingId);

    NetworkResponse networkResponse = await NetworkInteractor(context).sendGetRequest(url);

    // Decode and return the response
    try {
      return GetBookingDetailsResponse.fromJson(jsonDecode(networkResponse.body));
      //
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<CancellationCostResponse> getBookingCancellationCost(String bookingId) async {
    // Send request on server
    final String url = WebServices.GET_BOOKING_CANCEL_COST.replaceFirst('##', bookingId);

    NetworkResponse networkResponse = await NetworkInteractor(context).sendGetRequest(url);

    // Decode and return the response
    try {
      return CancellationCostResponse.fromJson(jsonDecode(networkResponse.body));
      //
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<BaseResponse> cancelBooking(CancelBookingRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());
    final String url = WebServices.CANCEL_BOOKING.replaceFirst('##', request.bookingId);

    NetworkResponse networkResponse =
        await NetworkInteractor(context).sendPatchRequest(url, requestJson);

    // Decode and return the response
    try {
      return BaseResponse.fromJson(jsonDecode(networkResponse.body));
      //
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }
}
