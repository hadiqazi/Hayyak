/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 22/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/controller/auth/apple_auth_handler.dart';
import 'package:hayyak/controller/auth/facebook_auth_handler.dart';
import 'package:hayyak/controller/auth/google_auth_handler.dart';
import 'package:hayyak/controller/service/base_service.dart';
import 'package:hayyak/model/core/social_signup_info.dart';

class SocialAuthService extends BaseService {
  final BuildContext context;

  SocialAuthService(this.context);

  Future<SocialSignUpInfo> loginWithGoogle() async {
    return GoogleAuthHandler(context).signIn();
  }

  void logoutFromGoogle() async {
    GoogleAuthHandler(context).signOut();
  }

  Future<SocialSignUpInfo> loginWithFacebook() async {
    return FacebookAuthHandler(context).signIn();
  }

  void logoutFromFacebook() async {
    FacebookAuthHandler(context).signOut();
  }

  Future<SocialSignUpInfo> loginWithApple() async {
    return AppleAuthHandler(context).signIn();
  }

  void logoutFromApple() async {
    AppleAuthHandler(context).signOut();
  }
}
