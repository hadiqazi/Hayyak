/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 12/11/2021
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/model/network/response_code.dart';
import 'package:hayyak/view/utils/utils.dart';

abstract class BaseService {
  AppException generateParsingException(BuildContext context, Object e) {
    AppException e = AppException.errorCode(ResponseCode.HTTP_INVALID_RESPONSE);
    return Utils.processException(e, context);
  }
}
