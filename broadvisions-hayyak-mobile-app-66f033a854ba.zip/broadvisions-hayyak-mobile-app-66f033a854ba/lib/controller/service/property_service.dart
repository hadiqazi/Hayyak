/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 18/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/controller/process/network_interactor.dart';
import 'package:hayyak/controller/service/base_service.dart';
import 'package:hayyak/model/dto/request/get_ratings_request.dart';
import 'package:hayyak/model/dto/request/rate_property_request.dart';
import 'package:hayyak/model/dto/request/search_properties_request.dart';
import 'package:hayyak/model/dto/request/update_rating_request.dart';
import 'package:hayyak/model/dto/response/get_amenities_response.dart';
import 'package:hayyak/model/dto/response/get_ratings_response.dart';
import 'package:hayyak/model/dto/response/get_services_response.dart';
import 'package:hayyak/model/dto/response/lookup_response.dart';
import 'package:hayyak/model/dto/response/rate_property_response.dart';
import 'package:hayyak/model/dto/response/search_properties_response.dart';
import 'package:hayyak/model/network/network_response.dart';
import 'package:hayyak/model/network/web_services.dart';
import 'package:hayyak/view/utils/constants.dart';

class PropertyService extends BaseService {
  final BuildContext context;

  PropertyService(this.context);

  Future<LookupResponse> fetchLookupData() async {
    // Send request on server
    final String url = WebServices.LOOKUP;
    NetworkResponse networkResponse = await NetworkInteractor(context).sendGetRequest(url);

    // Decode and return the response
    try {
      final response = LookupResponse.fromJson(jsonDecode(networkResponse.body));

      // Save data in cache
      Cache.put(Constants.lookupData, response);

      return response;
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<SearchPropertiesResponse> searchProperties(
      SearchPropertiesRequest request, int pageNumber) async {
    //
    final String url = WebServices.SEARCH_PROPERTIES.replaceFirst('##', pageNumber.toString());
    // Send request on server
    String requestJson = jsonEncode(request.toJson());
    NetworkResponse networkResponse =
        await NetworkInteractor(context).sendPostRequest(url, requestJson);

    // Decode and return the response
    try {
      final response = SearchPropertiesResponse.fromJson(jsonDecode(networkResponse.body));
      if (response.properties == null) {
        response.properties = [];
      }
      return response;
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<GetServicesResponse> getValueAddedServices() async {
    // Send request on server
    final String url = WebServices.GET_SERVICES;
    NetworkResponse networkResponse = await NetworkInteractor(context).sendGetRequest(url);

    // Decode and return the response
    try {
      return GetServicesResponse.fromJson(jsonDecode(networkResponse.body));
      //
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<GetAmenitiesResponse> getAmenities() async {
    // Send request on server
    final String url = WebServices.GET_AMENITIES;
    NetworkResponse networkResponse = await NetworkInteractor(context).sendGetRequest(url);

    // Decode and return the response
    try {
      return GetAmenitiesResponse.fromJson(jsonDecode(networkResponse.body));
      //
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<GetRatingsResponse> getRatings(GetRatingsRequest request) async {
    final String url = WebServices.GET_RATINGS.replaceFirst('##', request.pageNum.toString());
    // Send request on server
    String requestJson = jsonEncode(request.toJson());
    NetworkResponse networkResponse =
        await NetworkInteractor(context).sendPostRequest(url, requestJson);

    // Decode and return the response
    try {
      return GetRatingsResponse.fromJson(jsonDecode(networkResponse.body));
      //
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<RatePropertyResponse> rateProperty(RatePropertyRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());
    NetworkResponse networkResponse =
        await NetworkInteractor(context).sendPostRequest(WebServices.RATE_PROPERTY, requestJson);

    // Decode and return the response
    try {
      return RatePropertyResponse.fromJson(jsonDecode(networkResponse.body));
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<RatePropertyResponse> updatePropertyRating(UpdateRatingRequest request) async {
    final String url = WebServices.UPDATE_RATING.replaceFirst('##', request.ratingId);
    // Send request on server
    String requestJson = jsonEncode(request.toJson());
    NetworkResponse networkResponse =
        await NetworkInteractor(context).sendPutRequest(url, requestJson);

    // Decode and return the response
    try {
      return RatePropertyResponse.fromJson(jsonDecode(networkResponse.body));
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }
}
