/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 12/11/2021
            Project: hayyak-mobile-app
 */

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hayyak/app/cache/cache.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/auth/facebook_auth_handler.dart';
import 'package:hayyak/controller/auth/google_auth_handler.dart';
import 'package:hayyak/controller/service/base_service.dart';
import 'package:hayyak/model/core/social_type.dart';
import 'package:hayyak/model/core/user.dart';
import 'package:hayyak/model/dto/request/get_otp_request.dart';
import 'package:hayyak/model/dto/request/login_request.dart';
import 'package:hayyak/model/dto/request/register_request.dart';
import 'package:hayyak/model/dto/request/social_login_request.dart';
import 'package:hayyak/model/dto/request/social_signup_request.dart';
import 'package:hayyak/model/dto/response/authentication_response.dart';
import 'package:hayyak/model/dto/response/base_response.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/model/network/response_code.dart';
import 'package:hayyak/view/utils/constants.dart';
import 'package:hayyak/view/utils/utils.dart';

import '/controller/process/network_interactor.dart';
import '/model/network/network_response.dart';
import '/model/network/web_services.dart';

class AuthenticationService extends BaseService {
  final BuildContext context;

  AuthenticationService(this.context);

  Future<BaseResponse> requestOTP(GetOTPRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());
    NetworkResponse networkResponse;
    try {
      networkResponse =
          await NetworkInteractor(context).sendPostRequest(WebServices.REQUEST_OTP, requestJson);
      //
    } on AppException catch (e) {
      // Update the localized message if user already exists
      if (e.errorCode == ResponseCode.CONFLICT) {
        e.localizedMessage = I18n.values(context)!.error_user_already_exists;
      }
      throw e;
    }

    // Decode and return the response
    try {
      return BaseResponse.fromJson(jsonDecode(networkResponse.body));
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<AuthenticationResponse> registerUser(RegisterRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());

    NetworkResponse networkResponse;
    try {
      networkResponse =
          await NetworkInteractor(context).sendPostRequest(WebServices.REGISTER, requestJson);
      //
    } on AppException catch (e) {
      final i18n = I18n.values(context)!;
      // Update the localized message if OTP is invalid or user already exists
      if (e.message == ResponseCode.INVALID_OTP) {
        e.localizedMessage = i18n.error_otp_incorrect;
      } else if (e.errorCode == ResponseCode.CONFLICT) {
        e.localizedMessage = i18n.error_user_already_exists;
      }
      throw e;
    }

    // Decode and return the response
    return await _processLogin(networkResponse.body);
  }

  Future<AuthenticationResponse> login(LoginRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());

    NetworkResponse networkResponse;
    try {
      networkResponse =
          await NetworkInteractor(context).sendPostRequest(WebServices.LOGIN, requestJson);
      //
    } on AppException catch (e) {
      // Update the localized message if credentials are invalid
      if (e.errorCode == ResponseCode.HTTP_UNAUTHORIZED) {
        e.localizedMessage = I18n.values(context)?.error_invalid_credentials;
      }
      throw e;
    }

    // Decode and return the response
    return await _processLogin(networkResponse.body);
  }

  Future<AuthenticationResponse> _processLogin(String data) async {
    try {
      final response = AuthenticationResponse.fromJson(jsonDecode(data));

      // Save token and user details
      Utils.saveUserLoginInfo(response.sessionToken, response.user);

      return response;
    } catch (e) {
      throw generateParsingException(context, e);
    }
  }

  Future<AuthenticationResponse> socialLogin(SocialLoginRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());

    NetworkResponse networkResponse;
    try {
      networkResponse =
          await NetworkInteractor(context).sendPostRequest(WebServices.SOCIAL_LOGIN, requestJson);
      //
    } on AppException catch (e) {
      // Update the localized message if user's credentials already exist in system
      if (e.errorCode == ResponseCode.SOCIAL_USER_CONFLICT) {
        e.localizedMessage = I18n.values(context)?.error_social_login_conflict;
      }
      throw e;
    }

    // Decode and return the response
    return await _processLogin(networkResponse.body);
  }

  Future<AuthenticationResponse> socialSignup(SocialSignupRequest request) async {
    // Send request on server
    String requestJson = jsonEncode(request.toJson());

    NetworkResponse networkResponse;
    try {
      networkResponse =
          await NetworkInteractor(context).sendPostRequest(WebServices.SOCIAL_SIGNUP, requestJson);
      //
    } on AppException catch (e) {
      final i18n = I18n.values(context)!;
      // Update the localized message if OTP is invalid or user already exists
      if (e.message == ResponseCode.INVALID_OTP) {
        e.localizedMessage = i18n.error_otp_incorrect;
      } else if (e.errorCode == ResponseCode.CONFLICT) {
        e.localizedMessage = i18n.error_user_already_exists;
      } else if (e.errorCode == ResponseCode.SOCIAL_USER_CONFLICT) {
        e.localizedMessage = I18n.values(context)?.error_social_login_conflict;
      }
      throw e;
    }

    // Decode and return the response
    return await _processLogin(networkResponse.body);
  }

  void logout() async {
    // Logout user from social account
    final user = await Cache.get(Constants.loggedInUser) as User;
    if (user.accountType == SocialType.FACEBOOK) {
      FacebookAuthHandler(context).signOut();
    } else if (user.accountType == SocialType.GOOGLE) {
      GoogleAuthHandler(context).signOut();
    }

    // Remove token and user details from cache
    Utils.clearUserLoginInfo();
  }
}
