/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 23/02/2022
            Project: hayyak-mobile-app
 */

import 'package:hayyak/model/core/social_signup_info.dart';

abstract class SocialAuthentication {
  //
  Future<SocialSignUpInfo> signIn();

  void signOut();
}
