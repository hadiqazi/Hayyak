/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 22/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/auth/social_auth.dart';
import 'package:hayyak/model/core/social_signup_info.dart';
import 'package:hayyak/model/core/social_type.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/model/network/response_code.dart';

class FacebookAuthHandler implements SocialAuthentication {
  late BuildContext context;

  FacebookAuthHandler(this.context);

  @override
  Future<SocialSignUpInfo> signIn() async {
    // Try to get access token for returning users
    AccessToken? accessToken = await FacebookAuth.instance.accessToken;

    if (accessToken == null) {
      // User not logged in, or re-login required
      final LoginResult result = await FacebookAuth.instance.login();

      if (result.status == LoginStatus.success && result.accessToken != null) {
        accessToken = result.accessToken;
      } else {
        // Throw exception if login fails
        throw AppException(
            ResponseCode.SOCIAL_LOGIN_ERROR, I18n.values(context)!.error_social_login);
      }
    }

    // Fetch user data
    final userData = await FacebookAuth.instance.getUserData();

    // return data
    return new SocialSignUpInfo(
      type: SocialType.FACEBOOK,
      token: accessToken!.token,
      name: userData['name'],
      email: userData['email'],
      profilePicUrl: userData['picture']?['data']?['url'],
    );
  }

  @override
  void signOut() => FacebookAuth.instance.logOut();
}
