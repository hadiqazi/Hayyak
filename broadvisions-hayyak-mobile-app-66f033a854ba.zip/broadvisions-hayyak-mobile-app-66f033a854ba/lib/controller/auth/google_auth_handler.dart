/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 22/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/auth/social_auth.dart';
import 'package:hayyak/model/core/social_signup_info.dart';
import 'package:hayyak/model/core/social_type.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/model/network/response_code.dart';

class GoogleAuthHandler implements SocialAuthentication {
  BuildContext context;
  late GoogleSignIn _googleSignIn;

  GoogleAuthHandler(this.context) {
    // Create the Google object
    _googleSignIn = GoogleSignIn(
      scopes: ['email'],
    );
  }

  @override
  Future<SocialSignUpInfo> signIn() async {
    // Try to log-in for returning users
    GoogleSignInAccount? account = await _googleSignIn.signInSilently();

    if (account == null) {
      // User not logged in, or re-login required
      account = await _handleSignIn();
    }

    final exception =
        AppException(ResponseCode.SOCIAL_LOGIN_ERROR, I18n.values(context)!.error_social_login);

    if (account == null) {
      // Throw exception if login fails
      throw exception;
    }

    // Fetch the token from account
    final authInfo = await account.authentication;

    if (authInfo.accessToken == null) {
      // Throw exception if token is null
      throw exception;
    }

    // Return data
    return new SocialSignUpInfo(
      type: SocialType.GOOGLE,
      token: authInfo.accessToken!,
      name: account.displayName,
      email: account.email,
      profilePicUrl: account.photoUrl,
    );
  }

  Future<GoogleSignInAccount?> _handleSignIn() async {
    try {
      return _googleSignIn.signIn();
      //
    } catch (error) {
      debugPrint(error.toString());
      return null;
    }
  }

  @override
  void signOut() => _googleSignIn.disconnect();
}
