/*
    @author Muhammad Umair
            Author Email: umair@broadvisions.net
            Created On: 24/02/2022
            Project: hayyak-mobile-app
 */

import 'package:flutter/material.dart';
import 'package:hayyak/app/resource/i18n.dart';
import 'package:hayyak/controller/auth/social_auth.dart';
import 'package:hayyak/model/core/social_signup_info.dart';
import 'package:hayyak/model/core/social_type.dart';
import 'package:hayyak/model/exception/app_exception.dart';
import 'package:hayyak/model/network/response_code.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

class AppleAuthHandler implements SocialAuthentication {
  late BuildContext context;

  AppleAuthHandler(this.context);

  @override
  Future<SocialSignUpInfo> signIn() async {
    try {
      // Login through Apple
      final credential = await SignInWithApple.getAppleIDCredential(scopes: [
        AppleIDAuthorizationScopes.email,
        AppleIDAuthorizationScopes.fullName,
      ]);

      // return data
      return new SocialSignUpInfo(
        type: SocialType.APPLE,
        token: credential.authorizationCode,
        name: ((credential.givenName ?? '') + ' ' + (credential.familyName ?? '')).trim(),
        email: credential.email,
      );
      //
    } catch (e) {
      // Throw exception if anything goes wrong
      debugPrint(e.toString());
      throw AppException(ResponseCode.SOCIAL_LOGIN_ERROR, I18n.values(context)!.error_social_login);
    }
  }

  @override
  void signOut() => {};
}
